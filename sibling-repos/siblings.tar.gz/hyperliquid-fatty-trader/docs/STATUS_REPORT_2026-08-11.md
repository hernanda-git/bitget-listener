# Status Report — hyperliquid-fatty-trader (VPS "Sera")

**Date:** 2026-08-11
**Repo:** hyperliquid-fatty-trader (Hyperliquid USDC perps signal-execution bot)
**Verdict:** Bot is structurally complete and correct, but **cannot place live orders** — blocked by a server-side Hyperliquid `422` on the `order` action.

---

## 1. Can it trade now? — NO

Every attempt to place an order returns:

```
HTTP 422
Failed to deserialize the JSON body into the target type
```

This is a **server-side rejection of the `order` action** on Hyperliquid mainnet.
It is not a bug in the bot's code.

---

## 2. Root-cause isolation (verified this session)

| Component | Result |
|---|---|
| `/exchange` connectivity | PASS |
| Wallet / authentication | PASS |
| Signature generation + recovery | PASS (recovers to `0x7030…4A81`) |
| Official SDK `noop` (mainnet) | **HTTP 200** |
| Official SDK `order` (mainnet) | **HTTP 422** |
| Custom adapter `order` (mainnet) | **HTTP 422** |
| Asset symbol vs index | ruled out |
| Buy/sell bool vs string | ruled out |
| `vaultAddress` / `expiresAfter` | ruled out |
| IOC vs GTC | ruled out |
| Price `0` vs `3.1` | ruled out |

**The discriminator:** `noop` (identical envelope + signing + auth) returns HTTP
200; `order` returns 422 — via both the custom adapter **and** the official
`hyperliquid-python-sdk` 0.24.0 (PyPI latest; GitHub `master` produces the same
wire format). The failure is specific to the `order` action and originates on
Hyperliquid's side.

We do **not** assert "HL changed its schema" as an absolute fact — there is no
official announcement and no currently-working client request captured. But the
practical threshold for further client-side permutation is crossed: continuing
to rewrite `a` / `b` / `p` / `t` / `v` / `chainId` / `vaultAddress` / `expiresAfter`
is no longer justified.

The correct next question is upstream/API:
> What does Hyperliquid's server expect for `action.type = "order"` today that the
> official 0.24.0 SDK (and our adapter, which matches it) is not providing?

---

## 3. What was actually fixed (real improvements, correct regardless of the wall)

- **Asset-index serialization.** `_hl_order` now sends HL's integer asset index
  (e.g. BTC = `0`, resolved from `meta`), not the symbol string `"BTC"`. The old
  form was a latent 422 that would have persisted even after the wall lifts.
- **Envelope parity.** `_post_exchange` includes `"vaultAddress": null,
  "expiresAfter": null`, matching the official SDK.
- **Min-notional-aware sizing.** `RiskManager.compute_size(min_notional_usd=…)`
  bumps small orders up to HL's per-coin floor and raises leverage to fit free
  margin (authorized leverage bump for min-notional perps).
- **Maker-limit entries.** Entry limit orders are post-only (`tif: Alo`) to earn
  the maker rebate; SL/TP are reduce-only triggers.
- **Dead-man's-switch.** `set_scheduled_cancel(24)` is armed on live (non-dry)
  startup so stale orders auto-cancel if the bot dies.
- **Per-pair min-notional store.** All 232 perp pairs are recorded in the
  Postgres table `hl_pair_min_notional` (`src/store/min_notional.py`,
  populated by `scripts/refresh_pair_min_notional.py`). `OrderService.min_notional_for()`
  reads the DB floor, falling back to `risk.cfg.min_notional_usd`.

---

## 4. Verified live state

- **Git:** HEAD `afe7a83`, IN_SYNC with `origin/main`. `.env` untracked.
- **Tests:** 130 passed (no network).
- **Bot process:** pid `485766` (`--bot fatty-main`), live (`paper=False`).
- **Wallet:** **9.9 USDC** spot, **0 positions**, **0 fills**.
  - Read via `info({'type':'spotClearinghouseState','user':…})` → USDC `total`.
  - Note: `clearinghouseState.spot` is now `None` (field shape changed); use
    `spotClearinghouseState` for balances.
- **Drift monitor:** `scripts/hl_api_probe.py` (daily cron 06:00 → Telegram)
  pings the moment `order` stops 422ing.

---

## 5. Per-pair minimums (stored in DB)

HL does **not** expose a per-asset `minTradeNtl` via any public `info` endpoint.
The stored floor is the documented default (**$10 for majors**);
`is_floor_from_api = FALSE` for these rows and can be overridden per coin when
HL publishes the true value.

Sampled rows (live, 2026-08-11):

| Coin | idx | szDec | maxLev | mid | step notional | floor |
|---|---|---|---|---|---|---|
| BTC | 0 | 5 | 40 | 64170 | $0.64 | $10 |
| ETH | 1 | 4 | 25 | 1879 | $0.19 | $10 |
| SOL | 5 | 2 | 20 | 75.8 | $0.76 | $10 |
| DOGE | 12 | 0 | 10 | 0.07 | $0.07 | $10 |
| XRP | 25 | 0 | 20 | 1.01 | $1.01 | $10 |
| kPEPE | 15 | 0 | 10 | 0.0029 | $0.003 | $10 |

Zero-`szDecimals` coins (DOGE/XRP/kPEPE) trade in whole units, so the $10 floor
is cleared by 10–150 coins, not fractions.

---

## 6. Cloning a bot — gotcha (verified)

`scripts/configure_bot.py` writes **`data/config.db` (SQLite)**, but the boot path
and `ConfigStore` read **Postgres `fatty_config`**. These are two different stores.
The live `fatty-main` row lives in Postgres. A clone created only via
`configure_bot.py` would land in SQLite and the running bot would not see it
unless the deploy also reads that SQLite.

**Before calling a clone live:**
1. Read the bots table from the store the deploy actually boots from
   (Postgres `fatty_config` `bots` table, or `data/config.db` — check
   `src/config/db.py` first).
2. Give the clone its **own TG bot token** (exactly one listener per token).
3. Add the row to the matching store.
4. Start it: `python3 -m src.main --bot <newname>`.
5. Confirm one process per token: `pgrep -f 'src.main --bot'`.

---

## 7. What unblocks live trading

Only Hyperliquid stopping the `order`-action rejection. No code change on our side
can fix it. When the daily monitor pings, run real verification (incremental,
capped, flatten) before any live money moves.

---

## 8. Raw artifacts for upstream investigation

Full request/response captures and the diagnostic matrix are in
[`docs/HL_API_422_RAW.md`](./HL_API_422_RAW.md).
