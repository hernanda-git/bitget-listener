# Setup & Recommendations — hyperliquid-fatty-trader

Working record of how this bot is configured, what was decided, and the
recommendations made along the way. NO secrets here — keys live only in `.env`
(git-ignored).

## Wallet & funds (as of 2026-08-09)
- Bot trading wallet: `<BOT_WALLET_ADDRESS>` (redacted in public repo; on-chain address is public regardless)
  (freshly generated for the bot; separate from the user's personal Rabby wallet).
- Personal Rabby wallet was emptied (private key had been pasted in chat — treat as
  COMPROMISED, rotate it).
- Bot wallet holds ~9.9 USDC inside Hyperliquid (spot, usable as unified perps
  margin). ~0.004 USDC dust remains on Arbitrum.

## Live-trading config (current)
| Setting | Value | Source / note |
|---|---|---|
| `dry_run` | `false` | `config.yaml` |
| `hyperliquid.testnet` | `false` (mainnet) | `config.yaml` |
| `HL_TESTNET` env | removed | `.env` |
| `default_leverage` | `3` | orchestrator `RiskManager(RiskConfig())` — hardcoded, NOT read from yaml |
| `default_margin_usd` | `1.0` | same — hardcoded in `RiskManager` |
| `min_confidence` | `0.5` | `config.yaml` |
| `max_portfolio_usd` | `1000.0` | `config.yaml` (not a real cap at this balance) |

Per-trade sizing (verified in code):
- Margin = **$1.00**, leverage = **3x**, notional = **$3.00** per trade.
- Even if a @fattyfatclub signal says "lev 20", `compute_size` caps effective
  leverage at `min(default_leverage=3, signal_leverage)` → still 3x.
- The `default_margin_usd` / `default_leverage` in `config.yaml` are NOT wired
  into the orchestrator's `RiskManager` — it uses its own `RiskConfig()` defaults.
  So "keep the default" is genuinely enforced at $1 / 3x.

## Go-live procedure (the human switch)
The bot runs in dry-run internally until a Telegram command flips it. Two steps:
1. Launch with `--go-live`: `python3 -m src.main --dashboard --go-live`
   - Prints a one-time token to the console, e.g. `send /live 5b7491e5 ...`.
2. From the bot chat (@val_unknown_trader_bot) send `/live <token>`.
   - Bot flips to live, replies confirming. Send `/paper` to revert instantly.

Without BOTH steps, no real orders fire. This is the safety rail.

## Telegram dashboard
- Bot username: `@val_unknown_trader_bot` (bot token in `.env` as `TG_BOT_TOKEN`).
- First time you message it, it learns your chat id automatically.
- Commands: `/start /help /status /balance /positions /signals /last /test /live /paper`.
- `/test` fires sample alerts so you can confirm the alert path is live.
- Slash commands backed by `src/notifier/bot.py` (python-telegram-bot).
- Event alerts wired into `orchestrator.py`: new signal, parse reject (normalize/
  validate), dry-run + live order placed, position opened, management action,
  TP/SL hit, and any top-level exception.

## Run modes (main.py)
- `--dashboard` : run with the bot dashboard (dry-run unless `--go-live`).
- `--dashboard --go-live` : permit `/live` to flip real trading (requires token).
- `--live-dry` : old mode, dry-run telemetry only.
- `--check-tg` : verify Telegram session + channel reach.
- `--transfer --amount X --to-perp/--confirm` : Spot<->Perp USDC transfer,
  gated (dry-run unless `--confirm` + mainnet).

## Recommendations made (for future reference)
1. **Rotate the leaked Rabby key.** It was pasted in chat — considered burned.
   Personal funds were moved off it before going live.
2. **Keep margin small (default $1 / 3x).** Appropriate for a ~9.9 USDC account;
   avoids blowing the account on one bad signal. User confirmed: keep default,
   do not raise.
3. **Always use the two-step go-live** (`--go-live` token + `/live` command) so
   no real order fires without an explicit human action in the chat you watch.
4. **SL is mandatory.** Validator rejects trades whose SL is on the wrong side of
   entry; the bot refuses to open unhedged positions. Good.
5. **Watch `/status` and `/balance` after each trade.** At $3 notional per trade,
   9.9 USDC supports ~3 concurrent positions at 3x before margin gets tight.
6. **The bot wallet key lives in `.env` and is git-ignored.** Never commit it;
   if it ever leaks, regenerate a fresh wallet and move funds (done once already).
7. **Testnet verification first.** Before any mainnet flip, run the offline
   `scripts/verify_dashboard.py` (see repo) to confirm the notifier + command
   path works without touching funds.

## Known gaps / future work
- Orchestrator `RiskManager` ignores `config.yaml` risk values — if you later
  want to size from yaml, wire `RiskConfig` from `AppConfig.risk`.
- No automated rebalance of unused Arbitrum dust (~0.004 USDC) — negligible.
- Vision (chart-image) signals route through `_try_attachment_scalp`; offline
  OCR backend (`local`) works with no API key.
