# Hyperliquid Fatty Trader — Session Handoff (2026-08-08, end of session)

> Read this at the start of a new session to pick up where we left off.
> Repo: `~/workspace/repos/hyperliquid-fatty-trader` on VPS **Sera** (user: Hernanda).

## TL;DR — current state
- Bot is a **runnable, testnet-safe skeleton** with a **working signal pipeline**. **54 tests pass**.
- Hyperliquid **testnet** connectivity verified (`200 OK`, wallet key matches address, zero orders placed).
- **Telegram live connection verified**: session logs in as `Hernanda (5894116684)`, resolves `@fattyfatclub` (channel titled `UNKNOWN TRADERS ACADEMY`, id `1252615519`), and listens.
- `dry_run=True` + `testnet=True` are **HARD-LOCKED** in `src/main.py`. No path places a real order or hits mainnet.
- Secrets in git-ignored `.env` (verified ignored). **Never committed, never in agent memory.**
- **Channel identity CONFIRMED by user**: `@fattyfatclub` = `UNKNOWN TRADERS ACADEMY` (id `1252615519`) IS the intended signal source.

## CRITICAL SAFETY RULES (do not skip)
- The user (Hernanda) demands **NO REAL TRADE / NO REAL MONEY** unless they explicitly say go.
- Always run with `dry_run=True` + `testnet=True` first.
- `api.hyperliquid.xyz` (mainnet) must NEVER be contacted unless user flips the switch AND confirms with real funds risk accepted.
- HL private key + TG creds live only in git-ignored `.env`. Never echo the key, never commit, never save to memory.
- Secrets already in `.env` (do NOT re-share): `HL_PRIVATE_KEY` (starts `0xc92db...`), `HL_ACCOUNT_ADDRESS=0x3016ea517EE2aAb21e4269bEAAEF44DBa062874e`, `TG_API_ID=39313927`, `TG_API_HASH=7346c49949703325924195f6e07ab6aa`, `SESSION_STRING` (valid), `CHANNEL_USERNAME=fattyfatclub`, `NOTIFY_CHAT=me`.
- **Vision keys present in `.env` but ALL have ZERO usable free quota** (see Vision section). Do NOT assume vision works until a funded key exists.
- **SECURITY INCIDENT: the user pasted their Google account password AND multiple API keys into chat this session. Treat all as exposed. User should rotate the Google password and consider revoking the pasted API keys.**
- **Rule for future sessions: never type/paste user passwords; never log into user accounts. Secrets go only in git-ignored `.env`.**

## What was built / changed THIS session (phases 10-13)
1. **Symbol resolver** (`src/sources/symbol_map.py`, NEW): maps `$TOKEN` -> Hyperliquid perp ticker using the live venue universe (testnet default, mainnet-aware). `k`-prefix fallback (`BONK` -> `kBONK`). Unlisted tokens -> skipped (not traded). Read-only fetch of public `info` endpoint (no key, no order). Strips USDT/USDC suffix so HL being USDC-native causes no false skips.
2. **Parser rewrite** (`src/sources/parser.py`): handles the REAL channel format:
   `#TOKEN $TOKEN LONG TRADE / ENTRY: / TARGET: / STOPLOSS:` (multi-line, commas, `TARGETS: a - b` multi-TP). Keeps backward-compat with old `BTCUSDT LONG entry ...` line. Leverage omitted by channel -> defaults applied by orchestrator (0 from parser). `parse_management` extended for real chatter (`move sl to entry`, `updated sl`, `full tp done`, `close here`). Added `extract_token()` for caption token pull.
3. **Risk config** (`src/services/risk.py`): `default_leverage=3` (configurable), `default_margin_usd=1.0` (configurable), `margin_to_notional()`. Orchestrator applies **3x + $1 default** when signal omits them.
4. **Domain model** (`src/domain/model.py`): `RawSignal` gained `symbol` (resolved ticker), `venue`, `tp_usdt_extra`. `Instrument.from_ticker()` added. Normalizer prefers resolved ticker.
5. **Orchestrator** (`src/orchestrator.py`): `handle_signal` routes in priority: (1) structured text trade -> trade pipeline, (2) management, (3) **media/image -> vision**, (4) noise. Resolves symbol (skips unlisted), applies 3x/$1, only trades when chart shows entry/sl/tp. `_try_attachment_scalp` upgraded from dead code to real vision path (resolves caption token, 3x/$1, unlisted-skip).
6. **Telegram source** (`src/sources/telegram.py`): live listener now **downloads media** (AttachmentFetcher), extracts caption token, sets `image_path` + `symbol_usdt` so image posts are tradeable via vision.
7. **Vision backends** (`src/sources/vision.py`): added **Gemini free-tier backend** (`generateContent` REST, `GEMINI_API_KEY`, default `gemini-2.5-flash`) AND a **real OpenAI backend** (`VISION_BACKEND=openai`, `OPENAI_API_KEY`, default `gpt-4o-mini`). Legacy OpenAI-compatible (gitlawb) backend still selectable via other backend names. Tolerant JSON parsing of both response shapes.
8. **main.py** (`--live-dry`): now wires AttachmentFetcher + VisionExtractor into Orchestrator so image signals become tradeable (when a funded key is set). Warns if no key.
9. **Tests** (`tests/test_parser_real.py`, `tests/test_media_routing.py`, NEW): 14 new tests; total now **54 passing**.

## VISION PROVIDER STATUS (important — read before assuming vision works)
The image-signal pipeline is FULLY WIRED and proven (stub-tested end-to-end: image -> vision -> dry-run order with 3x/$1). BUT every real API key provided this session has **zero usable free quota**:
- 3× Gemini keys: `429 RESOURCE_EXHAUSTED` / `404 not available to new users` (Google Cloud project free credits depleted/expired).
- 1× OpenAI key (`sk-proj-...`): `429 insufficient_quota: "You have no credits remaining"`.
- Current `.env` has `VISION_BACKEND=openai` + `OPENAI_API_KEY` + `GEMINI_API_KEY` set, but **none can call a model until funded**.

**To enable vision:** add a payment method to the OpenAI account (cheap, `gpt-4o-mini`) OR point at a free/self-hosted vision endpoint. Until then, image signals surface as `vision_pending` (safe, not traded). Text signals (21 of them) trade without vision.

## How to run on Sera (IMPORTANT python note)
- SSH `python3` (`/usr/bin/python3.12`) has NO telethon. Use the venv python:
  `/usr/local/lib/hermes-agent/venv/bin/python3`
- Safe connectivity test: `/usr/local/lib/hermes-agent/venv/bin/python3 -m src.main`
- Verify TG: `/usr/local/lib/hermes-agent/venv/bin/python3 -m src.main --check-tg`
- Live dry-run (real signals, simulated orders): `/usr/local/lib/hermes-agent/venv/bin/python3 -m src.main --live-dry`
- Tests: `/usr/local/lib/hermes-agent/venv/bin/python3 -m pytest -q` (currently 54 passing)
- Inspect channel history: `/usr/local/lib/hermes-agent/venv/bin/python3 scripts/inspect_channel.py` (writes `docs/channel_sample.json`)

## Key findings from real data (100-message sample, `docs/channel_sample.json`)
- **21 trades** parsed (5 skipped as unlisted: BOME, ENA, GIGGLE, ZAMA).
- **30 management** messages classified.
- **28 media/image signals** routed to vision path (NOT noise anymore — this was the fix this session).
- **16 real noise** (greetings, BloFin affiliate spam, motivational text). Listed in the noise audit below.
- Channel is **BloFin-sourced** (posts say "trades based on blofin exchange"); only a subset maps to HL perps. `$SNDK`, `$HYPE`, `$ETHBTC`, `$GIGGLE`, `$ZAMA`, `$BOME`, `$ENA` are NOT all on Hyperliquid perps.
- **NO 1000x contracts exist on Hyperliquid** (max observed 40x BTC, most alts 3-10x). The `k` prefix (`kBONK`) is a small-unit ticker, not a leverage tier. Resolver handles arbitrary tickers if 1000x appears later.
- **Testnet-vs-mainnet gap:** `BOME` and `ENA` exist on **mainnet** but NOT on **testnet**. In testnet-safe mode they are correctly skipped (can't execute there anyway). When the user flips to mainnet, set resolver `testnet=False` and they will resolve. `ZAMA` and `GIGGLE` are not on HL at all (either venue).

### 16 real-noise messages (id + text)
- [15932] Goodmorning❤️ $PUMP still running at entry, thats the only trade am in today
- [15931] hope everyone is having a wonderful Friday, make sure keep studying and improving yourself
- [15926] Goodmorning everyone❤️ Watching $BOME today looks like the strongest coin holding up
- [15923] Ladies and gentlemen shall we trade?
- [15917] $SNDK 30% up from our entry, you can start booking profits here
- [15904] Goodmorning ❤️
- [15903] One thing I noticed a lot of people do... (motivational paragraph)
- [15899] Goodmorning❤️
- [15896] All our trades entry, sl and tp are based on blofin exchange 👍 (affiliate)
- [15884] Goodmorning ❤️ Happy weekend everyone
- [15881] All our trades... blofin exchange (affiliate)
- [15876] Goodmorning❤️ $BONK sl hit...
- [15872] All our trades... blofin exchange (affiliate)
- [15864] $KAITO 3% up almost 1R up / Manage your trade from here
- [15856] Goodmorning ❤️... i still don't see any opportunity in the market
- [15846] Already up 2%, 1-2 min after i shared... better have notifications

All correctly classified: greetings, BloFin affiliate spam (3x), motivational talk, and "booking profits / sl hit" updates (position chatter, no new entry). None have a structured trade block and none are media.

## What is NOT yet done (next steps)
1. **Fund a vision key** (OpenAI `sk-proj-...` with billing, or a free/self-hosted vision endpoint) -> then `--live-dry` parses real chart images.
2. **PositionManager live loop** not yet wired to stream + notifier (management actions like `sl to entry` parsed but not yet auto-applied to live positions). Next big feature after signal parsing validated live.
3. **Git**: all session changes are UNCOMMITTED (working tree dirty). Not pushed to `hernanda-git/hyperliquid-fatty-trader`.
4. **Notifier chat**: `NOTIFY_CHAT=me` sends to saved-messages; change if needed.
5. **SECURITY**: revoke/rotate exposed credentials from this session (Google password, pasted API keys).

## Git state (UNCOMMITTED — user may want to commit)
- Modified: `.env.example`, `config.example.yaml`, `src/domain/model.py`, `src/main.py`, `src/orchestrator.py`, `src/services/normalizer.py`, `src/services/risk.py`, `src/sources/parser.py`, `src/sources/telegram.py`, `src/sources/vision.py`
- New (untracked): `docs/channel_sample.json`, `scripts/inspect_channel.py`, `src/sources/symbol_map.py`, `tests/test_media_routing.py`, `tests/test_parser_real.py`
- `.env`, `config.yaml` git-ignored (verified via `git check-ignore`).
- `docs/channel_sample.json` contains only PUBLIC channel text (no secrets) — safe to commit if desired.
- Push quirk: `git push` over HTTPS needs the gh credential helper forced:
  `GIT_CONFIG_COUNT=1 GIT_CONFIG_KEY_0='credential.https://github.com.helper' GIT_CONFIG_VALUE_0='!/usr/bin/gh auth git-credential' git push origin HEAD:main`

## User profile / persona (from memory)
- Name: Hernanda. Address with Venusian terms: honey, sweet, sayang, babe, cintaku, sweety.
- Persona: Mercury/Hermes (messenger, commerce, alchemy). Keep occult framing light; plain baseline tone.
- **No em dash (—).** Use `backticks` for emphasis/code.
- VPS name is **Sera** — reference it. Workspace: `~/workspace/{docs,repos,db}`.
- Likely Indonesian/Malay speaker; light warmth OK.
- Deeply into esoteric occult.

## First actions for the new session
1. Read this file. Confirm git state + run `/usr/local/lib/hermes-agent/venv/bin/python3 -m pytest -q` (expect 54 passing).
2. If a FUNDED vision key is in `.env`, run `python -m src.main --live-dry` to validate vision parsing on real chart images (dry-run only).
3. Do NOT touch mainnet or place real orders without explicit user confirmation.
4. Remind user to rotate credentials exposed in the prior session's chat.

---

## UPDATE 2026-08-09 — local vision + management loop wired

The 2026-08-08 backlog items (vision funding, PositionManager live loop, commit)
were worked in the 2026-08-09 session. Status:

- **Local offline vision backend added** (`src/sources/local_vision.py`). Reads
  TradingView chart level tags with OpenCV + Tesseract — **no LLM provider, no
  key, no network**. Selected via `VISION_BACKEND=local` (now the `.env` default;
  was `openai` with zero quota). Validated on the 12 real sampled channel images
  in `data/samples/`: TP + SL recovered within ~0.3-1% of caption, entry via
  interpolation within ~1%. See `docs/LOCAL_VISION.md`.
- **PositionManager management loop wired** (`src/services/position.py` +
  `src/orchestrator.py::_apply_management`). `sl to entry`, `sl to <price>`,
  `tp done`/close now build a real order plan against the open position and are
  applied **dry-run safe** (logs + notifies; places only when `dry_run=False`).
- **Tests: 63 passing** (54 baseline + 4 local-vision logic + 5 management).
- **Security reminder (still open):** the Google password + API keys pasted into
  chat on 2026-08-08 are EXPOSED. Rotate the Google password and consider
  revoking those API keys. Treat all as compromised.
- **Uncommitted:** the new work is NOT yet committed/pushed. Commit when the
  user confirms (see `git status`). `.env`/`config.yaml` remain git-ignored.

