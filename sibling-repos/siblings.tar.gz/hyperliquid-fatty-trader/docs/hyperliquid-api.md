# Hyperliquid API reference (for the ExchangeAdapter)

Hyperliquid is an on-chain perpetuals exchange. Trading is via the Hyperliquid
L1 (HyperCore); data + order entry go through the API, which is backed by the
chain. **Settlement is always in USDC.** There is no API-key IP-ban problem like
on Binance — the API is reachable from any IP, including Tencent/cloud ranges.

## Endpoints

### Info (read) — `https://api.hyperliquid.xyz/info` (mainnet)
Testnet: `https://api.hyperliquid-testnet.xyz/info`

A JSON-RPC style POST endpoint. Common `type`s:

- `meta` — list of tradable perps (`universe[].name` e.g. `BTC`, `ETH`).
- `allMids` — latest mid price per coin (USDC).
- `clearinghouseState` — positions, marginSummary, withdrawable for an address.
- `frontendOpenOrders` — open orders for an address.
- `userFills` — recent fills.
- `l2Book` — order book snapshot for a coin.
- `candle` — OHLCV history.

### Exchange (write) — `https://api.hyperliquid.xyz/exchange` (mainnet)
Testnet: `https://api.hyperliquid-testnet.xyz/exchange`

Signed actions (the bot uses `order` and `cancel`):

```json
{
  "action": {
    "type": "order",
    "orders": [{
      "a": "BTC",            // asset
      "b": true,             // isBuy
      "p": "60000.5",        // price (string, USDC)
      "s": "0.01",           // size (in coin units)
      "r": false,            // reduceOnly
      "t": { "limit": { "tif": "Gtc" } },   // or "trigger" for SL/TP
      "c": "clientoid123"    // client order id (idempotency)
    }]
  },
  "nonces": 1,
  "signature": "0x..."
}
```

Order types:
- `limit` (tif: Gtc/Ioc/Alo)
- `trigger` (for SL/TP): `{ "trigger": { "triggerPx": "...", "isMarket": true, "tpsl": "sl"|"tp" } }`
- `market` order via `tif: "Ioc"` with a reference price.

### Auth
- Wallet signer (EVM private key) signs the action. The bot can use a dedicated
  **session key** (approved via `approveAgent`/`createSubAccount`) so the hot key
  has limited, revocable permissions — recommended for automation.

## WebSocket (primary data path)

`wss://api.hyperliquid.xyz/ws` (testnet: `wss://api.hyperliquid-testnet.xyz/ws`)

- **Public** (no auth): subscribe to `l2Book`, `allMids`, `bbo`, `trades`,
  `candle` for one or many coins.
- **Private** (`userEvents`): after sending a `{"method":"subscribe","subscription":{"type":"webData2","user":"0xADDRESS"}}`
  (auth via signed action), the socket pushes positions, orders, and fills in
  real time. No listenKey/REST-refresh dance (unlike Binance).

### Why this fits the pipeline
- One connection carries market data AND account events. SL monitoring, fill
  detection, and PnL updates are all pushes -> near-zero REST weight.
- Self-healing: on reconnect, refetch `clearinghouseState` + `frontendOpenOrders`
  to reconcile local state.

## Rate limits (lenient, no IP bans)
Hyperliquid does not publish aggressive per-IP request-weight bans. REST is used
only for order entry/cancel and occasional reconciliation. The WS is the hot path.

## Settlement note
All amounts (entry, sl, tp, margin, PnL) are in **USDC**. Coin size `s` is in the
base asset (e.g. BTC). The adapter converts a USD notional -> coin size using the
live mid from `allMids`/`bbo`. This is exactly why the `UsdNotional` domain type
keeps USD separate from the settlement asset.
