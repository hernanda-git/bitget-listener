# Channel Token & Noise Audit (@fattyfatclub)

Generated from `docs/channel_sample.json` (100-message sample) and the LIVE
Hyperliquid universes (testnet 210 assets, mainnet 232). Reference for the next
session — rebuild with `scripts/audit_tokens.py` + `scripts/audit_prefix.py` +
`scripts/list_noise.py`.

## 1. Token classification (source token -> Hyperliquid ticker)

Listed + tradeable on testnet:
`AAVE` `BONK->kBONK` `BTC` `HYPE` `INJ` `KAITO` `ONDO` `PUMP` `PYTH` `WLD`

Mainnet-only (skipped in testnet-safe mode, resolves on mainnet flip):
`BOME` `ENA`

Unlisted on BOTH venues (never traded):
`ETHBTC` `GIGGLE` `SNDK` `ZAMA`

## 2. Name differences (no "1000x" contracts exist on HL)

Hyperliquid uses small-unit naming, NOT leverage tiers:
- `k`-prefix (both venues): `kBONK, kDOGS, kLUNC, kNEIRO, kPEPE, kSHIB` (testnet);
  mainnet adds `kFLOKI`.
- `1000`-prefix: NONE present in the current live universe (0 on both venues).
  Resolver still matches it (`1000PEPE` etc.) if HL lists it later.

Canonical map from this channel's data:
`BONK -> kBONK`

The resolver (`src/sources/symbol_map.py`) tries: exact -> k-prefix -> 1000-prefix.

## 3. Binance-pair / typo alias (same coin, different spelling)

The channel mixes Binance-style pairs with `$TOKEN` mentions. Collapsed via the
alias map in `src/sources/parser.py` so positions + resolution line up:
`BOMSEUSDT -> BOME`, `BOMSE -> BOME`, `BOMEUSDT -> BOME`, `BOME -> BOME`.
Also any `BASEUSDT` pair is stripped to its base (`BTCUSDT -> BTC`).

## 4. Image-only posts with NO $TOKEN caption -> vision_pending (14)

These have media but no ticker in the caption, so the offline local-vision
backend cannot set a side; they stay `vision_pending` (safe, not traded):
`[15925] [15922] [15921] [15920] [15918] [15905] [15894] [15892] [15867]
 [15865] [15861] [15855] [15850] [15835]`
(Mostly giveaways, chart-requests, greetings, or image-only with no ticker.)

## 5. Noise (16 total, correctly ignored)

Text-only, not a trade, not management, not a chart:
1. `[15932]` Goodmorning❤️ $PUMP still running at entry, thats the only trade am in today
2. `[15931]` hope everyone is having a wonderful Friday, make sure keep studying...
3. `[15926]` Goodmorning everyone❤️ Watching $BOME today looks like the strongest coin holding up
4. `[15923]` Ladies and gentlemen shall we trade?
5. `[15917]` $SNDK 30% up from our entry, you can start booking profits here  (-> tp_hit, see note)
6. `[15904]` Goodmorning ❤️
7. `[15903]` One thing I noticed a lot of people do... (motivational paragraph)
8. `[15899]` Goodmorning❤️
9. `[15896]` All our trades... blofin exchange ... partner.blofin.com (affiliate)
10. `[15884]` Goodmorning ❤️ Happy weekend everyone
11. `[15881]` All our trades... blofin exchange (affiliate)
12. `[15876]` Goodmorning❤️ $BONK sl hit ... We had two sl the past 2 weeks...
13. `[15872]` All our trades... blofin exchange (affiliate)
14. `[15864]` $KAITO 3% up almost 1R up / Manage your trade from here  (-> manage, see note)
15. `[15856]` Goodmorning ❤️ ... i still don't see any opportunity in the market...
16. `[15846]` Already up 2%, 1-2 min after i shared ... better have notifications...

NOTE: messages #5 and #14 are management (not noise) once an open position for
that token exists — they route to `tp_hit` (close/book profit) and `manage` (trail
SL) respectively. In the no-position replay they show as `management:no_position`;
with a live position they fire `dry-run:management`. The "16 noise" count is the
text-only baseline; the live pipeline reclassifies #5/#14 as management when a
position is held.

## 6. Rebuild commands (Sera, venv python)
- Token audit: `PYTHONPATH=. run scripts/audit_tokens.py`
- Prefix/name-diff audit: `PYTHONPATH=. run scripts/audit_prefix.py`
- Noise list: `PYTHONPATH=. run scripts/list_noise.py`
