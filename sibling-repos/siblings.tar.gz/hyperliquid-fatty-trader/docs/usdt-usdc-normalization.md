# USDT ↔ USDC normalization

The single most important architectural concern for this project: **signals are
quoted in USDT (Bybit), execution settles in USDC (Hyperliquid).** This document
defines how that difference is handled *once*, centrally, and never leaked into the
rest of the system.

## Principle

> The mismatch is resolved at exactly one boundary: `SignalNormalizer`. Every
> downstream component (validator, risk, order, execution, PnL) speaks only USDC.

## Peg model

USDT and USDC are both USD-pegged stablecoins. Under normal conditions
`1 USDT ≈ 1 USDC`. We treat the conversion rate as a live, monitored value:

```
peg_rate = USDC_per_USDT   (default 1.0)
```

Sources for `peg_rate` (in priority order):
1. A `PegSource` interface (e.g. HL `allMids` for a USDT/USDC pool, or a stablecoin
   index). Pluggable.
2. Fallback constant `1.0` if the source is unavailable (with a warning).

## Conversion rules (in `SignalNormalizer`)

For a Bybit signal with prices in USDT and notional in USDT:

```
usdc_entry = usdt_entry * peg_rate
usdc_sl    = usdt_sl    * peg_rate
usdc_tp    = usdt_tp    * peg_rate
usdc_notional_usd = usdt_notional_usd * peg_rate   # USD value in USDC terms
```

The emitted `Signal` carries:
- `instrument.quote = "USDC"`
- prices in USDC
- `notional.amount_usd` (USD risk budget, peg-invariant)
- `notional.settlement = "USDC"`
- `raw` = the original Bybit payload for audit.

## Depeg guard (`StablecoinPegGuard`, runs in validation)

If `|peg_rate - 1.0| > max_depeg` (config, default `0.005` = 0.5%), the signal is
**rejected** with reason `DEPEG`. Rationale: trading through a stablecoin depeg
turns a clean USD risk into an unknown basis risk; safer to skip the trade than to
misprice SL/TP.

## Coin-size conversion (in `ExchangeAdapter`)

Hyperliquid order size `s` is in the **base coin** (e.g. BTC), not USD. The adapter
computes:

```
coin_size = usd_notional / usdc_mark_price
```

using the live mid from `allMids`/`bbo`. Liquidation, margin, and PnL are all in
USDC natively — no further conversion needed.

## Avoided anti-patterns

- ❌ Scattering `* 1.0` or `usdt_to_usdc()` calls across validators, risk, and
  execution.
- ❌ Storing prices in `Signal` without recording which stablecoin they're in.
- ❌ Trusting the peg without a guard (a depeg would silently move every SL/TP).

## Test plan

- Normalizer test: `BTCUSDT` @ 60000 USDT, peg 1.0 -> `BTC` @ 60000 USDC.
- Normalizer test: peg 0.997 -> USDC prices scaled; notional USD unchanged.
- Guard test: peg 0.98, max_depeg 0.005 -> signal rejected (DEPEG).
- Round-trip: raw USDT price recovered from `Signal.raw` for audit.
