# Local vision (offline chart reading, no LLM provider)

The bot can read `@fattyfatclub` chart images **without any cloud LLM** using a
local OpenCV + Tesseract pipeline. This was added so image signals become
tradeable with zero API cost and no data leaving the box.

## How it works (`src/sources/local_vision.py`)

Signal charts from the channel are TradingView screenshots: a right-edge price
axis plus colored level tags (green = take-profit, red/purple = entry/stop).

1. The image is upscaled 2x for small-axis OCR.
2. Colored level tags are located **by colour** (robust even when an entry box
   shows a countdown timer instead of a price).
3. Each tag's own price is OCR'd from its rectangle (keeps the decimal point).
4. Tags that show a timer (no price) get their price by interpolating the
   y->price line fitted from the other OCR'd tags + the grey price axis.
5. The caption's `LONG`/`SHORT` word decides which tag is entry vs stop vs target.
6. Returns the same structured dict as the Gemini/OpenAI backends, so the
   orchestrator and tests are unchanged.

It is conservative: it only returns tradeable levels when >=2 distinct coloured
prices are found; otherwise `has_chart_data=False` and the signal stays
`vision_pending` (never traded).

## Accuracy (measured on real channel samples)

On the downloaded real charts the local backend recovered TP and SL to within
~0.3-1% of the caption, and the entry (when its tag held a timer) to within
~1% via interpolation. Good enough to act on; the 3x/$1 default risk budget
absorbs the small error.

## Switching backends

`VISION_BACKEND` in `.env` selects the backend:

- `local`  (default) — offline, no key needed.
- `gemini` — needs `GEMINI_API_KEY`.
- `openai` — needs `OPENAI_API_KEY` + billing.

## Dependencies

`opencv-python-headless` and `pytesseract` (system `tesseract` binary) must be
installed. The `VisionExtractor` in `vision.py` lazy-imports `LocalVisionExtractor`
so installs that only use remote backends don't require them.

## Validating

- Unit tests: `tests/test_local_vision.py` (perception mocked, deterministic).
- Real-image smoke: `PYTHONPATH=. run scripts/test_local_vision.py` reads the
  sampled charts in `data/samples/`.
