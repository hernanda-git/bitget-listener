# Signal source: Telegram `@fattyfatclub` (USDT-pair signals)

The signal source is **identical to the learnernoearner-listener**: the Telegram
channel **t.me/fattyfatclub**. Messages are free-text trading calls (e.g.
`BTCUSDT LONG entry 60000 sl 58000 tp 64000`). The channel references
**Bybit USDT pairs**, which is the source of the USDT/USDC mismatch this
architecture must handle.

## How it works (mirrors the listener)

1. A Telegram listener (`SignalSource` impl) connects to `@fattyfatclub`
   (configurable via `CHANNEL_USERNAME`, default `fattyfatclub`).
2. Each new message is passed to the **same free-text parser** used by the
   listener (`parse_signal`): extracts symbol, side, entry, sl, tp, leverage,
   confidence, and any management hints (`sl to entry`, `sl be`, `tp1 here`,
   `close here`).
3. The parser emits a `RawSignal` whose `symbol` is a **USDT pair** (e.g.
   `BTCUSDT`) and whose prices are in **USDT**.
4. `SignalNormalizer` strips `USDT`, resolves the base (`BTC`), and re-prices in
   **USDC** using the live peg (see `docs/usdt-usdc-normalization.md`).

So: **Bybit is the pair *naming convention* in the signals, not a live data
feed.** No Bybit API/WS connection is required. This keeps the source identical
to the listener you already run, satisfying "very same behavior."

## Mapping (recap)

| Listener field | Internal |
|----------------|----------|
| `BTCUSDT`      | base `BTC`, quote `USDT` (stripped) |
| `LONG`/`SHORT`| `BUY`/`SELL` |
| USDT prices    | kept in `raw`; converted to USDC by `SignalNormalizer` |
| leverage       | `leverage` (capped by `RiskManager`) |
| confidence     | `confidence` (0..1) |

## Management messages (same as listener)

The parser also handles follow-up messages that modify an open trade:
`sl to entry`, `sl be`, `tp1 here`, `close here`. These are routed to the
`PositionManager`/`OrderService` which adjust the Hyperliquid position (USDC)
accordingly. The USDT→USDC conversion applies to any price in these messages too.

## Source resilience

- Listener reconnects with backoff; pushes `RawSignal` onto an async queue so a
  source blip never blocks execution.
- Duplicate/stale signals de-duplicated by `(instrument, side, entry, ts)`.
- Signals older than `max_signal_age_s` are dropped before validation.
