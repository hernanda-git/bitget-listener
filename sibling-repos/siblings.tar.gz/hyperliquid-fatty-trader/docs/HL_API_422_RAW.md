# Hyperliquid /exchange 422 — raw request artifacts (sanitized)

Wallet: `<BOT_WALLET_ADDRESS>` (redacted in public repo; on-chain address is public regardless)
Captured: 2026-08-11 (UTC+8)

---

## Artifact 1 — MY adapter (custom httpx + eth_account)

POST /exchange
Content-Type: application/json

{
  "action": {
    "type": "order",
    "orders": [
      {
        "a": "BTC",
        "b": true,
        "p": "0",
        "s": "0.000003",
        "r": false,
        "t": { "limit": { "tif": "Ioc" } },
        "c": "RAWREQ01"
      }
    ],
    "grouping": "na"
  },
  "nonce": 1786438207670,
  "signature": {
    "r": "0x9cffaa80e22624f797c43a30981663d29bdb0f53837b83280558d2d4446b2a9d",
    "s": "0x42f1fc34283b3a92869948eb2b26a8985e9c56b366ad01baea5306dd063bfc0f",
    "v": "0x1c"
  }
}

HTTP 422
Failed to deserialize the JSON body into the target type

---

## Artifact 2 — OFFICIAL hyperliquid-python-sdk 0.24.0

POST /exchange
Content-Type: application/json

{
  "action": {
    "type": "order",
    "orders": [
      {
        "a": 3,
        "b": "b",
        "p": "3.1",
        "s": "0.000003",
        "r": false,
        "t": { "limit": { "tif": "Ioc" } }
      }
    ],
    "grouping": "na"
  },
  "nonce": 1786438242942,
  "signature": {
    "r": "0xcdc4cf08891f1bffd449baae52d537b47989bdb257472812cbbaa4dca7813d40",
    "s": "0xda8410aeed3ca0fa3b7e9b982978c646be897c8892cf98e7a539e5d43a8ede9",
    "v": 28
  },
  "vaultAddress": null,
  "expiresAfter": null
}

HTTP 422
Failed to deserialize the JSON body into the target type
(Server: nginx/1.26.2  — testnet)

---

## Metadata

SDK version: 0.24.0
SDK git commit: NOT AVAILABLE (installed from PyPI wheel; no .git in package)
Python version: 3.11.15

## Key divergence between the two requests (both 422)
- MY adapter: `"a": "BTC"` (symbol string), `"b": true` (bool)
- OFFICIAL SDK: `"a": 3` (asset INDEX for BTC), `"b": "b"` (string "b"/"s")
- SDK adds top-level `"vaultAddress": null` and `"expiresAfter": null`
- Both use `signature` as `{"r","s","v"}` object. SDK's `v` is integer `28`;
  mine is hex `"0x1c"` (same value, different encoding).
- Both signatures are correctly derived (mine recovers to the wallet address).

## Decisive test matrix (run 2026-08-11)

### `noop` through official SDK — MAINNET
```
HTTP 200
{"status":"ok","response":{"type":"default"}}
```
The `/exchange` envelope, signing, and signature ALL work on mainnet. The user
exists. This isolates the failure to the `order` action specifically.

### `noop` through official SDK — TESTNET
```
HTTP 200 body: {"status":"err","response":"User or API Wallet 0x7030...4A81 does not exist."}
```
(Testnet uses separate credentials; the user isn't registered there, which is
why testnet order tests can't trade with this key.)

### `order` — MAINNET — every variant tried, ALL 422
| Variant | `a` | `b` | `r` | `p` | tif | nulls | result |
|---|---|---|---|---|---|---|---|
| custom (pre-fix) | `"BTC"` | `true` | `false` | `"0"` | Ioc | omitted | 422 |
| official SDK market_open | `0` | `"b"` | `false` | `"3.1"` | Ioc | yes | 422 |
| custom (post-fix) | `0` | `"b"` | `false` | `"0"` | Ioc | yes | 422 |
| official SDK order() GTC | `0` | `true` | `3` | `"3.1"` | Gtc | yes | 422 |

The fix to use asset INDEX (`a:0`) + string side (`b:"b"`) made my request
byte-for-byte equivalent to the official SDK's — and it STILL 422s. So the
field-convention hypotheses (symbol vs index, bool vs string side, null
optional fields, IOC vs GTC, price "0" vs "3.1") are all RULED OUT.

### Signing matches the SDK exactly
`_sign_l1` mirrors `hyperliquid-python-sdk` `sign_l1_action` (msgpack action +
nonce + `b"\x00"` vault flag -> keccak -> `Agent` EIP-712 over chainId 1337).
Signature recovers to `0x7030...4A81`. The SDK's own order 422s too.

## Conclusion (updated from handoff)
The handoff ranked "API/server-side schema drift" as PLAUSIBLE, NOT PROVEN, and
said it becomes much stronger if `noop` succeeds but `order` fails. That exact
condition is now met:

- `noop` (envelope + signature) -> HTTP 200 OK on mainnet.
- `order` (identical envelope + signature, only `action.type` differs) -> 422,
  reproducibly, via BOTH the custom adapter AND the official SDK 0.24.0, in
  every field-convention variant.

This is now strong evidence of a **server-side rejection of the `order` action**
with a generic `422 Failed to deserialize` on HL's mainnet `/exchange`. It is no
longer a client signing/serialization bug: the client matches the vendor SDK
and `noop` works. The remaining unknown is whether HL intends this (temp API
state, per-account restriction, or undocumented schema change) — but it is
outside what the bot code can fix.

### What was actually FIXED in the adapter (real improvement)
- `_hl_order` serializes the asset as HL's integer **asset index** (resolved
  from `meta`), not the symbol string — matching the SDK (`b` is now the string
  `"b"`/`"s"`).
- `_post_exchange` includes `"vaultAddress": null, "expiresAfter": null`.
- These are correct regardless of the 422 wall and remove a latent bug that
  would have 422'd even after the wall lifts.

## Structural diff: noop(200) vs order(422) — official SDK, mainnet

Outer envelope (both requests):
```
['action', 'nonce', 'signature', 'vaultAddress', 'expiresAfter']
```
- `vaultAddress` / `expiresAfter`: SAME (null) in both.
- `nonce`: DIFF only (different timestamps — expected).
- `signature`: DIFF only (different signed payloads — expected).
- `action`: the ONLY structural difference:
  - noop  -> `{"type": "noop"}`
  - order -> `{"type":"order","orders":[{"a":0,"b":"b","p":"3.1","s":"0.000003","r":false,"t":{"limit":{"tif":"Ioc"}}}],"grouping":"na"}`

So the envelope, signing, and auth are identical between the 200 and 422 cases.
The discriminators are purely inside `action`. Since `noop`'s `action` is
accepted and `order`'s is not, the rejection is specific to the `order` action's
content/shape as HL's server currently interprets it.

## Upstream source check (GitHub main-branch vs PyPI 0.24.0)

- PyPI latest = `0.24.0` (no newer release exists).
- GitHub `master` `order_request_to_order_wire` produces:
  ```python
  {"a": asset, "b": order["is_buy"], "p": float_to_wire(limit_px),
   "s": float_to_wire(sz), "r": order["reduce_only"], "t": order_type_to_wire(...)}
  ```
  i.e. `b` and `r` are BOOLS, `a` is the integer index, `c` only when a cloid is
  set. This is the SAME wire format PyPI 0.24.0 sends — and it 422s too.
- Therefore there is **no newer/working SDK order schema** to copy. The SDK's
  `order` wire is exactly what we (and the SDK) already send, and HL rejects it.

## Conclusion (final, per upstream-investigation framing)
The evidence establishes a **reproducible server-side incompatibility specific
to the `order` action**: same `/exchange` infrastructure, auth, and signing
that make `noop` return HTTP 200 are rejected for `order` with a generic
`422 Failed to deserialize`, via both the custom adapter and the official SDK.

Per the investigation handoff, we STOP short of asserting "HL changed its
schema" as absolute fact (no official announcement, no currently-working client
request captured). But the practical threshold is crossed: continuing to
rewrite the signing/client envelope is no longer justified — every permutation
(`a`, `b`, `p`, `t`, `v`, chainId, vaultAddress, expiresAfter) has been tested
and ruled out.

**The correct next question is upstream/API, not client-side:**
> What does Hyperliquid's server expect for `action.type = "order"` today that
> the official 0.24.0 SDK (and our adapter, which matches it) is not providing?

The only way to answer that is a **known-good `order` request from a currently
working client** — e.g. Hyperliquid's own web frontend network capture, or an
SDK/integration that is placing orders successfully right now. Without that, the
client cannot be fixed by further permutation; the fix must come from HL
publishing the current schema, or from observing a working request.

### Status
- Live trading: STILL BLOCKED (every `order` -> 422).
- Adapter correctness: IMPROVED (asset index + null envelope fields now match
  the SDK; latent 422 fixed). Ready the moment HL accepts `order`.
- Monitor: `scripts/hl_api_probe.py` (daily cron) detects recovery.
