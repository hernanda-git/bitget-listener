# Implementation Plan

This plan is executed **only after review/validation (Step 3)** and after the
repository is initialized and committed (Steps 4-6). Each phase is independently
testable. No implementation code is written until this plan is approved.

## Phase 0 — Repository scaffolding (after git init)
- Create the directory tree under `src/` per `README.md` layout.
- `requirements.txt` (httpx, websockets, web3 / eth-account for signing,
  pyyaml, pydantic for config, pytest).
- `config.example.yaml`, `.gitignore` (ignore `config.yaml`, `credentials/`,
  `__pycache__`, `*.db`).
- `pyproject.toml` for tooling.
- **Acceptance:** `tree` shows the layout; `python -c "import src"` works with
  empty packages.

## Phase 1 — Domain model (no IO)
- `src/domain/`: `Instrument`, `UsdNotional`, `Signal`, `RawSignal`, `Order`,
  `OrderRequest`, `Position`, `Fill`, enums (`Side`, `OrderType`, `Settlement`).
- Pure dataclasses, fully unit-tested with fakes.
- **Acceptance:** 100% of domain methods covered by unit tests; zero imports of
  network/async libs in `domain/`.

## Phase 2 — Interfaces (ports)
- `src/interfaces/`: `SignalSource`, `ExchangeAdapter`, `MarketStream`,
  `Notifier`, `RiskPolicy`, `PegSource`.
- Each is a Protocol/ABC with narrow methods.
- **Acceptance:** concrete impls in later phases satisfy the interfaces via
  `isinstance`/structural checks; mypy clean.

## Phase 3 — Signal ingestion (Telegram @fattyfatclub)
- `src/sources/telegram.py`: `TelegramSignalSource` implements `SignalSource`.
  - Connects to `@fattyfatclub` (configurable via `CHANNEL_USERNAME`), reusing the
    same free-text `parse_signal` logic as the listener.
  - Messages reference **Bybit USDT pairs** (e.g. `BTCUSDT`); the parser emits a
    `RawSignal` with `quote=USDT`.
  - Pushes `RawSignal` onto an async queue; reconnect with backoff.
  - Management messages (`sl to entry`, `sl be`, `tp1 here`, `close here`) are
    routed to the PositionManager.
- **Frontrun handling (per owner rule):** if a signal's price is slightly
  frontrunned vs current mark, enter **25% at market** immediately and place the
  remaining **75% as a limit** at the signal price, same SL/TP. Implemented in
  `OrderService` via a `frontrun_split` flag.
- **Acceptance:** with a recorded `@fattyfatclub` message, source emits a correct
  `RawSignal` (USDT, base stripped). Network-free fake source used in tests.

## Phase 4 — Normalization + validation (USDT→USDC)
- `src/services/normalizer.py`: `SignalNormalizer` applies `docs/usdt-usdc-normalization.md`
  rules; emits `Signal` (USDC, prices converted, `raw` preserved).
- `src/services/validator.py`: structural checks (entry/sl/tp sanity, age,
  confidence floor) + `StablecoinPegGuard` (depeg reject).
- **Acceptance:** normalizer + guard unit tests from the doc's test plan pass.

## Phase 5 — Risk + order + position services
- `src/services/risk.py`: `RiskManager` computes coin size + leverage from
  `UsdNotional`, portfolio state, and caps. No external calls.
- `src/services/order.py`: `OrderService` builds `OrderRequest` (entry + child SL/TP
  trigger orders) from a validated `Signal`; assigns client order ids (idempotency).
- `src/services/position.py`: `PositionManager` tracks live positions from WS
  pushes; reconciles via `clearinghouseState` on (re)connect.
- **Acceptance:** given a $1000 notional @ 60000 USDC, risk emits correct coin
  size; order service emits entry + SL + TP requests with unique client ids.

## Phase 6 — Hyperliquid adapter (execution)
- `src/exchanges/hyperliquid.py`: `HyperliquidAdapter` implements `ExchangeAdapter`.
  - REST `exchange` for place/cancel (signed with session key).
  - `info` for reconciliation.
  - Converts `OrderRequest` -> HL order action; coin size via live mid.
- **Acceptance (testnet):** place a limit order on HL testnet, read it back via
  `frontendOpenOrders`, cancel it. Integration test is opt-in (marked, not in
  default suite).

## Phase 7 — Streaming (WS)
- `src/streaming/market.py`: `MarketDataStream` — `allMids`/`bbo`/`l2Book`/trades.
- `src/streaming/user.py`: `UserEventStream` — `webData2` user events (positions,
  orders, fills); auth via signed subscription.
- Reconnect with jittered backoff; re-subscribe + reconcile on connect.
- **Acceptance (testnet):** opening a position reflects in `userEvents` within the
  stream; mark price updates drive SL checks.

## Phase 8 — Orchestrator + config + main
- `src/orchestrator.py`: wires sources -> normalizer -> validator -> risk -> order
  -> adapter; consumes WS; runs SL logic on pushes. Injects all dependencies.
- `src/config/loader.py`: typed config (pydantic), env override for testnet/keys.
- `src/main.py`: composition root; starts WS, source, orchestrator; graceful
  shutdown.
- **Acceptance:** `python -m src.main --dry-run` starts, ingests a fake signal,
  simulates the full pipeline (paper mode), prints a trade summary, exits clean.

## Phase 9 — Notifier + slash commands
- `src/notifier/telegram.py`: implements `Notifier`; trade/health alerts.
- Slash commands: `/status`, `/paper`, `/live`, `/binancestatus`-equivalent
  (`/venue`), `/help`. (Reuses the listener's pattern; no Binance dependency.)
- **Acceptance:** a simulated fill produces a Telegram alert via `InMemoryNotifier`
  in tests; live send is integration-only.

## Phase 10 — Tests + CI + docs polish
- Unit suite (no network) green; integration suite (opt-in, testnet) documented.
- README quickstart, `config.example.yaml` annotated, run-book for depeg/ban
  (N/A for HL but kept for completeness).
- **Acceptance:** `pytest` green offline; `pytest -m integration` documented for
  testnet.

## Global acceptance criteria (definition of done)
- SOLID verified: no high-level module imports a concrete adapter directly.
- Zero network in unit tests (all IO behind fakes).
- USDT/USDC handled only in `SignalNormalizer` + `PegSource`; depeg guard present.
- Dry-run (`--dry-run`) exercises the whole pipeline end-to-end without placing
  real orders.
- Testnet integration passes before any mainnet key is used.

## Sequencing note
Phases 1-2 (domain, interfaces) are written first and committed as the foundation.
Then 3-9 build outward. Each phase ends with a green test run before the next
begins — matching the "complete each step sequentially" instruction.
