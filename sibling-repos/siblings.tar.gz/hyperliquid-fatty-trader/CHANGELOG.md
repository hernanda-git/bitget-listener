# Changelog

All notable changes to **hyperliquid-fatty-trader** are recorded here.
This file is the **canonical, historical record of behavior changes** — it is the
single source of truth for "what does the bot do now, and when did that change?"

Format: [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).
Versioning: semver, mirrored by the root `VERSION` file (the deployed version is
reported by the bot's 🚀 deploy and 💓 hourly health checks).

## How to update this file (MANDATORY)

`./deploy.sh` **refuses to deploy** if `VERSION` is bumped without a matching
`## [x.y.z]` section here. That guard is deliberate: the changelog cannot drift.

Workflow for any change:

1. Make the code change and get tests green.
2. Add an `[Unreleased]` entry (or a new version section) describing the
   change under `Added` / `Changed` / `Fixed` / `Removed` / `Safety`.
3. Run `./deploy.sh [patch|minor|major]`. It bumps `VERSION`, renames the
   `[Unreleased]` heading to the new version + today's date, verifies the
   section exists, restarts the bot, and health-checks it.

**Behavior-change entries must state the OLD behavior too.** A future session
reading only this file has to be able to tell what the bot used to do — that
context is what prevents re-introducing a fixed bug.

---

## [Unreleased]

### Added (HL best-practice, verifiable offline + on testnet)
- **Min-notional-aware sizing with leverage bump.** `RiskManager.compute_size`
  now takes `min_notional_usd` (default `RiskConfig.min_notional_usd = 10.0`,
  HL's per-order floor). When the risk-sized notional lands below the floor, the
  notional is lifted to the floor and effective leverage is raised (within
  `max_leverage`) so the required margin (`notional/leverage`) still fits free
  margin. This is the "bump leverage to clear the min-notional wall" behaviour
  the user authorized, so small-account orders stop getting rejected for being
  below HL's minimum. `OrderService.build_orders` passes the floor through.
- **Maker-limit (post-only) entry orders.** `OrderService` gains
  `prefer_maker=True` (default). Entry limit orders are now built as `post_only`
  so the adapter sends `tif: Alo` (maker/post-only) and the bot earns the maker
  rebate instead of paying taker fees. Market legs (frontrun fill, no known
  entry, SL/TP triggers, flatten) stay `Ioc`/`Gtc` as before. `OrderRequest`
  gains a `post_only` field; `_hl_order` maps it to `tif: Alo`.
- **Dead-man's-switch (`scheduleCancel`).** `HyperliquidAdapter.set_scheduled_cancel`
  arms HL's `scheduleCancel` (24h window) so stale orders auto-cancel if the bot
  dies. `run_bot_instance` arms it on live (non-dry) startup, wrapped so an API
  error never blocks startup.
- **Per-pair minimum-notional reference stored in Postgres.** New
  `src/store/min_notional.py` (`MinNotionalStore`) + table `hl_pair_min_notional`:
  populated from HL's live `meta` (`szDecimals`, `maxLeverage`, asset index) and
  `allMids` (mid) for **all 232 perp pairs** (mainnet). Stores the computed
  min-size step, min-step notional, and the bot's min-notional floor. `OrderService`
  now reads the per-coin floor via `min_notional_for()` (DB-backed, falls back to
  `risk.cfg.min_notional_usd` when a coin/DB is absent), so small-account orders
  are bumped above HL's per-coin floor instead of being rejected. Populated by
  `scripts/refresh_pair_min_notional.py`. Honesty note: HL does NOT expose a
  per-asset `minTradeNtl` via any public `info` endpoint, so the stored floor is
  the documented default ($10 for majors); `is_floor_from_api` is `False` for
  these rows and can be overridden per coin when HL publishes the true value.
  Tests: `tests/test_min_notional.py` (131→ committed). See commit `f583629`.


  matrix from the investigation handoff. `noop` through the official SDK returns
  **HTTP 200** on mainnet (envelope + signing + signature all valid; user
  exists), while every `order` variant — custom adapter AND official
  `hyperliquid-python-sdk` 0.24.0, with `a` as symbol/index, `b` as bool/string,
  `tif` Ioc/Gtc, with/without null fields — returns **422** reproducibly. The
  adapter's signing matches the SDK byte-for-byte (recovers to the wallet). This
  rules out client signing/serialization bugs and is now strong evidence of a
  **server-side rejection of the `order` action** on HL's mainnet `/exchange`.
  Real fixes made regardless: `_hl_order` now serializes the asset as HL's
  integer **asset index** (from `meta`, not the symbol string) and `b` as the
  string `"b"`/`"s"`; `_post_exchange` includes `"vaultAddress": null,
  "expiresAfter": null`. These match the SDK and remove a latent 422 that would
  have persisted even after the wall lifts. See `docs/HL_API_422_RAW.md`.
  Live order placement remains blocked until HL stops rejecting `order`.


  attempt (zero real-money risk, cancelled immediately) that reports whether
  HL's exchange endpoint is placeable again. Writes `data/hl_api_status.json`
  and prints a one-line verdict. Background: live order placement is currently
  BLOCKED because HL's `/exchange` returns `422` on every order (the official
  `hyperliquid-python-sdk` 0.24.0 fails identically on testnet+mainnet) — an
  external HL API change. This monitor detects the moment it recovers so live
  verification can resume. Verified: probe correctly reports BLOCKED (422) and
  writes the status file; unit tests cover sizing, maker routing, and the
  `Alo`/`Gtc` tif mapping. Live execution remains unverified until the API
  recovers (see the "NOT YET VERIFIED" note above).

### Fixed
- **Free-form entry calls were silently dropped.** The 2026-08-10 ONDO call
  (`shorted $ONDO here at 0.345 / Stoploss above 0.3545`) never traded.
  OLD behavior: `_SHORT_RE` was `\bshort\b`, which does not match `shorted`, so
  `parse_signal` returned `None`; the message fell through to the media/vision
  branch and built a bare `RawSignal` whose `side` field defaults to `Side.BUY`
  — which is why the dashboard displayed a SHORT call as **BUY**. NEW: the side
  regexes accept `long|longed|longing|buying|bought` and
  `short|shorted|shorting|sold`.
- **Prose price forms were unparseable.** OLD: `_ENTRY_RE` required
  `entry[ :]<num>` and `_SL_RE` required `stoploss[ :]<num>`, so `here at 0.345`
  and `Stoploss above 0.3545` both yielded `None` (no entry, no SL, no
  protective order). NEW: entry also accepts `entered/enter/here at/in at/from/
  around/@`, and stoploss also accepts `above/below/over/under/at/to`.

### Changed
- **LLM cross-parser enabled.** OLD: `LLM_SIGNAL_API_KEY` was empty, so
  `LLMSignalParser.from_env()` returned `None` and the bot was regex-only with
  no cross-check on free-form phrasing. NEW: pointed at the opencode Go
  subscription (`https://opencode.ai/zen/v1`, model `mimo-v2.5-free`), verified
  end-to-end returning `signal` / `management` / `noise` correctly, and verified
  to accept `image_url` content parts for chart attachments. Note: the paid
  models on that workspace currently return `CreditsError` (insufficient
  balance); the free tier is what works today.

### Safety
- Killed a stale `--live-dry` process (pid 144591, running since Aug 09) that
  was double-listening on the same telethon session as the live `fatty-main`
  bot. Exactly one listener per token is an invariant (AGENTS.md §2.6).
- Verification was dry-run only; no real order was placed. `scripts/replay_ondo.py`
  replays the real ONDO message through the live orchestrator and now yields
  `[dry-run] SELL ONDO entry=0.345 sl=0.3545 lev=3 orders=2`. Full suite: 100
  passed. `scripts/replay_real.py`: no regressions on the 100 real messages.

### Added
- `scripts/replay_ondo.py` — focused regression replay for the free-form
  short-call path.
- **`src/sources/chart_prompt.py`** — `RICH_CHART_PROMPT`, a strict
  observation-only chart parser prompt (forbids advice/prediction/fabrication,
  separates visible FACTS from interpretation of annotations, treats a drawn
  arrow as an annotation rather than a forecast), plus
  `adapt_rich_to_struct()` which maps its rich schema onto the internal vision
  struct (`position.*` -> `levels.*`, `position.direction` -> `trend`,
  zones/support_resistance -> `levels.support`/`levels.resistance`). The full
  rich payload is preserved under `["rich"]` for logging. The adapter never
  invents a level, and deliberately does NOT let arrows choose the trade side.
- **`tests/conftest.py`** — autouse fixtures forcing `LLM_SIGNAL_API_KEY=""`
  and `VISION_RICH_PROMPT=""` for every test. See the Fixed entry below.
- `tests/test_chart_prompt_adapter.py` — 14 adapter tests, including "empty
  payload is not tradeable" and "arrows never set the trade side".

### Changed
- **Chart vision: remote LLM backend built, then ROLLED BACK to `local`.**
  OLD: `VISION_BACKEND=local` (OpenCV + Tesseract, `model=local-cv`).
  Intermediate: switched to `VISION_BACKEND=openai` against the opencode zen
  gateway (`mimo-v2.5-free`) with `VISION_RICH_PROMPT=1`. FINAL: back to
  `local`. The remote path is fully working and stays configured in `.env`
  ready to re-enable, but no usable provider exists today —
  opencode paid models return `CreditsError`, `OPENAI_API_KEY` returns
  `429 credit_balance_exhausted`, and the one model that does answer
  (`mimo-v2.5-free`) is **nondeterministic**: the same ONDO chart, same prompt,
  `temperature=0`, read `short entry=0.3449 sl=0.3496` on one run and "no
  position at all" on the next. A chart that trades on one read and not the
  next must not drive real orders. Text signal parsing is unaffected and stays
  on `mimo-v2.5-free`, which IS verified deterministic on the message classes
  we tested.
  The `openai` branch now honours `VISION_API_URL` / `VISION_MODEL` /
  `VISION_API_KEY` so any OpenAI-compatible vision endpoint can be selected
  from `.env` without a code change (previously hard-wired to `api.openai.com`
  + `OPENAI_API_KEY`). Recommended when credits exist: `gpt-4o-mini`.

### Fixed
- **The rich-chart adapter fabricated a take-profit price.** OLD: `_mid()`
  averaged a zone's bounds for every zone type, so a green target zone spanning
  `0.3449..0.2898` on the real 2026-08-10 ONDO chart became `tp=0.31735` — a
  price printed NOWHERE on the chart, and a direct violation of the prompt's
  "never fabricate values" rule. NEW: `_edge()` is used for entry/stop/target
  zones and returns only a displayed number — the explicit `price`, or a lone
  boundary when just one is given; when BOTH bounds exist it returns `None`
  rather than guessing which edge the trader meant. `_mid()` is still used for
  support/resistance context, where an approximate band centre is harmless
  because it never places an order. Regression test:
  `test_target_zone_never_becomes_a_midpoint_tp`.
- **`_coerce` defaulted `has_chart_data` to `True`.** OLD: any vision payload
  it did not understand produced "chart present, every level null", which
  passes the orchestrator's gate at `orchestrator.py:382` carrying nothing
  tradeable. NEW: an explicit `False` is still honoured, but a missing flag is
  derived from whether any level actually survived coercion.
- **The test suite was making live network calls.** OLD: once
  `LLM_SIGNAL_API_KEY` was set in `.env`, `LLMSignalParser.from_env()` returned
  a live parser inside tests, so `Orchestrator` called the real signal endpoint
  and a remote model — not the fixture — decided message kinds. Three
  `test_media_routing.py` tests then failed in the full run while passing in
  isolation (`bias_logged` instead of `vision_pending`). NEW: `tests/conftest.py`
  clears the key for every test (both modules call `load_dotenv()` at import, so
  clearing the env before pytest starts is not sufficient). Suite runtime went
  ~10s -> ~2s, confirming no network.
- **The rich-chart adapter fabricated support/resistance prices via zone
  midpoints.** OLD: `adapt_rich_to_struct` emitted `(top+bottom)/2` for every
  zone, so the BTC bias chart produced `63542.2`, then `63994.75`, then
  `63678.55` across three reads — three numbers that are printed NOWHERE on the
  chart and differ run to run. NEW: a zone's two real, displayed bounds are
  emitted verbatim (e.g. support `[63930.5, 64059.0]`); an explicit `price` is
  used when given; no midpoint is ever computed. This closes the same
  "derived value reaches an order-relevant field" hole `_edge()` fixed for
  entry/sl/tp. Regression tests: `test_zone_bounds_are_kept_verbatim_not_averaged`,
  `test_zone_with_explicit_price_uses_it`.
- **Vision calls were silently truncated / timed out.** Two bugs hid behind the
  same empty result. (a) No `max_tokens` was sent, so the provider's default cut
  `RICH_CHART_PROMPT`'s large JSON off mid-object (`finish_reason: "length"` ->
  unparseable -> empty struct, indistinguishable from "no levels found"). NEW:
  `max_tokens=8000` (covers a full BTC bias read of ~4900 tokens), overridable
  via `VISION_MAX_TOKENS`. (b) `timeout=60s` was too short for `mimo-v2.5-free`
  to encode a chart AND emit the schema, so ~half the calls died with
  `ReadTimeout` and — because `extract()` swallows exceptions — returned
  "no chart data" silently. NEW: `timeout=180s` (env `VISION_TIMEOUT`) plus
  `retries=2` (env `VISION_RETRIES`) on read timeout, and a loud
  `log.warning` when truncation is detected. After this fix, 4/4 consecutive
  reads of the BTC bias chart returned identical, fully-on-chart levels with
  zero fabrications.

### Added
- **Bias charts now carry their arrow direction + S/R zones.** OLD: `parse_bias`
  detected a bias call from the text word "bias" only and recorded
  `{bias, target, text}`. The drawn arrow on a bias chart was parsed into
  `rich["arrows"]` by the vision adapter and then **discarded**; a chart-only
  bias post (`$BTC` + chart, no "bias" word) fell through to the trade pipeline
  and was dropped as `vision_pending`. NEW: when a bias call carries a chart,
  `_read_chart_bias` pulls the arrow direction
  (`projected_upward_movement`->BULLISH, `projected_downward_movement`->BEARISH)
  and the parsed S/R bounds, enriches the `BiasRecord` (`arrow`, `levels_json`,
  `source`), and persists them (`bias_log` gains `arrow`/`levels_json`/`src`
  columns, added idempotently so existing rows are preserved). A chart-only post
  with a directional arrow is now logged as `bias_logged` (source `chart`)
  instead of being lost; a chart with zones but NO arrow still stays
  `vision_pending` (bias is never invented from zones alone). Arrow/text
  disagreement keeps the text direction and warns. Dashbaord `/bias` now shows
  arrow + source + S/R levels. Bias STILL never trades. Tests:
  `test_text_bias_enriched_with_chart_arrow`,
  `test_chart_only_bias_with_arrow_is_logged_not_pending`,
  `test_chart_with_zones_but_no_arrow_stays_pending`.

### Changed (NOT YET VERIFIED END-TO-END)
- **Hyperliquid order signing rewritten to match HL's current SDK scheme.**
  OLD: `_post_exchange` sent `action` as a JSON *string* and `signature` as a
  concatenated `0x…` hex string, signed via an `Action`/`string` EIP-712 type
  over `chainId 42161`. HL's exchange endpoint rejected every order with
  `422 Failed to deserialize the JSON body`. NEW: `_sign_l1` signs the
  **msgpack-encoded** action as an `Agent` typed message over `chainId 1337`
  with `verifyingContract 0x0…0`, and `_post_exchange` sends `action` as the raw
  OBJECT + `signature` as the `{"r","s","v"}` object — exactly HL's Python SDK
  `sign_l1_action`. A unit test confirms the produced signature recovers to the
  configured wallet address.
  **STATUS:** signing now matches the official SDK byte-for-byte, but LIVE ORDER
  PLACEMENT IS STILL BLOCKED by an HL API/SDK drift. Verified facts:
  - The adapter's signature recovers to the wallet address `0x7030…4A81`
    (offline unit test passes).
  - The OFFICIAL `hyperliquid-python-sdk` 0.24.0 (latest on PyPI) ALSO returns
    `422 Failed to deserialize` on BOTH testnet and mainnet from this env.
  - Tried `chainId` 1337 / 42161 / 421614 for the `Agent` message — all 422.
  - `update_leverage` returns error `3`; `usd_class_transfer` returns
    `Action disabled when unified account is active`.
  This is an external HL API change the published SDK has not caught up to;
  there is no newer SDK to upgrade to. It is NOT an adapter-logic bug. No real
  order was placed during diagnosis; the wallet remains at 9.9 USDC, 0
  positions, 0 fills. The signing fix is kept because it is provably correct
  (signature recovers to the wallet); it simply cannot be exercised until HL's
  API/SDK incompatibility resolves. (Diagnosis note: an early test imported the
  wrong `hyperliquid` PyPI package — ccxt's `hyperliquid 0.4.66` — which shadows
  the official SDK; the bot's own adapter uses only `httpx`+`eth_account` and was
  never affected by that.)

---

## [0.1.17] — 2026-08-10

### Added
- **LLM-backed signal + management parser** (`src/sources/llm_signal.py`). The
  source channel text (trade calls AND manual SL/TP/close messages) is now parsed
  by an OpenAI-compatible LLM (default `tencent/hy3:free` via `LLM_SIGNAL_BASE_URL`
  / `LLM_SIGNAL_MODEL` / `LLM_SIGNAL_API_KEY` in `.env`). The regex parser remains
  as the fallback (used when the key is unset) and as the **cross-check partner**.
- **Cross-check before every trade.** The orchestrator compares the LLM parse
  against the regex parse (and, for chart images, against the vision levels). On
  disagreement of symbol/side (text) or >5% divergence of entry/sl/tp (image vs
  text) it HOLDS and alerts `needs_review` instead of trading a misread. This
  satisfies the "input and output before/after LLM should be wired right" goal:
  LLM is the parser, the independent readers validate it.
- **On-demand `/balance` refresh.** `/balance` now refreshes live perp equity +
  spot USDC before replying (was showing stale hourly snapshot).

### Fixed
- **Equity showed $0.00 on the channel.** `_on_health` only fetched the SPOT
  balance and copied that single number into `equity_usd`, `perp_usdc` AND
  `spot_usdc`. Perp equity is now read from `clearinghouseState.marginSummary.
  accountValue` (its real source) and spot USDC from `spotClearinghouseState`;
  each field is set from its own endpoint. Risk sizing uses perp equity.

### Fixed
- **Equity showed $0.00 on the channel.** `_on_health` only fetched the SPOT
  balance and copied that single number into `equity_usd`, `perp_usdc` AND
  `spot_usdc`. Perp equity is now read from `clearinghouseState.marginSummary.
  accountValue` (its real source) and spot USDC from `spotClearinghouseState`;
  each field is set from its own endpoint. Risk sizing uses the deployable
  equity.
- **Unified-account margin.** This wallet is a Hyperliquid **unified account**:
  spot USDC IS the perp trading margin (the `usdClassTransfer` action is disabled
  on unified accounts — it returns 422 "Failed to deserialize"). When perp
  `accountValue` is 0 but spot USDC > 0, the bot now sizes trades from the spot
  USDC (the real available margin) instead of 0. (The `usd_class_transfer`
  method in `hyperliquid.py` was corrected to HL's dedicated user-signed-action
  scheme for classic accounts that do need it; it is a no-op on this wallet.)
- **LLM parser leverage bug.** The LLM signal branch clobbered the default 3x
  with `leverage=0` when the model omitted leverage; now keeps the default.

### Changed
- LLM parser disables itself (regex fallback) when `LLM_SIGNAL_API_KEY` is empty,
  so the bot degrades safely with no key.

## [0.1.15] — 2026-08-10

### Added
- **Durable signal/trade ledger for future evaluation.** The bot previously only
  showed events in chat and kept signals/positions in memory (lost on restart) —
  so win rate, P&L, and signal→outcome could not be measured later. Now a
  Postgres-backed ledger in the same externally-reachable `fatty_config` DB records
  every signal (`signals_log`: symbol/side/source/message_id/**raw_text**/status),
  every order and position open/close (`trades_log`: entry/sl/tp/lev/size/margin on
  open; exit_px/**pnl**/close_reason/dry on close), and market bias (`bias_log`).
  `src/store/ledger.py` (`Ledger`) writes via the `BotDashboard` notifier (the
  single event chokepoint), so the ledger always matches the alerts. New `/trades`
  command reports win rate + net P&L + recent closes; `/bias` reports `bias_log`.

### Changed
- **Bias recorder migrated SQLite -> PostgreSQL.** `src/sources/bias.py`
  (`BiasRecorder`) now writes to `fatty_config.bias_log` (same `app` role, same DB
  as config + ledger). The old local `data/bias.db` SQLite file is gone — there is
  **no SQLite anywhere in the repo** now (config, ledger, and bias are all Postgres).

---

## [0.1.13] — 2026-08-10

### Added
- **Raw signal message now posted to the Telegram bot channel.** Previously a new
  signal alerted only with the parsed `symbol`/`side`/`source`/`message_id`, and
  when parsing yielded nothing the alert showed a bare `?` with no context. Now
  `signal_received` also forwards the original message text (`RawSignal.raw_text`)
  and the dashboard renders it as a `<pre>` block under `raw_message`, so every
  alert shows the actual trade call from `@fattyfatclub` verbatim. Human-verifiable
  even when the parser can't resolve a symbol.

### Changed
- `signal_received(symbol, side, src, mid, raw_text="")` gained a `raw_text`
  argument; `recent_signals` entries now also store `raw`. Orchestrator passes
  `raw.raw_text` on every incoming signal.

### Changed
- **Config store is now PostgreSQL, not SQLite.** `src/config/db.py`
  (`ConfigStore`) talks to a real PostgreSQL 16 server instead of a local
  `data/config.db` file. The old behavior: config lived in a file on the VPS
  filesystem, unreachable from outside the box. New behavior: config lives in the
  `fatty_config` database, bound to `0.0.0.0:5432` on the VPS, so it is reachable
  over TCP from outside the VPS (your laptop, another container, a dashboard).
  Connection string is `CONFIG_DB_URL` in `.env` (non-superuser `app` role, scoped
  to `fatty_config` only). One fresh `psycopg.connect()` per operation keeps it
  safe under asyncio (same reasoning as the python-sqlite-async skill).
- `requirements.txt` now lists `psycopg[binary]>=3.1`.
- Docs (README/ARCHITECTURE/AGENTS) updated: "SQLite" -> "PostgreSQL, externally
  accessible"; removed all `data/config.db` references.

### Added
- A dedicated test database `fatty_config_test` (same schema) so tests never
  touch production config; `test_config_db.py` / `test_multibot_e2e.py` now run
  against Postgres.

### Removed
- The `data/config.db` SQLite file and its schema; the repo no longer carries a
  file-based config. External access also requires opening inbound 5432 in the
  provider's Security Group (edge firewall) — documented in AGENTS.md 3b.

---

## [0.1.10] — 2026-08-10

### Added
- **SQLite-backed, multi-bot configuration (`src/config/db.py`, `ConfigStore`).**
  Runtime config is now a DB, not yaml. One row per bot holds `paper` (dry-run
  gate), `channel`, `testnet`, the TG-token/chat env-var *names*, and a per-bot
  `risk` row. Secrets are never stored in the DB — only env-var names. This
  replaces the single global `config.yaml` so N bots (each its own TG bot token +
  HL account) run independently from one canonical store.
- **`/toggle` now persists to the DB.** The paper<->live switch writes the `paper`
  flag back to `data/config.db`, so a bot's mode survives restarts (previously the
  in-memory flag reset to whatever `config.yaml` said on every reboot).
- **Multi-bot launcher.** `python -m src.main --bot NAME` runs one bot;
  `--all-bots` spawns one supervised child process per enabled bot
  (`scripts/run_bots.sh` restarts any child that crashes). Each child polls its
  own `TG_BOT_TOKEN`, so there is never more than one listener per token.
- `scripts/configure_bot.py` — create/update/list bot rows (paper/live, channel,
  network, token env var, risk) without hand-editing the DB.
- Per-bot dashboard fields (`bot_name`, `channel`, `alert_chat_env`) so status /
  health / deploy alerts name the bot and persist the right chat id per bot.

### Changed
- **`AppConfig.from_bot()`** builds the typed engine config from a DB `BotConfig`
  (`dry_run` == `paper`, `testnet` from the row). The old file-only `AppConfig.load`
  is kept for the safe `run`/`check_tg`/`live_dry` modes.
- **Deploy restart now uses `run_bots.sh`** (supervised, one process per enabled
  bot) instead of a single `--dashboard` process. Guard checks "at least one
  listener running" rather than "exactly one dashboard".
- Docs (`README.md`, `ARCHITECTURE.md`, `AGENTS.md`) corrected: the real signal
  source is the Telegram `@fattyfatclub` channel (not Bybit), and the canonical
  config is now the DB. Stale "always starts in dry-run" language removed.

### Fixed
- **Misleading boot log.** `main.py` printed `=== DASHBOARD ready (starts in
  DRY-RUN) ===` even when the config said LIVE. The log now prints the actual
  resolved mode (`PAPER (dry-run)` / `LIVE (real money)`), network, and channel,
  read from the DB. The AGENTS.md rule that claimed "the engine always starts in
  dry-run" was wrong and has been corrected: a bot boots in whatever the DB `paper`
  flag says (paper is configured, not assumed-safe).

---

## [0.1.9] — 2026-08-10

### Added
- `CHANGELOG.md` — this file, the canonical historical record of behavior changes.
- `AGENTS.md` (+ `CLAUDE.md` symlink) — operating manual for AI agents: safety
  rules, signal reality, pitfalls, and the required change workflow.
- `deploy.sh` **guards**: the deploy now runs the full test suite and refuses to
  proceed unless `CHANGELOG.md` documents the release. A non-empty
  `## [Unreleased]` section is auto-promoted to a dated version heading, so the
  history cannot drift from the code. Emergency bypass: `SKIP_GUARDS=1`.

### Fixed
- `deploy.sh` used `pkill -f "src.main --dashboard"`, whose pattern matched the
  deploying shell's own command line and could kill it. It now collects pids via
  `pgrep -f "python3 -m src[.]main --dashboard"` and kills them explicitly.
- `deploy.sh` ran the bot with the system `python3` (no `telethon`); it now
  prefers the Hermes venv interpreter and verifies exactly one dashboard process
  is running after restart.

---

## [0.1.8] — 2026-08-10

Management vocabulary aligned to the **real** `@fattyfatclub` message formats,
after auditing ~400 channel messages.

### Context: no multi-TP exists
All 11 captured full trade calls contain exactly **one** `TARGET:`. The channel
does not send multi-TP signals. Scale-out / multi-TP was **explicitly rejected**
as a feature: building it would require inventing price levels the signal never
stated, violating "the signal is the source of truth". The channel's actual risk
management style is *one target, then move SL to breakeven* — that is what we
automate. Do not re-open this without new evidence from the channel.

### Added
- `parse_management` action `close_at_entry` (`close pump at entry`) — places a
  reduce-only **LIMIT at `pos.entry_px`** (true breakeven exit).
- `parse_management` action `partial_close` (`book profits on $ONDO`) —
  reduce-only **MARKET for 50%** of position size. The signal never states a
  fraction; **0.5 is our documented default**, not a signal-derived number.
- `parse_management` action `cancel_entry` (`cancel PENGU limit`) — cancels
  resting **entry** orders. Handled in `Orchestrator._apply_management` *before*
  the `pos is None` guard, because it acts on an order, not a position. Skips
  any `reduce_only` order so a protective SL/TP can never be cancelled.
- `parse_management` action `sl_hit` (`sl hit on XAI`) — sends no orders; clears
  local position state (the exchange already closed the position).
- `extract_management_token()` in `src/sources/parser.py` — extracts the coin
  from messages with **no `$`/`#` sigil** (`close pump at entry` -> `PUMP`,
  `sl hit on XAI` -> `XAI`, `cancel PENGU limit` -> `PENGU`) using phrase
  regexes plus a `_BARE_STOPWORDS` filter.
- `scripts/replay_mgmt.py` — seeds fake positions and replays the real
  management messages through the live `_apply_management` in dry-run.
- `tests/test_parser_real.py::test_mgmt_real_formats` — asserts action + token
  for every real format above.

### Changed
- **BREAKING (behavior):** `booking profits` / `book profits` was `tp_hit`,
  which closed **100%** of the position. It is now `partial_close` at **50%**.
- Management token resolution in `_apply_management` now uses
  `extract_management_token` instead of `extract_token` (sigil-only).
- `tests/test_parser_real.py::test_mgmt_booking_profits_is_tp_hit` updated to
  the new contract (the old assertion encoded the 100%-close behavior).

### Fixed
- `close pump at entry` previously parsed as generic `close` -> fired a **market
  close at whatever price the market was at**, not at entry. Also returned token
  `None`, so it could not find its position at all.
- `cancel PENGU limit` and `sl hit on XAI` previously returned `None` from
  `parse_management` and were silently dropped as noise. `sl hit` left a stale
  local position that the bot believed was still open.

### Pitfall recorded
Branch ordering in `parse_management` matters: the `cancel_entry` / `sl_hit` /
`close_at_entry` / `partial_close` checks must sit **above** the generic
`sl to entry` and `close` branches, or the generic branches swallow them.

---

## [0.1.7] — 2026-08-10

### Added
- **Bias recording.** Market-bias posts are parsed by `parse_bias()` and stored
  in `data/bias.db` (SQLite) via `BiasRecorder`, surfaced with a 🧭 alert and
  reviewable with `/bias [COIN]`. Record-only by design — the bot never trades a
  bias post. The branch sits after management, before the media/vision branch.

### Fixed
- **Bias detector swallowed chart signals.** `parse_bias` matched any
  (directional word + token), so a caption like `$BTC range identified` returned
  `bias_logged` and the vision path never ran — charts were silently never
  traded. `parse_bias` now **requires the literal word "bias"**.
  Regression guard: `tests/test_media_routing.py`.
- **Leverage silently collapsed to 1x.** `RiskManager.compute_size` computed
  `eff_lev = int(min(notional / free_margin, cap))`; a risk-sized position
  (e.g. $5.94 notional against $9.9 margin) implied `0.6` -> floored to `1`, so
  `set_leverage(symbol, 1)` was sent and the intended 3x was dropped. Now
  `eff_lev = int(min(default_leverage, cap))` unless the notional genuinely
  exceeds `free_margin × cap`.
- **sqlite3 + asyncio "Cannot operate on a closed database."** A connection
  created in sync scope and reused from a coroutine dies on Python 3.11+. Fixed
  by opening a fresh connection per operation and closing it in `finally`.

---

## [0.1.6] — 2026-08-09

### Added
- **Risk-based dynamic sizing** replacing the fixed `$1 × 3x`. Every trade risks
  `equity × risk_pct` (2%), sized from the signal's actual stop-loss distance.
  `OrderService.set_equity()` is refreshed on each health check so sizing
  self-scales with the account.
- **Manual override commands** so the user can intervene if the bot misses:
  `/close SYMBOL [size]` (market flatten) and
  `/jump SYMBOL BUY|SELL [margin_usd]` (manual entry).
- Hourly 💓 health check (`_health_loop`, 3600s) refreshing balance/positions.

### Changed
- Sizing config lives in `src/services/risk.py` (`RiskConfig`); the `risk:` block
  in `config.yaml` is **not** read for sizing.

### Fixed
- `/toggle` was a sync function that `bot.py` `await`ed -> the live/paper switch
  silently never flipped. Any handler in `state.handlers` must be `async def`.
- `run_bot()` hardcoded `dry_run = True`, overriding `config.yaml`. Now
  `dry_run = bool(cfg.dry_run)`, so config decides boot mode and `/toggle` is the
  runtime switch.
- Alert chat lost on restart — the chat id is now persisted to `.env` on first
  contact, with a `TG_OWNER_CHAT` fallback.

---

## [0.1.5] — 2026-08-09

### Added
- **Telegram Bot API dashboard** (`src/notifier/bot.py`): rich event notifier
  plus slash-command control surface (`/status /positions /balance /signals
  /last /toggle /close /jump /test /help`), decoupled from the telethon
  user-account signal source.
- **Versioning + deploy health check**: root `VERSION` file, `deploy.sh`, and a
  🚀 Deployed message on startup.

### Fixed
- Slash menu was blank because `bot.set_my_commands()` was never called at
  startup — registering handlers alone is not enough.

### Removed
- The two-step `--go-live` + `/live <token>` flow, replaced by a single
  `/toggle`. (User preference: simplest viable control surface.)

---

## [0.1.4] — 2026-08-09

### Added
- **Always-on listener**: `scripts/fatty_watchdog.sh` restart loop plus a Hermes
  cron heartbeat that restarts the watchdog if the listener dies.
- `scripts/audit_tokens.py` / `scripts/audit_prefix.py` cross-referencing channel
  tokens against the live testnet + mainnet perp universes.

### Fixed
- **Token alias collapse.** The channel mixes `BOMSEUSDT` and `$BOME` for one
  coin; without collapsing, positions and resolutions split across two keys.
  Any `BASEUSDT` is now normalized to its base, plus an explicit alias map.

### Documented
- **No `1000*` prefix exists on Hyperliquid** (verified across 210 testnet + 232
  mainnet assets). `1000X` is a Binance-ism. Small-unit names use only the `k`
  prefix (`kBONK`). Max leverage anywhere on the venue is 40x — there are no
  1000x contracts.

---

## [0.1.3] — 2026-08-09

### Added
- **`PositionManager.apply_management`** turning parsed management actions into
  concrete order plans (`sl_to_entry`, `sl_to <price>`, `tp_hit`, `close`,
  `manage`), with `Position` gaining `sl_px` / `sl_order_id` / `tp_px`.
- **Offline local vision backend** (`src/sources/local_vision.py`): OpenCV +
  Tesseract read a chart's colored level tags by colour and OCR the prices. No
  API key, no network. `VISION_BACKEND=local`.
- `scripts/replay_real.py` — replays real captured messages and chart images
  through the live orchestrator in dry-run.

### Fixed
- Two live-path crashes that unit tests missed and that would have broken
  `--live-dry` on the first real signal:
  1. `_apply_management` referenced `extract_token` without importing it ->
     `NameError` on every live `sl to entry`.
  2. `VisionExtractor.extract` passed an undefined `config` to the local backend
     -> `NameError` on every chart image.

### Documented
- **Free-tier cloud vision quota is dead.** Three Gemini keys and one OpenAI key
  all had valid format but zero quota. A valid-format key is **not** proof that
  vision works — probe with `scripts/verify_vision_key.py`.

---

## [0.1.2] — 2026-08-08

### Changed
- **Parser rewritten for the REAL channel format**, proven against 100 live
  messages. Previous match rate was ~0%. The real format is multi-line:
  `#TOKEN $TOKEN LONG TRADE` / `ENTRY:` / `TARGET:` / `STOPLOSS:`, no leverage
  field and no USDT suffix. Backward-compatible with the old single-line
  `BTCUSDT LONG entry .. sl .. tp .. lev ..` form.

### Added
- Media/image signal routing to the vision pipeline (chart screenshots with a
  short caption), rather than discarding them as noise.
- `SymbolResolver`: `$TOKEN` -> canonical perp ticker via exact match, then
  `k`-prefixed variant, else skip. `$TOKEN` is **not** a 1:1 map to the ticker.
- Telegram user-session (telethon `StringSession`) signal source.

---

## [0.1.1] — 2026-08-08

### Added
- Hyperliquid adapter (raw `httpx` REST + `websockets`), market-data WS stream,
  and the `Orchestrator` wiring signal -> normalize -> validate -> risk -> order.
- Safe entrypoint: `python -m src.main` runs a testnet connectivity check and a
  simulated pipeline, placing zero orders.

### Documented
- The bot does **not** depend on the PyPI `hyperliquid` SDK.
  `ModuleNotFoundError: No module named 'hyperliquid'` is expected and harmless.

---

## [0.1.0] — 2026-08-08

### Added
- Initial architecture: domain model, interfaces, normalizer, validator, risk /
  order / position services, pydantic config loader, and project documentation.
- USDT (signal) -> USDC (execution) normalization as a first-class concern, with
  a stablecoin peg guard.
