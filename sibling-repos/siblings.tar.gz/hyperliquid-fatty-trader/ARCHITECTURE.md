# Architecture

Clean, SOLID-aligned architecture for a system that ingests **Telegram
`@fattyfatclub` trade signals** (USDT-quoted calls) and executes on
**Hyperliquid (USDC perps)**.

## SOLID mapping

- **S — Single Responsibility:** each module owns one job.
  - `SignalSource` only reads raw signals (Telegram `@fattyfatclub` listener).
  - `SignalNormalizer` only maps channel USDT -> Hyperliquid/USDC.
  - `SignalValidator` only enforces structural + policy rules.
  - `RiskManager` only computes size/leverage from portfolio state.
  - `OrderService` only translates a validated signal into order requests.
  - `ExchangeAdapter` only talks to Hyperliquid.
  - `PositionManager` only tracks live positions from the WS.
  - `MarketDataStream` only delivers pushes (mark, book, fills, orders).
  - `Notifier` only sends user messages.
- **O — Open/Closed:** new signal sources or venues are added via new adapters
  behind existing interfaces; the orchestrator and services never change.
- **L — Liskov Substitution:** any `SignalSource` / `ExchangeAdapter` /
  `Notifier` implementation is substitutable for its interface.
- **I — Interface Segregation:** interfaces are small and role-specific
  (`SignalSource`, `ExchangeAdapter`, `RiskPolicy`, `Notifier`, `MarketStream`).
- **D — Dependency Inversion:** high-level `Orchestrator` depends on interfaces,
  not concretes. Concrete adapters are injected at composition root (`main.py`).

## Layer diagram

```
┌──────────────────────────────────────────────────────────────────┐
│ orchestrator.py  (composition root, dependency injection)         │
└───────┬───────────────┬──────────────┬──────────────┬────────────┘
        │               │              │              │
   sources/         services/      exchanges/      streaming/     notifier/
   SignalSource     Normalizer      ExchangeAdapter MarketDataStream  Notifier
   (telegram)       Validator       (hyperliquid)  UserEventStream
                    RiskManager
                    OrderService
                    PositionManager
        │               │              │              │
        └─────── domain/ (Signal, Instrument, Order, Position, UsdNotional)
```

## Domain model (the heart)

These are pure, framework-free dataclasses. No exchange SDK, no asyncio, no IO.

```python
@dataclass(frozen=True)
class Instrument:
    symbol: str          # Hyperliquid canonical: "BTC" (perp) / "BTC-PERP"
    base: str            # "BTC"
    quote: str = "USDC"  # Hyperliquid always settles in USDC
    venue: str = "hyperliquid"

@dataclass(frozen=True)
class UsdNotional:
    """Risk is expressed in USD; the settlement asset is a separate concern."""
    amount_usd: float
    settlement: Literal["USDT", "USDC"] = "USDC"

@dataclass
class Signal:
    instrument: Instrument
    side: Literal["BUY", "SELL"]          # mapped from LONG/SHORT
    entry: float | None                   # in USDC (post-normalization)
    sl: float | None
    tp: float | None
    notional: UsdNotional                 # risk budget in USD
    leverage: int
    confidence: float
    raw: dict                             # original channel payload (audit)
    source: str = "fattyfatclub"
```

Key point: **prices in `Signal` are already in USDC** (normalized). The channel's
USDT price only ever exists in `RawSignal`/`raw`. This keeps the rest of the
system ignorant of which stablecoin the signal used.

## The USDT ↔ USDC boundary (handled once)

Only `SignalNormalizer` knows about the mismatch:

1. Parse the channel's `#TOKEN $TOKEN LONG TRADE` call -> base `TOKEN`, quote `USDT`.
2. Look up the live **USDT/USDC peg rate** (from a `PegSource`, e.g. a stablecoin
   index or HL's own USDC price). Default 1.0 with a tight tolerance.
3. Convert every USDT price to USDC: `usdc_price = usdt_price * peg_rate`.
4. Emit a `Signal` with `instrument=TOKEN`, `quote=USDC`, prices in USDC.
5. `StablecoinPegGuard` runs inside validation and rejects the signal if
   `|peg_rate - 1| > max_depeg` (e.g. 0.5%), preventing trades through a depeg.

This satisfies the requirement that the difference is "properly handled in the
architecture" rather than scattered as `* 1.0` hacks. See
`docs/usdt-usdc-normalization.md`.

## Execution role (Hyperliquid)

- **REST (minimal):** place/cancel orders, maybe query open orders on bootstrap.
- **WebSocket (primary):**
  - `wss://api.hyperliquid.xyz/ws` (mainnet) / `.../ws` on testnet.
  - `l2Book`, `allMids`, `bbo`, `trades` for market data.
  - `userEvents` (subscribed after auth) for positions, orders, fills.
- SL/TP: Hyperliquid supports order types natively (limit, trigger market/limit).
  The `OrderService` emits SL/TP as separate child orders tied to the position.

## Resilience

- **Backpressure-free pushes:** WS stream writes to bounded queues; services
  consume asynchronously.
- **Reconnect with jittered backoff**; on reconnect, re-subscribe + refetch
  positions via `clearinghouseState`.
- **No datacenter IP ban risk:** Hyperliquid API is not a CEX that blocks cloud
  ranges, so the bans we hit on Binance do not occur here.
- **Idempotency:** every order carries a client order id; duplicate sends are
  de-duplicated before hitting the wire.
- **Circuit breaker:** if the adapter reports a fatal condition, the orchestrator
  halts new orders and notifies, without crashing the stream.

## Config & secrets

- **PostgreSQL `fatty_config` (`src/config/db.py`, `ConfigStore`):** canonical,
  multi-bot config. Runs as a real server on the VPS, bound to `0.0.0.0:5432`, so
  the config is reachable from outside the box over TCP. One row per bot
  (`paper`, `channel`, `testnet`, TG token env var, risk). The `paper` flag IS the
  dry-run/live gate and is persisted — `/toggle` in the chat flips it and writes
  it back. Secrets are never stored here, only the *env-var names* that hold them;
  the connection string is `CONFIG_DB_URL` in `.env` (non-superuser `app` role).
- `config.yaml` (committed as `config.example.yaml`): optional file fallback /
  legacy path; not the primary source anymore.
- Secrets (HL private key / session key, TG bot token, TG_API_ID/HASH) come from
  env or `.env` (git-ignored). Never hard-coded.

## Testability

Because domain is pure and ports are interfaces, each service is unit-tested with
fakes:
- `FakeSignalSource`, `FakeExchangeAdapter`, `InMemoryNotifier`.
- Normalizer/validator tests use recorded channel payloads.
- No network in unit tests; integration tests (separate, opt-in) hit testnet.
