# Code Review — Phases 0-5 (pre-Phase-6 gate)

Reviewed: domain model, interfaces, normalizer, validator, risk, order, position, peg.
Scope: full static read of all 10 source files + full unit suite (14 passing) + compileall (clean).

## Verdict: LEGIT — no Critical / High / Medium findings.

### Critical / High / Medium
None.

### Low (3, all non-blocking)
1. ~~`RiskManager.compute_size` ignores signal leverage~~ — WITHDRAWN: it passes
   `sig.leverage` as the cap (`eff_lev = min(default_leverage, cap)`), so the
   signal's requested leverage is honored up to the default cap. Correct.
2. `OrderService.build_orders` child SL/TP size uses full `coin_size` (not the
   frontrun-split remainder). Correct for single-position semantics; if the
   resting 75% limit never fills, SL/TP for 100% exist while only 25% open.
   Acceptable; document if multi-fill handling is added later.
3. `Instrument.from_usdt_pair` strips only trailing `USDT`; non-USDT pairs would
   mis-parse. Safe in practice (signals are Bybit USDT pairs).

### Warnings (2)
1. `ConstantPegSource(1.0)` is the default → depeg guard is dormant until a live
   `HyperliquidPegSource` is wired (Phase 6/7). Documented fallback, not a bug.
2. `PositionManager` dict is not locked; safe under a single async loop, add
   `asyncio.Lock` only if multi-task concurrency is introduced.

### End-to-end trace (verified by tests)
RawSignal(USDT) -> SignalNormalizer (USDT->USDC) -> SignalValidator
(confidence + SL/TP sanity) -> RiskManager.compute_size (USD->coin)
-> OrderService.build_orders (entry + frontrun split + SL/TP triggers)
-> PositionManager store. All pure, zero network, all green.

Conclusion: safe to proceed to Phase 6 (Hyperliquid adapter).

---

# Code Review — Bug-fix + runnable layer (post-Phase-9 hardening)

Scope: fixed latent crashes (RawSignal fields, dotenv dep, dataclass default
order, orchestrator image_path), added the missing runnable layer: free-text
`parse_signal`/`parse_management` parser, `src/config/loader.py` (pydantic),
`config.example.yaml`, `src/main.py` safe entrypoint, `TelegramNotifier`,
`tests/test_parser.py`, README/REVIEW refresh.

## Verdict: LEGIT — no Critical / High findings. Safe to commit.

### Verification performed
- `python -m compileall -q src` clean.
- `pytest` green: **37 passed** (was 26; +11 new parser + notional tests).
- SAFE end-to-end run (`python -m src.main`): testnet=True, dry_run=True.
  - Key derives to 0x3016...874e, **match=True** (wallet key/address consistent).
  - `POST https://api.hyperliquid-testnet.xyz/info` 200 OK (positions/orders/fills).
  - Pipeline status `dry-run`; **zero orders placed**; wallet untouched.

### Notes (non-blocking)
1. WS `allMids` returned `BTC mark = None` within the 5s window on testnet.
   Pipeline still completes via `entry` fallback. Robustness: extend wait /
   add resubscribe-backoff check. Not a correctness bug.
2. `.env` / `config.yaml` confirmed git-ignored (`git check-ignore`). Private
   key never committed, never stored in agent memory. Mainnet never contacted
   (`api.hyperliquid.xyz` absent from logs).
3. Live Telegram channel still requires user-supplied `TG_API_ID` /
   `TG_API_HASH` / `SESSION_STRING`; the source now parses messages but needs
   those creds to connect. Not wired to live until provided.

### Safety posture
- Defaults: `dry_run=True`, `testnet=True`. No path in this commit places a
  real order or reaches mainnet.
