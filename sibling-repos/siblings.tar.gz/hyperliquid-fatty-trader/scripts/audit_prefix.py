"""Scan live universes for prefix-style name variants of channel tokens.

Hyperliquid uses BOTH:
 - k-prefix on testnet (kBONK)
 - 1000-prefix on mainnet (1000BONK, 1000PEPE, ...) for small-unit tokens
Neither is a leverage tier (no 1000x contracts exist). The resolver must map
source token -> correct prefixed ticker.
"""
import asyncio, json, sys
sys.path.insert(0, ".")
from src.sources.symbol_map import fetch_universe, _normalize_token
from src.sources.parser import extract_token

async def main():
    d = json.load(open("docs/channel_sample.json"))
    bases = sorted({_normalize_token(extract_token(m.get("text") or ""))
                    for m in d["messages"] if extract_token(m.get("text") or "")})
    testnet = await fetch_universe(testnet=True, force=True)
    mainnet = await fetch_universe(testnet=False, force=True)

    def variants(uni, base):
        out = {}
        if base in uni: out["exact"] = base
        if f"k{base}" in uni: out["k"] = f"k{base}"
        if f"1000{base}" in uni: out["1000"] = f"1000{base}"
        return out

    print("=== CHANNEL TOKEN -> HL TICKER MAPPING (both venues) ===")
    for base in bases:
        t = variants(testnet, base)
        m = variants(mainnet, base)
        row = f"  {base:8} testnet={str(t or 'NONE'):<28} mainnet={m or 'NONE'}"
        print(row)

    # Also report ALL 1000* / k* tickers in each universe (to confirm naming)
    k_t = [n for n in testnet if n.startswith("k")]
    k_m = [n for n in mainnet if n.startswith("k")]
    x_t = [n for n in testnet if n.startswith("1000")]
    x_m = [n for n in mainnet if n.startswith("1000")]
    print(f"\ntestnet  k* tickers ({len(k_t)}): {sorted(k_t)[:20]}{'...' if len(k_t)>20 else ''}")
    print(f"mainnet  k* tickers ({len(k_m)}): {sorted(k_m)[:20]}{'...' if len(k_m)>20 else ''}")
    print(f"testnet  1000* tickers ({len(x_t)}): {sorted(x_t)[:20]}{'...' if len(x_t)>20 else ''}")
    print(f"mainnet 1000* tickers ({len(x_m)}): {sorted(x_m)[:25]}{'...' if len(x_m)>20 else ''}")

asyncio.run(main())
