"""Audit channel tokens vs Hyperliquid universe.

For every message in docs/channel_sample.json:
 - extract token(s) from text caption (and note if media-only with no $TOKEN)
 - resolve against LIVE testnet + mainnet universes
 - classify: listed(testnet) / listed(mainnet-only) / unlisted
 - flag image-only posts with NO $TOKEN caption -> vision_pending candidates
 - build a name-difference map (source token -> HL ticker) including k-prefix
"""
import asyncio, json, re, sys
sys.path.insert(0, ".")
from src.sources.symbol_map import fetch_universe, _normalize_token
from src.sources.parser import extract_token

async def main():
    d = json.load(open("docs/channel_sample.json"))
    msgs = d["messages"]
    testnet = await fetch_universe(testnet=True, force=True)
    mainnet = await fetch_universe(testnet=False, force=True)
    print(f"testnet universe size : {len(testnet)}")
    print(f"mainnet universe size: {len(mainnet)}")

    seen = {}  # token -> set of statuses
    vision_pending = []  # (id, text) media-only no $TOKEN
    for m in msgs:
        mid = m["id"]
        text = m.get("text") or ""
        has_media = m.get("has_media", False)
        tok = extract_token(text)
        if tok:
            base = _normalize_token(tok)
            in_test = base in testnet
            in_main = base in mainnet
            in_test_k = f"k{base}" in testnet
            in_main_k = f"k{base}" in mainnet
            if in_test:
                status = f"LISTED(testnet:{base})"
            elif in_test_k:
                status = f"LISTED(testnet:k{base})"
            elif in_main:
                status = f"mainnet-only:{base}"
            elif in_main_k:
                status = f"mainnet-only:k{base}"
            else:
                status = "UNLISTED"
            seen.setdefault(base, set()).add(status)
        elif has_media:
            # media but no $TOKEN in caption -> vision_pending candidate
            vision_pending.append((mid, text.strip()[:50]))

    print("\n=== TOKEN CLASSIFICATION (by base) ===")
    unlisted = []
    for base in sorted(seen):
        sts = seen[base]
        line = f"  {base:10} -> {sorted(sts)}"
        print(line)
        if any("UNLISTED" in s for s in sts) or all("mainnet-only" in s for s in sts):
            unlisted.append((base, sorted(sts)))

    print("\n=== UNLISTED / MAINNET-ONLY on testnet (skipped in testnet mode) ===")
    for base, sts in sorted(unlisted):
        print(f"  {base:10} -> {sts}")

    print(f"\n=== IMAGE-ONLY POSTS WITH NO $TOKEN CAPTION ({len(vision_pending)}) ===")
    for mid, t in vision_pending:
        print(f"  [{mid}] {t!r}")

    # Name-difference map: source base -> HL ticker when they differ
    print("\n=== NAME DIFFERENCES (source token -> HL ticker) ===")
    diffs = {}
    for m in msgs:
        tok = extract_token(m.get("text") or "")
        if not tok:
            continue
        base = _normalize_token(tok)
        for uni_name, uni in (("testnet", testnet), ("mainnet", mainnet)):
            if base in uni:
                if base != uni_name and False:
                    pass
                # exact match, same name
                break
            if f"k{base}" in uni:
                diffs[base] = f"k{base} ({uni_name})"
                break
    for base, hl in sorted(diffs.items()):
        print(f"  {base:10} -> {hl}")

asyncio.run(main())
