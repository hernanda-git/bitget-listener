"""End-to-end verification of the dashboard notifier + orchestrator wiring.

Runs fully offline (no network, no real keys needed for the notifier path):
 - builds a BotDashboard with a fake app (captures sent messages)
 - runs a sample signal through the orchestrator in dry-run
 - asserts rich events fired (signal received, parse, order placed)
 - exercises the slash-command renderers (/status, /positions, /balance...)

Run: python scripts/verify_dashboard.py
"""

import asyncio
import sys

# Fake out telegram before importing the dashboard so no real client is built.
import types
import src.notifier.bot as botmod

from src.notifier.bot import BotDashboard, DashboardState
from src.orchestrator import Orchestrator, OrchestratorConfig
from src.domain.model import RawSignal, Side
from src.sources.parser import parse_signal


class FakeApp:
    """Captures send_message calls instead of hitting Telegram."""
    def __init__(self):
        self.sent = []

    async def initialize(self):
        pass

    async def start(self):
        pass

    async def stop(self):
        pass

    async def shutdown(self):
        pass

    class _Bot:
        def __init__(self, cap):
            self._cap = cap
        async def send_message(self, chat_id, text, parse_mode=None):
            self._cap.append((chat_id, text))
    @property
    def bot(self):
        return FakeApp._Bot(self.sent)
    @property
    def updater(self):
        class U:
            async def start_polling(self):
                pass
            async def stop(self):
                pass
        return U()


class FakeMarket:
    def mark_price(self, symbol):
        return {"BTC": 60000.0}.get(symbol, 1.0)
    async def start(self):
        pass
    async def stop(self):
        pass


class FakeAdapter:
    async def place_order(self, o):
        return "fake-order-id"
    async def cancel_order(self, inst, cid):
        return True


async def main():
    state = DashboardState()
    state.testnet = True
    state.wallet = "0x1111111111111111111111111111111111111111"  # dummy, public-repo safe
    state.alert_chat = "testchat"  # simulate that the user already contacted the bot
    dash = BotDashboard(token="fake", state=state)
    dash.app = FakeApp()  # inject fake app; start() won't be called

    # 1) Sample signal -> orchestrator (dry-run)
    parsed = parse_signal("BTCUSDT LONG entry 60000 sl 58000 tp 64000 lev 10")
    # Promote parsed RawSignal to look like channel input
    raw = RawSignal(
        symbol_usdt="BTCUSDT",
        side=Side.BUY,
        entry_usdt=60000.0, sl_usdt=58000.0, tp_usdt=64000.0,
        leverage=10, notional_usd=100.0, confidence=0.8,
        raw_text="BTCUSDT LONG entry 60000 sl 58000 tp 64000 lev 10",
        source="fattyfatclub", message_id=12345,
    )
    orch = Orchestrator(
        source=None, peg=__import__("src.services.peg", fromlist=["ConstantPegSource"]).ConstantPegSource(1.0),
        adapter=FakeAdapter(), market=FakeMarket(), notifier=dash,
        config=OrchestratorConfig(dry_run=True, testnet=True),
    )
    orch.resolver = __import__("src.sources.symbol_map", fromlist=["SymbolResolver"]).SymbolResolver(
        testnet=True, universe={"BTC": 40, "ETH": 25, "SOL": 20})
    status = await orch.handle_signal(raw)
    print("pipeline status:", status)
    print("captured alerts:")
    for chat, txt in dash.app.sent:
        print("  -", txt.replace("\n", " | "))

    # 2) Slash command rendering
    state.mode = "dry-run"
    state.equity_usd = 12.10
    state.perp_usdc = 12.10
    state.spot_usdc = 0.0
    print("\nformatted /status:")
    # reuse internal formatter
    from src.notifier.bot import _esc, _money
    print(f"  Mode: {_esc(state.mode)} | Equity: ${_money(state.equity_usd)}")

    # 3) exception path
    await dash.exception("test_where", "something blew up")
    last = state.last_event
    print("\nlast event after exception:", last["title"], "|", last["fields"])

    ok = status == "dry-run" and len(dash.app.sent) >= 2
    print("\nVERIFY:", "PASS" if ok else "FAIL")
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    asyncio.run(main())
