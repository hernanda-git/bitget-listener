"""List every message the live pipeline classifies as NOISE (text-only, not a
trade, not management, not a chart). Cross-reference against the handoff's
curated 16-noise list."""
import json, sys
sys.path.insert(0, ".")
from src.sources.parser import parse_signal, parse_management, extract_token

d = json.load(open("docs/channel_sample.json"))
msgs = d["messages"]

noise = []
for m in msgs:
    mid = m["id"]
    text = m.get("text") or ""
    has_media = m.get("has_media", False)
    sig = parse_signal(text)
    mg = parse_management(text)
    if sig is None and mg is None and not has_media:
        noise.append((mid, text.strip()))

print(f"TOTAL messages: {len(msgs)}")
print(f"NOISE (current pipeline) count: {len(noise)}\n")
for mid, t in noise:
    disp = t if t else "<empty/media-only-without-text>"
    print(f"[{mid}] {disp!r}")
