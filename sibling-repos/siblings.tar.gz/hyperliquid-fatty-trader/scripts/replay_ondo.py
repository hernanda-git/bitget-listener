"""Replay the real ONDO short message through the live-dry orchestrator.

Proves the parser fix produces a SELL entry with SL, dry_run only, no orders.
"""
import sys, asyncio
sys.path.insert(0, ".")
from src.orchestrator import Orchestrator, OrchestratorConfig
from src.domain.model import RawSignal
from src.sources.parser import parse_signal
from src.services.peg import ConstantPegSource


class N:
    def __init__(self): self.sent = []
    async def send(self, t):
        self.sent.append(t)
        print("NOTIFY:", t)


class M:
    def mark_price(self, sym): return 0.345


TEXT = "shorted $ONDO here at 0.345 / Stoploss above 0.3545"


async def go():
    n = N()
    orch = Orchestrator(
        source=None, peg=ConstantPegSource(1.0), adapter=None,
        market=M(), notifier=n,
        config=OrchestratorConfig(dry_run=True, testnet=True))
    sig = parse_signal(TEXT)
    print("PARSED:", sig.symbol_usdt, sig.side, "entry", sig.entry_usdt, "sl", sig.sl_usdt)
    raw = RawSignal(message_id=15947, channel="fattyfatclub", raw_text=TEXT,
                    has_media=True, symbol_usdt=sig.symbol_usdt)
    raw.side = sig.side
    raw.entry_usdt = sig.entry_usdt
    raw.sl_usdt = sig.sl_usdt
    raw.confidence = 0.8
    status = await orch.handle_signal(raw)
    print("STATUS:", status)
    print("---- notifications:", len(n.sent))


asyncio.run(go())
