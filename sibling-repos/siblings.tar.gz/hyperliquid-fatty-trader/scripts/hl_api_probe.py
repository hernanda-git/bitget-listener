"""Hyperliquid API-drift monitor.

WHY: our order adapter signs correctly (signature recovers to the wallet) but
HL's exchange endpoint currently rejects EVERY order with `422 Failed to
deserialize` — and the official `hyperliquid-python-sdk` 0.24.0 does too, on
both testnet and mainnet. This is an external HL API change the SDK hasn't
caught up to, so live order placement is BLOCKED until HL reverts/fixes it.

WHAT THIS DOES: once per run, attempt a TINY testnet order (zero real-money
risk) through our real adapter. If it suddenly SUCCEEDS, the API has recovered
and live verification can proceed. Writes a status file the dashboard/cron can
read, and prints a one-line verdict. Exits 0 if blocked (expected), 0 if
recovered (so cron can alert on a separate "recovered" signal), and 1 only on
unexpected internal error.

Safe: testnet only, tiny notional, order is cancelled immediately after.
"""
from __future__ import annotations

import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from dotenv import load_dotenv

load_dotenv(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), ".env"))

from src.exchanges.hyperliquid import HyperliquidAdapter
from src.domain.model import OrderRequest, OrderType, Side, Instrument, Settlement


STATUS_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "data", "hl_api_status.json")


def _write_status(placeable: bool, detail: str) -> None:
    import json
    os.makedirs(os.path.dirname(STATUS_PATH), exist_ok=True)
    with open(STATUS_PATH, "w") as f:
        json.dump({
            "placeable": placeable,
            "detail": detail,
            "ts_ms": int(time.time() * 1000),
        }, f)


def main() -> int:
    key = os.getenv("HL_PRIVATE_KEY")
    addr = os.getenv("HL_ACCOUNT_ADDRESS")
    if not key or not addr:
        print("HL_API_PROBE: no credentials in .env -> cannot probe")
        return 1

    ad = HyperliquidAdapter(private_key=key, account_address=addr, testnet=True)
    mids = ad._info({"type": "allMids"})
    px = float(mids.get("BTC") or 0)
    if not px:
        print("HL_API_PROBE: could not read testnet mark -> indeterminate")
        _write_status(False, "no testnet mark")
        return 0

    # tiny testnet market order, immediately cancelled
    sz = 0.000001  # well below any min; we only care if the API accepts the call
    req = OrderRequest(
        instrument=Instrument(symbol="BTC", base="BTC", quote=Settlement.USDC),
        side=Side.BUY, order_type=OrderType.MARKET, price=None,
        size_coin=sz, reduce_only=False, client_order_id="PROBE_" + str(int(time.time())),
        is_market=True,
    )
    import asyncio

    async def _probe() -> str | None:
        try:
            oid = await ad.place_order(req)
            # recovered! cancel it immediately
            try:
                await ad.cancel_order(req.instrument, oid)
            except Exception:
                pass
            return oid
        except Exception as e:  # noqa: BLE001
            return f"ERR:{e}"

    res = asyncio.run(_probe())
    if res is None:
        print("HL_API_PROBE: unexpected — place_order returned None")
        _write_status(False, "none")
        return 1
    if res.startswith("ERR:"):
        msg = res[4:]
        if "422" in msg:
            print("HL_API_PROBE: still BLOCKED (422 from /exchange) — unchanged, expected.")
            _write_status(False, "422 exchange")
            return 0
        print(f"HL_API_PROBE: unexpected error: {msg[:200]}")
        _write_status(False, f"unexpected: {msg[:120]}")
        return 1
    print(f"HL_API_PROBE: RECOVERED — testnet order accepted (oid={res}). Live verification can proceed.")
    _write_status(True, f"testnet order accepted oid={res}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
