"""Populate the `hl_pair_min_notional` table from Hyperliquid's live `meta` + `allMids`.

Usage:
    python3 scripts/refresh_pair_min_notional.py            # mainnet
    python3 scripts/refresh_pair_min_notional.py --testnet # testnet

Uses the same `.env` credentials as the bot. Writes every perp pair's
szDecimals / maxLeverage / mid / computed floor into Postgres (fatty_config).
The floor is the documented default ($10 for majors) unless a per-coin
override has been set via `MinNotionalStore.upsert_pair(is_floor_from_api=True)`.

Honesty note: Hyperliquid does NOT expose per-asset `minTradeNtl` via any public
`info` endpoint. The `min_notional` stored here is computed from the documented
default; `is_floor_from_api` is FALSE for these rows. When HL publishes the true
per-coin minimum (or a working request reveals it), override per coin.
"""
import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from dotenv import load_dotenv

from src.exchanges.hyperliquid import HyperliquidAdapter
from src.store.min_notional import MinNotionalStore


def main() -> int:
    load_dotenv()
    ap = argparse.ArgumentParser()
    ap.add_argument("--testnet", action="store_true")
    ap.add_argument("--floor", type=float, default=None,
                    help="override the default min-notional floor (USD)")
    args = ap.parse_args()

    key = os.getenv("HL_PRIVATE_KEY")
    addr = os.getenv("HL_ACCOUNT_ADDRESS")
    if not key or not addr:
        print("refresh_pair_min_notional: HL_PRIVATE_KEY / HL_ACCOUNT_ADDRESS "
              "missing from .env -> cannot build adapter")
        return 1

    from src.services.risk import RiskConfig
    floor = args.floor if args.floor is not None else RiskConfig.min_notional_usd
    adapter = HyperliquidAdapter(private_key=key, account_address=addr,
                                  testnet=args.testnet)
    store = MinNotionalStore()
    n = store.refresh_from_hl(adapter, default_floor=floor)
    print(f"refresh_pair_min_notional: wrote {n} pairs to hl_pair_min_notional "
          f"({'testnet' if args.testnet else 'mainnet'})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
