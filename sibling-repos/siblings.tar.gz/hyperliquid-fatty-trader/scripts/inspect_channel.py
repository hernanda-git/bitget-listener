"""Read-only Telegram channel inspector (diagnostic, no trading).

Pulls the latest N messages from the configured signal channel and writes
their raw text to a local file for parser tuning. Also prints the channel's
true identity so we can confirm we are listening to the intended source.

Run:
  /usr/local/lib/hermes-agent/venv/bin/python3 scripts/inspect_channel.py
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
from pathlib import Path

from dotenv import load_dotenv
from telethon import TelegramClient
from telethon.sessions import StringSession

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)
log = logging.getLogger("inspect_channel")

REPO_ROOT = Path(__file__).resolve().parents[1]
load_dotenv(REPO_ROOT / ".env")

API_ID = int(os.getenv("TG_API_ID", "0"))
API_HASH = os.getenv("TG_API_HASH", "")
CHANNEL = os.getenv("CHANNEL_USERNAME", "fattyfatclub")
SESSION_STR = os.getenv("SESSION_STRING", "")
LIMIT = int(os.getenv("INSPECT_LIMIT", "100"))
OUT = REPO_ROOT / "docs" / "channel_sample.json"


async def main() -> None:
    session = StringSession(SESSION_STR) if SESSION_STR else str(REPO_ROOT / "session")
    client = TelegramClient(session, API_ID, API_HASH)
    await client.connect()
    if not await client.is_user_authorized():
        raise RuntimeError("Session not authorized. Regenerate SESSION_STRING.")

    me = await client.get_me()
    log.info("Connected as %s (%s)", me.first_name, me.id)

    entity = await client.get_entity(CHANNEL)
    ident = {
        "lookup": CHANNEL,
        "title": getattr(entity, "title", None),
        "username": getattr(entity, "username", None),
        "id": entity.id,
        "access_hash": getattr(entity, "access_hash", None),
        "about": getattr(entity, "about", None),
        "participants_count": getattr(entity, "participants_count", None),
        "is_channel": getattr(entity, "broadcast", None),
    }
    log.info("CHANNEL IDENTITY: %s", json.dumps(ident, ensure_ascii=False))

    messages = []
    async for msg in client.iter_messages(entity, limit=LIMIT):
        if msg.message:
            text = msg.message
        elif msg.media:
            text = "<MEDIA/%s>" % type(msg.media).__name__
        else:
            text = "<empty>"
        messages.append({
            "id": msg.id,
            "date": msg.date.isoformat() if msg.date else None,
            "out": msg.out,
            "text": text,
            "has_media": msg.media is not None,
        })

    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps({
        "identity": ident,
        "count": len(messages),
        "messages": messages,
    }, ensure_ascii=False, indent=2))

    log.info("Wrote %d messages to %s", len(messages), OUT)
    # Also dump a quick human-readable tail to stdout
    print("=" * 60)
    print("LATEST %d MESSAGES (oldest->newest tail):" % len(messages))
    for m in messages[-15:]:
        snippet = m["text"].replace("\n", " ⏎ ")
        print(f"[{m['id']}] {snippet[:120]}")
    await client.disconnect()


if __name__ == "__main__":
    asyncio.run(main())
