"""Replay real channel data through the live-dry orchestrator path.

Feeds the real messages from docs/channel_sample.json (and the sampled chart
images where available) through the SAME Orchestrator + local VisionExtractor
that `src.main --live-dry` uses. No network, no real orders: dry_run=True.

Run: PYTHONPATH=. run scripts/replay_real.py
"""
import sys, asyncio, json
from pathlib import Path

sys.path.insert(0, ".")
from src.domain.model import RawSignal
from src.orchestrator import Orchestrator, OrchestratorConfig
from src.sources.vision import VisionExtractor
from src.sources.parser import parse_signal, parse_management, extract_token
from src.services.peg import ConstantPegSource


class N:
    def __init__(self): self.sent = []
    async def send(self, t): self.sent.append(t)


class M:
    def mark_price(self, sym): return 1.0  # replay stub; live uses real testnet WS


async def go():
    n = N()
    orch = Orchestrator(
        source=None, peg=ConstantPegSource(1.0), adapter=None,
        market=M(), notifier=n,
        config=OrchestratorConfig(dry_run=True, testnet=True))
    orch.vision_extractor = VisionExtractor()
    orch.attachment_fetcher = object()  # signal "fetcher present"

    sample = json.loads(Path("docs/channel_sample.json").read_text())
    # map message id -> local image path if we sampled it
    img_dir = Path("data/samples")
    trades = mgmt = charts = noise = 0
    # Seed a couple of open positions from real parsed trades so management
    # has something to act on (the live bot only manages positions it opened).
    from src.domain.model import Instrument, Position, Side, Settlement
    seeded = set()
    for m in sample["messages"]:
        sig = parse_signal(m.get("text") or "")
        if sig and sig.symbol_usdt and sig.symbol_usdt not in seeded:
            # resolve via the orchestrator's resolver when possible
            try:
                tk = await orch.resolver.resolve(sig.symbol_usdt)
            except Exception:
                tk = sig.symbol_usdt
            if tk:
                orch.on_position(Position(
                    instrument=Instrument(symbol=tk, base=tk, quote=Settlement.USDC),
                    side=Side.BUY, size_coin=100.0, entry_px=(sig.entry_usdt or 1.0),
                    leverage=3, margin_usd=1.0, sl_px=(sig.sl_usdt or None),
                    sl_order_id=f"sl_{tk}"))
                seeded.add(sig.symbol_usdt)
    print(f"seeded positions: {sorted(seeded)}\n")

    for m in sample["messages"]:
        txt = m.get("text") or ""
        mid = m["id"]
        # try structured text trade
        sig = parse_signal(txt)
        raw = RawSignal(message_id=mid, channel="fattyfatclub", raw_text=txt,
                        has_media=m.get("has_media", False), symbol_usdt=extract_token(txt) or "")
        if sig is not None:
            raw.symbol_usdt = sig.symbol_usdt
            raw.confidence = 0.8  # parser default for real signals
            status = await orch.handle_signal(raw)
            if status not in ("noise",):
                trades += 1
                print(f"[{mid}] TEXT TRADE -> {status}")
            continue
        mg = parse_management(txt)
        if mg is not None:
            status = await orch.handle_signal(raw)
            mgmt += 1
            print(f"[{mid}] MGMT {mg['action']} -> {status}")
            continue
        if m.get("has_media"):
            img = img_dir / f"fattyfatclub_{mid}.jpg"
            if img.exists():
                raw.image_path = str(img)
                status = await orch.handle_signal(raw)
                charts += 1
                print(f"[{mid}] CHART -> {status}")
            else:
                print(f"[{mid}] CHART (no sample img) -> skipped")
            continue
        noise += 1

    print("\n=== SUMMARY ===")
    print(f"text trades routed : {trades}")
    print(f"management routed  : {mgmt}")
    print(f"chart images routed: {charts}")
    print(f"noise (ignored)    : {noise}")
    print(f"notify messages    : {len(n.sent)}")
    print("sample notifies:")
    for s in n.sent[:8]:
        print("   ", s[:110])


if __name__ == "__main__":
    asyncio.run(go())
