"""Replay the REAL management messages through the live orchestrator (dry-run).

No network orders. Seeds a fake position per token, then feeds each real
message from the channel through Orchestrator.handle_signal exactly as the
live listener does, printing the routed status + notifier output.
"""
from __future__ import annotations

import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from src.domain.model import Instrument, Position, RawSignal, Side
from src.orchestrator import Orchestrator
from src.sources.parser import extract_management_token

MESSAGES = [
    "close pump at entry",
    "Sl to entry $ONDO",
    "move sl to breakeven",
    "book profits on $ONDO",
    "$SYM 3.5% up, move sl to breakeven",
    "cancel PENGU limit",
    "sl hit on XAI",
    "$BTC -> 67k ... move your stoploss to entry",
    "updated sl",
    "Goodmorning everyone, watching $BOME",
]


class Notifier:
    async def send(self, msg: str) -> None:
        print(f"    notify: {msg}")


class Cfg:
    dry_run = True


class Resolver:
    async def resolve(self, token):
        return token.upper() if token else None


class Market:
    def mark_price(self, symbol):
        return 1.0


async def main() -> None:
    orch = Orchestrator.__new__(Orchestrator)
    from src.services.position import PositionManager

    orch.cfg = Cfg()
    orch.notifier = Notifier()
    orch.resolver = Resolver()
    orch.market = Market()
    orch.positions = PositionManager()
    orch.adapter = None
    orch.bias_recorder = None

    # Seed one open position per token the messages reference.
    for tok in ("PUMP", "ONDO", "SYM", "XAI", "BTC"):
        inst = Instrument(symbol=tok, base=tok, quote="USDC", venue="hyperliquid")
        orch.positions.apply_position_update(
            Position(instrument=inst, side=Side.BUY, size_coin=10.0,
                     entry_px=1.0, leverage=3, margin_usd=3.3)
        )
        p = orch.positions.get(tok)
        p.sl_px = 0.9
        p.sl_order_id = "seed-sl"

    for text in MESSAGES:
        raw = RawSignal(raw_text=text, source="fattyfatclub", message_id=0)
        raw.symbol_usdt = extract_management_token(text)
        status = await orch._apply_management(raw, __import__(
            "src.sources.parser", fromlist=["parse_management"]
        ).parse_management(text) or {"action": "noop"})
        print(f"{text!r:55} -> {status}\n")


asyncio.run(main())
