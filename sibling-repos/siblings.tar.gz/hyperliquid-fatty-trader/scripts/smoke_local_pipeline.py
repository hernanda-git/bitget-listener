"""End-to-end wiring smoke test (no network, no orders): build the orchestrator
with the LOCAL vision backend and a fake attachment fetcher, feed it a real
downloaded chart (image-only) + the XAI caption side, and confirm it routes to a
dry-run trade plan. Also feeds a management message against a mock position.
"""
import sys, asyncio
sys.path.insert(0, ".")
from pathlib import Path
from src.domain.model import Instrument, Position, Side, Settlement
from src.orchestrator import Orchestrator, OrchestratorConfig
from src.sources.vision import VisionExtractor

class N:
    def __init__(s): s.sent=[]
    async def send(s,t): s.sent.append(t)
class FakePeg:
    async def peg_rate(self): return 1.0

class M:
    def mark_price(self, sym): return 0.0073

async def go():
    n = N()
    orch = Orchestrator(source=None, peg=FakePeg(), adapter=None, market=M(), notifier=n,
                        config=OrchestratorConfig(dry_run=True, testnet=True))
    ve = VisionExtractor()  # reads VISION_BACKEND from env (.env -> local)
    orch.vision_extractor = ve
    orch.attachment_fetcher = object()
    print("vision backend =", getattr(ve, "backend", "?"))

    # image-only chart (XAI long) -> should extract + dry-run trade
    img = Path("data/samples/fattyfatclub_15938.jpg")
    if img.exists():
        from src.domain.model import RawSignal
        raw = RawSignal(message_id=15938, channel="fattyfatclub",
                        raw_text="$XAI LONG", has_media=True, image_path=str(img),
                        symbol_usdt="XAI", confidence=0.8)
        status = await orch.handle_signal(raw)
        print("chart status:", status)
        for s in n.sent: print("   NOTIFY:", s)

    # management message against a tracked position
    orch.on_position(Position(instrument=Instrument(symbol="XAI", base="XAI",
                    quote=Settlement.USDC), side=Side.BUY, size_coin=100.0,
                    entry_px=0.0073, leverage=3, margin_usd=1.0, sl_px=0.007058,
                    sl_order_id="oldsl"))
    from src.domain.model import RawSignal as R2
    mgmt = R2(message_id=999, channel="fattyfatclub", raw_text="$XAI sl to entry",
              symbol_usdt="XAI")
    st2 = await orch.handle_signal(mgmt)
    print("mgmt status:", st2)
    for s in n.sent:
        if "mgmt" in s or "SL" in s: print("   NOTIFY:", s)

asyncio.run(go())
