"""Validate LocalVisionExtractor against the real downloaded channel charts.

Run: PYTHONPATH=. run scripts/test_local_vision.py
"""
import asyncio
import json
from pathlib import Path

from src.sources.local_vision import LocalVisionExtractor

SAMPLES = Path(__file__).resolve().parents[1] / "data" / "samples"
INDEX = SAMPLES / "index.json"


async def main():
    idx = json.loads(INDEX.read_text()) if INDEX.exists() else []
    ext = LocalVisionExtractor({})
    for s in idx:
        cap = s.get("caption", "")
        # image-only path: keep only side word, strip structured text so vision
        # must read the chart itself.
        side_word = "long" if "LONG" in cap.upper() else ("short" if "SHORT" in cap.upper() else "")
        synthetic = (("LONG ") if side_word == "long" else ("SHORT ") if side_word == "short" else "")
        res = await ext.extract(s["path"], caption=synthetic)
        lv = res.get("levels", {})
        print(f"[{s['id']}] side={side_word!r}")
        print(f"    entry={lv.get('entry')} sl={lv.get('sl')} tp={lv.get('tp')} "
              f"has_chart_data={res.get('has_chart_data')}")


if __name__ == "__main__":
    asyncio.run(main())
