#!/bin/sh
# fatty_watchdog.sh — keep the fatty-trader live-dry listener always running.
#
# Runs `python -m src.main --live-dry` in a restart loop with a short delay
# between exits. Logs to logs/fatty.log (rotated by size here: keep last 3).
# SAFE: --live-dry is hard-locked to testnet + dry_run in src/main.py — this
# script can never place a real order or touch mainnet.
#
# Usage:
#   sh scripts/fatty_watchdog.sh start    # (used by the cron heartbeat)
#   sh scripts/fatty_watchdog.sh           # foreground loop (Ctrl-C to stop)
set -u

REPO_DIR="$(cd "$(dirname "$0")/.." && pwd)"
VENV_PY="$REPO_DIR/../../.hermes/venv/bin/python3"
if [ ! -x "$VENV_PY" ]; then
  VENV_PY="$(command -v python3)"
fi
LOG_DIR="$REPO_DIR/logs"
LOG="$LOG_DIR/fatty.log"
mkdir -p "$LOG_DIR"

cd "$REPO_DIR" || exit 1

rotate() {
  # keep last 3 copies
  [ -f "$LOG".3 ] && rm -f "$LOG".3
  [ -f "$LOG".2 ] && mv -f "$LOG".2 "$LOG".3
  [ -f "$LOG".1 ] && mv -f "$LOG".1 "$LOG".2
  [ -f "$LOG" ]   && mv -f "$LOG"  "$LOG".1
}

echo "$(date '+%F %T') watchdog: starting live-dry listener (testnet, dry-run)" >>"$LOG"
while true; do
  PYTHONPATH="$REPO_DIR" "$VENV_PY" -m src.main --live-dry >>"$LOG" 2>&1
  rc=$?
  echo "$(date '+%F %T') watchdog: listener exited (rc=$rc); restart in 10s" >>"$LOG"
  sleep 10
done
