"""One-off: download real chart images from @fattyfatclub for local-vision tuning.

Writes up to N media messages to data/samples/ and prints basic stats.
Read-only (download only). Never used in production.

Run: run scripts/grab_samples.py
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
from pathlib import Path

from dotenv import load_dotenv
from telethon import TelegramClient
from telethon.sessions import StringSession

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("grab_samples")

REPO = Path(__file__).resolve().parents[1]
load_dotenv(REPO / ".env")
API_ID = int(os.getenv("TG_API_ID", "0"))
API_HASH = os.getenv("TG_API_HASH", "")
CHANNEL = os.getenv("CHANNEL_USERNAME", "fattyfatclub")
SESSION_STR = os.getenv("SESSION_STRING", "")
OUT = REPO / "data" / "samples"
LIMIT = int(os.getenv("GRAB_LIMIT", "25"))


async def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    session = StringSession(SESSION_STR) if SESSION_STR else str(REPO / "session")
    client = TelegramClient(session, API_ID, API_HASH)
    await client.connect()
    if not await client.is_user_authorized():
        raise RuntimeError("Session not authorized.")
    entity = await client.get_entity(CHANNEL)
    log.info("Channel: %s (%s)", getattr(entity, "title", CHANNEL), entity.id)

    saved = []
    async for msg in client.iter_messages(entity, limit=LIMIT):
        if not msg.media:
            continue
        dest = OUT / f"{CHANNEL}_{msg.id}.jpg"
        try:
            await client.download_media(msg, file=str(dest))
        except Exception as e:
            log.warning("download failed %s: %s", msg.id, e)
            continue
        caption = (msg.message or "")[:120]
        is_photo = msg.photo is not None
        saved.append({"id": msg.id, "path": str(dest), "caption": caption, "photo": is_photo})
        if len(saved) >= int(os.getenv("GRAB_MAX", "15")):
            break

    (OUT / "index.json").write_text(json.dumps(saved, ensure_ascii=False, indent=2))
    log.info("Saved %d images to %s", len(saved), OUT)
    for s in saved:
        print(f"[{s['id']}] photo={s['photo']} {s['caption'][:80]}")
    await client.disconnect()


if __name__ == "__main__":
    asyncio.run(main())
