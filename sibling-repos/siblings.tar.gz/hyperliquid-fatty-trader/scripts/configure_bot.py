#!/usr/bin/env python3
"""configure_bot.py — manage bots in the SQLite config DB (multi-bot setup).

Creates or updates a bot row. Secrets are NOT stored here — only the env-var
NAMES that hold the TG bot token / chat id, and the HL account address (display
only). The HL private key is read from HL_PRIVATE_KEY in .env at runtime.

Examples:
  # create a paper bot on testnet
  python3 scripts/configure_bot.py --name fatty-2 --paper --channel fattyfatclub2 \\
      --testnet --token-env TG_BOT_TOKEN_2 --chat-env TG_BOT_CHAT_2

  # flip an existing bot to live (mainnet)
  python3 scripts/configure_bot.py --name fatty-main --live --mainnet

  # disable / enable
  python3 scripts/configure_bot.py --name fatty-2 --disable
  python3 scripts/configure_bot.py --name fatty-2 --enable

  # list all bots
  python3 scripts/configure_bot.py --list
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from src.config.db import BotConfig, ConfigStore, ensure_default_bot


def main() -> None:
    ap = argparse.ArgumentParser(description="Manage bots in data/config.db")
    ap.add_argument("--name", help="bot id")
    ap.add_argument("--paper", action="store_true", help="set paper (dry-run) mode")
    ap.add_argument("--live", action="store_true", help="set LIVE mode (real money)")
    ap.add_argument("--testnet", action="store_true", help="run on HL testnet")
    ap.add_argument("--mainnet", action="store_true", help="run on HL mainnet")
    ap.add_argument("--channel", help="signal source channel (e.g. fattyfatclub)")
    ap.add_argument("--token-env", help="env var holding this bot's TG bot token")
    ap.add_argument("--chat-env", help="env var holding this bot's alert-chat id")
    ap.add_argument("--wallet", help="HL account address (display only)")
    ap.add_argument("--min-confidence", type=float, help="min signal confidence")
    ap.add_argument("--enable", action="store_true")
    ap.add_argument("--disable", action="store_true")
    ap.add_argument("--list", action="store_true", help="list all bots and exit")
    ap.add_argument("--db", default=None, help="path to config.db (default data/config.db)")
    args = ap.parse_args()

    store = ConfigStore(args.db)
    ensure_default_bot(store)

    if args.list or not args.name:
        if args.list:
            print(f"{'NAME':<16} {'EN':>3} {'MODE':>6} {'NET':>8} {'CHANNEL':<16}")
            for b in store.list_bots():
                print(f"{b.name:<16} {'yes' if b.enabled else 'no':>3} "
                      f"{'LIVE' if b.live else 'paper':>6} "
                      f"{'mainnet' if not b.testnet else 'testnet':>8} "
                      f"{b.channel:<16}")
            return
        ap.error("either --name or --list is required")

    existing = store.get_bot(args.name)
    cfg = existing or BotConfig(name=args.name)
    cfg.name = args.name

    if args.paper:
        cfg.paper = True
    if args.live:
        cfg.paper = False
    if args.testnet:
        cfg.testnet = True
    if args.mainnet:
        cfg.testnet = False
    if args.channel:
        cfg.channel = args.channel
    if args.token_env:
        cfg.tg_bot_token_env = args.token_env
    if args.chat_env:
        cfg.tg_bot_chat_env = args.chat_env
    if args.wallet:
        cfg.wallet_address = args.wallet
    if args.min_confidence is not None:
        cfg.min_confidence = args.min_confidence
    if args.enable:
        cfg.enabled = True
    if args.disable:
        cfg.enabled = False

    store.upsert_bot(cfg)
    print(f"Saved bot '{cfg.name}': "
          f"mode={'LIVE' if cfg.live else 'paper'}, "
          f"network={'mainnet' if not cfg.testnet else 'testnet'}, "
          f"channel={cfg.channel}, enabled={cfg.enabled}")


if __name__ == "__main__":
    main()
