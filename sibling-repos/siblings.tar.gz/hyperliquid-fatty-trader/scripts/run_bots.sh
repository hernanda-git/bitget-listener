#!/bin/bash
# run_bots.sh — supervised launcher for ALL enabled bots.
#
# Spawns one supervised child per enabled bot via `python -m src.main --bot NAME`,
# and restarts any child that exits (so a crash doesn't leave a bot silent).
# Each child owns its own TG bot token, so there is never more than one listener
# per token. Stop with Ctrl-C (SIGINT) to terminate all children cleanly.
set -u
cd "$(dirname "$0")/.."
PY="${PY:-/usr/local/lib/hermes-agent/venv/bin/python3}"
[[ -x "$PY" ]] || PY="python3"
mkdir -p logs

# Collect enabled bot names from the config DB.
mapfile -t BOTS < <("$PY" -c "
import sys; sys.path.insert(0,'.')
from src.config.db import ConfigStore
for b in ConfigStore().list_bots(enabled_only=True):
    print(b.name)
")

if [[ ${#BOTS[@]} -eq 0 ]]; then
  echo "No enabled bots in data/config.db. Create one with scripts/configure_bot.py"
  exit 1
fi

echo "Supervising bots: ${BOTS[*]}"

# Restart loop: keep each child alive until the supervisor gets SIGINT.
declare -A PIDS
cleanup() {
  echo "Stopping all bots..."
  for name in "${!PIDS[@]}"; do
    kill "${PIDS[$name]}" 2>/dev/null
  done
  wait
  echo "All bots stopped."
  exit 0
}
trap cleanup SIGINT SIGTERM

while true; do
  for name in "${BOTS[@]}"; do
    if [[ -z "${PIDS[$name]:-}" ]] || ! kill -0 "${PIDS[$name]}" 2>/dev/null; then
      echo "[$(date '+%F %T')] starting bot $name"
      nohup "$PY" -m src.main --bot "$name" >>"logs/bot_${name}.log" 2>&1 &
      PIDS[$name]=$!
    fi
  done
  sleep 15
done
