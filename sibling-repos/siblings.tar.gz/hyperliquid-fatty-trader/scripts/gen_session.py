"""Generate a Telegram SESSION_STRING for Sera and save it to .env.

Run:  /usr/local/lib/hermes-agent/venv/bin/python3 scripts/gen_session.py
Answer the prompts. It writes SESSION_STRING into .env (preserving other keys)
and also prints it. No manual copy/paste needed.
"""

from __future__ import annotations

import asyncio
import re
from pathlib import Path

from telethon import TelegramClient
from telethon.sessions import StringSession

ENV = Path(__file__).resolve().parents[1] / ".env"


async def main() -> None:
    api_id = int(input("TG_API_ID: ").strip())
    api_hash = input("TG_API_HASH: ").strip()
    phone = input("Phone (+628...): ").strip()

    client = TelegramClient(StringSession(), api_id, api_hash)
    await client.connect()
    sent = await client.send_code_request(phone)
    code = input("Code Telegram sent you: ").strip()
    try:
        await client.sign_in(phone, code, phone_code_hash=sent.phone_code_hash)
    except Exception:
        pw = input("2FA password: ").strip()
        await client.sign_in(password=pw)
    me = await client.get_me()
    session = client.session.save()
    print("LOGGED IN AS", getattr(me, "first_name", ""), me.id)

    # write into .env, preserving other keys
    text = ENV.read_text() if ENV.exists() else ""
    lines = [ln for ln in text.splitlines() if not ln.startswith("SESSION_STRING=")]
    lines.append(f"SESSION_STRING={session}")
    ENV.write_text("\n".join(lines) + "\n")
    print("SESSION_STRING saved to .env (len=%d)" % len(session))
    await client.disconnect()


if __name__ == "__main__":
    asyncio.run(main())
