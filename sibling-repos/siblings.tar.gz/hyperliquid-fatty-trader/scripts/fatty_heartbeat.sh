#!/bin/sh
# fatty_heartbeat.sh — ensure the live-dry listener is running.
# Run by the Hermes cron every 15 min. If the process is missing, start the
# watchdog (which itself restarts the listener on crash). Writes a one-line
# status to stdout (delivered to Telegram by the cron job).
REPO_DIR="$(cd "$(dirname "$0")/.." && pwd)"
LOG="$REPO_DIR/logs/fatty.log"
mkdir -p "$(dirname "$LOG")"

if pgrep -f "src.main --live-dry" >/dev/null 2>&1; then
  echo "$(date '+%F %T') heartbeat: listener alive (pid $(pgrep -f 'src.main --live-dry' | head -1))"
  exit 0
fi

echo "$(date '+%F %T') heartbeat: listener MISSING -> restarting watchdog" >>"$LOG"
# start watchdog detached so cron doesn't block
cd "$REPO_DIR" && nohup sh scripts/fatty_watchdog.sh >/dev/null 2>&1 &
echo "$(date '+%F %T') heartbeat: restarted watchdog (pid $!)"
