# Hyperliquid Trader

> **Working on this repo?** Read [`AGENTS.md`](AGENTS.md) first (aliased as
> `CLAUDE.md`) — safety rules, signal reality, and the required workflow.
> Behavior history lives in [`CHANGELOG.md`](CHANGELOG.md), the canonical record.
> `./deploy.sh` blocks any deploy whose change is not documented there.

An autonomous trading system that **consumes trading signals from the Telegram
channel `@fattyfatclub`** (titled *UNKNOWN TRADERS ACADEMY* — the odd title is
expected and confirmed correct) and **executes them on Hyperliquid (USDC perps)**.

The system is built from scratch with a clean, SOLID-aligned architecture: signal
ingestion, normalization, validation, risk, and execution are separated into
small, independently testable components wired together by a dependency-injected
orchestrator.

> Project status: **phases 0-9 implemented (domain, adapters, WS, orchestrator,
> parser, notifier, config, entrypoint).** Config is now **DB-backed and
> multi-bot**: each bot has its own row in the PostgreSQL `fatty_config` database
> (paper/live flag, channel, network, TG token env var, risk), which runs on the
> VPS and is reachable from outside it over TCP. `--all-bots` launches every
> enabled bot as its own supervised process. The `/toggle` command flips a bot
> between PAPER (dry-run) and LIVE and persists the choice. Live trading requires
> the bot row to be set `paper=0` (real money, user-authorized) plus real keys
> in `.env`.

---

## Why this design

- **`@fattyfatclub` (Telegram) = signal source, Hyperliquid = execution venue.**
  The channel posts USDT-quoted trade calls (e.g. `#BONK $BONK LONG TRADE`,
  `ENTRY/STOPLOSS/TARGET`). Hyperliquid trades the same underlying as USDC-settled
  perps (`BONK-PERP`, margin in USDC). The architecture treats the USDT/USDC
  mismatch as a first-class concern, not an afterthought
  (see `docs/usdt-usdc-normalization.md`).
- **Zero-REST monitoring.** Hyperliquid streams positions, orders, and fills over
  a single multiplexed websocket. The pipeline relies on pushes, not polling, so
  SL monitoring and PnL tracking carry negligible request weight.
- **No datacenter IP bans.** Hyperliquid is an on-chain venue reached via its API
  (not a CEX that blocks cloud ranges), so the Tencent-ap-jakarta ban problem we
  hit on Binance does not apply here.
- **SOLID.** Every boundary is an interface; concrete exchanges and signal
  sources are swappable without touching orchestration or services.
- **DB-backed multi-bot config.** Each bot is a row in the PostgreSQL
  `fatty_config` database (running on the VPS, reachable from outside over TCP).
  Paper/live, channel, network, TG token env var, and risk are all per-bot and
  persisted. `/toggle` flips paper<->live and survives restart.

---

## Key design decisions

| Decision | Rationale |
|----------|-----------|
| Signal source and execution venue are separate adapters | Lets us later add more signal providers or more venues without rewriting the core. |
| Canonical internal model uses a neutral `UsdNotional` + `Instrument` | Decouples "how much USD risk" from "which stablecoin quotes it". |
| A `SignalNormalizer` translates the channel's USDT prices -> Hyperliquid USDC | Single, audited place where the USDT/USDC difference is handled. |
| A `StablecoinPegGuard` rejects signals when USDT/USDC depeg exceeds a threshold | Prevents trading through a stablecoin depeg event. |
| `ExchangeAdapter` interface for execution | Hyperliquid today; other venues later, behind the same contract. |
| WebSocket-first market + user data | Minimal REST weight; resilient to rate limits. |
| PostgreSQL `ConfigStore` for multi-bot config | One row per bot; persisted paper flag is the single human gate to real money. |

---

## Signal flow (high level)

```
@fattyfatclub (Telegram, USDT-quoted trade calls)
        │  TelegramSignalSource (user-account listener)
        ▼
   RawSignal (channel token + USDT prices)
        │  parse_signal / parse_management / parse_bias
        ▼
   Signal (instrument=BTC, quote=USDC, prices in USDC via peg)
        │  SignalNormalizer
        ▼
   Signal (instrument=BTC, quote=USDC, prices in USDC via peg)
        │  SignalValidator (+ StablecoinPegGuard)
        ▼
   ValidatedSignal
        │  OrderService (+ RiskManager sizing) + PositionManager
        ▼
   OrderRequest  ──►  HyperliquidAdapter (REST place/cancel)
        ▼
   Hyperliquid (USDC)  ◄── MarketDataStream (WS: mark, positions, orders, fills)
```

---

## Repository layout (target)

```
hyperliquid-trader/
├── README.md
├── ARCHITECTURE.md
├── PLAN.md
├── docs/
│   ├── hyperliquid-api.md
│   ├── bybit-signals.md
│   └── usdt-usdc-normalization.md
├── src/
│   ├── domain/            # Signal, Instrument, Order, Position, UsdNotional
│   ├── interfaces/        # SignalSource, ExchangeAdapter, Notifier, RiskPolicy
│   ├── sources/            # telegram signal source + parser + vision
│   ├── exchanges/          # hyperliquid adapter
│   ├── services/           # normalizer, validator, order/position/risk services
│   ├── streaming/          # market data + user-event WS
│   ├── config/             # typed config loader + PostgreSQL ConfigStore (multi-bot, external)
│   ├── orchestrator.py
│   └── main.py
├── tests/
├── scripts/
├── config.example.yaml
├── requirements.txt
└── .gitignore
```

(The `src/` tree is created during the implementation phase, not in the initial
documentation commit.)

---

## Documentation index

- `ARCHITECTURE.md` — SOLID component design, domain model, data flow, resilience.
- `PLAN.md` — phased implementation plan with acceptance criteria.
- `docs/hyperliquid-api.md` — Hyperliquid info/exchange endpoints, websockets, USDC settlement.
- `docs/bybit-signals.md` — historical note: signal format was prototyped against Bybit USDT pairs; production source is `@fattyfatclub` (see AGENTS.md).
- `docs/usdt-usdc-normalization.md` — the USDT↔USDC handling design.

---

## Getting started

1. `cp config.example.yaml config.yaml` and edit (risk params, channel) if you
   use the file-based path; the **canonical** config is the PostgreSQL
   `fatty_config` database (connection in `.env` as `CONFIG_DB_URL`). Create/manage
   bots with
   `python3 scripts/configure_bot.py --name fatty-main --live --mainnet --channel fattyfatclub`.
2. Create `.env` with `HL_PRIVATE_KEY`, `HL_ACCOUNT_ADDRESS`, `TG_API_ID`,
   `TG_API_HASH`, `SESSION_STRING`, `TG_BOT_TOKEN` (secrets, git-ignored).
   **Never commit secrets.**
3. Install: `pip install -r requirements.txt` (add `.[test]` for pytest).
4. Run the SAFE end-to-end check (testnet, dry-run, no real orders):
   `python -m src.main`
5. Launch the bot(s): `python -m src.main --all-bots` (supervised, one process
   per enabled bot) or `--bot NAME` for a single bot. The bot's mode (paper/live)
   is the persisted `paper` flag in the PostgreSQL `fatty_config` DB. Send
   `/toggle` in the bot chat to flip it; the change is written back to the DB and
   survives restarts.

## License

Proprietary. Private repository.
