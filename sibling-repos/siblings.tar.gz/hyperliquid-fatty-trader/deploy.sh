#!/usr/bin/env bash
# deploy.sh — bump version, restart the dashboard bot, and send a deploy health check.
# Usage:  ./deploy.sh [patch|minor|major]   (default: patch)
#
# Bumps the VERSION file (patch = x.y.Z+1), then reboots the running --dashboard
# process. The bot reads VERSION on startup and sends a 🚀 Deployed health check
# to the Telegram chat. Does NOT touch secrets (.env is git-ignored).
#
# CHANGELOG GUARD: this script REFUSES to deploy unless CHANGELOG.md documents
# the change. Write your notes under "## [Unreleased]" first; the script renames
# that heading to the new version + today's date. This is what keeps the
# canonical history from drifting away from the code.
#
# TEST GUARD: the full pytest suite must be green before a deploy proceeds.
# Skip both guards only in a genuine emergency:  SKIP_GUARDS=1 ./deploy.sh
set -euo pipefail

cd "$(dirname "$0")"

BUMP="${1:-patch}"
PY="${PY:-/usr/local/lib/hermes-agent/venv/bin/python3}"
[[ -x "$PY" ]] || PY="python3"

if [[ ! -f VERSION ]]; then
  echo "0.1.0" > VERSION
fi

OLD="$(cat VERSION)"
IFS='.' read -r MAJ MIN PAT <<< "$OLD"
case "$BUMP" in
  major) MAJ=$((MAJ+1)); MIN=0; PAT=0 ;;
  minor) MIN=$((MIN+1)); PAT=0 ;;
  patch|*) PAT=$((PAT+1)) ;;
esac
NEW="$MAJ.$MIN.$PAT"

# ---------------------------------------------------------------- guards ----
if [[ "${SKIP_GUARDS:-0}" != "1" ]]; then

  # 1) Tests must pass.
  echo "Running test suite..."
  if ! "$PY" -m pytest -q > /tmp/deploy_pytest.log 2>&1; then
    echo "DEPLOY BLOCKED: tests are failing."
    tail -25 /tmp/deploy_pytest.log
    exit 1
  fi
  echo "Tests green: $(tail -1 /tmp/deploy_pytest.log)"

  # 2) CHANGELOG.md must document this release.
  if [[ ! -f CHANGELOG.md ]]; then
    echo "DEPLOY BLOCKED: CHANGELOG.md is missing (it is the canonical history)."
    exit 1
  fi
  if grep -q "^## \[$NEW\]" CHANGELOG.md; then
    : # already written explicitly for this version
  elif grep -q "^## \[Unreleased\]" CHANGELOG.md; then
    # The Unreleased section must actually have content.
    BODY="$(awk '/^## \[Unreleased\]/{f=1;next} /^## \[/{f=0} f' CHANGELOG.md \
            | grep -v '^\s*$' | grep -v '^_Nothing yet\._$' | grep -v '^---$' || true)"
    if [[ -z "$BODY" ]]; then
      echo "DEPLOY BLOCKED: CHANGELOG.md '## [Unreleased]' is empty."
      echo "Describe the change (Added/Changed/Fixed/Removed/Safety) before deploying."
      exit 1
    fi
    # Promote [Unreleased] -> [NEW] - today, and open a fresh Unreleased section.
    TODAY="$(date +%F)"
    "$PY" - "$NEW" "$TODAY" <<'PYEOF'
import sys, pathlib, re
new, today = sys.argv[1], sys.argv[2]
p = pathlib.Path("CHANGELOG.md")
lines = p.read_text().split("\n")
# Anchor on the real HEADING LINE only. Matching the bare string would also hit
# the words "## [Unreleased]" inside this file's own instructions prose.
for i, ln in enumerate(lines):
    if re.fullmatch(r"## \[Unreleased\]\s*", ln):
        lines[i:i+1] = [
            "## [Unreleased]",
            "",
            "_Nothing yet._",
            "",
            "---",
            "",
            f"## [{new}] — {today}",
        ]
        break
else:
    sys.exit("CHANGELOG.md: no '## [Unreleased]' heading line found")
p.write_text("\n".join(lines))
print(f"CHANGELOG.md: [Unreleased] promoted to [{new}] - {today}")
PYEOF
  else
    echo "DEPLOY BLOCKED: CHANGELOG.md has no '## [Unreleased]' or '## [$NEW]' section."
    exit 1
  fi
fi

echo "$NEW" > VERSION
echo "VERSION bumped: $OLD -> $NEW"

# --------------------------------------------------------------- restart ----
# Exactly one listener per bot token must be running (see AGENTS.md rule 6).
# Stop any existing dashboard/bot/supervisor processes FIRST, then launch a
# single run_bots.sh supervisor. Killing only the children (not the supervisor)
# leaves the old supervisor alive, which respawns a duplicate child -> Telegram
# Conflict (two listeners on one token).
echo "Restarting bot processes..."
# Kill the supervisors first (so they can't respawn), then the children.
pkill -f "scripts/run_bots.sh" 2>/dev/null || true
PIDS="$(pgrep -f "python3 -m src[.]main --dashboard" || true) $(pgrep -f "python3 -m src[.]main --bot" || true)"
if [[ -n "$PIDS" ]]; then
  for pid in $PIDS; do kill "$pid" 2>/dev/null || true; done
  sleep 2
  for pid in $PIDS; do kill -9 "$pid" 2>/dev/null || true; done
fi
sleep 1

# Sanity: ensure no stray bot/supervisor survived before launching the new one.
if pgrep -f "scripts/run_bots.sh" >/dev/null 2>&1 || pgrep -f "python3 -m src[.]main --bot" >/dev/null 2>&1; then
  echo "WARNING: a previous supervisor/bot is still alive; killing again."
  pkill -9 -f "scripts/run_bots.sh" 2>/dev/null || true
  pkill -9 -f "python3 -m src[.]main --bot" 2>/dev/null || true
  sleep 2
fi

mkdir -p logs
# Launch ONE supervisor (restarts crashed children, one per enabled bot).
PYTHONPATH=. nohup bash scripts/run_bots.sh > logs/bots_supervisor.log 2>&1 &
echo "Started bot supervisor (pid $!) — log: logs/bots_supervisor.log"
sleep 6

# Exactly one listener must run per bot token; overlapping listeners double-send
# alerts and can double-trade.
RUNNING="$(pgrep -fc "python3 -m src[.]main --bot" || true)"
echo "Running bot --bot processes: ${RUNNING:-0}"
if [[ "${RUNNING:-0}" -lt 1 ]]; then
  echo "WARNING: expected at least 1 bot process, found ${RUNNING:-0}."
fi
if [[ "${RUNNING:-0}" -gt 1 ]]; then
  echo "WARNING: MORE THAN ONE bot process (${RUNNING}) — Telegram Conflict risk. Check supervisors."
fi

echo "--- last startup lines ---"
tail -8 logs/bot_fatty-main.log
echo ""
echo "Done. The bot will send a 🚀 Deployed health check (v$NEW) to the chat."
echo "Remember to commit: git add -A && git commit -m 'release v$NEW'"
