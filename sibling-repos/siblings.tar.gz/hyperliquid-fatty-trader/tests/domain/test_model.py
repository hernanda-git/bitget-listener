"""Unit tests for the pure domain model. No network, no async needed."""

from src.domain.model import (
    Instrument,
    OrderRequest,
    RawSignal,
    Side,
    Signal,
    UsdNotional,
    OrderType,
    Settlement,
)


def test_instrument_from_usdt_pair():
    inst = Instrument.from_usdt_pair("BTCUSDT")
    assert inst.base == "BTC"
    assert inst.symbol == "BTC"
    assert inst.quote.value == "USDC"
    assert inst.venue == "hyperliquid"


def test_raw_signal_carries_usdt():
    raw = RawSignal(
        symbol_usdt="BTCUSDT",
        side=Side.BUY,
        entry_usdt=60000.0,
        notional_usd=1000.0,
        leverage=10,
        confidence=0.8,
    )
    assert raw.entry_usdt == 60000.0
    assert raw.symbol_usdt.endswith("USDT")


def test_signal_is_usdc_native():
    inst = Instrument.from_usdt_pair("BTCUSDT")
    sig = Signal(
        instrument=inst,
        side=Side.BUY,
        entry=60000.0,
        sl=58000.0,
        tp=64000.0,
        notional=UsdNotional(amount_usd=1000.0, settlement=Settlement.USDC),
        leverage=10,
        confidence=0.8,
        peg_rate=1.0,
    )
    assert sig.entry == 60000.0
    assert sig.notional.settlement.value == "USDC"
    assert sig.instrument.quote.value == "USDC"


def test_order_request_coin_sized():
    inst = Instrument.from_usdt_pair("BTCUSDT")
    o = OrderRequest(
        instrument=inst,
        side=Side.BUY,
        order_type=OrderType.LIMIT,
        price=60000.0,
        size_coin=0.01,
        client_order_id="c1",
    )
    assert o.size_coin == 0.01
    assert o.order_type == OrderType.LIMIT
