"""Global test isolation.

The suite must never depend on a live LLM endpoint.

Why this exists: once ``LLM_SIGNAL_API_KEY`` was set in ``.env``,
``LLMSignalParser.from_env()`` started returning a live parser inside tests,
so ``Orchestrator`` made real network calls to the signal endpoint. Tests in
``test_media_routing.py`` then failed non-deterministically (``bias_logged``
instead of ``vision_pending``) because a remote model, not the fixture, was
deciding the message kind. They passed in isolation and failed in the full
run, which is the worst possible failure mode.

``vision.py`` and ``llm_signal.py`` both call ``load_dotenv()`` at import, so
simply unsetting the var before pytest starts is not enough — the .env value
is re-read. This fixture clears it after import, for every test.

Any test that WANTS the LLM must opt in explicitly by monkeypatching
``LLMSignalParser._call`` (never by making a real request).
"""

import os

import pytest


@pytest.fixture(autouse=True)
def _no_live_llm(monkeypatch):
    """Force the regex-only path unless a test explicitly opts in."""
    monkeypatch.setenv("LLM_SIGNAL_API_KEY", "")
    yield


@pytest.fixture(autouse=True)
def _no_live_vision(monkeypatch):
    """Keep the vision backend offline during tests."""
    monkeypatch.setenv("VISION_RICH_PROMPT", "")
    yield
