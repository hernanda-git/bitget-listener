"""Tests for the image-only attachment pipeline in Hyperliquid Trader."""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pytest

from src.sources.attachment_fetcher import AttachmentFetcher
from src.sources.vision import parse_vision_response


def test_attachment_fetcher_path_uses_jpg():
    f = AttachmentFetcher(media_dir="/tmp")
    assert f.path_for("abc", 1, ".jpg").suffix == ".jpg"


def test_vision_parse_response_coerces():
    assert parse_vision_response("")["has_chart_data"] is False
    out = parse_vision_response('{"levels":{"support":[1.0]}, "trend":"up"}')
    assert out["levels"]["support"] == [1.0]
    assert out["trend"] == "up"
    assert out["bias"]["primary"] == ""


def test_vision_parse_response_extracts_json_from_text():
    raw = 'Here is the chart: {"levels":{"resistance":[2.0]}, "trend":"down", "has_chart_data":true}'
    out = parse_vision_response(raw)
    assert out["levels"]["resistance"] == [2.0]
    assert out["has_chart_data"] is True
