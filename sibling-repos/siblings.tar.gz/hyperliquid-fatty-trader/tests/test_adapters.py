"""Tests for Phase 6 adapters (no network; fake adapter + translation logic)."""

import pytest

from src.domain.model import Instrument, OrderType, Side, UsdNotional, Settlement, Signal
from src.exchanges.fake import FakeHyperliquidAdapter
from src.exchanges.hyperliquid import _hl_order, _position_from_hl


def _sig(symbol="BTC", side=Side.BUY, entry=60000.0, sl=58000.0, tp=64000.0):
    inst = Instrument(symbol=symbol, base=symbol, quote=Settlement.USDC)
    return Signal(
        instrument=inst, side=side, entry=entry, sl=sl, tp=tp,
        notional=UsdNotional(amount_usd=1000.0, settlement=Settlement.USDC),
        leverage=10, confidence=0.8, peg_rate=1.0,
    )


@pytest.mark.asyncio
async def test_fake_adapter_places_and_fills_market():
    a = FakeHyperliquidAdapter()
    from src.services.risk import RiskManager
    from src.services.order import OrderService
    osvc = OrderService(RiskManager())
    sig = _sig()
    # frontrun scenario: mark moved up 1% -> 25% market fills immediately
    orders = osvc.build_orders(sig, mark_price=60600.0)
    for o in orders:
        await a.place_order(o)
    assert len(a.fills) >= 1  # market entry filled
    positions = await a.get_positions()
    assert any(p.instrument.symbol == "BTC" for p in positions)


@pytest.mark.asyncio
async def test_fake_adapter_cancel():
    a = FakeHyperliquidAdapter()
    from src.domain.model import OrderRequest
    inst = Instrument(symbol="BTC", base="BTC")
    o = OrderRequest(instrument=inst, side=Side.BUY, order_type=OrderType.LIMIT,
                     price=60000.0, size_coin=0.01, client_order_id="x1")
    oid = await a.place_order(o)
    assert oid == "x1"
    assert len(await a.get_open_orders()) == 1
    await a.cancel_order(inst, "x1")
    assert len(await a.get_open_orders()) == 0


def test_hl_order_translation_limit():
    inst = Instrument(symbol="BTC", base="BTC")
    from src.domain.model import OrderRequest
    o = OrderRequest(instrument=inst, side=Side.BUY, order_type=OrderType.LIMIT,
                     price=60000.5, size_coin=0.01, client_order_id="c1")
    # `a` is the HL asset INDEX (resolved by the adapter from metadata), not the
    # symbol string; `b` is the string "b"/"s", not a bool.
    h = _hl_order(o, "c1", asset_index=0)
    assert h["a"] == 0
    assert h["b"] == "b"
    assert h["p"] == "60000.5"
    assert h["s"] == "0.01"
    assert h["c"] == "c1"
    assert h["t"] == {"limit": {"tif": "Gtc"}}


def test_hl_order_translation_limit_post_only_uses_alo():
    inst = Instrument(symbol="BTC", base="BTC")
    from src.domain.model import OrderRequest
    o = OrderRequest(instrument=inst, side=Side.SELL, order_type=OrderType.LIMIT,
                     price=60000.5, size_coin=0.01, post_only=True, client_order_id="c9")
    h = _hl_order(o, "c9", asset_index=0)
    assert h["a"] == 0
    assert h["b"] == "s"
    assert h["t"] == {"limit": {"tif": "Alo"}}


def test_hl_order_translation_trigger():
    inst = Instrument(symbol="BTC", base="BTC")
    from src.domain.model import OrderRequest
    o = OrderRequest(instrument=inst, side=Side.BUY, order_type=OrderType.TRIGGER,
                     price=58000.0, size_coin=0.01, reduce_only=True,
                     trigger_px=58000.0, tpsl="sl", is_market=True,
                     client_order_id="c2")
    h = _hl_order(o, "c2")
    assert h["t"]["trigger"]["tpsl"] == "sl"
    assert h["r"] is True


def test_position_from_hl_roundtrip():
    pos = {
        "coin": "BTC", "szi": "0.02", "entryPx": "60000",
        "leverage": {"value": "10", "type": "cross"}, "marginUsed": "120",
        "unrealizedPnl": "5.5", "liquidationPx": "55000",
    }
    p = _position_from_hl(pos)
    assert p.instrument.symbol == "BTC"
    assert p.side == Side.BUY
    assert p.size_coin == 0.02
    assert p.entry_px == 60000.0
    assert p.leverage == 10
    assert p.unrealized_pnl_usd == 5.5
    assert p.liquidation_px == 55000.0
