"""Tests for the free-text signal + management parser (pure, no IO)."""

from __future__ import annotations

from src.sources.parser import parse_signal, parse_management
from src.domain.model import Side


def test_parse_long_entry():
    r = parse_signal("BTCUSDT LONG entry 60000 sl 58000 tp 64000 lev 10")
    assert r is not None
    assert r.symbol_usdt == "BTC"  # normalized base (USDT suffix stripped)
    assert r.side == Side.BUY
    assert r.entry_usdt == 60000.0
    assert r.sl_usdt == 58000.0
    assert r.tp_usdt == 64000.0
    assert r.leverage == 10
    assert r.raw_text.startswith("BTCUSDT")


def test_parse_short_lowercase():
    r = parse_signal("ethusdt short entry 3000 sl 3100")
    assert r is not None
    assert r.symbol_usdt == "ETH"  # normalized base
    assert r.side == Side.SELL
    assert r.entry_usdt == 3000.0
    assert r.sl_usdt == 3100.0


def test_parse_no_side_returns_none():
    assert parse_signal("BTCUSDT entry 60000") is None


def test_parse_no_pair_returns_none():
    assert parse_signal("buy the dip") is None


def test_parse_comma_thousands():
    r = parse_signal("BTCUSDT LONG entry 60,000 sl 58,000")
    assert r is not None
    assert r.entry_usdt == 60000.0


def test_management_sl_to_entry():
    assert parse_management("sl to entry") == {"action": "sl_to_entry"}


def test_management_sl_be():
    assert parse_management("sl be") == {"action": "sl_be"}


def test_management_sl_to_price():
    a = parse_management("sl 59000")
    assert a == {"action": "sl_to", "price": 59000.0}


def test_management_tp_hit():
    a = parse_management("tp1 here")
    assert a == {"action": "tp_hit", "index": 1}


def test_management_close():
    assert parse_management("close here") == {"action": "close"}


def test_management_noise_returns_none():
    assert parse_management("just a regular message") is None
