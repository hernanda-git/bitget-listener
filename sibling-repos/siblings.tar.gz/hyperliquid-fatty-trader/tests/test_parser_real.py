"""Tests for the real @fattyfatclub format parser + symbol resolver (pure, no IO)."""

from __future__ import annotations

import pytest

from src.sources.parser import parse_signal, parse_management
from src.sources.symbol_map import SymbolResolver
from src.domain.model import Side


# ---- Real channel format ----

def test_parse_real_long_format():
    text = "#PUMP $PUMP LONG TRADE\n\nENTRY: 0.002304\n\nTARGET: 0.0025\n\nSTOPLOSS: 0.002235"
    r = parse_signal(text)
    assert r is not None
    assert r.symbol_usdt == "PUMP"
    assert r.side == Side.BUY
    assert r.entry_usdt == 0.002304
    assert r.sl_usdt == 0.002235
    assert r.tp_usdt == 0.0025
    assert r.leverage == 0  # default applied later by orchestrator


def test_parse_real_multi_tp():
    text = "#AAVE $AAVE LONG TRADE\nENTRY: 100.75\nTARGETS: 110.7 - 117.2\nSTOPLOSS: 98.25"
    r = parse_signal(text)
    assert r is not None
    assert r.symbol_usdt == "AAVE"
    assert r.tp_usdt == 110.7
    assert r.tp_usdt_extra == [117.2]
    assert r.sl_usdt == 98.25


def test_parse_real_short_format():
    text = "$BONK SHORT TRADE\nENTRY: 0.003\nTARGET: 0.0025\nSTOPLOSS: 0.0032"
    r = parse_signal(text)
    assert r is not None
    assert r.side == Side.SELL
    assert r.symbol_usdt == "BONK"


def test_parse_real_comma_thousands():
    text = "$INJ LONG TRADE\nENTRY: 4,910\nTARGET: 5,390\nSTOPLOSS: 4,802"
    r = parse_signal(text)
    assert r is not None
    assert r.entry_usdt == 4910.0
    assert r.tp_usdt == 5390.0


def test_parse_no_side_none():
    # chat / commentary with a $ token but no LONG/SHORT -> not a trade
    assert parse_signal("$BTC next move") is None


def test_parse_no_token_none():
    # old-style pair still works, but a bare sentence without pair/token is None
    assert parse_signal("buy the dip") is None


# ---- Management (real chatter) ----

def test_mgmt_move_sl_to_entry():
    assert parse_management("move sl to entry") == {"action": "sl_to_entry"}


def test_mgmt_updated_sl():
    assert parse_management("updated sl") == {"action": "sl_to_entry"}


def test_mgmt_full_tp_done():
    assert parse_management("$KAITO full tp done") == {"action": "tp_hit", "index": 0}


def test_mgmt_close_here():
    assert parse_management("$WLD closed here little below entry") == {"action": "close"}


def test_mgmt_booking_profits_is_tp_hit():
    # #5: "$SNDK 30% up from our entry, you can start booking profits here"
    # "book profits" means take PARTIAL profit, not flatten the whole position.
    r = parse_management("$SNDK 30% up from our entry, you can start booking profits here")
    assert r == {"action": "partial_close", "fraction": 0.5}


def test_mgmt_real_formats():
    from src.sources.parser import extract_management_token
    cases = [
        ("close pump at entry", "close_at_entry", "PUMP"),
        ("Sl to entry $ONDO", "sl_to_entry", "ONDO"),
        ("move sl to breakeven", "sl_be", None),
        ("book profits on $ONDO", "partial_close", "ONDO"),
        ("cancel PENGU limit", "cancel_entry", "PENGU"),
        ("cancel $PENGU limit", "cancel_entry", "PENGU"),
        ("sl hit on XAI", "sl_hit", "XAI"),
        ("$BTC -> 67k ... move your stoploss to entry", "sl_be", "BTC"),
    ]
    for text, action, token in cases:
        got = parse_management(text)
        assert got is not None, text
        assert got["action"] == action, (text, got)
        assert extract_management_token(text) == token, text
    # noise must stay noise
    assert parse_management("Goodmorning everyone, watching $BOME") is None



def test_mgmt_manage_your_trade():
    # #14: "$KAITO 3% up almost 1R up / Manage your trade from here"
    r = parse_management("$KAITO 3% up almost 1R up\nManage your trade from here")
    assert r == {"action": "manage"}


def test_mgmt_noise_none():
    assert parse_management("Goodmorning everyone, watching $BOME") is None


def test_extract_token_binance_pair_and_alias():
    # Channel sometimes uses Binance-style BASEUSDT or a typo for the same coin.
    from src.sources.parser import extract_token
    assert extract_token("BOMEUSDT looking strong") == "BOME"
    assert extract_token("BOMSEUSDT update") == "BOME"   # typo -> canonical
    assert extract_token("$BOME still holding") == "BOME"


# ---- Backward compat (old Bybit single-line format) ----

def test_parse_old_format_lev():
    r = parse_signal("BTCUSDT LONG entry 60000 sl 58000 tp 64000 lev 10")
    assert r is not None
    assert r.symbol_usdt == "BTC"   # normalized base (USDT stripped)
    assert r.side == Side.BUY
    assert r.entry_usdt == 60000.0
    assert r.tp_usdt == 64000.0
    assert r.leverage == 10


# ---- Symbol resolver ----

@pytest.mark.asyncio
async def test_resolver_exact():
    uni = {"PUMP": 10, "kBONK": 5, "BTC": 40}
    r = SymbolResolver(universe=uni)
    assert await r.resolve("PUMP") == "PUMP"
    assert await r.resolve("$PUMP") == "PUMP"
    assert await r.resolve("#PUMP") == "PUMP"
    assert await r.resolve("BONK") == "kBONK"   # k-prefixed variant
    assert await r.resolve("ZAMA") is None      # not listed -> skip


@pytest.mark.asyncio
async def test_resolver_max_leverage():
    uni = {"PUMP": 10, "kBONK": 5}
    r = SymbolResolver(universe=uni)
    assert await r.max_leverage_for("PUMP") == 10
    assert await r.max_leverage_for("kBONK") == 5
    assert await r.max_leverage_for(None) is None
