"""End-to-end pipeline test (Phase 8) using fakes — zero network.

Wires: FakeSignalSource -> Orchestrator -> normalizer/validator/risk/order ->
FakeHyperliquidAdapter, with FakeMarketStream + FakeNotifier. Verifies the whole
path from a RawSignal to a placed (dry-run or real) order, and position updates.
"""

import asyncio

import pytest

from src.domain.model import Instrument, Position, RawSignal, Side, Settlement
from src.exchanges.fake import FakeHyperliquidAdapter
from src.services.peg import ConstantPegSource
from src.streaming.fake import FakeMarketStream, FakeUserStream
from src.orchestrator import Orchestrator, OrchestratorConfig


class FakeNotifier:
    def __init__(self):
        self.sent: list[str] = []
        self.signals: list[dict] = []

    async def send(self, text: str) -> None:
        self.sent.append(text)

    async def signal_received(self, symbol, side, src, mid, raw_text=""):
        self.signals.append({
            "symbol": symbol, "side": side, "src": src,
            "mid": mid, "raw_text": raw_text,
        })


def _raw(symbol="BTCUSDT", entry=60000.0, sl=58000.0, tp=64000.0, conf=0.8, lev=10):
    return RawSignal(
        symbol_usdt=symbol, side=Side.BUY, entry_usdt=entry, sl_usdt=sl,
        tp_usdt=tp, notional_usd=1000.0, leverage=lev, confidence=conf,
    )


@pytest.mark.asyncio
async def test_pipeline_dry_run():
    adapter = FakeHyperliquidAdapter()
    market = FakeMarketStream(["BTC"])
    market.push_mark("BTC", 60000.0)
    notifier = FakeNotifier()
    orch = Orchestrator(
        source=None, peg=ConstantPegSource(1.0), adapter=adapter,
        market=market, notifier=notifier,
        config=OrchestratorConfig(dry_run=True, min_confidence=0.5),
    )
    status = await orch.handle_signal(_raw())
    assert status == "dry-run"
    # no real orders placed; notification logged
    assert any("dry-run" in s for s in notifier.sent)
    assert len(adapter.placed) == 0


@pytest.mark.asyncio
async def test_pipeline_live_places_orders():
    adapter = FakeHyperliquidAdapter()
    market = FakeMarketStream(["BTC"])
    market.push_mark("BTC", 60600.0)  # frontrun -> 25% market fills
    notifier = FakeNotifier()
    orch = Orchestrator(
        source=None, peg=ConstantPegSource(1.0), adapter=adapter,
        market=market, notifier=notifier,
        config=OrchestratorConfig(dry_run=False, min_confidence=0.5),
    )
    status = await orch.handle_signal(_raw())
    assert status == "placed"
    assert len(adapter.placed) >= 1
    # market portion filled -> position tracked
    positions = await adapter.get_positions()
    assert any(p.instrument.symbol == "BTC" for p in positions)


@pytest.mark.asyncio
async def test_pipeline_rejects_depeg():
    adapter = FakeHyperliquidAdapter()
    market = FakeMarketStream(["BTC"])
    market.push_mark("BTC", 60000.0)
    notifier = FakeNotifier()

    # peg source reporting a big depeg
    class DepegPeg:
        async def peg_rate(self): return 0.98

    orch = Orchestrator(
        source=None, peg=DepegPeg(), adapter=adapter,
        market=market, notifier=notifier,
        config=OrchestratorConfig(dry_run=False, min_confidence=0.5),
    )
    status = await orch.handle_signal(_raw())
    assert status == "rejected:normalize"
    assert len(adapter.placed) == 0


@pytest.mark.asyncio
async def test_pipeline_applies_default_notional():
    adapter = FakeHyperliquidAdapter()
    market = FakeMarketStream(["BTC"])
    market.push_mark("BTC", 60000.0)
    notifier = FakeNotifier()
    orch = Orchestrator(
        source=None, peg=ConstantPegSource(1.0), adapter=adapter,
        market=market, notifier=notifier,
        config=OrchestratorConfig(dry_run=True, min_confidence=0.5,
                                  default_notional_usd=250.0),
    )
    # signal with no notional -> default budget applied
    raw = RawSignal(symbol_usdt="BTCUSDT", side=Side.BUY, entry_usdt=60000.0,
                    sl_usdt=58000.0, tp_usdt=64000.0, notional_usd=0.0,
                    leverage=10, confidence=0.8)
    status = await orch.handle_signal(raw)
    assert status == "dry-run"
    # notifier message should reflect a real (nonzero) size was computed
    assert any("orders=3" in s for s in notifier.sent)


@pytest.mark.asyncio
async def test_on_position_tracks_state():
    adapter = FakeHyperliquidAdapter()
    market = FakeMarketStream(["BTC"])
    notifier = FakeNotifier()
    orch = Orchestrator(
        source=None, peg=ConstantPegSource(1.0), adapter=adapter,
        market=market, notifier=notifier,
    )
    pos = Position(
        instrument=Instrument(symbol="BTC", base="BTC", quote=Settlement.USDC),
        side=Side.BUY, size_coin=0.01, entry_px=60000.0, leverage=10, margin_usd=60.0,
    )
    await orch.on_position(pos)
    assert orch.positions.has("BTC")
    assert orch.positions.get("BTC").size_coin == 0.01


@pytest.mark.asyncio
async def test_signal_received_forwards_raw_text():
    """The raw source message must be forwarded to the notifier so the Telegram
    alert shows the actual signal text, not just a parsed '?'."""
    adapter = FakeHyperliquidAdapter()
    market = FakeMarketStream(["BTC"])
    market.push_mark("BTC", 60000.0)
    notifier = FakeNotifier()
    orch = Orchestrator(
        source=None, peg=ConstantPegSource(1.0), adapter=adapter,
        market=market, notifier=notifier,
        config=OrchestratorConfig(dry_run=True, min_confidence=0.5),
    )
    raw_text = "#BONK $BONK LONG TRADE\nENTRY: 0.002472\nTARGET: 0.002615\nSTOPLOSS: 0.002402"
    # Unparsed raw (symbol_usdt empty) — the case that previously showed '?'.
    raw = RawSignal(side=Side.BUY, raw_text=raw_text, message_id=42)
    await orch.handle_signal(raw)
    assert len(notifier.signals) == 1
    sig = notifier.signals[0]
    assert sig["raw_text"] == raw_text
    # parsed symbol still resolves from the text even though symbol_usdt empty
    assert sig["symbol"] in ("BONKUSDT", "BONK")


@pytest.mark.asyncio
async def test_llm_signal_agree_routes_to_trade(monkeypatch):
    """LLM parse agrees with regex -> trades (no needs_review)."""
    adapter = FakeHyperliquidAdapter()
    market = FakeMarketStream(["BONK"])
    market.push_mark("BONK", 0.0025)
    notifier = FakeNotifier()
    orch = Orchestrator(
        source=None, peg=ConstantPegSource(1.0), adapter=adapter,
        market=market, notifier=notifier,
        config=OrchestratorConfig(dry_run=True, min_confidence=0.5),
    )
    orch.llm_signal = __import__("src.sources.llm_signal", fromlist=["LLMSignalParser"]).LLMSignalParser(
        api_key="k")

    async def fake_call(text):
        return {"kind": "signal", "token": "BONK", "side": "LONG",
                "entry": 0.002472, "sl": 0.002402, "tp": [0.002615], "leverage": None}
    monkeypatch.setattr(orch.llm_signal, "_call", fake_call)
    orch.resolver.resolve = lambda s: _async(s)

    raw = RawSignal(side=Side.BUY, notional_usd=1000.0, leverage=10, confidence=0.8,
                    raw_text="#BONK $BONK LONG TRADE\nENTRY: 0.002472\nTARGET: 0.002615\nSTOPLOSS: 0.002402",
                    message_id=7)
    status = await orch.handle_signal(raw)
    assert status != "needs_review:signal_conflict"
    assert status in ("dry-run", "placed")
    assert any("BONK" in (s.get("symbol") or "") for s in notifier.signals)


@pytest.mark.asyncio
async def test_llm_signal_conflict_holds(monkeypatch):
    """LLM says SHORT but regex says LONG -> HOLD (needs_review)."""
    adapter = FakeHyperliquidAdapter()
    market = FakeMarketStream(["BONK"])
    notifier = FakeNotifier()
    orch = Orchestrator(
        source=None, peg=ConstantPegSource(1.0), adapter=adapter,
        market=market, notifier=notifier,
        config=OrchestratorConfig(dry_run=True, min_confidence=0.5),
    )
    orch.llm_signal = __import__("src.sources.llm_signal", fromlist=["LLMSignalParser"]).LLMSignalParser(
        api_key="k")

    async def fake_call(text):
        return {"kind": "signal", "token": "BONK", "side": "SHORT",
                "entry": 0.002472, "sl": 0.002500, "tp": [0.002300], "leverage": None}
    monkeypatch.setattr(orch.llm_signal, "_call", fake_call)

    raw = RawSignal(side=Side.BUY,
                    raw_text="#BONK $BONK LONG TRADE\nENTRY: 0.002472\nTARGET: 0.002615\nSTOPLOSS: 0.002402",
                    message_id=8)
    status = await orch.handle_signal(raw)
    assert status == "needs_review:signal_conflict"
    assert len(adapter.placed) == 0


@pytest.mark.asyncio
async def test_llm_management_routes(monkeypatch):
    """LLM management 'sl_to_entry' on $BONK -> applied, no conflict."""
    adapter = FakeHyperliquidAdapter()
    market = FakeMarketStream(["BONK"])
    notifier = FakeNotifier()
    orch = Orchestrator(
        source=None, peg=ConstantPegSource(1.0), adapter=adapter,
        market=market, notifier=notifier,
        config=OrchestratorConfig(dry_run=True, min_confidence=0.5),
    )
    orch.llm_signal = __import__("src.sources.llm_signal", fromlist=["LLMSignalParser"]).LLMSignalParser(
        api_key="k")
    from src.domain.model import Instrument, Settlement
    await orch.on_position(Position(
        instrument=Instrument(symbol="BONK", base="BONK", quote=Settlement.USDC),
        side=Side.BUY, size_coin=100.0, entry_px=0.002472, leverage=3,
        margin_usd=1.0, sl_px=0.002402, sl_order_id="sl_BONK"))

    async def fake_call(text):
        return {"kind": "management", "action": "sl_to_entry", "token": "BONK",
                "fraction": None, "price": None}
    monkeypatch.setattr(orch.llm_signal, "_call", fake_call)

    raw = RawSignal(side=Side.BUY, raw_text="sl to entry $BONK", message_id=9)
    status = await orch.handle_signal(raw)
    assert status != "needs_review:mgmt_conflict"
    assert status in ("managed", "sl_moved", "sl_to_entry", "partial", "closed",
                      "dry-run:management")


def _async(v):
    async def _():
        return v
    return _()
