"""Tests for the rich chart prompt -> internal struct adapter.

The danger this guards against: the rich schema does not match the internal
one, so an unmapped payload would null every level while leaving
``has_chart_data`` True, letting a chart pass the orchestrator gate carrying
nothing tradeable.
"""

import json

from src.sources.chart_prompt import adapt_rich_to_struct
from src.sources.vision import parse_vision_response


def test_position_tool_maps_to_levels_and_trend():
    rich = {
        "position": {
            "direction": "short",
            "entry": 0.345,
            "stop_loss": 0.3545,
            "take_profit": 0.31,
            "risk_reward": 2.0,
        }
    }
    out = adapt_rich_to_struct(rich)
    assert out["levels"]["entry"] == 0.345
    assert out["levels"]["sl"] == 0.3545
    assert out["levels"]["tp"] == [0.31]
    assert out["trend"] == "downtrend"
    assert out["has_chart_data"] is True


def test_long_direction_maps_to_uptrend():
    out = adapt_rich_to_struct({"position": {"direction": "LONG", "entry": 100.0}})
    assert out["trend"] == "uptrend"


def test_typed_price_levels_fill_gaps():
    rich = {
        "price_levels": [
            {"price": 0.345, "type": "entry"},
            {"price": 0.3545, "type": "stop_loss"},
            {"price": 0.31, "type": "take_profit"},
            {"price": 0.30, "type": "support"},
            {"price": 0.40, "type": "resistance"},
        ]
    }
    out = adapt_rich_to_struct(rich)
    assert out["levels"]["entry"] == 0.345
    assert out["levels"]["sl"] == 0.3545
    assert out["levels"]["tp"] == [0.31]
    assert out["levels"]["support"] == [0.30]
    assert out["levels"]["resistance"] == [0.40]


def test_zone_bounds_are_kept_verbatim_not_averaged():
    """Zone bounds are REAL displayed prices; the midpoint is invented.

    OLD behavior emitted (top+bottom)/2, which put a number on the chart that
    was never printed there AND drifted run to run (63542.2 / 63994.75 /
    63678.55 across three reads of the same BTC bias chart).
    """
    rich = {
        "support_resistance": [
            {"type": "support", "top": 64059.0, "bottom": 63930.5},
            {"type": "resistance", "top": 68206.4, "bottom": 67442.3},
        ]
    }
    out = adapt_rich_to_struct(rich)
    assert out["levels"]["support"] == [63930.5, 64059.0]
    assert out["levels"]["resistance"] == [67442.3, 68206.4]
    # the midpoints must NOT appear
    assert 63994.75 not in out["levels"]["support"]
    assert 67824.35 not in out["levels"]["resistance"]


def test_zone_with_explicit_price_uses_it():
    rich = {"support_resistance": [{"type": "support", "price": 63153.9}]}
    out = adapt_rich_to_struct(rich)
    assert out["levels"]["support"] == [63153.9]


def test_target_zone_never_becomes_a_midpoint_tp():
    """REGRESSION (real ONDO chart, 2026-08-10).

    A green target zone spanning 0.3449..0.2898 was turned into
    ``tp=0.31735`` — the midpoint, a price printed NOWHERE on the chart.
    A tradeable level must be a number actually displayed.
    """
    rich = {
        "position": {"direction": "short", "entry": 0.3449, "stop_loss": 0.3496},
        "zones": [
            {"type": "target", "top": 0.3449, "bottom": 0.2898, "color": "green"},
        ],
    }
    out = adapt_rich_to_struct(rich)
    assert 0.31735 not in out["levels"]["tp"], "fabricated a midpoint target price"
    assert out["levels"]["entry"] == 0.3449
    assert out["levels"]["sl"] == 0.3496


def test_single_bound_zone_is_usable():
    """One boundary is unambiguous, so it may be used."""
    rich = {"zones": [{"type": "stop_loss", "top": 0.3496, "bottom": None}]}
    out = adapt_rich_to_struct(rich)
    assert out["levels"]["sl"] == 0.3496


def test_commas_and_approx_strings_are_parsed():
    rich = {"position": {"entry": "63,930.5", "stop_loss": "approx 62000"}}
    out = adapt_rich_to_struct(rich)
    assert out["levels"]["entry"] == 63930.5
    assert out["levels"]["sl"] == 62000.0


def test_empty_payload_is_not_tradeable():
    """The critical guard: nothing readable -> has_chart_data False."""
    out = adapt_rich_to_struct({"chart": {"symbol": "BTCUSDT"}, "position": {}})
    assert out["has_chart_data"] is False
    assert out["levels"]["entry"] is None
    assert out["levels"]["sl"] is None
    assert out["levels"]["tp"] == []


def test_all_null_position_is_not_tradeable():
    rich = {
        "position": {
            "direction": None,
            "entry": None,
            "stop_loss": None,
            "take_profit": None,
        },
        "annotations": [{"type": "text", "description": "gm"}],
    }
    assert adapt_rich_to_struct(rich)["has_chart_data"] is False


def test_garbage_input_is_safe():
    for bad in (None, "nope", 42, []):
        out = adapt_rich_to_struct(bad)
        assert out["has_chart_data"] is False
        assert out["levels"]["entry"] is None


def test_arrows_never_set_the_trade_side():
    """An arrow is an annotation, not a prediction. It must not pick a side."""
    rich = {
        "arrows": [
            {
                "direction": "up",
                "movement_type": "projected_upward_movement",
                "start_price": 100.0,
                "end_price": 120.0,
            }
        ]
    }
    out = adapt_rich_to_struct(rich)
    assert out["trend"] == ""  # no side derived from a drawing
    assert out["has_chart_data"] is False  # and nothing tradeable


def test_rich_payload_preserved_for_logging():
    rich = {"chart": {"symbol": "ONDO"}, "position": {"entry": 0.345}}
    out = adapt_rich_to_struct(rich)
    assert out["rich"]["chart"]["symbol"] == "ONDO"


def test_parse_vision_response_routes_rich_schema():
    raw = json.dumps({"position": {"direction": "short", "entry": 0.345,
                                   "stop_loss": 0.3545}})
    out = parse_vision_response(raw, rich=True)
    assert out["levels"]["entry"] == 0.345
    assert out["trend"] == "downtrend"


def test_parse_vision_response_strips_fences_in_rich_mode():
    raw = '```json\n{"position": {"entry": 1.5, "direction": "long"}}\n```'
    out = parse_vision_response(raw, rich=True)
    assert out["levels"]["entry"] == 1.5
    assert out["trend"] == "uptrend"


def test_legacy_schema_still_works_when_rich_disabled():
    raw = json.dumps({
        "levels": {"entry": 1.0, "sl": 0.9, "tp": [1.2], "support": [], "resistance": []},
        "trend": "uptrend", "has_chart_data": True,
    })
    out = parse_vision_response(raw)
    assert out["levels"]["entry"] == 1.0
    assert out["trend"] == "uptrend"


def test_rich_schema_through_legacy_path_is_inert_not_dangerous():
    """Regression: the rich shape must never yield has_chart_data=True with
    empty levels. That combination would pass the orchestrator gate with
    nothing to trade on."""
    raw = json.dumps({"position": {"entry": 0.345, "stop_loss": 0.3545}})
    legacy = parse_vision_response(raw)  # rich=False -> old coercion
    if legacy["has_chart_data"]:
        assert legacy["levels"]["entry"] is not None, (
            "legacy coercion reported chart data while dropping every level"
        )
