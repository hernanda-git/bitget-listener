"""Tests for the offline local vision backend (no LLM provider).

The pixel->price OCR path is validated separately against real channel charts
(see scripts/test_local_vision.py / the 12 sampled images). Here we unit-test
the *decision logic* (color -> role mapping, side handling, y->price
interpolation) by injecting predetermined perception results, which keeps the
tests deterministic and offline.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from src.sources.local_vision import LocalVisionExtractor


def _fake_img(path: Path) -> None:
    """Write a small valid image so cv2.imread succeeds (perception is mocked)."""
    import cv2
    import numpy as np
    cv2.imwrite(str(path), np.zeros((100, 100, 3), dtype=np.uint8))


@pytest.mark.asyncio
async def test_local_vision_long_classifies_entry_sl_tp(tmp_path):
    img = tmp_path / "chart.jpg"
    _fake_img(img)
    ext = LocalVisionExtractor({})

    # Inject perception: anchors (y, price) + colored tags (y, ocr_price|None).
    # Axis: y=100->0.0060, y=900->0.0090  (slope = +0.0030/800px)
    ext._axis_anchors = lambda im: [(100, 0.0060), (900, 0.0090)]
    # green TP at y=200, red entry box (timer, price=None) at y=400, red SL at y=800
    ext._colored_tags = lambda strip: {
        "green": [(200, 0.0085)],
        "red": [(400, None), (800, 0.0070)],
        "purple": [], "orange": [],
    }

    res = await ext.extract(img, caption="LONG")
    lv = res["levels"]
    assert res["has_chart_data"] is True
    # SL from OCR'd red tag
    assert lv["sl"] is not None and abs(lv["sl"] - 0.0070) < 1e-4
    # TP from green
    assert lv["tp"] and abs(lv["tp"][0] - 0.0085) < 1e-4
    # entry: red tag had no OCR price -> interpolated via the y->price fit line.
    # The fit is a regression through all anchors, so allow a tolerance band
    # within the axis-scale range rather than an exact two-point interp.
    assert lv["entry"] is not None
    assert 0.0065 < lv["entry"] < 0.0080


@pytest.mark.asyncio
async def test_local_vision_short_classifies(tmp_path):
    img = tmp_path / "chart.jpg"
    _fake_img(img)
    ext = LocalVisionExtractor({})
    ext._axis_anchors = lambda im: [(100, 0.0055), (900, 0.0075)]
    ext._colored_tags = lambda strip: {
        "green": [(800, 0.0058)],
        "red": [(300, 0.0065), (250, 0.0068)],  # entry lower, SL higher (short)
        "purple": [], "orange": [],
    }
    res = await ext.extract(img, caption="SHORT")
    lv = res["levels"]
    assert res["has_chart_data"] is True
    assert lv["sl"] is not None and abs(lv["sl"] - 0.0068) < 1e-4
    assert lv["tp"] and abs(lv["tp"][0] - 0.0058) < 1e-4
    assert lv["entry"] is not None and abs(lv["entry"] - 0.0065) < 1e-4


@pytest.mark.asyncio
async def test_local_vision_no_colored_levels_returns_no_data(tmp_path):
    img = tmp_path / "chart.jpg"
    _fake_img(img)
    ext = LocalVisionExtractor({})
    ext._axis_anchors = lambda im: [(100, 0.0060), (900, 0.0090)]
    ext._colored_tags = lambda strip: {  # only axis, no trade tags
        "green": [], "red": [], "purple": [], "orange": [],
    }
    res = await ext.extract(img, caption="LONG")
    assert res["has_chart_data"] is False


@pytest.mark.asyncio
async def test_local_vision_missing_file(tmp_path):
    ext = LocalVisionExtractor({})
    res = await ext.extract(tmp_path / "nope.jpg", caption="LONG")
    assert res["has_chart_data"] is False
