"""Safe end-to-end checks for the multi-bot launcher plumbing.

These prove the money-path wiring (paper flag -> dry_run, /toggle persistence,
launcher selection) WITHOUT any network or live orders. The actual trade
execution is covered by tests/test_orchestrator.py with fakes.

Uses the dedicated test database (fatty_config_test), never production.
"""

import asyncio
import os

import psycopg
import pytest

from src.config.db import BotConfig, ConfigStore
from src.config.loader import AppConfig
from src.orchestrator import Orchestrator, OrchestratorConfig
from src.services.peg import ConstantPegSource
from src.exchanges.fake import FakeHyperliquidAdapter
from src.streaming.fake import FakeMarketStream
from src.notifier.bot import DashboardState

TEST_DB_URL = os.getenv(
    "CONFIG_DB_TEST_URL",
    "postgresql://app:app@127.0.0.1:5432/fatty_config_test",
)


def _wipe():
    with psycopg.connect(TEST_DB_URL) as c:
        c.execute("DELETE FROM risk")
        c.execute("DELETE FROM bots")
        c.commit()


@pytest.fixture
def store():
    _wipe()
    yield ConfigStore(TEST_DB_URL)
    _wipe()


class FakeNotifier:
    def __init__(self):
        self.sent = []
    async def send(self, text):
        self.sent.append(text)


def _orch_from_bot(bot: BotConfig):
    cfg = AppConfig.from_bot(bot)
    return Orchestrator(
        source=None, peg=ConstantPegSource(1.0),
        adapter=FakeHyperliquidAdapter(), market=FakeMarketStream(["BTC"]),
        notifier=FakeNotifier(),
        config=OrchestratorConfig(dry_run=cfg.dry_run, min_confidence=cfg.min_confidence),
    )


@pytest.mark.asyncio
async def test_paper_bot_does_not_place_real_orders(store):
    store.upsert_bot(BotConfig(name="paper1", paper=True, testnet=True))
    bot = store.get_bot("paper1")
    orch = _orch_from_bot(bot)
    assert orch.cfg.dry_run is True  # paper == dry-run, no real orders


@pytest.mark.asyncio
async def test_toggle_persists_paper_flag_to_db(store):
    store.upsert_bot(BotConfig(name="t1", paper=True))
    bot = store.get_bot("t1")

    # Simulate the dashboard /toggle -> live handler.
    async def on_toggle(mode):
        store.set_paper("t1", paper=(mode != "live"))
    state = DashboardState()
    state.handlers["on_toggle"] = on_toggle

    await state.handlers["on_toggle"]("live")
    assert store.get_bot("t1").paper is False
    await state.handlers["on_toggle"]("dry-run")
    assert store.get_bot("t1").paper is True


@pytest.mark.asyncio
async def test_live_bot_flag_drives_dry_run_false(store):
    store.upsert_bot(BotConfig(name="live1", paper=False, testnet=False))
    bot = store.get_bot("live1")
    cfg = AppConfig.from_bot(bot)
    assert cfg.dry_run is False
    assert cfg.hyperliquid.testnet is False


@pytest.mark.asyncio
async def test_run_bot_instance_refuses_missing_token(capsys):
    """A bot with no TG token in env must not start (and must not crash)."""
    import src.main as main
    _wipe()
    store = ConfigStore(TEST_DB_URL)
    store.upsert_bot(BotConfig(name="notok", tg_bot_token_env="NOPE_TOKEN"))
    # No NOPE_TOKEN in env -> should return early, no exception.
    await main.run_bot_instance("notok", store)
    assert True
