"""Tests for the LLM signal/management parser + cross-check helpers.

The LLM network call is monkeypatched (_call returns canned JSON) so no real
endpoint/key is needed. Cross-check statics are tested directly.
"""

import pytest

from src.orchestrator import Orchestrator
from src.sources.llm_signal import LLMSignalParser, normalize_llm
from src.sources.parser import parse_signal
from src.domain.model import RawSignal, Side


@pytest.mark.asyncio
async def test_llm_parse_signal(monkeypatch):
    p = LLMSignalParser(base_url="http://x/v1", model="tencent/hy3:free", api_key="k")
    assert p.enabled
    async def fake_call(text):
        return {
            "kind": "signal", "token": "BONK", "side": "LONG",
            "entry": 0.002472, "sl": 0.002402, "tp": [0.002615], "leverage": None,
        }
    monkeypatch.setattr(p, "_call", fake_call)
    out = await p.parse("#BONK $BONK LONG TRADE")
    assert out["kind"] == "signal"
    assert out["token"] == "BONK"
    assert out["side"] == "LONG"
    assert out["entry"] == 0.002472
    assert out["tp"] == [0.002615]


@pytest.mark.asyncio
async def test_llm_parse_management(monkeypatch):
    p = LLMSignalParser(api_key="k")
    async def fake_call(text):
        return {"kind": "management", "action": "sl_to_entry", "token": "ONDO",
                "fraction": None, "price": None}
    monkeypatch.setattr(p, "_call", fake_call)
    out = await p.parse("sl to entry $ONDO")
    assert out["kind"] == "management"
    assert out["action"] == "sl_to_entry"


@pytest.mark.asyncio
async def test_llm_disabled_without_key():
    p = LLMSignalParser(api_key="")
    assert p.enabled is False
    assert await p.parse("anything") is None


def test_normalize_handles_noise_and_bias():
    assert normalize_llm({"kind": "noise"}) == {"kind": "noise"}
    b = normalize_llm({"kind": "bias", "token": "btc", "bias": "bullish"})
    assert b["kind"] == "bias" and b["token"] == "BTC" and b["bias"] == "BULLISH"


def test_signal_agree():
    llm = {"token": "BONK", "side": "LONG"}
    regex = parse_signal("#BONK $BONK LONG TRADE\nENTRY: 0.002472\nTARGET: 0.002615\nSTOPLOSS: 0.002402")
    assert Orchestrator._signal_agree(llm, regex) is True
    # side conflict
    bad = {"token": "BONK", "side": "SHORT"}
    assert Orchestrator._signal_agree(bad, regex) is False
    # symbol conflict
    bad2 = {"token": "PUMP", "side": "LONG"}
    assert Orchestrator._signal_agree(bad2, regex) is False


def test_levels_diverge():
    # same within 5%
    assert Orchestrator._levels_diverge(
        {"entry": 0.002472, "sl": 0.002402, "tp": 0.002615},
        {"entry": 0.002470, "sl": 0.002400, "tp": 0.002610},
    ) is False
    # 20% apart on entry -> diverge
    assert Orchestrator._levels_diverge(
        {"entry": 0.002472, "sl": 0.002402, "tp": 0.002615},
        {"entry": 0.003000, "sl": 0.002402, "tp": 0.002615},
    ) is True
    # one-side missing -> no conflict
    assert Orchestrator._levels_diverge(
        {"entry": 0.002472, "sl": None, "tp": None},
        {"entry": 0.002472, "sl": 0.002402, "tp": 0.002615},
    ) is False
