"""Tests for the PostgreSQL-backed multi-bot config store.

Uses a dedicated test database (fatty_config_test) so the production config is
never touched. Requires CONFIG_DB_URL to point at it (set via env in conftest or
pytest.ini). No secrets, no network beyond the local PG instance.

Verifies the canonical config source of truth: round-trip of bot settings, the
persisted paper (dry-run) flag, and that multiple bots coexist independently.
"""

import os

import psycopg
import pytest

from src.config.db import (
    BotConfig, ConfigStore, RiskRow, ensure_default_bot,
)

# Dedicated test DB (schema created by the test fixture / deploy bootstrap).
TEST_DB_URL = os.getenv(
    "CONFIG_DB_TEST_URL",
    "postgresql://app:app@127.0.0.1:5432/fatty_config_test",
)


@pytest.fixture
def store():
    """A fresh store with a wiped bots/risk table for isolation."""
    s = ConfigStore(TEST_DB_URL)
    with psycopg.connect(TEST_DB_URL) as c:
        c.execute("DELETE FROM risk")
        c.execute("DELETE FROM bots")
        c.commit()
    yield s
    # cleanup
    with psycopg.connect(TEST_DB_URL) as c:
        c.execute("DELETE FROM risk")
        c.execute("DELETE FROM bots")
        c.commit()


def test_upsert_then_get_bot(store):
    cfg = BotConfig(
        name="fatty-2", paper=False, channel="otherchan", min_confidence=0.7,
        testnet=False, wallet_address="0xABC",
    )
    store.upsert_bot(cfg)
    got = store.get_bot("fatty-2")
    assert got is not None
    assert got.name == "fatty-2"
    assert got.paper is False
    assert got.live is True
    assert got.channel == "otherchan"
    assert got.min_confidence == 0.7
    assert got.testnet is False
    assert got.wallet_address == "0xABC"


def test_paper_flag_persists_across_restart(store):
    # A paper bot is dry-run; toggling to live flips and survives re-open.
    cfg = BotConfig(name="bot-x", paper=True)
    store.upsert_bot(cfg)
    assert store.get_bot("bot-x").live is False

    assert store.set_paper("bot-x", False) is True
    # Re-open the store (fresh pooled connection) to prove it's persisted in PG.
    reopened = ConfigStore(TEST_DB_URL)
    assert reopened.get_bot("bot-x").paper is False
    assert reopened.get_bot("bot-x").live is True

    # And back to paper.
    reopened.set_paper("bot-x", True)
    assert ConfigStore(TEST_DB_URL).get_bot("bot-x").live is False


def test_multiple_bots_independent(store):
    store.upsert_bot(BotConfig(name="a", paper=True, channel="chanA"))
    store.upsert_bot(BotConfig(name="b", paper=False, channel="chanB"))
    bots = {b.name: b for b in store.list_bots()}
    assert set(bots) == {"a", "b"}
    assert bots["a"].paper is True
    assert bots["b"].paper is False
    assert bots["a"].channel == "chanA"
    # toggling a does not affect b
    store.set_paper("a", False)
    assert store.get_bot("b").paper is False
    assert store.get_bot("a").paper is False


def test_set_paper_missing_bot_returns_false(store):
    assert store.set_paper("nope", False) is False
    assert store.set_enabled("nope", True) is False


def test_enabled_filter(store):
    store.upsert_bot(BotConfig(name="on", enabled=True))
    store.upsert_bot(BotConfig(name="off", enabled=False))
    enabled = store.list_bots(enabled_only=True)
    assert {b.name for b in enabled} == {"on"}
    all_bots = store.list_bots()
    assert {b.name for b in all_bots} == {"on", "off"}


def test_risk_round_trip(store):
    store.upsert_bot(BotConfig(name="r1"))
    r = RiskRow(risk_pct=0.05, default_leverage=5, max_notional_usd=500.0)
    store.upsert_risk("r1", r)
    got = store.get_risk("r1")
    assert got.risk_pct == 0.05
    assert got.default_leverage == 5
    assert got.max_notional_usd == 500.0


def test_ensure_default_bot_idempotent(store):
    first = ensure_default_bot(store, "fatty-main")
    assert first.name == "fatty-main"
    second = ensure_default_bot(store, "fatty-main")
    assert second.name == "fatty-main"
    assert len(store.list_bots()) == 1


def test_appconfig_from_bot_paper_maps_to_dry_run():
    """paper flag must drive dry_run in the typed config used by the engine."""
    from src.config.loader import AppConfig
    bot = BotConfig(name="x", paper=True, channel="c", testnet=True)
    cfg = AppConfig.from_bot(bot)
    assert cfg.dry_run is True
    bot2 = BotConfig(name="x", paper=False, channel="c", testnet=False)
    cfg2 = AppConfig.from_bot(bot2)
    assert cfg2.dry_run is False
    assert cfg2.hyperliquid.testnet is False
