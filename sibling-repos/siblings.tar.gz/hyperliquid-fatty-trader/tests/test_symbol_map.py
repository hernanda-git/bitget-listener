"""Tests for the symbol resolver (token -> Hyperliquid ticker mapping)."""

from __future__ import annotations

import pytest

from src.sources.symbol_map import SymbolResolver, _normalize_token


@pytest.mark.asyncio
async def test_exact_match():
    r = SymbolResolver(universe={"PUMP": 10, "BTC": 40})
    assert await r.resolve("PUMP") == "PUMP"
    assert await r.resolve("$BTC") == "BTC"
    assert await r.resolve("btcusdt") == "BTC"


@pytest.mark.asyncio
async def test_k_prefix_variant():
    r = SymbolResolver(universe={"kBONK": 5, "PUMP": 10})
    assert await r.resolve("BONK") == "kBONK"
    assert await r.resolve("$bonk") == "kBONK"


@pytest.mark.asyncio
async def test_1000_prefix_variant():
    # Some small-unit tokens use the 1000-prefix on mainnet; resolver maps to it.
    r = SymbolResolver(universe={"1000PEPE": 20, "PUMP": 10})
    assert await r.resolve("PEPE") == "1000PEPE"


@pytest.mark.asyncio
async def test_exact_beats_prefix():
    r = SymbolResolver(universe={"PEPE": 20, "1000PEPE": 20})
    assert await r.resolve("PEPE") == "PEPE"  # exact wins over 1000-prefix


@pytest.mark.asyncio
async def test_unlisted_returns_none():
    r = SymbolResolver(universe={"PUMP": 10})
    assert await r.resolve("NOTREAL") is None
    assert await r.resolve("") is None


def test_normalize_token():
    assert _normalize_token("$BONK") == "BONK"
    assert _normalize_token("#pump") == "PUMP"
    assert _normalize_token("btcusdt") == "BTC"
    assert _normalize_token("ethusdc") == "ETH"
