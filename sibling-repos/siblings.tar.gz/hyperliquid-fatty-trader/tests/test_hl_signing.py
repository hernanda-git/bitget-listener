"""Offline verification of Hyperliquid order signing.

This does NOT hit the network. It proves the adapter signs exchange actions the
way HL's own SDK does: the produced signature must recover to the configured
wallet address. (Live order placement itself is blocked by an HL API/SDK drift —
see CHANGELOG — so this is the strongest offline guarantee we can make.)
"""
import os
import sys

import pytest
from dotenv import load_dotenv

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from eth_account import Account  # noqa: E402

from src.exchanges.hyperliquid import HyperliquidAdapter, _DOMAIN_MAINNET  # noqa: E402

load_dotenv(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), ".env"))


def _recover(action, sig):
    """Recover the signer address from our _sign_l1 output (mirrors HL SDK)."""
    import msgpack
    import time
    from eth_account.messages import encode_typed_data
    from eth_utils import keccak

    nonce = 1234567890
    data = msgpack.packb(action) + nonce.to_bytes(8, "big") + b"\x00"
    action_hash = keccak(data)
    phantom = {"source": "a", "connectionId": action_hash}
    domain = {
        "chainId": 1337,
        "name": "Exchange",
        "verifyingContract": "0x0000000000000000000000000000000000000000",
        "version": "1",
    }
    types = {
        "Agent": [
            {"name": "source", "type": "string"},
            {"name": "connectionId", "type": "bytes32"},
        ],
        "EIP712Domain": [
            {"name": "name", "type": "string"},
            {"name": "version", "type": "string"},
            {"name": "chainId", "type": "uint256"},
            {"name": "verifyingContract", "type": "address"},
        ],
    }
    struct = encode_typed_data(
        full_message={"domain": domain, "types": types,
                       "primaryType": "Agent", "message": phantom}
    )
    return Account.recover_message(
        struct, vrs=(int(sig["v"], 16), int(sig["r"], 16), int(sig["s"], 16))
    )


@pytest.mark.skipif(
    not os.getenv("HL_PRIVATE_KEY"),
    reason="no HL key in env",
)
def test_sign_l1_recovers_to_wallet():
    ad = HyperliquidAdapter(
        private_key=os.getenv("HL_PRIVATE_KEY"),
        account_address=os.getenv("HL_ACCOUNT_ADDRESS"),
        testnet=False,
    )
    assert ad._domain is _DOMAIN_MAINNET
    action = {
        "type": "order",
        "orders": [{
            "a": "BTC", "b": True, "p": "0", "s": "0.000003",
            "r": False, "t": {"limit": {"tif": "Ioc"}},
            "c": "0x1234567890abcdef1234567890abcdef",
        }],
        "grouping": "na",
    }
    sig = ad._sign_l1(action, 1234567890)
    assert set(sig.keys()) == {"r", "s", "v"}
    recovered = _recover(action, sig)
    assert recovered.lower() == ad._address.lower()
