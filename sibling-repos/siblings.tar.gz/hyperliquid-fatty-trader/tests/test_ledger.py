"""Tests for the Postgres-backed signal/trade ledger and bias recorder.

Uses the dedicated test database (fatty_config_test) so production data is
never touched. CONFIG_DB_TEST_URL (set in .env) points here.
"""

import os

import pytest

from src.sources.bias import BiasRecorder, BiasRecord, parse_bias
from src.store.ledger import Ledger


def _ledger():
    # Honors CONFIG_DB_TEST_URL when present.
    l = Ledger(bot="test-bot")
    return l


@pytest.mark.asyncio
async def test_ledger_records_signal_and_trade_lifecycle():
    """A full signal -> order -> open -> close(pnl) cycle is durably stored."""
    l = _ledger()
    # wipe prior test rows
    conn = l._conn()
    try:
        conn.execute("DELETE FROM signals_log WHERE bot='test-bot'")
        conn.execute("DELETE FROM trades_log WHERE bot='test-bot'")
        conn.commit()
    finally:
        conn.close()

    l.log_signal("BONKUSDT", "BUY", "fattyfatclub", 777, "#BONK LONG\nENTRY 0.001")
    l.log_order("BONKUSDT", "BUY", entry=0.001, sl=0.0009, tp=0.0012, lev=3, dry=False)
    l.log_close("BONKUSDT", exit_px=0.00115, pnl=12.5, reason="tp")

    sigs = l.recent_signals(limit=5)
    assert any(s["symbol"] == "BONKUSDT" and "BONK LONG" in (s["raw"] or "") for s in sigs)

    trades = l.recent_trades(limit=5)
    assert any(t["symbol"] == "BONKUSDT" and t["reason"] == "tp" and t["pnl"] == 12.5
               for t in trades)

    summary = l.trade_summary()
    assert summary["total_closed"] >= 1
    assert summary["wins"] >= 1
    assert summary["net_pnl"] >= 12.5


@pytest.mark.asyncio
async def test_ledger_management_note():
    l = _ledger()
    conn = l._conn()
    try:
        conn.execute("DELETE FROM trades_log WHERE bot='test-bot'")
        conn.commit()
    finally:
        conn.close()
    l.log_order("SOLUSDT", "SELL", entry=150.0, dry=False)
    l.log_management("SOLUSDT", "sl_moved")
    trades = l.recent_trades(limit=5)
    assert any(t["symbol"] == "SOLUSDT" and (t["reason"] or "").startswith("mgmt:")
               for t in trades)


@pytest.mark.asyncio
async def test_bias_recorder_postgres_roundtrip():
    """BiasRecorder now writes to Postgres (no SQLite)."""
    rec = BiasRecorder()
    parsed = parse_bias("$BTC bias: BULLISH — send it")
    assert parsed is not None and parsed.bias == "BULLISH" and parsed.target == "BTC"
    rid = rec.record(parsed, message_id=999, channel="fattyfatclub")
    assert rid > 0
    recent = rec.recent(limit=5, target="BTC")
    assert any(r["bias"] == "BULLISH" and r["target"] == "BTC" for r in recent)
    summ = rec.summary()
    assert summ["BULLISH"] >= 1
