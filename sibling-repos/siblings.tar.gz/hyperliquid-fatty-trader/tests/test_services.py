"""Tests for risk / order (frontrun split) / position services."""

import pytest

from src.domain.model import Instrument, OrderType, Side, Signal, UsdNotional, Settlement, Position
from src.services.risk import RiskManager, RiskConfig
from src.services.order import OrderService
from src.services.position import PositionManager
from src.services.peg import ConstantPegSource
from src.services.normalizer import SignalNormalizer
import asyncio


def _signal(side=Side.BUY, entry=60000.0, sl=58000.0, tp=64000.0, lev=10, conf=0.8):
    inst = Instrument(symbol="BTC", base="BTC", quote=Settlement.USDC)
    return Signal(
        instrument=inst, side=side, entry=entry, sl=sl, tp=tp,
        notional=UsdNotional(amount_usd=1000.0, settlement=Settlement.USDC),
        leverage=lev, confidence=conf, peg_rate=1.0,
    )


def test_risk_compute_size_risk_based():
    """New behaviour: size is derived from risk_pct * equity / sl_distance."""
    rm = RiskManager(RiskConfig(risk_pct=0.02, default_leverage=3))
    equity = 100.0
    # sl distance 3.33% -> notional = 2 / 0.0333 = ~60 ; size = 60/60000
    size, lev = rm.compute_size(0.0, 60000.0, equity_usd=equity,
                                sl_price=58000.0, free_margin_usd=equity)
    expected_notional = (equity * 0.02) / (2000.0 / 60000.0)
    assert abs(size - (expected_notional / 60000.0)) < 1e-9
    assert lev == 3


def test_risk_compute_size_fallback_no_sl():
    """Without an SL, falls back to fallback_sl_pct so sizing stays bounded."""
    rm = RiskManager(RiskConfig(risk_pct=0.02, fallback_sl_pct=0.05))
    size, lev = rm.compute_size(0.0, 60000.0, equity_usd=100.0,
                                sl_price=None, free_margin_usd=100.0)
    expected_notional = (100.0 * 0.02) / 0.05
    assert abs(size - (expected_notional / 60000.0)) < 1e-9


def test_order_single_limit_when_no_frontrun():
    rm = RiskManager()
    osvc = OrderService(rm, frontrun_split=True)
    sig = _signal(entry=60000.0)
    orders = osvc.build_orders(sig, mark_price=60000.0)  # mark == entry -> not frontrunned
    # entry + sl + tp = 3 orders
    assert len(orders) == 3
    entry_orders = [o for o in orders if o.order_type == OrderType.LIMIT]
    assert len(entry_orders) == 1
    assert entry_orders[0].price == 60000.0


def test_order_frontrun_split_25_75():
    rm = RiskManager()
    osvc = OrderService(rm, frontrun_split=True, frontrun_threshold=0.0015)
    sig = _signal(side=Side.BUY, entry=60000.0)
    # mark moved UP 1% -> frontrunned long
    orders = osvc.build_orders(sig, mark_price=60600.0)
    mkt = [o for o in orders if o.order_type == OrderType.MARKET]
    lim = [o for o in orders if o.order_type == OrderType.LIMIT]
    assert len(mkt) == 1 and len(lim) == 1
    total = mkt[0].size_coin + lim[0].size_coin
    # market ~25%, limit ~75% of total
    assert abs(mkt[0].size_coin / total - 0.25) < 0.02
    assert abs(lim[0].size_coin / total - 0.75) < 0.02
    # child SL/TP present
    assert any(o.tpsl == "sl" for o in orders)
    assert any(o.tpsl == "tp" for o in orders)


def test_position_manager_reconcile():
    pm = PositionManager()
    inst = Instrument(symbol="BTC", base="BTC")
    pm.reconcile([
        Position(instrument=inst, side=Side.BUY, size_coin=0.01, entry_px=60000.0, leverage=10, margin_usd=100.0),
    ])
    assert pm.has("BTC")
    assert pm.get("BTC").size_coin == 0.01
    # zero-size removes
    pm.apply_position_update(Position(instrument=inst, side=Side.BUY, size_coin=0.0, entry_px=60000.0, leverage=10, margin_usd=0.0))


def test_risk_min_notional_bumps_leverage():
    """When the risk-sized notional lands below HL's min-notional floor, the
    notional is lifted to the floor and leverage is raised (within max) so the
    required margin still fits free margin. This is the 'bump leverage to clear
    the min-notional wall' behaviour the user authorized.
    """
    # tiny equity -> tiny risk_usd -> notional far below the $10 floor
    rm = RiskManager(RiskConfig(risk_pct=0.02, default_leverage=3,
                                 min_notional_usd=10.0, max_leverage=20))
    size, lev = rm.compute_size(0.0, 60000.0, equity_usd=1.0,
                                sl_price=59000.0, free_margin_usd=1.0)
    notional = size * 60000.0
    # notional lifted to the floor
    assert notional >= 10.0 - 1e-6
    # leverage raised so margin (notional/lev) fits free margin (1.0)
    assert notional / lev <= 1.0 + 1e-6
    # leverage is at least the default and capped
    assert lev >= 3
    assert lev <= 20
    # margin must be > 0 and within free margin
    assert 0 < notional / lev <= 1.0 + 1e-6


def test_order_entry_is_post_only_maker_when_prefer_maker():
    """Entry limit orders are post-only (maker) so we earn the rebate, not pay
    taker fees. SL/TP triggers and market legs stay untouched."""
    rm = RiskManager()
    osvc = OrderService(rm, prefer_maker=True)
    sig = _signal(entry=60000.0)
    orders = osvc.build_orders(sig, mark_price=60000.0)
    entry = [o for o in orders if o.order_type == OrderType.LIMIT and o.tpsl is None]
    assert entry and entry[0].post_only is True
    # SL/TP triggers are NOT post_only
    sl = [o for o in orders if o.tpsl == "sl"]
    assert sl and sl[0].post_only is False and sl[0].reduce_only is True


def test_order_post_only_disabled_when_prefer_maker_false():
    rm = RiskManager()
    osvc = OrderService(rm, prefer_maker=False)
    sig = _signal(entry=60000.0)
    orders = osvc.build_orders(sig, mark_price=60000.0)
    entry = [o for o in orders if o.order_type == OrderType.LIMIT and o.tpsl is None]
    assert entry and entry[0].post_only is False


def test_adapter_schedule_cancel_action_shape():
    """Dead-man's-switch action shape is correct (offline; no network)."""
    from src.exchanges.hyperliquid import HyperliquidAdapter, _hl_order
    from src.domain.model import OrderRequest, OrderType, Side, Instrument, Settlement

    # post_only -> tif Alo
    o = OrderRequest(instrument=Instrument(symbol="BTC", base="BTC", quote=Settlement.USDC),
                     side=Side.BUY, order_type=OrderType.LIMIT, price=60000.0,
                     size_coin=0.001, post_only=True, client_order_id="X")
    assert _hl_order(o, "X")["t"] == {"limit": {"tif": "Alo"}}
    # non-post limit -> Gtc
    o2 = OrderRequest(instrument=Instrument(symbol="BTC", base="BTC", quote=Settlement.USDC),
                      side=Side.BUY, order_type=OrderType.LIMIT, price=60000.0,
                      size_coin=0.001, post_only=False, client_order_id="Y")
    assert _hl_order(o2, "Y")["t"] == {"limit": {"tif": "Gtc"}}
