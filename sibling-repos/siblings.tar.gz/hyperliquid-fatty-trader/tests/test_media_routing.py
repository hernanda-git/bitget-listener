"""Tests for media/image-signal routing in the orchestrator (pure, fakes)."""

from __future__ import annotations

import pytest

from src.domain.model import RawSignal, Side
from src.orchestrator import Orchestrator, OrchestratorConfig


class FakeNotifier:
    def __init__(self):
        self.sent: list[str] = []
    async def send(self, text: str) -> None:
        self.sent.append(text)


class FakeMarket:
    def mark_price(self, symbol):
        return 60000.0


class FakePeg:
    async def peg_rate(self):
        return 1.0


def _orch(notifier, dry_run=True):
    return Orchestrator(
        source=None, peg=FakePeg(), adapter=None,
        market=FakeMarket(), notifier=notifier,
        config=OrchestratorConfig(dry_run=dry_run),
    )


@pytest.mark.asyncio
async def test_media_without_vision_returns_vision_pending():
    n = FakeNotifier()
    orch = _orch(n)
    # image post but no fetcher/vision wired -> surfaced, not dropped as noise
    raw = RawSignal(
        message_id=15913, channel="fattyfatclub", raw_text="$BTC going good so far",
        has_media=True, image_path="/tmp/x.jpg", symbol_usdt="BTC",
    )
    status = await orch.handle_signal(raw)
    assert status == "vision_pending"
    assert any("vision-pending" in s for s in n.sent)


@pytest.mark.asyncio
async def test_media_with_vision_but_no_tradeable_levels_returns_none_then_pending():
    n = FakeNotifier()
    orch = _orch(n)

    class FakeFetcher:
        async def download(self, *a, **k):
            return ("/tmp/x.jpg", "photo")
    class NoLevelsVision:
        async def extract(self, image_path="", caption=""):
            return {"has_chart_data": True, "levels": {"entry": None, "sl": None,
                    "tp": [], "support": [], "resistance": []}, "trend": "range"}
    orch.attachment_fetcher = FakeFetcher()
    orch.vision_extractor = NoLevelsVision()

    raw = RawSignal(message_id=15906, channel="fattyfatclub", raw_text="$BTC range identified",
                    has_media=True, image_path="/tmp/x.jpg", symbol_usdt="BTC")
    status = await orch.handle_signal(raw)
    # no entry/sl -> vision returns None -> handler reports vision_pending
    assert status == "vision_pending"


@pytest.mark.asyncio
async def test_media_with_vision_tradeable_levels_trades_dry_run():
    n = FakeNotifier()
    orch = _orch(n, dry_run=True)

    class FakeFetcher:
        async def download(self, *a, **k):
            return ("/tmp/x.jpg", "photo")
    class TradeableVision:
        async def extract(self, image_path="", caption=""):
            return {"has_chart_data": True,
                    "levels": {"entry": 60000.0, "sl": 58000.0, "tp": [64000.0],
                               "support": [58000.0], "resistance": [64000.0]},
                    "trend": "uptrend"}
    orch.attachment_fetcher = FakeFetcher()
    orch.vision_extractor = TradeableVision()

    raw = RawSignal(message_id=15913, channel="fattyfatclub", raw_text="$BTC going good so far",
                    has_media=True, image_path="/tmp/x.jpg", symbol_usdt="BTC")
    status = await orch.handle_signal(raw)
    assert status == "dry-run"
    assert any("BTC" in s and "dry-run" in s for s in n.sent)


class FakeBiasRecorder:
    """Captures the BiasRecord passed to record()."""
    def __init__(self):
        self.records: list = []
    def record(self, rec, message_id=None, channel=""):
        self.records.append(rec)
        return len(self.records)


@pytest.mark.asyncio
async def test_text_bias_enriched_with_chart_arrow():
    n = FakeNotifier()
    orch = _orch(n)
    orch.bias_recorder = FakeBiasRecorder()

    class ChartVision:
        async def extract(self, image_path="", caption=""):
            return {"has_chart_data": True,
                    "levels": {"entry": None, "sl": None, "tp": [],
                               "support": [63153.9, 63930.5],
                               "resistance": [67442.3, 68206.4]},
                    "trend": "range",
                    "rich": {"arrows": [{"movement_type": "projected_upward_movement"}]}}
    orch.vision_extractor = ChartVision()

    raw = RawSignal(message_id=15930, channel="fattyfatclub",
                    raw_text="BTC bias: BULLISH", has_media=True,
                    image_path="/tmp/x.jpg", symbol_usdt="BTC")
    status = await orch.handle_signal(raw)
    assert status == "bias_logged"
    assert orch.bias_recorder.records, "bias must be recorded"
    rec = orch.bias_recorder.records[0]
    assert rec.bias == "BULLISH"
    assert rec.arrow == "BULLISH"
    assert rec.source == "text+chart"
    assert rec.levels_json and "63153.9" in rec.levels_json


@pytest.mark.asyncio
async def test_chart_only_bias_with_arrow_is_logged_not_pending():
    n = FakeNotifier()
    orch = _orch(n)
    orch.bias_recorder = FakeBiasRecorder()

    class ChartVision:
        async def extract(self, image_path="", caption=""):
            return {"has_chart_data": True,
                    "levels": {"entry": None, "sl": None, "tp": [],
                               "support": [63153.9], "resistance": [68206.4]},
                    "trend": "range",
                    "rich": {"arrows": [{"movement_type": "projected_downward_movement"}]}}
    orch.vision_extractor = ChartVision()

    # No "bias" word in text -> this used to fall through to vision_pending.
    raw = RawSignal(message_id=15931, channel="fattyfatclub", raw_text="$BTC",
                    has_media=True, image_path="/tmp/x.jpg", symbol_usdt="BTC")
    status = await orch.handle_signal(raw)
    assert status == "bias_logged"
    rec = orch.bias_recorder.records[0]
    assert rec.bias == "BEARISH"
    assert rec.source == "chart"


@pytest.mark.asyncio
async def test_chart_with_zones_but_no_arrow_stays_pending():
    n = FakeNotifier()
    orch = _orch(n)
    orch.bias_recorder = FakeBiasRecorder()

    class ChartVision:
        async def extract(self, image_path="", caption=""):
            # S/R zones present, but NO arrow -> must NOT become a bias.
            return {"has_chart_data": True,
                    "levels": {"entry": None, "sl": None, "tp": [],
                               "support": [63153.9], "resistance": [68206.4]},
                    "trend": "range", "rich": {}}
    orch.vision_extractor = ChartVision()

    raw = RawSignal(message_id=15932, channel="fattyfatclub", raw_text="$BTC",
                    has_media=True, image_path="/tmp/x.jpg", symbol_usdt="BTC")
    status = await orch.handle_signal(raw)
    assert status == "vision_pending"
    assert orch.bias_recorder.records == []
