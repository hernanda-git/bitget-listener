"""Tests for the PositionManager management loop + orchestrator routing."""

from __future__ import annotations

import pytest

from src.domain.model import Instrument, Position, Side
from src.services.position import PositionManager


def _pos(symbol="XAI", side=Side.BUY, entry=0.0073, sl=0.007058, size=100.0):
    inst = Instrument.from_ticker(symbol)
    return Position(instrument=inst, side=side, size_coin=size, entry_px=entry,
                    leverage=3, margin_usd=1.0, sl_px=sl, sl_order_id="oldsl")


def test_sl_to_entry_moves_stop_and_emits_orders():
    pm = PositionManager()
    pm.apply_position_update(_pos())
    plan = pm.apply_management("XAI", "sl_to_entry")
    assert plan["ok"] is True
    assert plan["orders"]
    assert pm.get("XAI").sl_px == pytest.approx(0.0073)
    assert pm.get("XAI").sl_order_id != "oldsl"


def test_sl_to_price_updates_stop():
    pm = PositionManager()
    pm.apply_position_update(_pos())
    plan = pm.apply_management("XAI", "sl_to", price=0.0071)
    assert plan["ok"] is True
    assert pm.get("XAI").sl_px == pytest.approx(0.0071)


def test_close_emits_market_close():
    pm = PositionManager()
    pm.apply_position_update(_pos(side=Side.SELL))
    plan = pm.apply_management("XAI", "close")
    assert plan["ok"] is True
    # close side opposite of position side
    assert plan["orders"][0].side == Side.BUY
    assert plan["orders"][0].is_market is True


def test_tp_hit_closes_position():
    pm = PositionManager()
    pm.apply_position_update(_pos())
    plan = pm.apply_management("XAI", "tp_hit")
    assert plan["ok"] is True
    assert plan["orders"][0].side == Side.SELL


def test_no_position_returns_not_ok():
    pm = PositionManager()
    plan = pm.apply_management("XAI", "sl_to_entry")
    assert plan["ok"] is False
