"""Tests for the per-pair minimum-notional store (src/store/min_notional.py).

These run against CONFIG_DB_TEST_URL (a throwaway Postgres). The store creates
its own table idempotently. No live Hyperliquid calls: we feed a fake adapter
that returns canned `meta` + `allMids`.
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pytest

from src.services.risk import RiskConfig
from src.store.min_notional import MinNotionalStore


class FakeAdapter:
    """Returns canned meta + allMids, no network."""
    def _info(self, payload: dict):
        if payload.get("type") == "meta":
            return {"universe": [
                {"name": "BTC", "szDecimals": 5, "maxLeverage": 40},
                {"name": "ETH", "szDecimals": 4, "maxLeverage": 25},
                {"name": "DOGE", "szDecimals": 0, "maxLeverage": 10},
            ]}
        if payload.get("type") == "allMids":
            return {"BTC": "64000.0", "ETH": "1900.0", "DOGE": "0.07"}
        raise AssertionError("unexpected info call")


@pytest.fixture
def store():
    s = MinNotionalStore()  # honors CONFIG_DB_TEST_URL
    # clean slate
    conn = s._conn()
    try:
        conn.execute("DELETE FROM hl_pair_min_notional")
        conn.commit()
    finally:
        conn.close()
    return s


def test_refresh_and_get(store):
    n = store.refresh_from_hl(FakeAdapter())
    assert n == 3
    btc = store.get("BTC")
    assert btc is not None
    assert btc["asset_index"] == 0
    assert btc["sz_decimals"] == 5
    assert btc["max_leverage"] == 40
    assert btc["mid"] == 64000.0
    # 10^-5 * 64000 = 0.64
    assert abs(btc["min_step_notional"] - 0.64) < 1e-9
    # floor is the documented default; not from API
    assert btc["min_notional"] == RiskConfig.min_notional_usd
    assert btc["is_floor_from_api"] is False
    # DOGE szDecimals=0 -> step is 1.0 (whole coin), step notional = 0.07
    doge = store.get("DOGE")
    assert doge["min_size_step"] == 1.0
    assert abs(doge["min_step_notional"] - 0.07) < 1e-9


def test_upsert_override_marks_api(store):
    store.upsert_pair("BTC", 0, 5, 40, 64000.0, 1e-5, 0.64, 25.0,
                      is_floor_from_api=True)
    btc = store.get("BTC")
    assert btc["min_notional"] == 25.0
    assert btc["is_floor_from_api"] is True


def test_count_and_all(store):
    store.refresh_from_hl(FakeAdapter())
    assert store.count() == 3
    rows = store.all()
    assert {r["symbol"] for r in rows} == {"BTC", "ETH", "DOGE"}


def test_min_notional_for_fallback():
    # Without a store, OrderService.min_notional_for falls back to config.
    from src.services.order import OrderService
    from src.services.risk import RiskManager
    from src.domain.model import Instrument, Side, OrderType, Settlement, UsdNotional, Signal

    osvc = OrderService(RiskManager(), min_notional_store=None)
    assert osvc.min_notional_for("BTC") == RiskConfig.min_notional_usd

    # With a store, it reads the per-coin floor.
    s = MinNotionalStore()
    s.upsert_pair("SOL", 5, 2, 20, 75.0, 0.01, 0.75, 12.0, is_floor_from_api=True)
    osvc2 = OrderService(RiskManager(), min_notional_store=s)
    assert osvc2.min_notional_for("SOL") == 12.0
    # unknown coin falls back to config
    assert osvc2.min_notional_for("UNKNOWNCOIN") == RiskConfig.min_notional_usd
