"""Tests for SignalNormalizer + SignalValidator (USDT->USDC boundary)."""

import pytest

from src.domain.model import RawSignal, Side
from src.services.normalizer import SignalNormalizer, NormalizationError
from src.services.peg import ConstantPegSource
from src.services.validator import SignalValidator, ValidationError, ValidationConfig


def _raw(symbol="BTCUSDT", entry=60000.0, sl=58000.0, tp=64000.0, lev=10, conf=0.8):
    return RawSignal(
        symbol_usdt=symbol, side=Side.BUY, entry_usdt=entry,
        sl_usdt=sl, tp_usdt=tp, notional_usd=1000.0, leverage=lev, confidence=conf,
    )


@pytest.mark.asyncio
async def test_normalize_strips_usdt_to_usdc():
    n = SignalNormalizer(ConstantPegSource(1.0), max_depeg=0.005)
    sig = await n.normalize(_raw())
    assert sig.instrument.base == "BTC"
    assert sig.instrument.quote.value == "USDC"
    assert sig.entry == 60000.0
    assert sig.sl == 58000.0
    assert sig.tp == 64000.0
    assert sig.notional.settlement.value == "USDC"


@pytest.mark.asyncio
async def test_normalize_applies_peg():
    n = SignalNormalizer(ConstantPegSource(0.997), max_depeg=0.005)
    sig = await n.normalize(_raw())
    # prices scaled by peg, USD notional scaled, base unchanged
    assert abs(sig.entry - 60000.0 * 0.997) < 1e-6
    assert abs(sig.notional.amount_usd - 1000.0 * 0.997) < 1e-6
    assert sig.peg_rate == 0.997


@pytest.mark.asyncio
async def test_normalize_rejects_depeg():
    n = SignalNormalizer(ConstantPegSource(0.98), max_depeg=0.005)
    with pytest.raises(NormalizationError):
        await n.normalize(_raw())


@pytest.mark.asyncio
async def test_validator_passes_clean_signal():
    from src.services.normalizer import SignalNormalizer
    raw = _raw()
    sig = await SignalNormalizer(ConstantPegSource(1.0)).normalize(raw)
    v = SignalValidator(ValidationConfig(min_confidence=0.5))
    out = v.validate(sig)
    assert out.instrument.base == "BTC"


@pytest.mark.asyncio
async def test_validator_rejects_low_confidence():
    from src.services.normalizer import SignalNormalizer
    raw = _raw(conf=0.2)
    sig = await SignalNormalizer(ConstantPegSource(1.0)).normalize(raw)
    v = SignalValidator(ValidationConfig(min_confidence=0.5))
    with pytest.raises(ValidationError):
        v.validate(sig)


@pytest.mark.asyncio
async def test_validator_rejects_bad_sl():
    from src.services.normalizer import SignalNormalizer
    raw = _raw(entry=60000.0, sl=62000.0)  # SL above entry for BUY
    sig = await SignalNormalizer(ConstantPegSource(1.0)).normalize(raw)
    v = SignalValidator(ValidationConfig(min_confidence=0.0))
    with pytest.raises(ValidationError):
        v.validate(sig)
