"""TelegramNotifier — sends trade/health alerts via Telegram.

Implements the Notifier port. Uses a telethon user client (same session as the
signal source) to push messages to a configured chat (default: "me", i.e.
Saved Messages). Requires TG_API_ID / TG_API_HASH / SESSION_STRING in the
environment — never instantiated with live creds until you provide them.
"""

from __future__ import annotations

import logging
import os
from pathlib import Path

from dotenv import load_dotenv
from telethon import TelegramClient
from telethon.sessions import StringSession

from src.interfaces.ports import Notifier

log = logging.getLogger(__name__)


class TelegramNotifier:
    def __init__(self, config: dict | None = None):
        load_dotenv(Path(__file__).resolve().parents[2] / ".env")
        api_id = int(os.getenv("TG_API_ID", "0"))
        api_hash = os.getenv("TG_API_HASH", "")
        self.notify_chat = os.getenv("NOTIFY_CHAT", "me")
        session_str = os.getenv("SESSION_STRING", "")
        session = StringSession(session_str) if session_str else str(
            Path(__file__).resolve().parents[2] / "session"
        )
        self.client = TelegramClient(session, api_id, api_hash)
        self._started = False

    async def _ensure(self) -> None:
        if not self._started:
            await self.client.connect()
            self._started = True

    async def send(self, text: str) -> None:
        try:
            await self._ensure()
            await self.client.send_message(self.notify_chat, text)
        except Exception as e:  # alerts must never crash the pipeline
            log.warning("TelegramNotifier send failed: %s", e)

    async def stop(self) -> None:
        if self._started:
            await self.client.disconnect()
            self._started = False
