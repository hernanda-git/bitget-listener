"""BotDashboard — Telegram Bot API dashboard + rich event notifier.

Two responsibilities, both backed by a single python-telegram-bot Application:

1. EVENT NOTIFIER (called by the pipeline):
   Every meaningful action emits a compact, formatted alert:
     new signal parsed, parse success/failure, order placement, open position,
     TP hit, SL moved/hit, management actions, and any exception.
   Uses HTML formatting with status emojis + monospace blocks so it reads
   clean on mobile.

2. SLASH COMMANDS (interactive, inside the bot chat):
   /status   full snapshot: bot, mode, wallet, equity, open positions
   /positions  open positions only
   /balance  perp + spot USDC
   /signals  recently seen signals (last N)
   /last      most recent event
   /toggle    flip between PAPER (dry-run) and LIVE — one command, no token
   /help      command list

The dashboard holds a small in-memory "state" object that the orchestrator
pushes into (last event, recent signals, positions snapshot). Slash handlers
read from it. This keeps the bot fully decoupled from the trading engine
(reads state, never places orders itself except the guarded /toggle switch).

SAFETY: the bot never places orders directly. The ONLY thing that flips the
runtime between dry-run (paper) and live is the /toggle command, which writes
the paper flag to the config DB so it persists across restarts. A bot's startup
mode is whatever the DB says (bots are configured, not assumed-safe). /toggle is
the single human gate to real money. No token, no --go-live flag needed.
"""

from __future__ import annotations

import asyncio
import html
import logging
import os
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

from dotenv import load_dotenv
from telegram import Update
from telegram.ext import Application, CommandHandler, ContextTypes
from telegram import BotCommand

log = logging.getLogger(__name__)

MAX_RECENT = 25


def get_version() -> str:
    """Read the current version from the VERSION file (repo root)."""
    try:
        p = Path(__file__).resolve().parents[2] / "VERSION"
        return p.read_text().strip() or "unknown"
    except Exception:
        return "unknown"


def _esc(text: str) -> str:
    return html.escape(str(text))


def _money(x: float | None) -> str:
    if x is None:
        return "—"
    return f"{x:,.2f}"


def _px(x: float | None) -> str:
    if x is None:
        return "—"
    if x >= 1000:
        return f"{x:,.2f}"
    return f"{x:.5f}"


@dataclass
class DashboardState:
    """Shared, in-memory view the pipeline writes and slash commands read.

    Per-bot fields let one Telegram bot dashboard represent a single bot
    instance in a multi-bot deployment (the bot name, its channel, and which
    env var holds its alert-chat id).
    """

    mode: str = "dry-run"          # dry-run | live
    testnet: bool = True
    wallet: str = ""
    equity_usd: float = 0.0
    perp_usdc: float = 0.0
    spot_usdc: float = 0.0
    version: str = "unknown"
    bot_name: str = "fatty-main"   # which configured bot this dashboard serves
    channel: str = "fattyfatclub"  # signal source channel
    alert_chat_env: str = "TG_BOT_CHAT"  # env var that holds this bot's chat id
    positions: list[dict] = field(default_factory=list)
    recent_signals: list[dict] = field(default_factory=list)
    last_event: dict = field(default_factory=dict)
    handlers: dict[str, Callable] = field(default_factory=dict)  # name -> async fn


class BotDashboard:
    """Telegram Bot API notifier + command dashboard."""

    def __init__(self, token: str | None = None, state: DashboardState | None = None,
                 allowed_chat: str | None = None, ledger=None, bot_name: str = ""):
        load_dotenv(Path(__file__).resolve().parents[2] / ".env")
        self.token = token or os.getenv("TG_BOT_TOKEN", "")
        self.allowed_chat = allowed_chat or os.getenv("TG_BOT_CHAT", "")
        self.state = state or DashboardState()
        self.app: Application | None = None
        self._runner_task: asyncio.Task | None = None
        # Optional durable ledger (src/store/ledger.py). When present, every
        # pipeline event is also written to Postgres for later evaluation.
        self.ledger = ledger
        self.bot_name = bot_name or os.getenv("BOT_NAME", "")

    # ------------------------------------------------------------------ #
    # Event notifier (called by the pipeline)
    # ------------------------------------------------------------------ #
    def _event(self, kind: str, title: str, **fields) -> dict:
        """Record + return a normalized event dict (also used by /last)."""
        ev = {
            "kind": kind,
            "title": title,
            "fields": fields,
            "ts": time.time(),
        }
        self.state.last_event = ev
        return ev

    async def send(self, text: str) -> None:
        """Generic send (Protocol-compatible with Notifier). Plain text."""
        await self._push(format_html(text), None)

    def _fmt_event(self, ev: dict) -> str:
        lines = [f"<b>{_esc(ev['title'])}</b>"]
        for k, v in ev.get("fields", {}).items():
            if v in (None, ""):
                continue
            if k == "raw_message":
                # Preserve the original signal text verbatim (multiline).
                lines.append(f"• {_esc(k)}:\n<pre>{_esc(v)}</pre>")
            else:
                lines.append(f"• {_esc(k)}: <code>{_esc(v)}</code>")
        return format_html("\n".join(lines), kind=ev.get("kind", ""))

    async def notify_event(self, kind: str, title: str, **fields) -> None:
        ev = self._event(kind, title, **fields)
        await self._push(self._fmt_event(ev), kind)

    # Convenience typed helpers used by the orchestrator ------------------ #
    async def signal_received(self, symbol: str, side: str, src: str,
                             mid: int | None, raw_text: str = "") -> None:
        self.state.recent_signals.append({
            "symbol": symbol, "side": side, "src": src,
            "ts": time.time(), "mid": mid, "raw": raw_text,
        })
        self.state.recent_signals = self.state.recent_signals[-MAX_RECENT:]
        fields = {
            "symbol": symbol, "side": side, "source": src,
            "message_id": mid if mid else "—",
        }
        # Always echo the original signal message from the source channel so the
        # alert is human-verifiable even when parsing yields "?".
        if raw_text:
            fields["raw_message"] = raw_text
        await self.notify_event(
            "signal", "📡 New signal", **fields,
        )
        if self.ledger is not None:
            try:
                self.ledger.log_signal(symbol, side, src, mid, raw_text)
            except Exception:
                pass

    async def parse_result(self, ok: bool, symbol: str, detail: str) -> None:
        await self.notify_event(
            "parse", ("✅ Parsed" if ok else "⚠️ Parse skipped"),
            symbol=symbol, detail=detail,
        )

    async def order_placed(self, symbol: str, side: str, n_orders: int,
                           entry=None, sl=None, tp=None, lev=None, dry=False) -> None:
        await self.notify_event(
            "order", ("🟢 Order placed" if not dry else "🧪 Dry-run order"),
            symbol=symbol, side=side, orders=n_orders,
            entry=_px(entry), sl=_px(sl), tp=_px(tp), lev=lev,
        )
        if self.ledger is not None:
            try:
                self.ledger.log_order(symbol, side, entry, sl, tp, lev, dry)
            except Exception:
                pass

    async def position_opened(self, symbol: str, side: str, size: float,
                              entry: float, lev: int, margin: float) -> None:
        self.state.positions.append({
            "symbol": symbol, "side": side, "size": size, "entry": entry,
            "lev": lev, "margin": margin, "ts": time.time(),
        })
        self.state.positions = self.state.positions[-MAX_RECENT:]
        await self.notify_event(
            "position", "📈 Position opened",
            symbol=symbol, side=side, size=size,
            entry=_px(entry), lev=lev, margin=f"${_money(margin)}",
        )
        if self.ledger is not None:
            try:
                self.ledger.log_order(symbol, side, entry, None, None, lev,
                                      dry=False, source_msg_id=None)
            except Exception:
                pass

    async def tp_hit(self, symbol: str, price: float | None, pnl: float | None) -> None:
        await self.notify_event(
            "tp", "💰 Take-profit hit",
            symbol=symbol, price=_px(price), pnl=f"${_money(pnl)}",
        )
        if self.ledger is not None:
            try:
                self.ledger.log_close(symbol, exit_px=price, pnl=pnl, reason="tp")
            except Exception:
                pass

    async def sl_hit(self, symbol: str, price: float | None, pnl: float | None) -> None:
        self.state.positions = [p for p in self.state.positions if p["symbol"] != symbol]
        await self.notify_event(
            "sl", "🛑 Stop-loss hit",
            symbol=symbol, price=_px(price), pnl=f"${_money(pnl)}",
        )
        if self.ledger is not None:
            try:
                self.ledger.log_close(symbol, exit_px=price, pnl=pnl, reason="sl")
            except Exception:
                pass

    async def sl_moved(self, symbol: str, to: float, action: str) -> None:
        await self.notify_event(
            "sl", "🔧 SL moved", symbol=symbol, to=_px(to), action=action,
        )
        if self.ledger is not None:
            try:
                self.ledger.log_management(symbol, f"sl_moved:{action}")
            except Exception:
                pass

    async def management(self, symbol: str, action: str, msg: str, dry=False) -> None:
        await self.notify_event(
            "mgmt", ("🛠 Management" if not dry else "🧪 Dry-run mgmt"),
            symbol=symbol, action=action, result=msg,
        )
        if self.ledger is not None:
            try:
                self.ledger.log_management(symbol, action)
            except Exception:
                pass

    async def rejected(self, symbol: str, stage: str, reason: str) -> None:
        await self.notify_event(
            "reject", "⛔ Rejected",
            symbol=symbol or "—", stage=stage, reason=reason,
        )

    async def exception(self, where: str, err: str) -> None:
        await self.notify_event(
            "error", "🔥 Exception", where=where, error=_esc(err)[:500],
        )

    # ------------------------------------------------------------------ #
    # Underlying push
    # ------------------------------------------------------------------ #
    async def _push(self, text: str, kind: str | None) -> None:
        if not self.app:
            log.warning("BotDashboard not started; dropping alert: %s", text[:60])
            return
        try:
            # Prefer explicit config; otherwise use the chat we learned from
            # the first /start or /status the user sent to the bot.
            chat = self.allowed_chat or os.getenv("TG_BOT_CHAT", "") \
                or getattr(self.state, "alert_chat", "") or ""
            if not chat:
                log.info("No alert chat known yet (message the bot first). "
                         "Holding alert: %s", text[:60])
                # stash so it isn't lost once chat is learned
                self._pending = getattr(self, "_pending", []) + [(text, kind)]
                return
            await self.app.bot.send_message(
                chat_id=chat, text=text, parse_mode="HTML",
            )
        except Exception as e:  # alerts must never crash the pipeline
            log.warning("BotDashboard push failed: %s", e)

    # ------------------------------------------------------------------ #
    # Slash command dashboard
    # ------------------------------------------------------------------ #
    def _register_handlers(self, app: Application) -> None:
        app.add_handler(CommandHandler("start", self._cmd_start))
        app.add_handler(CommandHandler("help", self._cmd_help))
        app.add_handler(CommandHandler("status", self._cmd_status))
        app.add_handler(CommandHandler("positions", self._cmd_positions))
        app.add_handler(CommandHandler("balance", self._cmd_balance))
        app.add_handler(CommandHandler("signals", self._cmd_signals))
        app.add_handler(CommandHandler("trades", self._cmd_trades))
        app.add_handler(CommandHandler("last", self._cmd_last))
        app.add_handler(CommandHandler("toggle", self._cmd_toggle))
        app.add_handler(CommandHandler("close", self._cmd_close))
        app.add_handler(CommandHandler("jump", self._cmd_jump))
        app.add_handler(CommandHandler("bias", self._cmd_bias))
        app.add_handler(CommandHandler("test", self._cmd_test))

    async def _allowed(self, update: Update) -> bool:
        if not self.allowed_chat:
            return True  # not restricted
        return str(update.effective_chat.id) == str(self.allowed_chat) or \
            update.effective_chat.username == self.allowed_chat

    async def _learn_chat(self, update: Update) -> bool:
        if not await self._allowed(update):
            return False
        cid = str(update.effective_chat.id)
        # remember this chat as the alert destination (first contact wins)
        if not getattr(self.state, "alert_chat", ""):
            self.state.alert_chat = cid
            os.environ["TG_BOT_CHAT"] = cid
            # persist so deploy/health alerts reach you even before first contact
            self._persist_chat(cid)
        # flush any alerts that arrived before we knew the chat
        pending = getattr(self, "_pending", [])
        if pending:
            self._pending = []
            for text, kind in pending:
                try:
                    await self.app.bot.send_message(
                        chat_id=self.state.alert_chat, text=text, parse_mode="HTML")
                except Exception as e:
                    log.warning("flush pending alert failed: %s", e)
        return True

    def _persist_chat(self, cid: str) -> None:
        """Write the bot's alert-chat env var to .env so the alert destination
        survives restarts. Uses this instance's alert_chat_env (per-bot)."""
        try:
            env_key = getattr(self.state, "alert_chat_env", "TG_BOT_CHAT")
            p = Path(__file__).resolve().parents[2] / ".env"
            if not p.exists():
                return
            lines = p.read_text().splitlines()
            if any(l.strip().startswith(f"{env_key}=") for l in lines):
                return  # already set, don't overwrite
            with p.open("a") as f:
                f.write(f"\n{env_key}={cid}\n")
            os.environ[env_key] = cid
        except Exception as e:
            log.warning("persist chat id failed: %s", e)

    async def _cmd_start(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self._learn_chat(update):
            return
        await update.message.reply_text(
            "🤖 <b>Fatty Bot Dashboard</b>\n\nUse /help for commands.\n"
            "Alerts will be sent here.",
            parse_mode="HTML")

    async def _cmd_help(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self._learn_chat(update):
            return
        txt = (
            "<b>Commands</b>\n"
            "/status — full snapshot (mode, wallet, equity, positions)\n"
            "/positions — open positions\n"
            "/balance — perp + spot USDC\n"
            "/signals — recent signals seen\n"
            "/trades — trade ledger (closed trades + win rate + P&L)\n"
            "/last — most recent event\n"
            "/toggle — flip PAPER ⇄ LIVE (one tap)\n"
            "/help — this message"
        )
        await update.message.reply_text(txt, parse_mode="HTML")

    async def _cmd_status(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self._learn_chat(update):
            return
        s = self.state
        pos_block = self._fmt_positions()
        txt = (
            f"<b>📊 Status</b>  <code>{_esc(s.bot_name)}</code>\n"
            f"• Mode: <code>{_esc(s.mode)}</code> {'✅' if s.mode=='live' else '🧪'}\n"
            f"• Network: <code>{'TESTNET' if s.testnet else 'MAINNET'}</code>\n"
            f"• Channel: <code>@{_esc(s.channel)}</code>\n"
            f"• Wallet: <code>{_esc(s.wallet)}</code>\n"
            f"• Equity: <code>${_money(s.equity_usd)}</code>\n"
            f"• Perp USDC: <code>${_money(s.perp_usdc)}</code>\n"
            f"• Spot USDC: <code>${_money(s.spot_usdc)}</code>\n"
            f"• Open positions: <code>{len(s.positions)}</code>\n"
            f"{pos_block}"
        )
        await update.message.reply_text(txt, parse_mode="HTML")

    async def _cmd_positions(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self._learn_chat(update):
            return
        if not self.state.positions:
            await update.message.reply_text("No open positions.", parse_mode="HTML")
            return
        await update.message.reply_text(
            "<b>📈 Positions</b>\n" + self._fmt_positions(), parse_mode="HTML")

    async def _cmd_balance(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self._learn_chat(update):
            return
        # Refresh live balances on demand (perp equity + spot USDC) so the
        # reply reflects reality instead of the last hourly health snapshot.
        refresh = self.state.handlers.get("on_health")
        if callable(refresh):
            try:
                await refresh()
            except Exception:
                pass
        s = self.state
        txt = (
            "<b>💵 Balance</b>\n"
            f"• Equity: <code>${_money(s.equity_usd)}</code>\n"
            f"• Perp USDC: <code>${_money(s.perp_usdc)}</code>\n"
            f"• Spot USDC: <code>${_money(s.spot_usdc)}</code>"
        )
        await update.message.reply_text(txt, parse_mode="HTML")

    async def _cmd_signals(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self._learn_chat(update):
            return
        sigs = self.state.recent_signals[-10:]
        if not sigs:
            await update.message.reply_text("No signals seen yet.", parse_mode="HTML")
            return
        lines = ["<b>📡 Recent signals</b>"]
        for sg in reversed(sigs):
            lines.append(
                f"• <code>{_esc(sg['symbol'])}</code> {_esc(sg['side'])} "
                f"via {_esc(sg['src'])}")
        await update.message.reply_text("\n".join(lines), parse_mode="HTML")

    async def _cmd_trades(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
        """Report trade ledger: latest closed trades + all-time summary."""
        if not await self._learn_chat(update):
            return
        if self.ledger is None:
            await update.message.reply_text(
                "📒 Ledger not enabled for this bot.", parse_mode="HTML")
            return
        try:
            summary = self.ledger.trade_summary()
            trades = self.ledger.recent_trades(limit=10)
        except Exception as e:
            await update.message.reply_text(
                f"📒 Ledger read failed: {_esc(str(e))[:200]}", parse_mode="HTML")
            return
        lines = ["<b>📒 Trade ledger</b>"]
        lines.append(
            f"• Closed: <code>{summary['total_closed']}</code>  "
            f"W/L: <code>{summary['wins']}/{summary['losses']}</code>  "
            f"Win%: <code>{summary['win_rate']}</code>")
        lines.append(f"• Net P&L: <code>${_money(summary['net_pnl'])}</code>")
        if trades:
            lines.append("")
            for t in reversed(trades):
                pnl = t["pnl"]
                pnl_s = f"${_money(pnl)}" if pnl is not None else "open"
                lines.append(
                    f"• <code>{_esc(t['symbol'])}</code> {_esc(t['side'])} "
                    f"pnl={pnl_s} {_esc(t['reason'] or '')}".rstrip())
        else:
            lines.append("• No closed trades yet.")
        await update.message.reply_text("\n".join(lines), parse_mode="HTML")

    async def _cmd_last(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self._learn_chat(update):
            return
        ev = self.state.last_event
        if not ev:
            await update.message.reply_text("No events yet.", parse_mode="HTML")
            return
        await update.message.reply_text(self._fmt_event(ev), parse_mode="HTML")

    async def _cmd_toggle(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self._learn_chat(update):
            return
        # Flip the single human gate between paper (dry-run) and live.
        going_live = self.state.mode != "live"
        self.state.mode = "live" if going_live else "dry-run"
        if going_live:
            await update.message.reply_text(
                "🟢 <b>LIVE.</b> Real orders will be placed on mainnet using "
                "dynamic risk-based sizing (≈2% of equity risked per trade). "
                "Send /toggle again to return to paper.", parse_mode="HTML")
        else:
            await update.message.reply_text(
                "🧪 <b>PAPER.</b> Dry-run — no real orders will be placed. "
                "Send /toggle again to go live.", parse_mode="HTML")
        # notify the engine so it actually flips the orchestrator flag
        fn = self.state.handlers.get("on_toggle")
        if fn:
            try:
                await fn(self.state.mode)
            except Exception as e:
                log.warning("on_toggle handler error: %s", e)

    async def _cmd_close(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
        """Manually flatten an open position (market, reduce_only).

        Usage:  /close BTC        -> close the BTC position (any size)
                /close BTC 0.5    -> close 0.5 BTC (partial)
        """
        if not await self._learn_chat(update):
            return
        if self.state.mode != "live":
            await update.message.reply_text(
                "⚠️ Bot is in PAPER mode. /toggle to LIVE first.", parse_mode="HTML")
            return
        args = ctx.args or []
        if not args:
            await update.message.reply_text(
                "Usage: /close SYMBOL [size]\nExample: /close BTC", parse_mode="HTML")
            return
        symbol = args[0].upper()
        size_arg = args[1] if len(args) > 1 else None
        fn = self.state.handlers.get("on_close")
        if not fn:
            await update.message.reply_text("Manual close not wired.", parse_mode="HTML")
            return
        try:
            result = await fn(symbol, size_arg)
            await update.message.reply_text(
                f"🔧 <b>Close requested</b>\n• Symbol: <code>{_esc(symbol)}</code>\n"
                f"• Result: <code>{_esc(result)}</code>", parse_mode="HTML")
        except Exception as e:
            await update.message.reply_text(f"🔥 Close failed: {_esc(str(e))[:300]}",
                                           parse_mode="HTML")

    async def _cmd_jump(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
        """Manually open a market position if the bot missed a signal.

        Usage:  /jump BTC BUY        -> $1 margin × 3x market long
                /jump BTC BUY 2      -> $2 margin × 3x market long
                /jump ETH SELL 1     -> $1 margin × 3x market short
        """
        if not await self._learn_chat(update):
            return
        if self.state.mode != "live":
            await update.message.reply_text(
                "⚠️ Bot is in PAPER mode. /toggle to LIVE first.", parse_mode="HTML")
            return
        args = ctx.args or []
        if len(args) < 2:
            await update.message.reply_text(
                "Usage: /jump SYMBOL BUY|SELL [margin_usd]\n"
                "Example: /jump BTC BUY", parse_mode="HTML")
            return
        symbol = args[0].upper()
        side = args[1].upper()
        if side not in ("BUY", "SELL"):
            await update.message.reply_text("Side must be BUY or SELL.", parse_mode="HTML")
            return
        margin = float(args[2]) if len(args) > 2 else 1.0
        fn = self.state.handlers.get("on_jump")
        if not fn:
            await update.message.reply_text("Manual jump not wired.", parse_mode="HTML")
            return
        try:
            result = await fn(symbol, side, margin)
            await update.message.reply_text(
                f"🚀 <b>Jump requested</b>\n• <code>{_esc(symbol)}</code> "
                f"{_esc(side)} @ ~${_money(margin)} ×3x\n"
                f"• Result: <code>{_esc(result)}</code>", parse_mode="HTML")
        except Exception as e:
            await update.message.reply_text(f"🔥 Jump failed: {_esc(str(e))[:300]}",
                                           parse_mode="HTML")

    async def _cmd_bias(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self._learn_chat(update):
            return
        fn = self.state.handlers.get("on_bias")
        try:
            target = ""
            if ctx.args:
                target = ctx.args[0].upper()
            if fn:
                text = await fn(target=target)
            else:
                text = "⚠️ Bias database not available."
            await update.message.reply_text(text, parse_mode="HTML")
        except Exception as e:
            await update.message.reply_text(f"🔥 Bias failed: {_esc(str(e))[:300]}",
                                           parse_mode="HTML")

    async def _cmd_test(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self._learn_chat(update):
            return
        # Fire sample events so the user can confirm the alert path is LIVE.
        await self.signal_received("BTCUSDT", "BUY", "fattyfatclub", 99999)
        await self.order_placed("BTC", "BUY", 3, entry=60000, sl=58000,
                                tp=64000, lev=10, dry=True)
        await self.notify_event(
            "test", "✅ End-to-end verify",
            note="if you see this in your chat, the dashboard alert path is LIVE")
        await update.message.reply_text(
            "📨 Test alerts sent to this chat. Check above for the rich "
            "signal / order / verify events.", parse_mode="HTML")

    def _fmt_positions(self) -> str:
        if not self.state.positions:
            return "  (none)"
        lines = []
        for p in self.state.positions:
            lines.append(
                f"  <code>{_esc(p['symbol'])}</code> {_esc(p['side'])} "
                f"x{int(p.get('lev',0))} @ {_px(p.get('entry'))} "
                f"sz {p.get('size')}")
        return "\n".join(lines)

    # ------------------------------------------------------------------ #
    # Lifecycle
    # ------------------------------------------------------------------ #
    async def start(self) -> None:
        if not self.token:
            raise RuntimeError("TG_BOT_TOKEN missing — cannot start dashboard")
        self.app = Application.builder().token(self.token).build()
        self._register_handlers(self.app)
        await self.app.initialize()
        await self.app.start()
        # Register the slash-command menu so Telegram shows it when you type "/"
        try:
            await self.app.bot.set_my_commands([
                BotCommand("status", "full snapshot (mode, wallet, equity, positions)"),
                BotCommand("positions", "open positions"),
                BotCommand("balance", "perp + spot USDC"),
                BotCommand("signals", "recent signals seen"),
                BotCommand("trades", "trade ledger: win rate + P&L"),
                BotCommand("last", "most recent event"),
                BotCommand("toggle", "flip PAPER <-> LIVE (one tap)"),
                BotCommand("close", "manually close a position: /close BTC [size]"),
                BotCommand("jump", "manually open: /jump BTC BUY [margin_usd]"),
                BotCommand("help", "command list"),
            ])
        except Exception as e:
            log.warning("set_my_commands failed: %s", e)
        # start the polling loop as a background task tied to this event loop
        self._runner_task = asyncio.create_task(self.app.updater.start_polling())
        # start the hourly health-check loop
        self._health_task = asyncio.create_task(self._health_loop())
        log.info("BotDashboard started.")

    async def _health_loop(self) -> None:
        """Send a compact health-check to the alert chat once every hour."""
        while True:
            await asyncio.sleep(3600)
            try:
                fn = self.state.handlers.get("on_health")
                if fn:
                    try:
                        await fn()
                    except Exception as e:
                        log.warning("on_health refresh failed: %s", e)
                await self.health_check()
            except Exception as e:
                log.warning("health_check error: %s", e)

    async def health_check(self) -> None:
        """Compact hourly heartbeat: bot, mode, equity, open positions, connection."""
        s = self.state
        n_pos = len(s.positions)
        line = (
            f"💓 <b>Health check</b>  <code>{_esc(s.bot_name)}</code>  v{_esc(s.version)}\n"
            f"• Mode: <code>{_esc(s.mode)}</code> {'✅' if s.mode=='live' else '🧪'}\n"
            f"• Network: <code>{'MAINNET' if not s.testnet else 'TESTNET'}</code>\n"
            f"• Channel: <code>@{_esc(s.channel)}</code>\n"
            f"• Equity: <code>${_money(s.equity_usd)}</code>\n"
            f"• Open positions: <code>{n_pos}</code>\n"
            f"• Last event: <code>{_esc(s.last_event.get('title','—'))}</code>\n"
            f"• Uptime OK ✅"
        )
        await self._push(line, "health")

    async def deploy_check(self) -> None:
        """Health check sent immediately on deploy/startup (includes version)."""
        s = self.state
        line = (
            f"🚀 <b>Deployed</b>  <code>{_esc(s.bot_name)}</code>  v{_esc(s.version)}\n"
            f"• Mode: <code>{_esc(s.mode)}</code> {'✅' if s.mode=='live' else '🧪'}\n"
            f"• Network: <code>{'MAINNET' if not s.testnet else 'TESTNET'}</code>\n"
            f"• Channel: <code>@{_esc(s.channel)}</code>\n"
            f"• Wallet: <code>{_esc(s.wallet)}</code>\n"
            f"• Equity: <code>${_money(s.equity_usd)}</code>\n"
            f"• Bot online ✅"
        )
        await self._push(line, "deploy")

    async def stop(self) -> None:
        if self.app:
            try:
                if self._runner_task:
                    self._runner_task.cancel()
                if getattr(self, "_health_task", None):
                    self._health_task.cancel()
                await self.app.updater.stop()
                await self.app.stop()
                await self.app.shutdown()
            except Exception as e:
                log.warning("BotDashboard stop error: %s", e)
            self.app = None


def format_html(text: str, kind: str | None = None) -> str:
    """Wrap plain text in a tidy HTML block. Used for generic sends."""
    return text
