"""Composition root / entrypoint.

Modes:
  python -m src.main                  -> safe connectivity + pipeline test (no TG)
  python -m src.main --check-tg       -> verify Telegram session + @channel reach
  python -m src.main --live-dry       -> connect real TG source + notifier, dry-run
  python -m src.main --dashboard      -> run ONE bot instance (the default bot)
  python -m src.main --bot NAME       -> run a specific bot from the DB config
  python -m src.main --all-bots       -> launch EVERY enabled bot (one process each:
                                         use ./run_bots.sh, which spawns children)

SAFETY MODEL (read carefully, this is money-path):
  * `paper` (DB flag) == dry_run. A paper bot simulates orders and never touches
    mainnet. A live bot places REAL orders with REAL funds.
  * The engine boots in the mode the DB config says. This is by design: the
    live state is a persisted fact, not a hopeful default. /toggle flips it and
    the new value is written back to the DB so it survives restarts.
  * Secrets (HL private key, TG bot token, TG_API_ID/HASH, SESSION_STRING) are
    NEVER read from the DB or printed. They live only in the environment /
    git-ignored `.env`.
"""

from __future__ import annotations

import argparse
import asyncio
import json
import logging
import os
import time
from pathlib import Path

from src.config.db import ConfigStore, ensure_default_bot
from src.config.loader import AppConfig
from src.exchanges.hyperliquid import HyperliquidAdapter
from src.streaming.hyperliquid_ws import MarketDataStream
from src.services.peg import ConstantPegSource
from src.orchestrator import Orchestrator, OrchestratorConfig
from src.notifier.bot import BotDashboard, DashboardState, get_version

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)
log = logging.getLogger("main")


def _make_ledger(bot_name: str):
    """Build a Postgres-backed trade/signal ledger, or None if unavailable."""
    try:
        from src.store.ledger import Ledger
        return Ledger(bot=bot_name)
    except Exception as e:  # ledger must never block the bot from starting
        log.warning("Ledger init failed (continuing without durable logging): %s", e)
        return None


class NullNotifier:
    async def send(self, text: str) -> None:
        log.info("NOTIFY: %s", text)


def _secrets_present(cfg: AppConfig) -> bool:
    return bool(cfg.hyperliquid.private_key) and bool(cfg.hyperliquid.account_address)


async def run(cfg: AppConfig) -> None:
    """SAFE MODE connectivity + pipeline test (testnet, dry-run, zero orders)."""
    testnet = True
    dry_run = True
    log.info("=== SAFE MODE: testnet=%s dry_run=%s -> NO REAL ORDERS, NO MAINNET ===",
             testnet, dry_run)

    try:
        adapter = HyperliquidAdapter(
            private_key=cfg.hyperliquid.private_key,
            account_address=cfg.hyperliquid.account_address,
            testnet=testnet,
        )
        log.info("Adapter built. Key derives to %s (match=%s)",
                 adapter._acct.address,
                 adapter._acct.address.lower() == cfg.hyperliquid.account_address.lower())
    except Exception as e:
        log.error("Adapter build FAILED (key/address mismatch?): %s", e)
        return

    try:
        positions = await adapter.get_positions()
        orders = await adapter.get_open_orders()
        fills = await adapter.get_fills()
        log.info("TESTNET INFO OK -> positions=%d open_orders=%d fills=%d",
                 len(positions), len(orders), len(fills))
    except Exception as e:
        log.warning("TESTNET info endpoints unreachable: %s", e)

    market = MarketDataStream(symbols=["BTC"], testnet=testnet)
    await market.start()
    await asyncio.sleep(5)
    btc_mark = market.mark_price("BTC")
    log.info("TESTNET WS allMids -> BTC mark = %s", btc_mark)

    from src.sources.parser import parse_signal
    parsed = parse_signal("BTCUSDT LONG entry 60000 sl 58000 tp 64000 lev 10")
    orch = Orchestrator(
        source=None, peg=ConstantPegSource(1.0), adapter=adapter, market=market,
        notifier=NullNotifier(),
        config=OrchestratorConfig(
            dry_run=dry_run, min_confidence=cfg.min_confidence,
            default_notional_usd=cfg.risk.default_notional_usd,
        ),
    )
    if parsed is None:
        log.error("Sample signal failed to parse -> abort pipeline test")
        return
    status = await orch.handle_signal(parsed)
    log.info("PIPELINE status = %s", status)

    log.info("=== DONE. Zero orders placed. Wallet %s UNTOUCHED. ===",
             cfg.hyperliquid.account_address)
    await market.stop()


async def check_tg(cfg: AppConfig) -> None:
    """Verify Telegram session + channel reach. No trading."""
    from src.sources.telegram import TelegramSignalSource
    queue: asyncio.Queue = asyncio.Queue(maxsize=100)
    src = TelegramSignalSource(queue, {"channel": cfg.channel})
    try:
        await src.start()
        log.info("TG CONNECTED. Listening on @%s. Press Ctrl-C to stop.", cfg.channel)
        for _ in range(3):
            raw = await asyncio.wait_for(queue.get(), timeout=30)
            log.info("SAMPLE MSG -> %s", (raw.raw_text or "<media>")[:80])
    except asyncio.TimeoutError:
        log.warning("No messages arrived in 30s (channel may be quiet). "
                    "Connection itself succeeded if no auth error above.")
    except Exception as e:
        log.error("TG check failed: %s", e)
    finally:
        await src.stop()


async def live_dry(cfg: AppConfig) -> None:
    """Connect real TG source + notifier, run pipeline in DRY-RUN only.

    SAFE: hard-coded dry_run=True + testnet=True. This path can never place a
    real order or touch mainnet regardless of any config value.
    """
    testnet = True
    dry_run = True
    log.info("=== LIVE-DRY: real @%s source, dry_run=%s (NO REAL ORDERS) ===",
             cfg.channel, dry_run)

    adapter = HyperliquidAdapter(
        private_key=cfg.hyperliquid.private_key,
        account_address=cfg.hyperliquid.account_address,
        testnet=testnet,
    )
    market = MarketDataStream(symbols=["BTC", "ETH", "SOL"], testnet=testnet)
    await market.start()

    try:
        from src.notifier.telegram import TelegramNotifier
        notifier = TelegramNotifier()
    except Exception as e:
        log.warning("Notifier init failed, falling back to log: %s", e)
        notifier = NullNotifier()

    try:
        from src.sources.attachment_fetcher import AttachmentFetcher
        from src.sources.vision import VisionExtractor
        attachment_fetcher = AttachmentFetcher(
            media_dir=Path(__file__).resolve().parents[1] / "data" / "attachments"
        )
        vision_extractor = VisionExtractor()
        if getattr(vision_extractor, "backend", "") != "local" and not getattr(vision_extractor, "api_key", ""):
            log.warning("No vision API key set (GEMINI_API_KEY) — image signals "
                        "will be surfaced as vision_pending, not traded.")
    except Exception as e:
        log.warning("Vision pipeline init failed: %s", e)
        attachment_fetcher = None
        vision_extractor = None

    try:
        from src.sources.bias import BiasRecorder
        bias_recorder = BiasRecorder()
    except Exception as e:
        log.warning("Bias recorder init failed: %s", e)
        bias_recorder = None

    orch = Orchestrator(
        source=None, peg=ConstantPegSource(1.0), adapter=adapter, market=market,
        notifier=notifier, bias_recorder=bias_recorder,
        config=OrchestratorConfig(
            dry_run=dry_run, min_confidence=cfg.min_confidence,
            default_notional_usd=cfg.risk.default_notional_usd, testnet=testnet,
        ),
        attachment_fetcher=attachment_fetcher, vision_extractor=vision_extractor,
    )

    from src.sources.telegram import TelegramSignalSource
    queue: asyncio.Queue = asyncio.Queue(maxsize=100)
    src = TelegramSignalSource(queue, {"channel": cfg.channel})

    async def consumer() -> None:
        while True:
            raw = await queue.get()
            await orch.handle_signal(raw)

    consumer_task = asyncio.create_task(consumer())
    try:
        await src.start()
    finally:
        consumer_task.cancel()
        await market.stop()
        try:
            await notifier.stop()
        except Exception:
            pass


async def run_bot_instance(bot_name: str, store: ConfigStore | None = None) -> None:
    """Run a single bot instance (dashboard + engine) for `bot_name`.

    This is the production mode. The bot's mode (paper/live), channel, risk, and
    which env vars hold its secrets all come from the DB config row. The paper
    flag is the human gate to real money and is persisted, so /toggle outlives a
    restart.
    """
    store = store or ConfigStore()
    bot = store.get_bot(bot_name)
    if bot is None:
        log.error("No bot named '%s' in the config DB. Create one with the "
                  "config tool or --all-bots will skip it.", bot_name)
        return
    if not bot.enabled:
        log.info("Bot '%s' is disabled in the config DB; not starting.", bot_name)
        return

    # Resolve secrets from the environment (NEVER from the DB).
    token = os.getenv(bot.tg_bot_token_env, "")
    if not token:
        log.error("Bot '%s' requires %s in the environment (.env). Aborting.",
                  bot_name, bot.tg_bot_token_env)
        return

    cfg = AppConfig.from_bot(bot)
    if not _secrets_present(cfg):
        log.error("Missing HL_PRIVATE_KEY / HL_ACCOUNT_ADDRESS in .env -> abort "
                  "for bot '%s'.", bot_name)
        return

    testnet = cfg.hyperliquid.testnet
    dry_run = cfg.dry_run          # == bot.paper
    mode_label = "LIVE (real money)" if not dry_run else "PAPER (dry-run)"
    log.info("=== Bot '%s' starting: mode=%s network=%s channel=@%s ===",
             bot_name, mode_label,
             "TESTNET" if testnet else "MAINNET", bot.channel)

    adapter = HyperliquidAdapter(
        private_key=cfg.hyperliquid.private_key,
        account_address=cfg.hyperliquid.account_address,
        testnet=testnet,
    )
    # Arm the dead-man's-switch (auto-cancel stale orders if the bot dies).
    # Only meaningful in live mode; wrapped so an API error never blocks startup.
    if not dry_run:
        try:
            await adapter.set_scheduled_cancel(hours=24)
            log.info("Live mode: scheduledCancel (24h dead-man's-switch) armed.")
        except Exception as e:
            log.warning("Could not arm scheduledCancel (continuing): %s", e)
    market = MarketDataStream(symbols=["BTC", "ETH", "SOL"], testnet=testnet)
    await market.start()

    state = DashboardState()
    state.testnet = testnet
    state.wallet = cfg.hyperliquid.account_address
    state.version = get_version()
    state.bot_name = bot_name
    state.mode = "live" if not dry_run else "dry-run"
    # Prefer a persisted chat id so health checks reach you before first contact.
    fallback_chat = os.getenv(bot.tg_bot_chat_env, "")
    if fallback_chat:
        state.alert_chat = fallback_chat

    dashboard = BotDashboard(token=token, state=state, allowed_chat=fallback_chat,
                             ledger=_make_ledger(bot_name), bot_name=bot_name)

    risk = store.get_risk(bot_name)
    orch = Orchestrator(
        source=None, peg=ConstantPegSource(1.0), adapter=adapter, market=market,
        notifier=dashboard,
        config=OrchestratorConfig(
            dry_run=dry_run, min_confidence=cfg.min_confidence,
            default_notional_usd=risk.default_margin_usd, testnet=testnet,
        ),
    )

    # ---- /toggle: flip paper<->live and persist it to the DB ----
    async def _on_toggle(mode: str) -> None:
        going_live = (mode == "live")
        store.set_paper(bot_name, paper=not going_live)
        orch.cfg.dry_run = not going_live
        log.info(">>> Bot '%s' mode toggled via /toggle -> %s (persisted) <<<",
                 bot_name, mode)
    state.handlers["on_toggle"] = _on_toggle

    # ---- manual override commands (so Hernanda can act if the bot fails) ----
    async def _on_close(symbol: str, size_arg: str | None) -> str:
        """Close an open position at market (reduce_only)."""
        pos = next((p for p in await adapter.get_positions()
                    if p.instrument.symbol.upper() == symbol.upper()), None)
        if not pos:
            return "no open position for " + symbol
        sz = abs(pos.size_coin)
        if size_arg:
            try:
                sz = min(sz, float(size_arg))
            except ValueError:
                return "bad size arg"
        oid = await adapter.close_position_market(
            pos.instrument.symbol, sz, pos.side.value)
        return f"closed {sz} {symbol} (order {oid[:8]}…)"

    async def _on_jump(symbol: str, side: str, margin: float) -> str:
        """Manually open a market position at the default 3x leverage."""
        mark = await adapter.get_mark_price(symbol)
        if not mark:
            return "no market price for " + symbol
        lev = 3
        coin_size = (margin * lev) / float(mark)
        coin_size = float(f"{coin_size:.6g}")
        oids = await adapter.open_market(symbol, side, coin_size, lev)
        return f"opened {side} {coin_size} {symbol} @3x (orders {','.join(o[:8] for o in oids)}…)"

    state.handlers["on_close"] = _on_close
    state.handlers["on_jump"] = _on_jump

    # ---- refresh live balance + positions before each health check ----
    async def _on_health() -> None:
        try:
            # Perp cross-margin account value (0 when no perp position / unified
            # account with funds only in spot).
            perp = adapter._info({"type": "clearinghouseState",
                                  "user": cfg.hyperliquid.account_address})
            perp_equity = float(
                (perp.get("marginSummary") or {}).get("accountValue", 0) or 0
            )
            # Spot USDC: on a UNIFIED account this IS the perp trading margin
            # (Hyperliquid merged spot+perp; usdClassTransfer is disabled). On a
            # classic account it is a separate pool that must be transferred in.
            spot = adapter._info({"type": "spotClearinghouseState",
                                  "user": cfg.hyperliquid.account_address})
            spot_usdc = float(next((b for b in spot.get("balances", [])
                                    if b.get("coin") == "USDC"),
                                   {"total": 0}).get("total", 0) or 0)
            # Trading equity = the balance the bot can actually deploy. On a
            # unified account perp accountValue stays 0 until a position exists,
            # so fall back to spot USDC (the real available margin). On a classic
            # account the perp equity (after a transfer) wins.
            trading_equity = perp_equity if perp_equity > 0 else spot_usdc
            state.equity_usd = trading_equity
            state.perp_usdc = perp_equity
            state.spot_usdc = spot_usdc
            # Risk sizing uses the deployable equity; spot is the free buffer.
            orch.order_svc.set_equity(trading_equity, spot_usdc)
            positions = await adapter.get_positions()
            state.positions = [{
                "symbol": p.instrument.symbol, "side": p.side.value,
                "size": p.size_coin, "entry": p.entry_px,
                "lev": getattr(p, "leverage", 3), "margin": p.margin_usd,
                "ts": time.time(),
            } for p in positions]
        except Exception as e:
            log.warning("health refresh failed: %s", e)
    state.handlers["on_health"] = _on_health

    # ---- bias log command ----
    try:
        from src.sources.bias import BiasRecorder
        bias_recorder = BiasRecorder()
    except Exception as e:
        log.warning("Bias recorder init failed: %s", e)
        bias_recorder = None
    orch.bias_recorder = bias_recorder

    async def _on_bias(target: str = "") -> str:
        if bias_recorder is None:
            return "⚠️ Bias database not available."
        summary = bias_recorder.summary()
        if summary["total"] == 0:
            return "🧭 No bias calls recorded yet."
        lines = [f"🧭 <b>Bias log</b> (total {summary['total']})"]
        lines.append(f"• Bullish: {summary['BULLISH']}  • Bearish: "
                     f"{summary['BEARISH']}  • Neutral: {summary['NEUTRAL']}")
        rows = bias_recorder.recent(limit=15, target=target)
        for r in rows:
            tgt = f" {r['target']}" if r["target"] else ""
            when = r["iso"][:16].replace("T", " ")
            arrow = f" ↗{r['arrow']}" if r.get("arrow") else ""
            src = f" [{r.get('source', 'text')}]" if r.get("source") != "text" else ""
            levels = ""
            if r.get("levels_json"):
                try:
                    lv = json.loads(r["levels_json"])
                    if lv.get("support") or lv.get("resistance"):
                        s = ",".join(str(x) for x in lv.get("support", []))
                        res = ",".join(str(x) for x in lv.get("resistance", []))
                        levels = f"  S:{s or '-'} R:{res or '-'}"
                except (ValueError, TypeError):
                    pass
            lines.append(
                f"  • {when} — <b>{r['bias']}</b>{tgt}{arrow}{src}{levels}"
            )
        return "\n".join(lines)
    state.handlers["on_bias"] = _on_bias

    # ---- Telegram signal source (one per bot instance) ----
    from src.sources.telegram import TelegramSignalSource
    queue: asyncio.Queue = asyncio.Queue(maxsize=100)
    src = TelegramSignalSource(queue, {"channel": bot.channel})

    async def consumer() -> None:
        while True:
            raw = await queue.get()
            await orch.handle_signal(raw)

    consumer_task = asyncio.create_task(consumer())

    try:
        await dashboard.start()
        # Send a deploy/startup health check so you know it came up.
        try:
            await dashboard.deploy_check()
        except Exception as e:
            log.warning("deploy_check failed: %s", e)
        log.info("=== Bot '%s' dashboard ready (mode=%s). "
                 "Send /toggle in the bot chat to flip PAPER <-> LIVE. ===",
                 bot_name, state.mode)
        await src.start()  # blocks until disconnected
    finally:
        consumer_task.cancel()
        await market.stop()
        try:
            await src.stop()
        except Exception:
            pass
        try:
            await dashboard.stop()
        except Exception:
            pass


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default=None)
    parser.add_argument("--check-tg", action="store_true",
                        help="verify Telegram session + channel reach")
    parser.add_argument("--live-dry", action="store_true",
                        help="connect real TG source, dry-run (no real orders)")
    parser.add_argument("--dashboard", action="store_true",
                        help="run the DEFAULT bot instance (DB name 'fatty-main')")
    parser.add_argument("--bot", type=str, default=None,
                        help="run a specific bot by name from the config DB")
    parser.add_argument("--all-bots", action="store_true",
                        help="launch every enabled bot as a separate process")
    parser.add_argument("--amount", type=float, default=0.0)
    parser.add_argument("--to-perp", action="store_true")
    parser.add_argument("--confirm", action="store_true")
    args = parser.parse_args()

    if args.all_bots:
        _launch_all_bots()
        return

    store = ConfigStore()
    ensure_default_bot(store)

    # Determine which bot this process runs.
    bot_name = args.bot or "fatty-main"
    # For --dashboard we resolve the default bot name from the config too.
    bot = store.get_bot(bot_name) or ensure_default_bot(store, bot_name)
    cfg = AppConfig.from_bot(bot)

    if not _secrets_present(cfg) and not (args.check_tg or args.live_dry):
        log.error("Missing HL_PRIVATE_KEY / HL_ACCOUNT_ADDRESS in .env -> abort.")
        return

    try:
        if args.check_tg:
            asyncio.run(asyncio.wait_for(check_tg(cfg), timeout=60))
        elif args.live_dry:
            asyncio.run(live_dry(cfg))
        elif args.dashboard or args.bot:
            asyncio.run(run_bot_instance(bot_name, store))
        else:
            asyncio.run(asyncio.wait_for(run(cfg), timeout=40))
    except asyncio.TimeoutError:
        log.warning("Run timed out (likely network). No orders were placed.")


def _launch_all_bots() -> None:
    """Spawn one child process per enabled bot (each owns its own TG bot token).

    We do NOT asyncio.gather them in one process, because each Telegram Bot API
    token must be polled by exactly one long-running client. Children are
    independent and can be supervised/signalled separately.
    """
    import subprocess
    store = ConfigStore()
    bots = store.list_bots(enabled_only=True)
    if not bots:
        log.error("No enabled bots in the config DB. Nothing to launch.")
        return
    py = os.environ.get("PY", "/usr/local/lib/hermes-agent/venv/bin/python3")
    if not os.path.exists(py):
        py = "python3"
    procs = []
    repo = Path(__file__).resolve().parents[2]
    for bot in bots:
        log.info("Launching bot '%s' (paper=%s) as a child process...",
                 bot.name, bot.paper)
        p = subprocess.Popen(
            [py, "-m", "src.main", "--bot", bot.name],
            cwd=str(repo),
            stdout=open(os.path.join(repo, "logs", f"bot_{bot.name}.log"), "a"),
            stderr=subprocess.STDOUT,
        )
        procs.append((bot.name, p))
    log.info("Launched %d bot process(es). PIDs: %s",
             len(procs), ", ".join(str(p.pid) for _, p in procs))
    # Relay the parent's exit so children are cleaned up on Ctrl-C.
    try:
        for _, p in procs:
            p.wait()
    except KeyboardInterrupt:
        for name, p in procs:
            log.info("Stopping bot '%s' (pid %s)...", name, p.pid)
            p.terminate()


if __name__ == "__main__":
    main()
