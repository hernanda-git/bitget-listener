"""HyperliquidPegSource — live USDT->USDC peg via HL allMids.

Hyperliquid settles in USDC. USDT trades as its own perp on HL; we read its mid as
the USDC-per-USDT rate. If USDT isn't available, fall back to 1.0 (pegged).

Implements the PegSource port so the depeg guard becomes live (vs ConstantPegSource).
"""

from __future__ import annotations

import httpx

from src.interfaces.ports import PegSource


class HyperliquidPegSource:
    def __init__(self, testnet: bool = False, timeout: float = 5.0):
        self._base = (
            "https://api.hyperliquid-testnet.xyz"
            if testnet else "https://api.hyperliquid.xyz"
        )
        self._timeout = timeout

    async def peg_rate(self) -> float:
        try:
            async with httpx.AsyncClient(base_url=self._base, timeout=self._timeout) as c:
                r = await c.post("/info", json={"type": "allMids"})
                r.raise_for_status()
                mids: dict = r.json()
            usdt = mids.get("USDT")
            if usdt:
                return float(usdt)
        except Exception:
            pass
        return 1.0
