"""HyperliquidAdapter — executes orders on Hyperliquid (USDC, on-chain perps).

Implements the ExchangeAdapter port. Uses EIP-712 action signing (eth_account)
and the Hyperliquid info/exchange REST endpoints. All amounts are USDC-native and
coin-sized (OrderService already did the USD->coin conversion).

Testable without network via FakeHyperliquidAdapter (same interface).
"""

from __future__ import annotations

import time

import httpx

from src.domain.model import (
    Instrument,
    OrderRequest,
    OrderType,
    Position,
    Fill,
    Side,
)
from src.interfaces.ports import ExchangeAdapter


# Hyperliquid EIP-712 domain (per HL docs). chainId differs by environment.
_DOMAIN_MAINNET = {"name": "Exchange", "version": "1", "chainId": 42161}
_DOMAIN_TESTNET = {"name": "Exchange", "version": "1", "chainId": 998}

_ORDER_TYPES = {
    "limit": {"limit": {"tif": "Gtc"}},
    "market": {"limit": {"tif": "Ioc"}},
}


def _keccak(data: bytes) -> bytes:
    from eth_utils import keccak as _k
    return _k(data)


class HyperliquidAdapter:
    def __init__(
        self,
        private_key: str,
        account_address: str,
        testnet: bool = False,
        base_url: str | None = None,
        timeout: float = 10.0,
    ):
        from eth_account import Account

        self._acct = Account.from_key(private_key)
        self._address = account_address
        # sanity: derived address must match configured account
        if self._acct.address.lower() != account_address.lower():
            raise ValueError("private_key does not match account_address")
        self._domain = _DOMAIN_TESTNET if testnet else _DOMAIN_MAINNET
        self._base = base_url or (
            "https://api.hyperliquid-testnet.xyz"
            if testnet
            else "https://api.hyperliquid.xyz"
        )
        self._timeout = timeout
        self._client = httpx.Client(base_url=self._base, timeout=timeout)
        # Symbol -> asset-index cache (HL orders use the integer asset index,
        # not the symbol string, e.g. BTC mainnet == 0). Populated lazily from
        # the `meta` info endpoint.
        self._asset_index_cache: dict[str, int] | None = None

    # ── signing ──────────────────────────────────────────────────────
    def _sign(self, action, nonce: int) -> str:
        """Back-compat shim: returns the concatenated-hex signature.

        NOTE: this old string-typed scheme is NOT what HL's exchange endpoint
        expects anymore; `_post_exchange` uses `_sign_l1` instead. Kept only for
        callers/tests that want the raw hex.
        """
        action_str = action if isinstance(action, str) else _json_dumps(action)
        return self._sign_str(action_str, nonce)

    def _sign_str(self, action_str: str, nonce: int) -> str:
        from eth_account import Account

        types = {
            "Action": [
                {"name": "action", "type": "string"},
                {"name": "nonce", "type": "uint64"},
            ]
        }
        message = {"action": action_str, "nonce": nonce}
        signed = Account.sign_typed_data(self._acct.key, self._domain, types, message)
        return "0x" + signed.signature.hex()

    def _sign_l1(self, action: dict, nonce: int,
                 vault_address: str | None = None,
                 expires_after: int | None = None) -> dict:
        """Sign an exchange action the way HL's own SDK does (msgpack action hash
        + `Agent` EIP-712 typed message, chainId 1337).

        Returns the wire-shape signature object {"r","s","v"}. This is what
        `_post_exchange` must send; the old JSON-string + concatenated-hex
        scheme produced the `422 Failed to deserialize` error.
        """
        import msgpack
        from eth_account import Account
        from eth_account.messages import encode_typed_data as _encode

        data = msgpack.packb(action)
        data += nonce.to_bytes(8, "big")
        if vault_address is None:
            data += b"\x00"
        else:
            data += b"\x01" + bytes.fromhex(vault_address[2:])
        if expires_after is not None:
            data += b"\x00" + expires_after.to_bytes(8, "big")
        action_hash = _keccak(data)

        is_mainnet = self._domain is _DOMAIN_MAINNET
        phantom_agent = {
            "source": "a" if is_mainnet else "b",
            "connectionId": action_hash,
        }
        domain = {
            "chainId": 1337,
            "name": "Exchange",
            "verifyingContract": "0x0000000000000000000000000000000000000000",
            "version": "1",
        }
        types = {
            "Agent": [
                {"name": "source", "type": "string"},
                {"name": "connectionId", "type": "bytes32"},
            ],
            "EIP712Domain": [
                {"name": "name", "type": "string"},
                {"name": "version", "type": "string"},
                {"name": "chainId", "type": "uint256"},
                {"name": "verifyingContract", "type": "address"},
            ],
        }
        structured = _encode(
            full_message={"domain": domain, "types": types,
                           "primaryType": "Agent", "message": phantom_agent}
        )
        signed = Account.sign_message(structured, self._acct.key)
        return {
            "r": "0x" + signed["r"].to_bytes(32, "big").hex(),
            "s": "0x" + signed["s"].to_bytes(32, "big").hex(),
            "v": "0x" + signed["v"].to_bytes(1, "big").hex(),
        }

    # ── public API (ExchangeAdapter) ────────────────────────────────
    async def place_order(self, order: OrderRequest) -> str:
        oid = order.client_order_id or _ulid()
        idx = self._asset_index(order.instrument.symbol)
        action = {
            "type": "order",
            "orders": [_hl_order(order, oid, asset_index=idx)],
        }
        await self._post_exchange(action)
        return oid

    async def cancel_order(self, instrument: Instrument, client_order_id: str) -> bool:
        action = {
            "type": "cancel",
            "cancels": [{"a": instrument.symbol, "o": client_order_id}],
        }
        await self._post_exchange(action)
        return True

    async def get_open_orders(self) -> list[OrderRequest]:
        data = self._info({"type": "frontendOpenOrders", "user": self._address})
        out: list[OrderRequest] = []
        for o in data:
            out.append(_order_from_hl(o))
        return out

    async def close_position_market(self, symbol: str, size_coin: float,
                                    side: str) -> str:
        """Manually flatten a position at market (reduce_only).

        `side` is the position side ("BUY"=long, "SELL"=short); the closing
        order takes the opposite side.
        """
        close_side = Side.SELL if side == "BUY" else Side.BUY
        oid = _ulid()
        action = {
            "type": "order",
            "orders": [{
                "a": symbol,
                "b": close_side == Side.BUY,
                "p": "0",           # market
                "s": _fmt_size(size_coin),
                "r": True,          # reduce only
                "t": {"limit": {"tif": "Ioc"}},
                "c": oid,
            }],
        }
        await self._post_exchange(action)
        return oid

    async def open_market(self, symbol: str, side: str, size_coin: float,
                          leverage: int) -> list[str]:
        """Manually open a market position (used by /jump). Returns order ids."""
        buy = side == "BUY"
        oid = _ulid()
        action = {
            "type": "order",
            "orders": [{
                "a": symbol,
                "b": buy,
                "p": "0",
                "s": _fmt_size(size_coin),
                "r": False,
                "t": {"limit": {"tif": "Ioc"}},
                "c": oid,
            }],
        }
        # Set leverage first (HL requires it before opening).
        lev_oid = _ulid()
        lev_action = {
            "type": "updateLeverage",
            "asset": symbol,
            "isCross": True,
            "leverage": leverage,
        }
        await self._post_exchange(lev_action)
        await self._post_exchange(action)
        return [oid]

    async def set_leverage(self, symbol: str, leverage: int, cross: bool = True) -> None:
        """Set the position leverage (and cross/isolated mode) for a coin."""
        action = {
            "type": "updateLeverage",
            "asset": symbol,
            "isCross": cross,
            "leverage": int(leverage),
        }
        await self._post_exchange(action)

    async def set_scheduled_cancel(self, hours: int = 24) -> None:
        """Arm the dead-man's-switch: auto-cancel all open orders if the bot
        hasn't refreshed this in `hours`. Protects against a crashed/lagging bot
        leaving stale entries unmanaged. HL's `scheduleCancel` action takes the
        cancel window in seconds.
        """
        action = {
            "type": "scheduleCancel",
            "cancelsAt": int(time.time() * 1000) + int(hours * 3600 * 1000),
        }
        await self._post_exchange(action)

    async def get_mark_price(self, symbol: str) -> float | None:
        """Mid price for a perp from HL's all_mids snapshot."""
        try:
            data = self._info({"type": "allMids"})
            px = data.get(symbol)
            return float(px) if px else None
        except Exception:
            return None

    async def get_positions(self) -> list[Position]:
        data = self._info({"type": "clearinghouseState", "user": self._address})
        out: list[Position] = []
        for p in data.get("assetPositions", []):
            pos = p.get("position", {})
            if float(pos.get("szi", "0")) == 0:
                continue
            out.append(_position_from_hl(pos))
        return out

    async def get_fills(self) -> list[Fill]:
        data = self._info({"type": "userFills", "user": self._address})
        return [_fill_from_hl(f) for f in data]

    # ── internal USD class transfer (Spot <-> Perp) ────────────────
    async def usd_class_transfer(self, amount_usdc: float, to_perp: bool) -> dict:
        """Move USDC internally between Spot and Perp.

        Uses the Hyperliquid `usdClassTransfer` action (NOT `spotSend`, which
        sends to an external wallet address). amount_usdc in whole USDC.
        to_perp=True  -> Spot -> Perp
        to_perp=False -> Perp -> Spot

        IMPORTANT: this is a *user-signed* action with its OWN EIP-712 domain
        (`HyperliquidSignTransaction` / `HyperliquidTransaction:UsdClassTransfer`),
        NOT the generic `Exchange`/`SignedAction` used by orders. Signing it with
        the order signer yields a 422. See `_sign_usd_class_transfer`.
        """
        nonce = int(time.time() * 1000)
        action = {
            "type": "usdClassTransfer",
            "amount": f"{float(amount_usdc):.8g}",
            "toPerp": to_perp,
            "nonce": nonce,
            "signatureChainId": "0x66eee",
            "hyperliquidChain": "Mainnet" if self._domain is _DOMAIN_MAINNET else "Testnet",
        }
        signature = self._sign_usd_class_transfer(action)
        payload = {
            "action": action,
            "nonce": nonce,
            "signature": signature,
            "vaultAddress": None,
            "expiresAfter": None,
        }
        r = self._client.post("/exchange", json=payload)
        r.raise_for_status()
        return r.json()

    def _sign_usd_class_transfer(self, action: dict) -> dict:
        """Sign a usdClassTransfer with HL's dedicated user-signed-action scheme.

        Returns {"r": "0x..", "s": "0x..", "v": "0x.."} (the wire format HL expects),
        as opposed to the concatenated hex string used for orders.
        """
        from eth_account import Account
        from eth_account.messages import encode_typed_data

        chain_id = int(action["signatureChainId"], 16)
        domain = {
            "name": "HyperliquidSignTransaction",
            "version": "1",
            "chainId": chain_id,
            "verifyingContract": "0x0000000000000000000000000000000000000000",
        }
        types = {
            "HyperliquidTransaction:UsdClassTransfer": [
                {"name": "hyperliquidChain", "type": "string"},
                {"name": "amount", "type": "string"},
                {"name": "toPerp", "type": "bool"},
                {"name": "nonce", "type": "uint64"},
            ],
            "EIP712Domain": [
                {"name": "name", "type": "string"},
                {"name": "version", "type": "string"},
                {"name": "chainId", "type": "uint256"},
                {"name": "verifyingContract", "type": "address"},
            ],
        }
        message = {k: v for k, v in action.items()
                   if k in ("hyperliquidChain", "amount", "toPerp", "nonce")}
        structured = encode_typed_data(full_message={
            "domain": domain, "types": types,
            "primaryType": "HyperliquidTransaction:UsdClassTransfer",
            "message": message,
        })
        signed = Account.sign_message(structured, self._acct.key)
        return {
            "r": "0x" + signed["r"].to_bytes(32, "big").hex(),
            "s": "0x" + signed["s"].to_bytes(32, "big").hex(),
            "v": "0x" + signed["v"].to_bytes(1, "big").hex(),
        }

    # ── transport ────────────────────────────────────────────────────
    def _asset_index(self, symbol: str) -> int:
        """Resolve a symbol (e.g. 'BTC') to HL's integer asset index.

        HL orders serialize the asset as its index in the `meta` universe, NOT
        the symbol string. Cached after first fetch. Raises if unknown.
        """
        if self._asset_index_cache is None:
            data = self._info({"type": "meta"})
            univ = data.get("universe", [])
            self._asset_index_cache = {
                u["name"]: i for i, u in enumerate(univ) if isinstance(u, dict)
            }
        if symbol not in self._asset_index_cache:
            raise ValueError(f"symbol {symbol!r} not found in HL meta universe")
        return self._asset_index_cache[symbol]

    def _info(self, payload: dict) -> dict:
        r = self._client.post("/info", json=payload)
        r.raise_for_status()
        return r.json()

    async def _post_exchange(self, action: dict) -> dict:
        nonce = int(time.time() * 1000)
        # HL's exchange endpoint expects `action` as the raw OBJECT and
        # `signature` as the {"r","s","v"} object. The signature is computed
        # over the msgpack-encoded action (SDK scheme: chainId 1337, `Agent`
        # typed message), NOT over a JSON string. Sending the old JSON-string
        # + concatenated-hex form returns `422 Failed to deserialize`.
        payload = {
            "action": action,
            "nonce": nonce,
            "signature": self._sign_l1(action, nonce),
            "vaultAddress": None,
            "expiresAfter": None,
        }
        r = self._client.post("/exchange", json=payload)
        r.raise_for_status()
        return r.json()


# ── helpers ───────────────────────────────────────────────────────────
def _ulid() -> str:
    import uuid
    return uuid.uuid4().hex[:16]


def _json_dumps(obj) -> str:
    import json
    return json.dumps(obj, separators=(",", ":"), ensure_ascii=False)


def _hl_order(order: OrderRequest, oid: str, asset_index: int | None = None) -> dict:
    # HL orders use the INTEGER asset index (e.g. BTC mainnet == 0), NOT the
    # symbol string. `asset_index` is resolved by the caller via the adapter's
    # metadata cache. The side is a string "b"/"s", not a bool.
    o: dict = {
        "a": asset_index if asset_index is not None else order.instrument.symbol,
        "b": "b" if order.side == Side.BUY else "s",
        "p": _fmt_price(order.price),
        "s": _fmt_size(order.size_coin),
        "r": order.reduce_only,
        "c": oid,
    }
    if order.order_type == OrderType.TRIGGER:
        o["t"] = {
            "trigger": {
                "triggerPx": _fmt_price(order.trigger_px),
                "isMarket": True,
                "tpsl": order.tpsl,
            }
        }
    elif order.is_market:
        o["t"] = {"limit": {"tif": "Ioc"}}
    else:
        # Limit order. When post_only, use ALO (post-only / maker) so we earn the
        # maker rebate instead of paying taker; otherwise GTC.
        tif = "Alo" if order.post_only else "Gtc"
        o["t"] = {"limit": {"tif": tif}}
    return o


def _fmt_price(p: float | None) -> str:
    return "0" if p is None else f"{p:.8g}"


def _fmt_size(s: float) -> str:
    return f"{s:.8g}"


def _order_from_hl(o: dict) -> OrderRequest:
    from src.domain.model import Settlement

    inst = Instrument(symbol=o.get("a", ""), base=o.get("a", ""), quote=Settlement.USDC)
    return OrderRequest(
        instrument=inst,
        side=Side.BUY if o.get("b") else Side.SELL,
        order_type=OrderType.LIMIT,
        price=float(o.get("p", 0)),
        size_coin=float(o.get("s", 0)),
        client_order_id=o.get("c"),
        reduce_only=o.get("r", False),
    )


def _position_from_hl(pos: dict) -> Position:
    from src.domain.model import Settlement

    sym = pos.get("coin", "")
    inst = Instrument(symbol=sym, base=sym, quote=Settlement.USDC)
    szi = float(pos.get("szi", "0"))
    return Position(
        instrument=inst,
        side=Side.BUY if szi > 0 else Side.SELL,
        size_coin=abs(szi),
        entry_px=float(pos.get("entryPx", 0) or 0),
        leverage=int(float(pos.get("leverage", {}).get("value", 1)) if isinstance(pos.get("leverage"), dict) else pos.get("leverage", 1)),
        margin_usd=float(pos.get("marginUsed", 0) or 0),
        unrealized_pnl_usd=float(pos.get("unrealizedPnl", 0) or 0),
        liquidation_px=float(pos.get("liquidationPx", 0) or 0) or None,
    )


def _fill_from_hl(f: dict) -> Fill:
    from src.domain.model import Settlement

    sym = f.get("coin", "")
    inst = Instrument(symbol=sym, base=sym, quote=Settlement.USDC)
    return Fill(
        instrument=inst,
        side=Side.BUY if f.get("side") == "B" else Side.SELL,
        price=float(f.get("px", 0)),
        size_coin=float(f.get("sz", 0)),
        fee_usd=float(f.get("fee", 0) or 0),
        ts_ms=int(f.get("time", 0)),
    )
