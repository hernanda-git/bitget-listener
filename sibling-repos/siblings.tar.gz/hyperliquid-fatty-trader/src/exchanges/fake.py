"""FakeHyperliquidAdapter — in-memory double for tests. No network.

Implements the ExchangeAdapter port so the orchestrator/tests run without touching
Hyperliquid. Tracks open orders + positions locally and simulates fills.
"""

from __future__ import annotations

from src.domain.model import (
    Fill,
    Instrument,
    OrderRequest,
    OrderType,
    Position,
    Side,
    Settlement,
)
from src.interfaces.ports import ExchangeAdapter


class FakeHyperliquidAdapter:
    def __init__(self) -> None:
        self.open_orders: dict[str, OrderRequest] = {}
        self.positions: dict[str, Position] = {}
        self.fills: list[Fill] = []
        self.placed: list[OrderRequest] = []
        self.cancelled: list[str] = []

    async def place_order(self, order: OrderRequest) -> str:
        oid = order.client_order_id or _ulid()
        self.open_orders[oid] = order
        self.placed.append(order)
        # Market orders fill immediately; limit orders rest (stay open) like the
        # real exchange. Reduce-only SL/TP triggers rest until price hits.
        if order.is_market or order.order_type == OrderType.MARKET:
            self._fill(order, oid)
        return oid

    async def cancel_order(self, instrument: Instrument, client_order_id: str) -> bool:
        self.open_orders.pop(client_order_id, None)
        self.cancelled.append(client_order_id)
        return True

    async def get_open_orders(self) -> list[OrderRequest]:
        return list(self.open_orders.values())

    async def get_positions(self) -> list[Position]:
        return list(self.positions.values())

    async def get_fills(self) -> list[Fill]:
        return list(self.fills)

    # ── test helpers ──
    def seed_position(self, symbol: str, side: Side, size: float, entry: float, lev: int = 10):
        inst = Instrument(symbol=symbol, base=symbol, quote=Settlement.USDC)
        self.positions[symbol] = Position(
            instrument=inst, side=side, size_coin=size, entry_px=entry,
            leverage=lev, margin_usd=size * entry / lev,
        )

    def _fill(self, order: OrderRequest, oid: str) -> None:
        px = order.price or 0.0
        self.fills.append(Fill(
            instrument=order.instrument, side=order.side, price=px,
            size_coin=order.size_coin, fee_usd=order.size_coin * px * 0.0004,
        ))
        # update position for non-reduce-only market orders
        if not order.reduce_only:
            sym = order.instrument.symbol
            existing = self.positions.get(sym)
            if existing is None:
                self.positions[sym] = Position(
                    instrument=order.instrument, side=order.side,
                    size_coin=order.size_coin, entry_px=px,
                    leverage=10, margin_usd=order.size_coin * px / 10,
                )
        self.open_orders.pop(oid, None)


def _ulid() -> str:
    import uuid
    return uuid.uuid4().hex[:16]
