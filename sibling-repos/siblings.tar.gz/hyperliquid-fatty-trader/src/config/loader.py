"""Typed config loader (Dependency Inversion: config = file + env).

Reads non-secret settings from config.yaml and overlays secrets from the
environment / .env. The Hyperliquid private key is ONLY ever read from env,
never from a committed file.
"""

from __future__ import annotations

import os
from pathlib import Path

from dotenv import load_dotenv
from pydantic import BaseModel

load_dotenv(Path(__file__).resolve().parents[2] / ".env")


# Optional bridge to the new DB-backed multi-bot config. Imported lazily so the
# loader has no hard dependency on the sqlite module (keeps unit tests light).
try:
    from src.config.db import BotConfig  # noqa: F401
except Exception:  # pragma: no cover
    BotConfig = None  # type: ignore


class RiskConfig(BaseModel):
    max_leverage: int = 20
    max_portfolio_usd: float = 1000.0
    default_leverage: int = 10
    default_notional_usd: float = 100.0


class HyperliquidConfig(BaseModel):
    testnet: bool = False
    account_address: str = ""
    private_key: str = ""      # from env only
    base_url: str | None = None


class AppConfig(BaseModel):
    dry_run: bool = True
    min_confidence: float = 0.5
    channel: str = "fattyfatclub"
    hyperliquid: HyperliquidConfig = HyperliquidConfig()
    risk: RiskConfig = RiskConfig()

    @classmethod
    def load(cls, path: str | Path | None = None) -> "AppConfig":
        cfg_path = Path(path) if path else (
            Path(__file__).resolve().parents[2] / "config.yaml"
        )
        data: dict = {}
        if cfg_path.exists():
            try:
                import yaml
                data = yaml.safe_load(cfg_path.read_text()) or {}
            except Exception:
                data = {}
        # env always wins for secrets + safety flags
        hl = data.setdefault("hyperliquid", {})
        hl.setdefault("private_key", os.getenv("HL_PRIVATE_KEY", ""))
        hl.setdefault("account_address", os.getenv("HL_ACCOUNT_ADDRESS", ""))
        if os.getenv("HL_TESTNET") == "1":
            hl["testnet"] = True
        if os.getenv("DRY_RUN") == "0":
            data["dry_run"] = False
        if os.getenv("CHANNEL_USERNAME"):
            data["channel"] = os.getenv("CHANNEL_USERNAME")
        return cls(**data)

    @classmethod
    def from_bot(cls, bot: "BotConfig") -> "AppConfig":
        """Build a typed AppConfig from a DB-backed BotConfig (multi-bot mode).

        Secrets (HL private key, account address) are always read from env, never
        from the DB. The DB only supplies non-secret runtime settings.
        """
        return cls(
            dry_run=bot.paper,           # paper == dry_run (no real orders)
            min_confidence=bot.min_confidence,
            channel=bot.channel,
            hyperliquid=HyperliquidConfig(
                testnet=bot.testnet,
                account_address=os.getenv("HL_ACCOUNT_ADDRESS", ""),
                private_key=os.getenv("HL_PRIVATE_KEY", ""),
            ),
        )
