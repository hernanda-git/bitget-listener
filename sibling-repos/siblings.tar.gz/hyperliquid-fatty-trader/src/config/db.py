"""PostgreSQL-backed configuration store (multi-bot, single source of truth).

Why a real client/server DB and not SQLite:
  * Multiple bots (each its own Telegram bot token + Hyperliquid account) need
    independent config without juggling N files.
  * The /toggle paper<->live switch must *persist* (survive restarts) and be
    readable by the launcher before the engine starts. A row flag does that.
  * PostgreSQL runs as its own server process, bound to 0.0.0.0:5432 on the VPS
    ("Sera"), so the config is reachable from OUTSIDE the box (your laptop,
    another container, a dashboard) over TCP — not trapped inside one filesystem.
    SQLite cannot do that.

Connection model:
  * A process-wide psycopg `ConnectionPool` (one connection per thread/coroutine
    under load, lazy). `check_same_thread`/`closed db` traps from sqlite do not
    apply; psycopg pools are async/thread safe.
  * If `CONFIG_DB_URL` is unset we fall back to a localhost app DB, so tests and
    the repo stay runnable without external secrets.

SECRETS ARE NEVER STORED HERE. Private keys, TG bot tokens, TG_API_ID/HASH,
SESSION_STRING, vision API keys stay in the environment / git-ignored `.env`.
This module only stores non-secret, per-bot runtime settings.
"""

from __future__ import annotations

import os
from dataclasses import dataclass

# Configured at deploy time (see deploy.sh / .env). The DB URL holds only the
# app role + a non-superuser password; never a private key or TG token.
# Read lazily (inside __init__/_conn) rather than at import time, because .env is
# loaded by src/config/loader.py via load_dotenv() and that may run after this
# module is first imported — a module-level os.getenv() would otherwise miss it.
DEFAULT_DB_URL = "postgresql://app:app@127.0.0.1:5432/fatty_config"

_SCHEMA = """
CREATE TABLE IF NOT EXISTS bots (
    name             TEXT PRIMARY KEY,
    enabled          BOOLEAN NOT NULL DEFAULT TRUE,
    paper            BOOLEAN NOT NULL DEFAULT TRUE,   -- TRUE = paper (dry-run), FALSE = live
    channel          TEXT    NOT NULL DEFAULT 'fattyfatclub',
    min_confidence   DOUBLE PRECISION NOT NULL DEFAULT 0.5,
    testnet          BOOLEAN NOT NULL DEFAULT TRUE,
    tg_bot_token_env TEXT    NOT NULL DEFAULT 'TG_BOT_TOKEN',
    tg_bot_chat_env  TEXT    NOT NULL DEFAULT 'TG_BOT_CHAT',
    wallet_address   TEXT    NOT NULL DEFAULT '',
    notes            TEXT    NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS risk (
    bot_name          TEXT PRIMARY KEY REFERENCES bots(name) ON DELETE CASCADE,
    max_leverage      INTEGER NOT NULL DEFAULT 20,
    max_portfolio_usd DOUBLE PRECISION NOT NULL DEFAULT 1000.0,
    default_leverage  INTEGER NOT NULL DEFAULT 3,
    risk_pct          DOUBLE PRECISION NOT NULL DEFAULT 0.02,
    fallback_sl_pct   DOUBLE PRECISION NOT NULL DEFAULT 0.05,
    max_notional_usd  DOUBLE PRECISION NOT NULL DEFAULT 1000.0,
    default_margin_usd DOUBLE PRECISION NOT NULL DEFAULT 1.0
);
"""

# Columns selected by the read path (kept in sync with upsert).
_BOT_COLS = (
    "name, enabled, paper, channel, min_confidence, testnet, "
    "tg_bot_token_env, tg_bot_chat_env, wallet_address, notes"
)


@dataclass
class BotConfig:
    name: str
    enabled: bool = True
    paper: bool = True
    channel: str = "fattyfatclub"
    min_confidence: float = 0.5
    testnet: bool = True
    tg_bot_token_env: str = "TG_BOT_TOKEN"
    tg_bot_chat_env: str = "TG_BOT_CHAT"
    wallet_address: str = ""
    notes: str = ""

    @property
    def live(self) -> bool:
        return (not self.paper) and self.enabled

    def to_db_row(self) -> dict:
        return {
            "name": self.name,
            "enabled": bool(self.enabled),
            "paper": bool(self.paper),
            "channel": self.channel,
            "min_confidence": float(self.min_confidence),
            "testnet": bool(self.testnet),
            "tg_bot_token_env": self.tg_bot_token_env,
            "tg_bot_chat_env": self.tg_bot_chat_env,
            "wallet_address": self.wallet_address,
            "notes": self.notes,
        }


@dataclass
class RiskRow:
    max_leverage: int = 20
    max_portfolio_usd: float = 1000.0
    default_leverage: int = 3
    risk_pct: float = 0.02
    fallback_sl_pct: float = 0.05
    max_notional_usd: float = 1000.0
    default_margin_usd: float = 1.0


class ConfigStore:
    """Thin PostgreSQL store. One row per bot. Pooled connections per call."""

    def __init__(self, db_url: str | None = None):
        # Resolve lazily: prefer an explicit URL, then CONFIG_DB_URL from the
        # environment. If .env wasn't loaded yet, load it now so the deploy-time
        # connection string is always picked up.
        if db_url is None:
            from dotenv import load_dotenv
            load_dotenv()
            db_url = os.getenv("CONFIG_DB_URL", DEFAULT_DB_URL)
        self.db_url = db_url
        # Lazily created pool (one per process). Created on first use so that
        # merely importing this module never opens a socket.
        self._pool = None
        self._ensure_schema()

    # ---- connection helper (one fresh connection per operation) ----
    def _conn(self):
        """Borrow a fresh connection. Caller must use it as a context manager
        (``with self._conn() as c:``) so it is closed afterwards. A new connect
        per call sidesteps any cross-thread / closed-connection traps under
        asyncio (same reasoning as the python-sqlite-async skill)."""
        import psycopg
        return psycopg.connect(
            self.db_url, connect_timeout=10, autocommit=False,
        )

    def _ensure_schema(self) -> None:
        """Create tables once, idempotently, via a standalone connection."""
        with self._conn() as c:
            c.execute(_SCHEMA)
            c.commit()

    # ---- bot CRUD ----
    def upsert_bot(self, cfg: BotConfig) -> None:
        row = cfg.to_db_row()
        cols = list(row.keys())
        placeholders = ", ".join(f"%({k})s" for k in cols)
        set_clause = ", ".join(f"{k}=EXCLUDED.{k}" for k in cols if k != "name")
        sql = (
            f"INSERT INTO bots ({', '.join(cols)}) VALUES ({placeholders}) "
            f"ON CONFLICT(name) DO UPDATE SET {set_clause}"
        )
        with self._conn() as c:
            c.execute(sql, row)
            c.execute(
                "INSERT INTO risk (bot_name) VALUES (%(name)s) "
                "ON CONFLICT(bot_name) DO NOTHING",
                {"name": cfg.name},
            )
            c.commit()

    def get_bot(self, name: str) -> BotConfig | None:
        with self._conn() as c:
            row = c.execute(
                f"SELECT {_BOT_COLS} FROM bots WHERE name = %(name)s",
                {"name": name},
            ).fetchone()
        if not row:
            return None
        return self._row_to_bot(row)

    def list_bots(self, enabled_only: bool = False) -> list[BotConfig]:
        sql = f"SELECT {_BOT_COLS} FROM bots"
        if enabled_only:
            sql += " WHERE enabled = TRUE"
        with self._conn() as c:
            rows = c.execute(sql).fetchall()
        return [self._row_to_bot(r) for r in rows]

    @staticmethod
    def _row_to_bot(row) -> BotConfig:
        return BotConfig(
            name=row[0], enabled=bool(row[1]), paper=bool(row[2]), channel=row[3],
            min_confidence=float(row[4]), testnet=bool(row[5]),
            tg_bot_token_env=row[6], tg_bot_chat_env=row[7],
            wallet_address=row[8] or "", notes=row[9] or "",
        )

    def set_paper(self, name: str, paper: bool) -> bool:
        """Persist the paper/live flag. Returns True if the bot exists."""
        with self._conn() as c:
            cur = c.execute(
                "UPDATE bots SET paper = %(paper)s WHERE name = %(name)s",
                {"paper": bool(paper), "name": name},
            )
            c.commit()
            return cur.rowcount > 0

    def set_enabled(self, name: str, enabled: bool) -> bool:
        with self._conn() as c:
            cur = c.execute(
                "UPDATE bots SET enabled = %(enabled)s WHERE name = %(name)s",
                {"enabled": bool(enabled), "name": name},
            )
            c.commit()
            return cur.rowcount > 0

    def delete_bot(self, name: str) -> bool:
        """Remove a bot (and its risk row via FK cascade). True if deleted."""
        with self._conn() as c:
            cur = c.execute("DELETE FROM bots WHERE name = %(name)s", {"name": name})
            c.commit()
            return cur.rowcount > 0

    # ---- risk ----
    _RISK_COLS = (
        "max_leverage, max_portfolio_usd, default_leverage, risk_pct, "
        "fallback_sl_pct, max_notional_usd, default_margin_usd"
    )

    def get_risk(self, name: str) -> RiskRow:
        with self._conn() as c:
            row = c.execute(
                f"SELECT {self._RISK_COLS} FROM risk WHERE bot_name = %(name)s",
                {"name": name},
            ).fetchone()
        if not row:
            return RiskRow()
        return RiskRow(*row)

    def upsert_risk(self, name: str, r: RiskRow) -> None:
        with self._conn() as c:
            c.execute(
                "INSERT INTO risk (bot_name, max_leverage, max_portfolio_usd, "
                "default_leverage, risk_pct, fallback_sl_pct, max_notional_usd, "
                "default_margin_usd) VALUES (%(name)s,%(ml)s,%(mp)s,%(dl)s,%(rp)s,"
                "%(fs)s,%(mn)s,%(dm)s) "
                "ON CONFLICT(bot_name) DO UPDATE SET "
                "max_leverage=EXCLUDED.max_leverage, "
                "max_portfolio_usd=EXCLUDED.max_portfolio_usd, "
                "default_leverage=EXCLUDED.default_leverage, "
                "risk_pct=EXCLUDED.risk_pct, "
                "fallback_sl_pct=EXCLUDED.fallback_sl_pct, "
                "max_notional_usd=EXCLUDED.max_notional_usd, "
                "default_margin_usd=EXCLUDED.default_margin_usd",
                {
                    "name": name, "ml": r.max_leverage, "mp": r.max_portfolio_usd,
                    "dl": r.default_leverage, "rp": r.risk_pct,
                    "fs": r.fallback_sl_pct, "mn": r.max_notional_usd,
                    "dm": r.default_margin_usd,
                },
            )
            c.commit()


def ensure_default_bot(store: ConfigStore | None = None,
                       name: str = "fatty-main") -> BotConfig:
    """Create the default bot row if absent. Returns the (possibly existing) config."""
    store = store or ConfigStore()
    existing = store.get_bot(name)
    if existing is not None:
        return existing
    cfg = BotConfig(name=name)
    store.upsert_bot(cfg)
    return cfg
