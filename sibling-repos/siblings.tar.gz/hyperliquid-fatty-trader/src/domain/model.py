"""Pure domain types. No IO, no async, no framework imports.

All prices in `Signal`/`OrderRequest` are in **USDC** (post-normalization).
The only place USDT appears is inside `RawSignal.raw` / `RawSignal.quote`,
which `SignalNormalizer` consumes and converts.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Literal


class Side(str, Enum):
    BUY = "BUY"
    SELL = "SELL"


class OrderType(str, Enum):
    LIMIT = "LIMIT"
    MARKET = "MARKET"
    TRIGGER = "TRIGGER"  # Hyperliquid tpsl / trigger order


class Settlement(str, Enum):
    USDT = "USDT"
    USDC = "USDC"


@dataclass(frozen=True)
class Instrument:
    """A tradeable instrument on the execution venue (Hyperliquid)."""

    symbol: str                 # canonical perp name, e.g. "BTC" or "BTC-PERP"
    base: str                   # "BTC"
    quote: Settlement = Settlement.USDC
    venue: str = "hyperliquid"

    @classmethod
    def from_usdt_pair(cls, pair: str) -> "Instrument":
        """Build from a Bybit-style USDT pair like 'BTCUSDT' -> BTC / USDC."""
        base = pair[:-4] if pair.endswith("USDT") else pair
        return cls(symbol=base, base=base, quote=Settlement.USDC)

    @classmethod
    def from_ticker(cls, ticker: str) -> "Instrument":
        """Build from an already venue-resolved perp ticker (e.g. 'kBONK')."""
        return cls(symbol=ticker, base=ticker, quote=Settlement.USDC)


@dataclass(frozen=True)
class UsdNotional:
    """Risk expressed in USD; the settlement asset is a separate concern."""

    amount_usd: float
    settlement: Settlement = Settlement.USDC


@dataclass
class RawSignal:
    """Unnormalized signal as produced by the source (Telegram @fattyfatclub).

    Prices are in the *source* quote asset (USDT). They are NOT used downstream;
    `SignalNormalizer` converts them to USDC and emits a `Signal`.

    ``symbol`` is the resolved, venue-canonical ticker (e.g. "BTC" or "kBONK"),
    filled by the parser after consulting the venue's perp universe. ``symbol_usdt``
    keeps the raw source pairing (e.g. "$BONK" / "BONKUSDT") for traceability.
    """

    symbol_usdt: str = ""       # e.g. "BTCUSDT"; filled later by the signal parser
    symbol: str = ""            # resolved venue ticker, e.g. "kBONK" (empty if unlisted)
    venue: str = "hyperliquid"  # execution venue the symbol was resolved against
    side: Side = Side.BUY      # placeholder; the signal parser sets the real side
    entry_usdt: float | None = None
    sl_usdt: float | None = None
    tp_usdt: float | None = None   # primary TP (first of multi-TP if given)
    tp_usdt_extra: list[float] = field(default_factory=list)  # additional TPs
    notional_usd: float = 0.0   # USD notional budget (peg-invariant)
    leverage: int = 1
    confidence: float = 0.0
    raw: dict = field(default_factory=dict)
    source: str = "fattyfatclub"
    message_id: int | None = None
    has_media: bool = False
    channel: str = ""        # source channel/username (Telegram @fattyfatclub)
    raw_text: str = ""       # original message text (for parser / vision caption)
    image_path: str = ""     # local path of downloaded chart image, if any


@dataclass
class Signal:
    """Normalized, execution-ready signal. All prices in **USDC**."""

    instrument: Instrument
    side: Side
    entry: float | None        # USDC
    sl: float | None           # USDC
    tp: float | None           # USDC
    notional: UsdNotional      # USD risk budget
    leverage: int
    confidence: float
    raw: dict = field(default_factory=dict)
    source: str = "fattyfatclub"
    message_id: int | None = None
    peg_rate: float = 1.0      # USDC per USDT used during normalization


@dataclass
class OrderRequest:
    """A single order to be placed on Hyperliquid (USDC-settled, coin-sized)."""

    instrument: Instrument
    side: Side
    order_type: OrderType
    price: float | None        # USDC; None for market
    size_coin: float           # base-asset size (e.g. BTC)
    reduce_only: bool = False
    client_order_id: str | None = None
    trigger_px: float | None = None   # for TRIGGER (SL/TP)
    tpsl: Literal["sl", "tp"] | None = None
    is_market: bool = False
    post_only: bool = False      # maker-only (HL `tif: Alo`); ignored for reduce_only/trigger


@dataclass
class Position:
    instrument: Instrument
    side: Side
    size_coin: float
    entry_px: float            # USDC
    leverage: int
    margin_usd: float
    unrealized_pnl_usd: float = 0.0
    liquidation_px: float | None = None
    sl_px: float | None = None           # current stop-loss price (USDC)
    sl_order_id: str | None = None       # client_order_id of the SL trigger order
    tp_px: float | None = None           # primary take-profit price (USDC)
    tp_order_ids: list[str] = field(default_factory=list)


@dataclass
class Fill:
    instrument: Instrument
    side: Side
    price: float               # USDC
    size_coin: float
    fee_usd: float = 0.0
    ts_ms: int | None = None
