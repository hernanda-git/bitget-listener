"""Port interfaces (Dependency Inversion). High-level modules depend on these,
never on concrete adapters.

Each interface is intentionally narrow (Interface Segregation).
"""

from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Protocol, runtime_checkable

from src.domain.model import (
    Fill,
    OrderRequest,
    Position,
    RawSignal,
    Signal,
)


@runtime_checkable
class SignalSource(Protocol):
    """Produces raw signals (e.g. from Telegram @fattyfatclub)."""

    async def start(self) -> None: ...

    def subscribe(self) -> "asyncio.Queue[RawSignal]": ...


@runtime_checkable
class ExchangeAdapter(Protocol):
    """Executes orders on the venue (Hyperliquid)."""

    async def place_order(self, order: OrderRequest) -> str:
        """Return the exchange order id (or client order id)."""
        ...

    async def cancel_order(self, instrument, client_order_id: str) -> bool: ...

    async def get_open_orders(self) -> list[OrderRequest]: ...

    async def get_positions(self) -> list[Position]: ...

    async def get_fills(self) -> list[Fill]: ...


@runtime_checkable
class MarketStream(Protocol):
    """Delivers realtime market + user events via pushes."""

    async def start(self) -> None: ...

    async def stop(self) -> None: ...

    def mark_price(self, symbol: str) -> float | None: ...


@runtime_checkable
class Notifier(Protocol):
    async def send(self, text: str) -> None: ...


@runtime_checkable
class RiskPolicy(Protocol):
    """Computes coin size + leverage from a USD notional and portfolio state."""

    def compute_size(
        self, notional_usd: float, mark_price_usdc: float, max_leverage: int
    ) -> tuple[float, int]:
        """Return (coin_size, effective_leverage)."""
        ...


@runtime_checkable
class PegSource(Protocol):
    """Provides the live USDT->USDC peg rate."""

    async def peg_rate(self) -> float: ...


@runtime_checkable
class AttachmentFetcher(Protocol):
    """Downloads Telegram image attachments to local disk."""

    async def download(self, client, message, channel: str = "") -> tuple[str, str]:
        """Return (local_path, media_type). Empty path = no media."""
        ...


@runtime_checkable
class VisionExtractor(Protocol):
    """Reads a chart image and returns structured levels/trend/setup."""

    async def extract(self, image_path: str | Path, caption: str = "") -> dict:
        ...
