"""PostgreSQL-backed per-pair minimum-notional reference for Hyperliquid perps.

Hyperliquid enforces a *minimum order notional* per coin, but it is NOT exposed
in any public `info` endpoint (`meta` / `metaAndAssetCtxs` do not carry a
per-asset `minTradeNtl`). The floor is enforced server-side only.

What we CAN read live from the API:
  * `meta`        -> per-coin `szDecimals` (min size increment) and `maxLeverage`
  * `allMids`     -> current mid price

From those we compute:
  * `min_size_step`       = 10 ** -szDecimals           (smallest size increment)
  * `min_step_notional`   = min_size_step * mid          (notional of one step)
  * `min_notional`        = configurable floor (default $10 for majors) -> the
                            size needed to clear that notional = floor / mid

The floor itself is a DOCUMENTED value (HL states ~$10 for majors; low-cap
coins are higher but not published per-coin). We store it under
`is_floor_from_api = FALSE` so the record is honest about provenance. When HL's
API or frontend reveals the true per-coin `minTradeNtl`, set it explicitly via
`upsert_pair(..., min_notional=..., is_floor_from_api=True)`.

The bot's `RiskManager` reads `min_notional` from here (falling back to the
configured default) so small-account orders are bumped above the floor instead
of being rejected.
"""

from __future__ import annotations

import os
from datetime import datetime, timezone

from src.services.risk import RiskConfig  # single source of truth for the default floor

DEFAULT_MIN_NOTIONAL_USD = RiskConfig.min_notional_usd

DEFAULT_DB_URL = "postgresql://app:***@127.0.0.1:5432/fatty_config"

_SCHEMA = """
CREATE TABLE IF NOT EXISTS hl_pair_min_notional (
    symbol           TEXT PRIMARY KEY,
    asset_index      INTEGER,
    sz_decimals      INTEGER,
    max_leverage     INTEGER,
    mid              DOUBLE PRECISION,
    min_size_step    DOUBLE PRECISION,   -- 10^-sz_decimals
    min_step_notional DOUBLE PRECISION, -- min_size_step * mid
    min_notional     DOUBLE PRECISION,  -- floor used by the bot (computed/default)
    is_floor_from_api BOOLEAN NOT NULL DEFAULT FALSE,  -- FALSE = documented default, not API
    updated_at       DOUBLE PRECISION NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_hlpmi_sym ON hl_pair_min_notional(symbol);
"""


def _now() -> float:
    return datetime.now(timezone.utc).timestamp()


class MinNotionalStore:
    """Per-pair minimum-notional reference, backed by PostgreSQL."""

    def __init__(self, db_url: str | None = None):
        if db_url is None:
            from dotenv import load_dotenv
            load_dotenv()
            db_url = os.getenv("CONFIG_DB_TEST_URL") or os.getenv(
                "CONFIG_DB_URL", DEFAULT_DB_URL)
        self.db_url = db_url
        self._ensure_schema()

    def _ensure_schema(self) -> None:
        import psycopg
        conn = psycopg.connect(self.db_url)
        try:
            conn.execute(_SCHEMA)
            conn.commit()
        finally:
            conn.close()

    def _conn(self):
        import psycopg
        return psycopg.connect(self.db_url)

    # ---- population from HL API -------------------------------------- #
    def refresh_from_hl(self, adapter, default_floor: float = DEFAULT_MIN_NOTIONAL_USD) -> int:
        """Fetch `meta` + `allMids` from the adapter and upsert every perp pair.

        Returns the number of pairs written.
        """
        meta = adapter._info({"type": "meta"})
        mids = adapter._info({"type": "allMids"})
        universe = meta.get("universe", [])
        count = 0
        for idx, u in enumerate(universe):
            if not isinstance(u, dict):
                continue
            symbol = u.get("name")
            if not symbol:
                continue
            sz_dec = u.get("szDecimals")
            if sz_dec is None:
                continue
            max_lev = u.get("maxLeverage")
            mid = float(mids.get(symbol, 0) or 0)
            step = 10.0 ** (-sz_dec)
            step_notional = step * mid if mid else None
            # floor computed from the documented default; per-coin API values can
            # override later via upsert_pair.
            min_notional = default_floor
            self.upsert_pair(
                symbol=symbol, asset_index=idx, sz_decimals=sz_dec,
                max_leverage=max_lev, mid=mid, min_size_step=step,
                min_step_notional=step_notional, min_notional=min_notional,
                is_floor_from_api=False,
            )
            count += 1
        return count

    # ---- writes -------------------------------------------------------- #
    def upsert_pair(self, symbol: str, asset_index: int | None, sz_decimals: int,
                    max_leverage: int | None, mid: float | None,
                    min_size_step: float | None, min_step_notional: float | None,
                    min_notional: float, is_floor_from_api: bool = False) -> None:
        conn = self._conn()
        try:
            conn.execute(
                """INSERT INTO hl_pair_min_notional
                   (symbol, asset_index, sz_decimals, max_leverage, mid,
                    min_size_step, min_step_notional, min_notional,
                    is_floor_from_api, updated_at)
                   VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
                   ON CONFLICT (symbol) DO UPDATE SET
                   asset_index=EXCLUDED.asset_index,
                   sz_decimals=EXCLUDED.sz_decimals,
                   max_leverage=EXCLUDED.max_leverage,
                   mid=EXCLUDED.mid,
                   min_size_step=EXCLUDED.min_size_step,
                   min_step_notional=EXCLUDED.min_step_notional,
                   min_notional=EXCLUDED.min_notional,
                   is_floor_from_api=EXCLUDED.is_floor_from_api,
                   updated_at=EXCLUDED.updated_at""",
                (symbol, asset_index, sz_decimals, max_leverage, mid,
                 min_size_step, min_step_notional, min_notional,
                 is_floor_from_api, _now()),
            )
            conn.commit()
        finally:
            conn.close()

    # ---- reads --------------------------------------------------------- #
    def get(self, symbol: str) -> dict | None:
        conn = self._conn()
        try:
            row = conn.execute(
                "SELECT symbol, asset_index, sz_decimals, max_leverage, mid, "
                "min_size_step, min_step_notional, min_notional, "
                "is_floor_from_api, updated_at FROM hl_pair_min_notional "
                "WHERE symbol=%s", (symbol,)).fetchone()
            if row is None:
                return None
            cols = ["symbol", "asset_index", "sz_decimals", "max_leverage", "mid",
                    "min_size_step", "min_step_notional", "min_notional",
                    "is_floor_from_api", "updated_at"]
            return dict(zip(cols, row))
        finally:
            conn.close()

    def all(self) -> list[dict]:
        conn = self._conn()
        try:
            rows = conn.execute(
                "SELECT symbol, asset_index, sz_decimals, max_leverage, mid, "
                "min_size_step, min_step_notional, min_notional, "
                "is_floor_from_api, updated_at FROM hl_pair_min_notional "
                "ORDER BY asset_index").fetchall()
            cols = ["symbol", "asset_index", "sz_decimals", "max_leverage", "mid",
                    "min_size_step", "min_step_notional", "min_notional",
                    "is_floor_from_api", "updated_at"]
            return [dict(zip(cols, r)) for r in rows]
        finally:
            conn.close()

    def count(self) -> int:
        conn = self._conn()
        try:
            return conn.execute("SELECT COUNT(*) FROM hl_pair_min_notional").fetchone()[0]
        finally:
            conn.close()
