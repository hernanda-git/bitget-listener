"""PostgreSQL-backed signal + trade ledger.

This is the durable store the bot was missing: every signal received, every
order placed, and every position open/close (with P&L and close reason) is
written here so performance can be evaluated *after the fact* — from outside the
VPS, because it lives in the same externally-reachable ``fatty_config`` database
as the bot config (no SQLite, no local files).

The notifier (``BotDashboard``) is the single chokepoint for all pipeline events,
so it owns the writes: ``signal_received`` -> signals_log, ``order_placed`` /
``position_opened`` -> trades_log (open), ``tp_hit`` / ``sl_hit`` / ``management``
-> trades_log (close/outcome). One fresh connection per operation (safe under
asyncio, see the python-sqlite-async skill — same rule applies to psycopg).

All methods are fire-and-forget tolerant: callers wrap them in try/except, and
this module never raises into the trading pipeline.
"""

from __future__ import annotations

import os
from datetime import datetime, timezone

# Connection URL comes from the same CONFIG_DB_URL as the config DB (the
# fatty_config database). The ledger shares that DB so it is reachable from
# outside the VPS alongside the bot config. Only the non-superuser app role is
# used; no private keys or TG tokens are ever stored here.
DEFAULT_DB_URL = "postgresql://app:app@127.0.0.1:5432/fatty_config"

_SCHEMA = """
CREATE TABLE IF NOT EXISTS signals_log (
    id          BIGSERIAL PRIMARY KEY,
    ts          DOUBLE PRECISION NOT NULL,
    iso         TEXT NOT NULL,
    bot         TEXT NOT NULL DEFAULT '',
    symbol      TEXT NOT NULL DEFAULT '',
    side        TEXT NOT NULL DEFAULT '',
    source      TEXT NOT NULL DEFAULT '',
    message_id  BIGINT,
    raw_text    TEXT NOT NULL DEFAULT '',
    status      TEXT NOT NULL DEFAULT 'received'
);
CREATE INDEX IF NOT EXISTS idx_sig_ts ON signals_log(ts);
CREATE INDEX IF NOT EXISTS idx_sig_bot ON signals_log(bot);

CREATE TABLE IF NOT EXISTS trades_log (
    id           BIGSERIAL PRIMARY KEY,
    ts_open      DOUBLE PRECISION NOT NULL,
    iso_open     TEXT NOT NULL,
    ts_close     DOUBLE PRECISION,
    iso_close    TEXT,
    bot          TEXT NOT NULL DEFAULT '',
    symbol       TEXT NOT NULL DEFAULT '',
    side         TEXT NOT NULL DEFAULT '',
    entry        DOUBLE PRECISION,
    exit_px      DOUBLE PRECISION,
    size         DOUBLE PRECISION,
    lev          INTEGER,
    sl           DOUBLE PRECISION,
    tp           DOUBLE PRECISION,
    margin       DOUBLE PRECISION,
    pnl          DOUBLE PRECISION,
    close_reason TEXT NOT NULL DEFAULT '',
    dry          BOOLEAN NOT NULL DEFAULT FALSE,
    source_msg_id BIGINT
);
CREATE INDEX IF NOT EXISTS idx_tr_open ON trades_log(ts_open);
CREATE INDEX IF NOT EXISTS idx_tr_sym ON trades_log(symbol);
CREATE INDEX IF NOT EXISTS idx_tr_bot ON trades_log(bot);
"""


def _now() -> tuple[float, str]:
    ts = datetime.now(timezone.utc).timestamp()
    iso = datetime.fromtimestamp(ts, timezone.utc).isoformat()
    return ts, iso


class Ledger:
    """Append-only signal/trade ledger on PostgreSQL."""

    def __init__(self, db_url: str | None = None, bot: str = ""):
        if db_url is None:
            from dotenv import load_dotenv
            load_dotenv()
            # Tests set CONFIG_DB_TEST_URL to a throwaway DB; production uses CONFIG_DB_URL.
            db_url = os.getenv("CONFIG_DB_TEST_URL") or os.getenv(
                "CONFIG_DB_URL", DEFAULT_DB_URL)
        self.db_url = db_url
        self.bot = bot
        self._ensure_schema()

    def _ensure_schema(self) -> None:
        import psycopg
        conn = psycopg.connect(self.db_url)
        try:
            conn.execute(_SCHEMA)
            conn.commit()
        finally:
            conn.close()

    def _conn(self):
        import psycopg
        return psycopg.connect(self.db_url)

    # ---- writes -------------------------------------------------------- #
    def log_signal(self, symbol: str, side: str, source: str,
                   message_id=None, raw_text: str = "", status: str = "received") -> None:
        ts, iso = _now()
        conn = self._conn()
        try:
            conn.execute(
                "INSERT INTO signals_log (ts, iso, bot, symbol, side, source, "
                "message_id, raw_text, status) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)",
                (ts, iso, self.bot, symbol or "", side or "", source or "",
                 message_id, raw_text or "", status),
            )
            conn.commit()
        finally:
            conn.close()

    def log_order(self, symbol: str, side: str, entry=None, sl=None, tp=None,
                  lev=None, dry: bool = False, source_msg_id=None) -> None:
        """Record a placed (or dry-run) order as an open trade row."""
        ts, iso = _now()
        conn = self._conn()
        try:
            conn.execute(
                "INSERT INTO trades_log (ts_open, iso_open, bot, symbol, side, "
                "entry, sl, tp, lev, dry, source_msg_id) "
                "VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",
                (ts, iso, self.bot, symbol or "", side or "", entry, sl, tp,
                 lev, dry, source_msg_id),
            )
            conn.commit()
        finally:
            conn.close()

    def log_close(self, symbol: str, exit_px=None, pnl=None,
                  reason: str = "", dry: bool = False) -> None:
        """Close the most recent open trade for a symbol (matches bot)."""
        ts, iso = _now()
        conn = self._conn()
        try:
            conn.execute(
                "UPDATE trades_log SET ts_close=%s, iso_close=%s, exit_px=%s, "
                "pnl=%s, close_reason=%s WHERE id = ("
                "SELECT id FROM trades_log WHERE symbol=%s AND bot=%s "
                "AND ts_close IS NULL ORDER BY ts_open DESC LIMIT 1)",
                (ts, iso, exit_px, pnl, reason or "", symbol or "", self.bot),
            )
            conn.commit()
        finally:
            conn.close()

    def log_management(self, symbol: str, action: str, dry: bool = False) -> None:
        """Note a management action on the open trade (e.g. sl moved)."""
        conn = self._conn()
        try:
            conn.execute(
                "UPDATE trades_log SET close_reason=%s WHERE id = ("
                "SELECT id FROM trades_log WHERE symbol=%s AND bot=%s "
                "AND ts_close IS NULL ORDER BY ts_open DESC LIMIT 1)",
                (f"mgmt:{action}", symbol or "", self.bot),
            )
            conn.commit()
        finally:
            conn.close()

    # ---- reads --------------------------------------------------------- #
    def recent_signals(self, limit: int = 20) -> list[dict]:
        conn = self._conn()
        try:
            rows = conn.execute(
                "SELECT iso, symbol, side, source, status, raw_text "
                "FROM signals_log WHERE bot=%s OR %s='' ORDER BY ts DESC LIMIT %s",
                (self.bot, self.bot, limit),
            ).fetchall()
        finally:
            conn.close()
        return [
            {"iso": r[0], "symbol": r[1], "side": r[2], "source": r[3],
             "status": r[4], "raw": r[5]}
            for r in rows
        ]

    def recent_trades(self, limit: int = 20) -> list[dict]:
        conn = self._conn()
        try:
            rows = conn.execute(
                "SELECT iso_open, symbol, side, entry, exit_px, pnl, "
                "close_reason, dry, iso_close FROM trades_log "
                "WHERE bot=%s OR %s='' ORDER BY ts_open DESC LIMIT %s",
                (self.bot, self.bot, limit),
            ).fetchall()
        finally:
            conn.close()
        return [
            {"open": r[0], "symbol": r[1], "side": r[2], "entry": r[3],
             "exit": r[4], "pnl": r[5], "reason": r[6], "dry": r[7], "close": r[8]}
            for r in rows
        ]

    def trade_summary(self) -> dict:
        """All-time win/loss/pnl summary (excludes dry-run rows)."""
        conn = self._conn()
        try:
            live = conn.execute(
                "SELECT COUNT(*), "
                "COALESCE(SUM(CASE WHEN pnl > 0 THEN 1 ELSE 0 END),0), "
                "COALESCE(SUM(CASE WHEN pnl < 0 THEN 1 ELSE 0 END),0), "
                "COALESCE(SUM(pnl),0) "
                "FROM trades_log WHERE dry=FALSE AND ts_close IS NOT NULL"
            ).fetchone()
            total, wins, losses, pnl = live
        finally:
            conn.close()
        return {
            "total_closed": total or 0,
            "wins": wins or 0,
            "losses": losses or 0,
            "net_pnl": round(pnl or 0.0, 4),
            "win_rate": round((wins / total) * 100, 1) if total else 0.0,
        }

    def signal_summary(self) -> dict:
        conn = self._conn()
        try:
            total = conn.execute(
                "SELECT COUNT(*) FROM signals_log WHERE bot=%s OR %s=''",
                (self.bot, self.bot)).fetchone()[0]
        finally:
            conn.close()
        return {"total_signals": total or 0}

    def close(self) -> None:
        pass
