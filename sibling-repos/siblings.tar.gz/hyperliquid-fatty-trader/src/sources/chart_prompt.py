"""Rich chart-parser prompt + adapter to the internal vision struct.

WHY THIS EXISTS
---------------
``VISION_PROMPT`` (the legacy prompt in ``vision.py``) asks the model for the
*internal* shape directly: ``{levels:{entry,sl,tp,support,resistance}, trend,
setup_type, wave, arrows, bias, has_chart_data}``. That shape is what
``_coerce`` and the orchestrator read.

``RICH_CHART_PROMPT`` below is a stricter, observation-only prompt: it forbids
prediction/advice, forbids fabricated values, and separates FACTS from
INTERPRETATION of annotations. It returns a much richer schema
(``position``, ``support_resistance``, ``zones``, ``arrows``,
``price_movements``, ``market_structure``, ...).

Those two schemas do not line up. Feeding the rich JSON straight into
``_coerce`` would silently null every level while defaulting
``has_chart_data`` to True — i.e. a chart would pass the orchestrator's gate
at ``orchestrator.py:382`` carrying no levels. On a live mainnet bot that is
the wrong direction to fail.

``adapt_rich_to_struct`` is the mapping layer. The rich output is preserved
verbatim under ``out["rich"]`` for logging/debugging, while the internal keys
the pipeline actually trades on are derived conservatively:

* ``position.entry/stop_loss/take_profit`` -> ``levels.entry/sl/tp``
* ``position.direction``                   -> ``trend`` (long->uptrend, short->downtrend)
* explicit ``price_levels[]`` entries       -> fill any gap left by ``position``
* support/resistance/zones                  -> ``levels.support`` / ``levels.resistance``
* ``has_chart_data``                        -> derived from what was ACTUALLY
  extracted, never taken on trust from the model.

SAFETY: this adapter never invents a level. If the model gives nothing
tradeable, ``has_chart_data`` is False and the orchestrator skips the image
(``vision_pending``) exactly as it does today.
"""

from __future__ import annotations

import json
from typing import Any

RICH_CHART_PROMPT = """You are a trading-chart image parser.

Your ONLY task is to inspect the provided chart image and convert the visually available information into structured JSON.

Do NOT provide trading advice.
Do NOT predict the market yourself.
Do NOT add commentary, explanations, opinions, or recommendations.
Do NOT invent or infer values that are not visually supported by the image.

The image may contain different chart layouts, indicators, annotations, drawings, arrows, zones, lines, labels, and price levels. Adapt to whatever is actually visible.

Extract objective information from the image, including when available:

1. CHART METADATA
- Symbol / asset if visible
- Timeframe if visible
- Chart date/time
- Chart source/platform
- Any visible title

2. CURRENT MARKET PRICE
- Current/latest price
- Current price label
- Current price position relative to visible levels

3. PRICE LEVELS
Extract every clearly visible labeled price level.
For each level, record:
- price
- label/type if identifiable
- visual representation
- whether it appears to be support, resistance, entry, target, stop, boundary, or unknown

Do NOT force a classification if it is unclear.

4. SUPPORT AND RESISTANCE
Identify visually meaningful support and resistance areas.

A support/resistance area may be represented by:
- horizontal lines
- colored zones
- repeated price reactions
- clearly marked boundaries
- boxes/rectangles
- manually annotated levels

For each:
- type: support / resistance / zone / unknown
- price or price range
- strength if explicitly indicated by the chart; otherwise null
- visual evidence
- color if identifiable

Do not invent numerical strength scores.

5. ZONES / AREAS
Detect colored or shaded regions such as:
- support zones
- resistance zones
- supply zones
- demand zones
- entry zones
- target zones
- stop-loss zones
- highlighted areas

Record:
- type
- top price
- bottom price
- color
- approximate location
- any associated label

6. ARROWS AND DRAWINGS
Detect manually drawn arrows or directional drawings.

For every arrow, determine ONLY what the drawing visually communicates.

Record:
- direction: up / down / sideways / curved / unknown
- starting approximate price
- ending approximate price
- starting approximate chart position/date if identifiable
- ending approximate chart position/date if identifiable
- path: rising / falling / sideways / mixed
- whether it appears to represent a projected movement or historical movement
- color
- any visible label associated with it

IMPORTANT:
An arrow is an annotation, not proof of what the market will actually do.

If an arrow clearly shows a projected path, describe it as:
"projected_upward_movement"
or
"projected_downward_movement"

Do NOT convert an arrow into a trading prediction.

7. PRICE MOVEMENT
Describe the objectively visible price movement in the chart.

Examples:
- upward movement
- downward movement
- sideways/consolidation
- range-bound movement
- sharp rise
- sharp decline
- recovery
- pullback
- breakout-looking movement
- rejection
- repeated testing of a level

Only describe movements that are visually apparent.

For each significant movement, record:
- direction
- approximate starting price
- approximate ending price
- approximate start/end date if readable
- movement description
- confidence

Do not predict future movement.

8. CANDLESTICKS
If individual OHLC values are explicitly readable, extract them.

If they cannot be reliably determined from the image, return an empty array.

Do NOT estimate candle OHLC values from pixel positions.

9. TRADING POSITION DRAWINGS
If the image contains a long/short position tool or clearly marked trade setup, extract:
- direction
- entry
- stop loss
- take profit
- risk/reward if explicitly shown
- associated price levels

Only populate these when visually supported.

10. TREND / STRUCTURE
Describe visible market structure only when reasonably clear:
- higher highs
- higher lows
- lower highs
- lower lows
- consolidation
- range
- trend
- breakout
- rejection
- pullback
Do not make a market forecast.

11. CHART ANNOTATIONS
Extract:
- arrows
- circles
- text labels
- icons
- drawings
- trend lines
- horizontal lines
- rectangles
- colored markings
- symbols

Preserve their visible meaning without adding interpretation.

12. TIME AXIS
Extract visible dates or time labels when readable.

13. VISUAL RELATIONSHIPS
Where possible, describe relationships between objects.

Examples:
- current price is inside support zone
- current price is below resistance
- current price is above support
- arrow starts near support and points toward resistance
- price repeatedly tests resistance
- price moves within a highlighted range

These relationships must be based only on visible chart information.

IMPORTANT DISTINCTION:

Separate:
A. FACTS directly visible in the chart
B. VISUAL INTERPRETATION of the chart's annotations

Never add your own market analysis.

For example, if the chart contains an upward blue arrow, report that the chart contains an upward blue arrow from approximately X to Y.

Do NOT say:
"Price will go up."

Instead say:
"An upward projected arrow is drawn from approximately X toward Y."

If a support zone is visibly marked between 63,930.5 and 64,059.0, report that range.

Do NOT invent additional support levels.

If a resistance zone is visibly marked between 67,442.3 and 68,206.4, report that range.

Do NOT assume other resistance levels unless visually supported.

NUMERICAL PRECISION:
- Preserve displayed decimal precision.
- Never fabricate missing digits.
- If a value is partially unreadable, use null.
- If a range has two visible boundaries, record both.
- Use approximate values only when the chart itself requires visual estimation, and mark them as approximate.

OUTPUT REQUIREMENTS:

Return ONLY valid JSON.

No Markdown.
No code fences.
No explanations.
No text before or after the JSON.

Use this flexible schema:

{
  "chart": {
    "symbol": null,
    "timeframe": null,
    "date_time": null,
    "source": null,
    "title": null
  },

  "current_price": {
    "price": null,
    "label": null,
    "position_relative_to_levels": []
  },

  "price_levels": [
    {
      "price": null,
      "type": "support|resistance|entry|stop_loss|take_profit|boundary|horizontal_line|unknown",
      "label": null,
      "color": null,
      "confidence": null
    }
  ],

  "support_resistance": [
    {
      "type": "support|resistance|zone|unknown",
      "top": null,
      "bottom": null,
      "price": null,
      "label": null,
      "color": null,
      "evidence": null,
      "confidence": null
    }
  ],

  "zones": [
    {
      "type": "support|resistance|supply|demand|entry|target|stop_loss|highlight|unknown",
      "top": null,
      "bottom": null,
      "color": null,
      "label": null
    }
  ],

  "arrows": [
    {
      "direction": "up|down|sideways|curved|unknown",
      "movement_type": "projected_upward_movement|projected_downward_movement|historical_movement|unknown",
      "start_price": null,
      "end_price": null,
      "start_date": null,
      "end_date": null,
      "path": null,
      "color": null,
      "label": null,
      "description": null,
      "confidence": null
    }
  ],

  "price_movements": [
    {
      "direction": "up|down|sideways|mixed",
      "start_price": null,
      "end_price": null,
      "start_date": null,
      "end_date": null,
      "description": null,
      "confidence": null
    }
  ],

  "market_structure": [
    {
      "type": "higher_high|higher_low|lower_high|lower_low|trend|range|consolidation|pullback|rejection|breakout|unknown",
      "description": null,
      "price_range": {
        "top": null,
        "bottom": null
      },
      "confidence": null
    }
  ],

  "position": {
    "direction": null,
    "entry": null,
    "stop_loss": null,
    "take_profit": null,
    "risk_reward": null
  },

  "candles": [],

  "horizontal_lines": [
    {
      "price": null,
      "color": null,
      "label": null
    }
  ],
"annotations": [
    {
      "type": "text|circle|arrow|rectangle|icon|trend_line|other",
      "description": null,
      "color": null
    }
  ],

  "time_axis": [],

  "indicators": [],

  "visual_relationships": [],

  "other": []
}

FINAL RULE:
The JSON must represent what is visible in the image, not what you think the trader should do or what the market will do.
"""


# --- adapter ---------------------------------------------------------- #

_LONG_WORDS = {"long", "buy", "bullish", "up", "upward"}
_SHORT_WORDS = {"short", "sell", "bearish", "down", "downward"}


def _num(v: Any) -> float | None:
    """Best-effort float. Tolerates '63,930.5', '0.345 (approx)', None."""
    if v is None or isinstance(v, bool):
        return None
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).strip().replace(",", "")
    if not s:
        return None
    try:
        return float(s)
    except ValueError:
        pass
    # pull the first numeric run out of e.g. "approx 0.3545"
    import re

    m = re.search(r"-?\d+(?:\.\d+)?", s)
    if m:
        try:
            return float(m.group(0))
        except ValueError:
            return None
    return None


def _num_list(vals: Any) -> list[float]:
    if not isinstance(vals, list):
        return []
    out = []
    for v in vals:
        n = _num(v)
        if n is not None:
            out.append(n)
    return out


def _direction_to_trend(direction: Any) -> str:
    d = str(direction or "").strip().lower()
    if not d:
        return ""
    if d in _LONG_WORDS or "long" in d:
        return "uptrend"
    if d in _SHORT_WORDS or "short" in d:
        return "downtrend"
    return ""


def _mid(item: dict) -> float | None:
    """Representative price for a support/resistance AREA.

    Uses the explicit price when given, else the midpoint of the band. A
    midpoint is acceptable for "roughly where is this zone" context, but it is
    a COMPUTED value that is not printed on the chart, so it must never be
    used as a tradeable entry/sl/tp. See ``_edge``.
    """
    p = _num(item.get("price"))
    if p is not None:
        return p
    top, bottom = _num(item.get("top")), _num(item.get("bottom"))
    if top is not None and bottom is not None:
        return (top + bottom) / 2.0
    return top if top is not None else bottom


def _edge(item: dict) -> float | None:
    """A tradeable price for an entry/stop/target ZONE — never a midpoint.

    Only returns a number that is actually displayed on the chart: the
    explicit ``price``, or a single boundary when only one is given. When a
    zone has BOTH bounds there is no way to know which edge the trader meant,
    so this returns None rather than inventing the average.

    Regression this guards: a green target zone spanning 0.3449..0.2898 was
    turned into ``tp=0.31735`` — a price printed nowhere on the chart.
    """
    p = _num(item.get("price"))
    if p is not None:
        return p
    top, bottom = _num(item.get("top")), _num(item.get("bottom"))
    if top is not None and bottom is not None:
        return None  # ambiguous: do not fabricate a level
    return top if top is not None else bottom


def adapt_rich_to_struct(rich: Any) -> dict:
    """Map the rich chart-parser JSON onto the internal vision struct.

    Returns the SAME shape ``_coerce`` produces, plus a ``rich`` key holding the
    original payload. Never fabricates a level; ``has_chart_data`` is derived
    from what was actually extracted, not from what the model asserts.
    """
    # Import here to avoid a circular import at module load.
    from src.sources.vision import EMPTY_STRUCT

    out = json.loads(json.dumps(EMPTY_STRUCT))
    if not isinstance(rich, dict):
        return out

    # --- 1. tradeable levels: the position tool is the strongest signal ---
    pos = rich.get("position") if isinstance(rich.get("position"), dict) else {}
    entry = _num(pos.get("entry"))
    sl = _num(pos.get("stop_loss"))
    tp_val = _num(pos.get("take_profit"))
    tps = [tp_val] if tp_val is not None else []

    # --- 2. fill gaps from explicitly typed price_levels ------------------
    support: list[float] = []
    resistance: list[float] = []
    for lvl in rich.get("price_levels") or []:
        if not isinstance(lvl, dict):
            continue
        price = _num(lvl.get("price"))
        if price is None:
            continue
        t = str(lvl.get("type") or "").strip().lower()
        if t == "entry" and entry is None:
            entry = price
        elif t == "stop_loss" and sl is None:
            sl = price
        elif t == "take_profit":
            if price not in tps:
                tps.append(price)
        elif t == "support":
            support.append(price)
        elif t == "resistance":
            resistance.append(price)

    # --- 3. support/resistance areas and zones ----------------------------
    # A zone is a BAND with two real, displayed boundaries. Emitting its
    # midpoint invents a price that is nowhere on the chart AND is unstable
    # run to run (the same BTC bias chart produced 63542.2, then 63994.75,
    # then 63678.55 across three reads). Emit the real bounds instead.
    for group in ("support_resistance", "zones"):
        for item in rich.get(group) or []:
            if not isinstance(item, dict):
                continue
            t = str(item.get("type") or "").strip().lower()
            if t in ("support", "demand", "resistance", "supply"):
                bucket = support if t in ("support", "demand") else resistance
                explicit = _num(item.get("price"))
                if explicit is not None:
                    bucket.append(explicit)
                    continue
                for key in ("top", "bottom"):
                    edge = _num(item.get(key))
                    if edge is not None:
                        bucket.append(edge)
            elif t in ("entry", "stop_loss", "target"):
                # Tradeable levels must be a price actually shown on the
                # chart, never a computed midpoint of a band.
                edge = _edge(item)
                if edge is None:
                    continue
                if t == "entry" and entry is None:
                    entry = edge
                elif t == "stop_loss" and sl is None:
                    sl = edge
                elif t == "target" and edge not in tps:
                    tps.append(edge)

    # --- 4. direction -> trend (orchestrator derives side from this) ------
    trend = _direction_to_trend(pos.get("direction"))
    if not trend:
        # market_structure may state a plain "trend" with a description
        for ms in rich.get("market_structure") or []:
            if not isinstance(ms, dict):
                continue
            blob = f"{ms.get('type') or ''} {ms.get('description') or ''}".lower()
            if "uptrend" in blob or "higher_high" in blob or "higher high" in blob:
                trend = "uptrend"
                break
            if "downtrend" in blob or "lower_low" in blob or "lower low" in blob:
                trend = "downtrend"
                break
            if "range" in blob or "consolidation" in blob:
                trend = "range"
                break

    # NOTE: arrows are deliberately NOT used to set trend. The prompt is
    # explicit that an arrow is an annotation, not a prediction; letting a
    # drawn arrow pick the trade side would turn someone's doodle into a
    # market order.

    out["levels"]["entry"] = entry
    out["levels"]["sl"] = sl
    out["levels"]["tp"] = tps
    out["levels"]["support"] = sorted(set(support))
    out["levels"]["resistance"] = sorted(set(resistance))
    out["trend"] = trend

    # setup_type: only the objectively-readable ones map across.
    for ms in rich.get("market_structure") or []:
        if isinstance(ms, dict):
            t = str(ms.get("type") or "").strip().lower()
            if t in ("breakout", "pullback", "rejection"):
                out["setup_type"] = "fakeout" if t == "rejection" else t
                break

    out["arrows"] = rich.get("arrows") if isinstance(rich.get("arrows"), list) else []
    out["wave"] = (
        rich.get("price_movements")
        if isinstance(rich.get("price_movements"), list)
        else []
    )

    # --- 5. has_chart_data: derived, never trusted ------------------------
    # True only when something actually tradeable or level-like was read.
    has_data = any(
        [
            entry is not None,
            sl is not None,
            bool(tps),
            bool(support),
            bool(resistance),
        ]
    )
    out["has_chart_data"] = has_data

    # Preserve the full rich payload for logging / later evaluation.
    out["rich"] = rich
    return out
