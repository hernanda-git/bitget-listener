"""Attachment fetcher — download Telegram chart images for vision extraction.

Read-only by design: downloads media and disconnects immediately so the
live bot's monitoring is never disrupted. Images are saved as jpg.

See docs/PLAN_attachment_bias.md deliverable #2.
"""

from __future__ import annotations

import logging
from pathlib import Path

log = logging.getLogger(__name__)

DEFAULT_MEDIA_DIR = Path("/data/attachments")


class AttachmentFetcher:
    """Downloads chart image attachments to local disk."""

    def __init__(self, media_dir: str | Path | None = None):
        self.media_dir = Path(media_dir) if media_dir else DEFAULT_MEDIA_DIR
        self.media_dir.mkdir(parents=True, exist_ok=True)

    def path_for(self, channel: str, message_id: int, suffix: str = ".jpg") -> Path:
        safe = "".join(c for c in (channel or "chan") if c.isalnum() or c in "-_")
        return self.media_dir / f"{safe}_{message_id}{suffix}"

    async def download(self, client, message, channel: str = "") -> tuple[str, str]:
        """Download a message's image media.

        Returns ``(local_path, media_type)``. ``local_path`` is "" when the
        message carries no media.
        """
        if not getattr(message, "media", None):
            return "", ""

        media_type = "photo"
        dest = self.path_for(channel, int(message.id), ".jpg")

        try:
            await client.download_media(message, file=str(dest))
        except Exception as e:  # noqa: BLE001 — never crash the pipeline on media
            log.warning("Attachment download failed for msg %s: %s", message.id, e)
            return "", media_type

        return str(dest), media_type
