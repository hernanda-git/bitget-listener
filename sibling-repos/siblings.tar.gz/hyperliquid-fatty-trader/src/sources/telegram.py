"""Telegram signal source for Hyperliquid Trader.

Consumes messages from a Telegram channel and emits RawSignal objects.
Read-only by design: only listens, never sends.
"""

from __future__ import annotations

import logging
import os
from pathlib import Path

from dotenv import load_dotenv
from telethon import TelegramClient, events
from telethon.sessions import StringSession

from src.domain.model import RawSignal, Side
from src.sources.parser import parse_signal, parse_management, extract_token
from src.sources.attachment_fetcher import AttachmentFetcher

log = logging.getLogger(__name__)


class TelegramSignalSource:
    """Telegram listener that produces RawSignal from channel posts."""

    def __init__(self, queue: "asyncio.Queue[RawSignal]", config: dict | None = None):
        self.queue = queue
        self.config = config or {}
        self.fetcher = AttachmentFetcher()  # downloads media for vision path

        load_dotenv(Path(__file__).resolve().parents[2] / ".env")
        api_id = int(os.getenv("TG_API_ID", "0"))
        api_hash = os.getenv("TG_API_HASH", "")
        channel = os.getenv("CHANNEL_USERNAME", "fattyfatclub")

        self.channel = channel
        session_str = os.getenv("SESSION_STRING", "")
        if session_str:
            session = StringSession(session_str)
        else:
            session = str(Path(__file__).resolve().parents[2] / "session")

        self.client = TelegramClient(session, api_id, api_hash)

    async def start(self) -> None:
        await self.client.connect()
        if not await self.client.is_user_authorized():
            raise RuntimeError("Telethon session not authorized. Set SESSION_STRING.")

        me = await self.client.get_me()
        log.info("Connected as %s (%s)", me.first_name, me.id)

        try:
            entity = await self.client.get_entity(self.channel)
            log.info("Channel found: %s (%s)", getattr(entity, "title", self.channel), entity.id)
        except Exception as e:
            log.error("Cannot access @%s: %s", self.channel, e)
            return

        @self.client.on(events.NewMessage(chats=self.channel))
        async def on_new_message(event):
            msg = event.message
            text = msg.text or msg.message or ""

            # Management message? Route to the queue tagged for the PositionManager.
            mgmt = parse_management(text)
            if mgmt:
                raw = RawSignal(
                    message_id=msg.id,
                    channel=self.channel,
                    raw_text=text,
                    has_media=msg.media is not None,
                    raw={"management": mgmt},
                )
                self._enqueue(raw)
                return

            # Trade-call message? Parse into a RawSignal (USDT prices).
            sig = parse_signal(text)
            if sig is not None:
                sig.message_id = msg.id
                sig.channel = self.channel
                sig.has_media = msg.media is not None
                self._enqueue(sig)
                return

            # Otherwise: ambiguous / chart-only / noise -> pass raw (vision path).
            # For media posts, download the image and pull the caption token so
            # the orchestrator can resolve it to a venue ticker for vision parsing.
            has_media = msg.media is not None
            image_path = ""
            caption_token = ""
            if has_media:
                try:
                    path, _ = await self.fetcher.download(self.client, msg, self.channel)
                    image_path = path
                except Exception as e:  # never crash the listener on media
                    log.warning("Media download failed for msg %s: %s", msg.id, e)
                caption_token = (extract_token(text) or "").upper()
            raw = RawSignal(
                message_id=msg.id,
                channel=self.channel,
                raw_text=text,
                has_media=has_media,
                image_path=image_path,
                symbol_usdt=caption_token,  # resolved later if vision trades it
                raw={"text": text},
            )
            self._enqueue(raw)

        log.info("Listening on @%s ...", self.channel)
        await self.client.run_until_disconnected()

    def _enqueue(self, raw: RawSignal) -> None:
        try:
            self.queue.put_nowait(raw)
        except asyncio.QueueFull:
            log.warning("Signal queue full, dropping message %s", raw.message_id)

    async def stop(self) -> None:
        await self.client.disconnect()
