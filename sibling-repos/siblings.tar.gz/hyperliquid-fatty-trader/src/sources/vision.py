"""Vision extraction — turn a chart image into structured levels/trend/setup.

Supports two backends (selected by config / env):

* ``gemini``   — Google Gemini free-tier ``generateContent`` REST API.
                 Free API key from https://aistudio.google.com/apikey -> set
                 ``GEMINI_API_KEY`` in .env. No card required.
* ``openai``   — OpenAI-compatible chat/completions endpoint (e.g. gitlawb).
                 Configured via the legacy ``GITLAWB_API_KEY`` / api_url.

The chart prompt asks for strict JSON (entry/sl/tp/support/resistance/trend),
and ``parse_vision_response`` is tolerant of prose-wrapped JSON. Vision is
optional: if no key is configured the extractor logs and returns empty so the
orchestrator surfaces the signal as ``vision_pending`` rather than crashing.
"""

from __future__ import annotations

import base64
import json
import logging
import os
from pathlib import Path

import httpx

from src.sources.chart_prompt import RICH_CHART_PROMPT

# Make VISION_BACKEND / keys available even when the caller didn't load .env
# (e.g. direct unit tests or scripts). Idempotent; safe to call repeatedly.
try:
    from dotenv import load_dotenv
    load_dotenv(Path(__file__).resolve().parents[2] / ".env")
except Exception:  # pragma: no cover
    pass

log = logging.getLogger(__name__)

VISION_PROMPT = """You are reading a crypto trading chart screenshot.

Return ONLY a JSON object, no prose, with exactly this shape:
{
  "levels": {"entry": null, "sl": null, "tp": [], "support": [], "resistance": []},
  "trend": "",
  "setup_type": "",
  "wave": [],
  "arrows": [],
  "bias": {"primary": "", "secondary": "", "horizon": ""},
  "has_chart_data": true
}

Rules:
- levels.support / levels.resistance: every horizontal line drawn on the chart,
  as exact numeric prices. Support = below current price, resistance = above.
- levels.entry / sl / tp: only if the chart explicitly labels them.
- trend: one of uptrend, downtrend, range, chop, up, down.
- setup_type: one of pullback, breakout, reversal, fakeout, pnl_card.
- wave: the drawn projected trajectory as ordered waypoints,
  [{"idx":0,"price":123.4,"label":"swing_low"}, ...].
  Labels: swing_low, swing_high, current, projected_target.
- arrows: [{"at":{"idx":1,"price":123.4},"dir":"right","meaning":"continuation"}].
  meaning is one of entry_trigger, target, continuation, reversal_pending.
- bias.primary: BULLISH, BEARISH, NEUTRAL, RANGE, or NO_CHASE. Only fill this
  in for market-bias/BTC posts; leave "" for ordinary trade setups.
- has_chart_data: false if this is a meme, a screenshot with no price levels,
  or a PnL card rather than a chart.
"""

EMPTY_STRUCT: dict = {
    "levels": {"entry": None, "sl": None, "tp": [], "support": [], "resistance": []},
    "trend": "",
    "setup_type": "",
    "wave": [],
    "arrows": [],
    "bias": {"primary": "", "secondary": "", "horizon": ""},
    "has_chart_data": False,
}

_JSON_BLOCK_RE = None
try:
    import re as _re
    _JSON_BLOCK_RE = _re.compile(r"\{.*\}", _re.S)
except Exception:
    pass


def _coerce(struct) -> dict:
    if not isinstance(struct, dict):
        return json.loads(json.dumps(EMPTY_STRUCT))

    out = json.loads(json.dumps(EMPTY_STRUCT))
    levels = struct.get("levels") or {}
    if isinstance(levels, dict):
        for key in ("entry", "sl"):
            try:
                out["levels"][key] = float(levels[key]) if levels.get(key) is not None else None
            except (TypeError, ValueError):
                out["levels"][key] = None
        for key in ("tp", "support", "resistance"):
            vals = levels.get(key) or []
            nums = []
            for v in vals if isinstance(vals, list) else []:
                try:
                    nums.append(float(v))
                except (TypeError, ValueError):
                    continue
            out["levels"][key] = nums

    out["trend"] = str(struct.get("trend") or "")
    out["setup_type"] = str(struct.get("setup_type") or "")
    out["wave"] = struct.get("wave") if isinstance(struct.get("wave"), list) else []
    out["arrows"] = struct.get("arrows") if isinstance(struct.get("arrows"), list) else []

    bias = struct.get("bias") or {}
    if isinstance(bias, dict):
        out["bias"] = {
            "primary": str(bias.get("primary") or "").upper(),
            "secondary": str(bias.get("secondary") or ""),
            "horizon": str(bias.get("horizon") or ""),
        }

    # has_chart_data: trust an explicit False, but never let a missing/True
    # flag assert "there is a chart here" when not a single level survived
    # coercion. That combination passes the orchestrator's gate
    # (orchestrator.py:382) carrying nothing tradeable — e.g. when a model
    # answers in a schema this coercion does not understand.
    any_level = (
        out["levels"]["entry"] is not None
        or out["levels"]["sl"] is not None
        or bool(out["levels"]["tp"])
        or bool(out["levels"]["support"])
        or bool(out["levels"]["resistance"])
    )
    claimed = struct.get("has_chart_data", None)
    if claimed is None:
        out["has_chart_data"] = any_level
    else:
        out["has_chart_data"] = bool(claimed)
    return out


def parse_vision_response(raw: str, rich: bool = False) -> dict:
    """Parse a model's chart JSON into the internal struct.

    ``rich=True`` means the response follows RICH_CHART_PROMPT's schema and is
    routed through ``adapt_rich_to_struct``; otherwise the legacy
    ``VISION_PROMPT`` shape is coerced directly.
    """
    if not raw:
        return _coerce(None)

    def _finish(obj):
        if rich:
            from src.sources.chart_prompt import adapt_rich_to_struct

            return adapt_rich_to_struct(obj)
        return _coerce(obj)

    try:
        return _finish(json.loads(raw))
    except (ValueError, TypeError):
        pass
    if _JSON_BLOCK_RE:
        match = _JSON_BLOCK_RE.search(raw)
        if match:
            try:
                return _finish(json.loads(match.group(0)))
            except (ValueError, TypeError):
                pass
    log.warning("Vision response was not parseable JSON")
    return _coerce(None)


class VisionExtractor:
    """Calls a vision-capable LLM endpoint and returns structured chart data."""

    def __init__(self, config: dict | None = None):
        self.config = config or {}
        cfg = ((config or {}).get("agent") or {}).get("vision") or {}
        # Backend: "gemini" (free tier) or "openai" (OpenAI-compatible).
        self.backend = (cfg.get("backend") or os.environ.get("VISION_BACKEND", "gemini")).lower()

        if self.backend == "local":
            # Offline OpenCV + Tesseract chart reader. No API key, no network.
            self.api_key = ""  # local backend needs no key
            self.model = "local-cv"
            self.api_url = ""
        elif self.backend == "gemini":
            self.api_key = cfg.get("api_key") or os.environ.get("GEMINI_API_KEY", "")
            self.model = cfg.get("model", "gemini-2.5-flash")
            self.api_url = (
                "https://generativelanguage.googleapis.com/v1beta/"
                f"models/{self.model}:generateContent"
            )
        elif self.backend == "openai":
            # Any OpenAI-compatible vision endpoint. Defaults to real OpenAI,
            # but VISION_API_URL / VISION_MODEL / VISION_API_KEY let it point
            # at another provider (e.g. the opencode zen gateway) without
            # touching code.
            self.api_key = (
                cfg.get("api_key")
                or os.environ.get("VISION_API_KEY", "")
                or os.environ.get("OPENAI_API_KEY", "")
            )
            self.model = cfg.get("model") or os.environ.get("VISION_MODEL", "gpt-4o-mini")
            self.api_url = (
                cfg.get("api_url")
                or os.environ.get("VISION_API_URL", "")
                or "https://api.openai.com/v1/chat/completions"
            )
        else:  # generic OpenAI-compatible (e.g. gitlawb) via custom url/env
            self.api_key = cfg.get("api_key") or os.environ.get(
                cfg.get("api_key_env", "GITLAWB_API_KEY"), ""
            )
            self.model = cfg.get("model", "google/gemini-3.1-flash-lite")
            self.api_url = cfg.get(
                "api_url", "https://opengateway.gitlawb.com/v1/chat/completions"
            )

        self.timeout = int(
            cfg.get("timeout")
            or os.environ.get("VISION_TIMEOUT")
            or 180
        )
        # Output cap. RICH_CHART_PROMPT emits a large JSON object; too small a
        # cap truncates it and loses the entire read. 8000 covers the full
        # schema comfortably (a complete BTC bias read was ~4900 tokens).
        self.max_tokens = int(
            cfg.get("max_tokens")
            or os.environ.get("VISION_MAX_TOKENS")
            or 8000
        )
        # Transient read-timeout retries (MiMo-free can exceed 60s on a chart).
        self.retries = int(
            cfg.get("retries") or os.environ.get("VISION_RETRIES") or 2
        )
        # Use the stricter observation-only RICH_CHART_PROMPT (+ adapter)
        # instead of the legacy VISION_PROMPT. Off by default: the legacy
        # prompt is what the current live config is validated against.
        self.rich_prompt = str(
            cfg.get("rich_prompt")
            or os.environ.get("VISION_RICH_PROMPT", "")
        ).strip().lower() in ("1", "true", "yes", "on")

    @staticmethod
    def encode_image(path: str | Path) -> str:
        return base64.b64encode(Path(path).read_bytes()).decode("ascii")

    async def extract(self, image_path: str | Path, caption: str = "") -> dict:
        """Read a chart image and return the structured chart data dict."""
        path = Path(image_path)
        if not path.exists():
            log.warning("Vision: image missing at %s", path)
            return _coerce(None)
        if self.backend == "local":
            # Lazy import: keep cv2/pytesseract optional for installs that only
            # use the remote backends.
            try:
                from src.sources.local_vision import LocalVisionExtractor
            except Exception as e:  # noqa: BLE001
                log.warning("Local vision backend unavailable: %s", e)
                return _coerce(None)
            return await LocalVisionExtractor((self.config or {}).get("agent", {})).extract(path, caption)
        if not self.api_key:
            log.warning("Vision: no API key configured (%s backend), skipping", self.backend)
            return _coerce(None)

        prompt = RICH_CHART_PROMPT if self.rich_prompt else VISION_PROMPT
        if caption:
            prompt += f"\n\nThe post's caption was: {caption!r}"

        try:
            if self.backend == "gemini":
                raw = await self._extract_gemini(prompt, path)
            else:
                raw = await self._extract_openai(prompt, path)
        except Exception as e:  # noqa: BLE001 — vision must never crash the pipeline
            log.warning("Vision extraction failed for %s: %s", path, e)
            return _coerce(None)

        return parse_vision_response(raw, rich=self.rich_prompt)

    async def _extract_gemini(self, prompt: str, path: Path) -> str:
        payload = {
            "contents": [{
                "parts": [
                    {"text": prompt},
                    {"inline_data": {
                        "mime_type": "image/jpeg",
                        "data": self.encode_image(path),
                    }},
                ],
            }],
            "generationConfig": {"temperature": 0, "responseMimeType": "application/json"},
        }
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            resp = await client.post(
                f"{self.api_url}?key={self.api_key}",
                json=payload,
            )
            resp.raise_for_status()
            data = resp.json()
        # Gemini nests text in candidates[].content.parts[].text
        parts = (
            data.get("candidates", [{}])[0]
            .get("content", {})
            .get("parts", [])
        )
        return "".join(p.get("text", "") for p in parts)

    async def _extract_openai(self, prompt: str, path: Path) -> str:
        payload = {
            "model": self.model,
            "messages": [{
                "role": "user",
                "content": [
                    {"type": "text", "text": prompt},
                    {"type": "image_url", "image_url": {
                        "url": f"data:image/jpeg;base64,{self.encode_image(path)}",
                    }},
                ],
            }],
            "temperature": 0,
            # RICH_CHART_PROMPT's schema is large; without an explicit cap the
            # provider's default cuts the JSON off mid-object and the whole
            # read is lost (`finish_reason: "length"` -> unparseable -> empty
            # struct, which is indistinguishable from "no levels found").
            "max_tokens": self.max_tokens,
        }
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            last_exc: Exception | None = None
            for attempt in range(self.retries + 1):
                try:
                    resp = await client.post(
                        self.api_url,
                        headers={"Authorization": f"Bearer {self.api_key}"},
                        json=payload,
                    )
                    resp.raise_for_status()
                    data = resp.json()
                    choice = (data.get("choices") or [{}])[0]
                    if choice.get("finish_reason") == "length":
                        log.warning(
                            "Vision response TRUNCATED (finish_reason=length, "
                            "max_tokens=%s) — raise VISION_MAX_TOKENS",
                            self.max_tokens,
                        )
                    return choice.get("message", {}).get("content", "")
                except httpx.ReadTimeout as exc:
                    # MiMo-free can take >60s to encode a chart + emit the
                    # full schema. A read timeout is transient: retry rather
                    # than silently fall back to "no chart data".
                    last_exc = exc
                    if attempt < self.retries:
                        log.warning(
                            "Vision read timed out (attempt %s/%s), retrying",
                            attempt + 1, self.retries + 1,
                        )
                        continue
                    raise
            raise last_exc  # unreachable but keeps mypy happy
