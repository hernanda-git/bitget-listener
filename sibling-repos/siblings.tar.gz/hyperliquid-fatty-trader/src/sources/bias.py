"""Bias analysis recorder for @fattyfatclub market-bias calls.

Sometimes the signal source posts a *market bias* ("BTC bias: BULLISH",
"$ETH bias bearish", "market bias neutral", etc.) rather than a concrete
trade. These are analyst reads on direction, not executable signals. We
record them to the **PostgreSQL `fatty_config` database** (same externally
reachable DB as the bot config, no SQLite, no local files) so the history can
be reviewed later (e.g. via the Telegram /bias command) and the bot can learn
the analyst's directional lean over time.

Pure storage + lightweight parsing. No network. Safe to call from the
orchestrator on every incoming message; if the message isn't a bias call it
returns None and nothing is stored.
"""

from __future__ import annotations

import os
import re
from dataclasses import dataclass

# Directional keywords -> normalized bias.
_BIAS_MAP = {
    "bullish": "BULLISH", "bull": "BULLISH", "long bias": "BULLISH",
    "bearish": "BEARISH", "bear": "BEARISH", "short bias": "BEARISH",
    "neutral": "NEUTRAL", "range": "NEUTRAL", "sideways": "NEUTRAL",
}
_BIAS_RE = re.compile(
    r"\b(bullish|bull|bearish|bear|neutral|range|sideways)\b", re.IGNORECASE
)
# A bias call mentions "bias" OR is clearly a directional market read.
_BIAS_TRIGGER_RE = re.compile(r"\bbias\b", re.IGNORECASE)

# Token mention ($BTC, #ETH, BTC, ETH) to attach a target symbol.
_TOKEN_RE = re.compile(r"[#$]?([A-Za-z]{2,6})\b")


@dataclass
class BiasRecord:
    ts: float
    bias: str            # BULLISH | BEARISH | NEUTRAL
    target: str          # e.g. "BTC", "" if none stated
    text: str            # original message text
    message_id: int | None = None
    channel: str = ""
    # --- chart-derived fields (populated when a bias call carries a chart) ---
    arrow: str | None = None      # BULLISH | BEARISH | None (from drawn arrow)
    levels_json: str | None = None  # JSON of parsed support/resistance bounds
    source: str = "text"          # "text" | "chart" (chart-only bias w/ arrow)


def parse_bias(text: str) -> BiasRecord | None:
    """Detect a market-bias call in a message. Returns a BiasRecord or None."""
    if not text:
        return None
    low = text.lower()

    # Must look like a bias read: contain "bias" or a directional word AND a
    # market framing. We accept either the word "bias", or a directional word
    # paired with a token (so "BTC pump" doesn't count, but "BTC bias bearish"
    # or "$ETH bearish" does).
    m = _BIAS_RE.search(low)
    if not m:
        return None
    bias = _BIAS_MAP[m.group(1).lower()]

    # A bias call MUST contain the literal word "bias" (e.g. "BTC bias: BULLISH",
    # "Market bias neutral", "$ETH bias bearish"). This avoids false positives on
    # ordinary chart captions like "$BTC range identified" or trade chatter that
    # merely contains a directional word + token — those must still flow through
    # to the trade / vision pipeline, not be swallowed as a bias record.
    if not _BIAS_TRIGGER_RE.search(low):
        return None

    tokens = [t.upper() for t in _TOKEN_RE.findall(text)]
    # Filter to plausible coin-ish tokens (skip common english words).
    coins = [t for t in tokens if t not in {
        "THE", "AND", "FOR", "BUT", "NOW", "OUR", "OUT", "ALL", "BIA", "THIS",
        "THAT", "WITH", "FROM", "HAS", "ARE", "WAS", "CAN", "GET",
    }]
    target = ""
    if coins:
        # Prefer BTC/ETH if present (they are the usual bias subjects),
        # else the first coin mentioned.
        for pref in ("BTC", "ETH", "SOL"):
            if pref in coins:
                target = pref
                break
        if not target:
            target = coins[0]

    return BiasRecord(
        ts=0.0,  # filled by caller (we don't import time here to stay pure)
        bias=bias, target=target, text=text.strip(),
    )


class BiasRecorder:
    """Append-only PostgreSQL store for bias calls (table bias_log in fatty_config)."""

    SCHEMA = """
    CREATE TABLE IF NOT EXISTS bias_log (
        id         BIGSERIAL PRIMARY KEY,
        ts         DOUBLE PRECISION NOT NULL,
        iso        TEXT NOT NULL,
        bias       TEXT NOT NULL,
        target     TEXT NOT NULL DEFAULT '',
        message_id BIGINT,
        channel    TEXT NOT NULL DEFAULT '',
        text       TEXT NOT NULL,
        arrow      TEXT,
        levels_json TEXT,
        src        TEXT NOT NULL DEFAULT 'text'
    );
    CREATE INDEX IF NOT EXISTS idx_bias_ts ON bias_log(ts);
    CREATE INDEX IF NOT EXISTS idx_bias_target ON bias_log(target);
    """

    def __init__(self, db_url: str | None = None):
        # Same database (and app role) as the bot config + ledger. No local files.
        if db_url is None:
            from dotenv import load_dotenv
            load_dotenv()
            # Tests set CONFIG_DB_TEST_URL to a throwaway DB; production uses CONFIG_DB_URL.
            db_url = os.getenv("CONFIG_DB_TEST_URL") or os.getenv(
                "CONFIG_DB_URL",
                "postgresql://app:app@127.0.0.1:5432/fatty_config",
            )
        self.db_url = db_url
        self._ensure_schema()

    def _ensure_schema(self) -> None:
        import psycopg
        conn = psycopg.connect(self.db_url)
        try:
            # CREATE TABLE IF NOT EXISTS handles a fresh DB. Existing tables
            # (prod or the test DB) need an idempotent ALTER to gain the new
            # chart-derived columns without dropping history.
            conn.execute(self.SCHEMA)
            for col, typ in (("arrow", "TEXT"), ("levels_json", "TEXT"),
                             ("src", "TEXT NOT NULL DEFAULT 'text'")):
                conn.execute(
                    f"ALTER TABLE bias_log ADD COLUMN IF NOT EXISTS {col} {typ}"
                )
            conn.commit()
        finally:
            conn.close()

    def _conn(self):
        import psycopg
        # Fresh connection per operation (safe under asyncio, same rule as the
        # config store / ledger). Schema is guaranteed by __init__.
        return psycopg.connect(self.db_url)

    def record(self, rec: BiasRecord, message_id: int | None = None,
               channel: str = "") -> int:
        import datetime
        ts = rec.ts or datetime.datetime.now(datetime.timezone.utc).timestamp()
        iso = datetime.datetime.fromtimestamp(ts, datetime.timezone.utc).isoformat()
        conn = self._conn()
        try:
            cur = conn.execute(
                "INSERT INTO bias_log "
                "(ts, iso, bias, target, message_id, channel, text, arrow, levels_json, src) "
                "VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s) RETURNING id",
                (ts, iso, rec.bias, rec.target, message_id or rec.message_id,
                 channel or rec.channel, rec.text, rec.arrow,
                 rec.levels_json, rec.source),
            )
            row = cur.fetchone()
            conn.commit()
            return row[0] if row else 0
        finally:
            conn.close()

    def recent(self, limit: int = 20, target: str = "") -> list[dict]:
        """Return the most recent bias records (optionally filtered by target)."""
        conn = self._conn()
        try:
            if target:
                rows = conn.execute(
                    "SELECT iso, bias, target, text, arrow, levels_json, src "
                    "FROM bias_log WHERE target=%s ORDER BY ts DESC LIMIT %s",
                    (target.upper(), limit),
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT iso, bias, target, text, arrow, levels_json, src "
                    "FROM bias_log ORDER BY ts DESC LIMIT %s", (limit,),
                ).fetchall()
        finally:
            conn.close()
        return [
            {"iso": r[0], "bias": r[1], "target": r[2], "text": r[3],
             "arrow": r[4], "levels_json": r[5], "source": r[6]}
            for r in rows
        ]

    def summary(self) -> dict:
        """Aggregate counts per bias direction (all-time)."""
        conn = self._conn()
        try:
            rows = conn.execute(
                "SELECT bias, COUNT(*) FROM bias_log GROUP BY bias"
            ).fetchall()
        finally:
            conn.close()
        out = {"BULLISH": 0, "BEARISH": 0, "NEUTRAL": 0, "total": 0}
        for bias, n in rows:
            out[bias] = n
            out["total"] += n
        return out

    def close(self) -> None:
        # Per-operation connections are closed immediately; nothing persistent to
        # tear down. Kept for API compatibility with callers that call .close().
        pass
