"""Symbol resolver: map a signal source token ($BONK, PUMP, ...) to the
Hyperliquid perp ticker actually listed on the venue.

Hyperliquid lists some tokens under a small-unit name:
  * ``k``-prefixed (e.g. ``kBONK`` for BONK, ``kSHIB`` for SHIB) — used on both
    testnet and mainnet.
  * ``1000``-prefixed (e.g. ``1000PEPE``) — the mainnet-style small-unit name.
Neither is a leverage tier. There is no "1000x" contract on Hyperliquid; max
leverage is capped per-asset (observed 3x..50x on testnet, up to 40x mainnet).
The resolver checks exact -> k-prefix -> 1000-prefix and returns the first hit.

The resolver caches the venue universe (fetched read-only from the public
``metaAndAssetCtxs`` endpoint) and maps a source token to the best available
ticker. If the token is not listed on the venue, resolution returns None and the
signal is skipped (not executed).

Pure-ish: network only on first fetch (and only the public info endpoint, no key,
no order, no funds). A static symbol set can be injected for tests/offline use.
"""

from __future__ import annotations

import asyncio
import re

import httpx

# Public info endpoint (no auth, no key). testnet by default for safety.
_TESTNET_INFO = "https://api.hyperliquid-testnet.xyz/info"
_MAINNET_INFO = "https://api.hyperliquid.xyz/info"

# Cache across instances (the universe changes rarely).
_CACHE: dict[str, dict[str, int]] = {}  # base_url -> {name: max_leverage}


def _normalize_token(tok: str) -> str:
    """Strip $/#/USDT/USDC decoration -> bare base, upper-cased."""
    t = tok.strip().lstrip("$#").upper()
    for suf in ("USDT", "USDC"):
        if t.endswith(suf) and len(t) > len(suf):
            t = t[: -len(suf)]
    return t


async def fetch_universe(testnet: bool = True, force: bool = False) -> dict[str, int]:
    """Fetch {name: max_leverage} for the venue. Read-only, no auth."""
    base = _TESTNET_INFO if testnet else _MAINNET_INFO
    if not force and base in _CACHE:
        return _CACHE[base]
    async with httpx.AsyncClient(timeout=20) as c:
        r = await c.post(base, json={"type": "metaAndAssetCtxs"})
        r.raise_for_status()
        data = r.json()
    uni = {m["name"]: int(m.get("maxLeverage", 0)) for m in data[0]["universe"]}
    _CACHE[base] = uni
    return uni


class SymbolResolver:
    """Resolve source tokens to venue tickers, with universe caching."""

    def __init__(self, testnet: bool = True, universe: dict[str, int] | None = None):
        self.testnet = testnet
        self._static = universe  # injected for tests / offline

    async def _universe(self) -> dict[str, int]:
        if self._static is not None:
            return self._static
        return await fetch_universe(testnet=self.testnet)

    async def resolve(self, token: str) -> str | None:
        """Return the venue ticker for a source token, or None if unlisted.

        Handles the two small-unit naming styles Hyperliquid actually uses:
          * ``k``-prefixed (testnet + mainnet, e.g. BONK -> kBONK)
          * ``1000``-prefixed (mainnet-style, e.g. PEPE -> 1000PEPE) when present
        Neither is a leverage tier — there are no "1000x" contracts on HL.
        """
        base = _normalize_token(token)
        if not base:
            return None
        uni = await self._universe()
        # 1) exact match (PUMP -> PUMP, BTC -> BTC)
        if base in uni:
            return base
        # 2) k-prefixed small-unit variant (BONK -> kBONK)
        if f"k{base}" in uni:
            return f"k{base}"
        # 3) 1000-prefixed small-unit variant (PEPE -> 1000PEPE) if HL lists it
        if f"1000{base}" in uni:
            return f"1000{base}"
        return None

    async def max_leverage_for(self, ticker: str | None) -> int | None:
        if not ticker:
            return None
        uni = await self._universe()
        return uni.get(ticker)
