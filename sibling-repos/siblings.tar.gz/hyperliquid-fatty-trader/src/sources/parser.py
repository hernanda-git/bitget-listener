"""Free-text signal parser for @fattyfatclub trade calls.

Pure, no IO. Handles the REAL channel format (observed over 100 live messages):

    #PUMP $PUMP LONG TRADE
    ENTRY: 0.002304
    TARGET: 0.0025
    STOPLOSS: 0.002235

and the multi-target variant:

    #AAVE $AAVE LONG TRADE
    ENTRY: 100.75
    TARGETS: 110.7 - 117.2
    STOPLOSS: 98.25

The token is taken from the ``$XXX`` (or ``#XXX``) mention; leverage is almost
never stated, so a configurable default is applied by the caller (the parser
leaves ``leverage`` at 0 and the orchestrator fills the default). Symbols are
NOT venue-resolved here — that happens via ``SymbolResolver`` in the
orchestrator, because it needs the live perp universe.

Backward-compatible with the old single-line Bybit-style format:
    BTCUSDT LONG entry 60000 sl 58000 tp 64000 lev 10

Management messages (``sl to entry``, ``sl be``, ``tp1 here``, ``close here``,
and the channel's looser chatter) are handled by ``parse_management``.
"""

from __future__ import annotations

import re

from src.domain.model import RawSignal, Side
from src.sources.symbol_map import _normalize_token

# Channel nickname -> canonical base. Some posts use a Binance-style pair
# (e.g. 'BOMEUSDT') or a typo'd ticker ('BOMSE') for the same coin; collapse
# them to one key so positions + resolutions line up.
_TOKEN_ALIASES = {
    "BOMSE": "BOME",
    "BOMSEUSDT": "BOME",
    "BOMEUSDT": "BOME",
    "BOME": "BOME",
}

# Old format: a "BASEUSDT" pair on one line.
_PAIR_RE = re.compile(r"\b([A-Za-z0-9]{2,20}USDT)\b", re.IGNORECASE)
# New format: a $TOKEN or #TOKEN mention (token only, no USDT suffix).
_TOKEN_RE = re.compile(r"[#$]([A-Za-z0-9]{2,20})\b")
# ENTRY: rigid "entry: 0.345" plus the channel's loose prose forms
# ("shorted here at 0.345", "entry around 0.345", "long from 0.345").
_ENTRY_RE = re.compile(
    r"\b(?:entry|entered|enter|here\s+at|in\s+at|from|around|@)"
    r"[\s:]*(?:at[\s:]*)?([0-9]+(?:[.,][0-9]+)?)",
    re.IGNORECASE,
)
# STOPLOSS: rigid "stoploss: 0.3545" plus "stoploss above/below 0.3545".
_SL_RE = re.compile(
    r"\b(?:stop[\s_-]?loss|sl)[\s:]*(?:is[\s:]*)?(?:above|below|over|under|at|to)?"
    r"[\s:]*([0-9]+(?:[.,][0-9]+)?)",
    re.IGNORECASE,
)
# TARGET / TARGETS: accept "0.0025" or "110.7 - 117.2" or bare "tp 64000"
_TP_RE = re.compile(
    r"\b(?:targets?|tp)[\s:]*([0-9]+(?:[.,][0-9]+)?(?:\s*-\s*[0-9]+(?:[.,][0-9]+)?)?)",
    re.IGNORECASE,
)
_LEV_RE = re.compile(r"\b(?:lev|leverage)[\s:]*([0-9]+)", re.IGNORECASE)
_LONG_RE = re.compile(r"\b(?:long|longed|longing|buying|bought)\b", re.IGNORECASE)
_SHORT_RE = re.compile(r"\b(?:short|shorted|shorting|sold)\b", re.IGNORECASE)


def _num(s: str) -> float:
    return float(s.replace(",", ""))


def _find(text: str, rx: re.Pattern) -> float | None:
    m = rx.search(text)
    return _num(m.group(1)) if m else None


def _find_all_tps(text: str) -> list[float]:
    m = _TP_RE.search(text)
    if not m:
        return []
    raw = m.group(1).replace(",", "")
    parts = re.split(r"\s*-\s*", raw)
    return [_num(p) for p in parts if p.strip()]


def _symbol_token(text: str) -> str | None:
    """Extract the trade token (e.g. 'PUMP') from a $/# mention, if present.
    Falls back to a Binance-style BASEUSDT pair (e.g. 'BOMEUSDT' -> 'BOME'),
    then collapses nicknames/typos to a canonical base (e.g. 'BOMSE' -> 'BOME')."""
    m = _TOKEN_RE.search(text)
    raw = m.group(1).upper() if m else None
    if not raw:
        pair_m = _PAIR_RE.search(text)
        if pair_m:
            raw = _normalize_token(pair_m.group(1).upper())
    if not raw:
        return None
    return _TOKEN_ALIASES.get(raw, raw)


def extract_token(text: str) -> str | None:
    """Public: best-effort token from a caption/commentary line (e.g. '$BTC').

    Handles both the channel's ``$TOKEN`` style and the occasional Binance-style
    ``BASEUSDT`` pair it uses for the same coin (e.g. 'BOMEUSDT' -> 'BOME').
    """
    return _symbol_token(text or "")


def parse_signal(text: str) -> RawSignal | None:
    """Parse a trade-call message into a RawSignal, or None if not a signal."""
    if not text or not text.strip():
        return None

    # Side is required to be a trade entry call.
    if _LONG_RE.search(text):
        side = Side.BUY
    elif _SHORT_RE.search(text):
        side = Side.SELL
    else:
        return None

    # Symbol: prefer the $/# token (new format); fall back to XxxUSDT (old).
    token = _symbol_token(text)
    if token:
        symbol_usdt = token  # bare base, resolved to a venue ticker later
    else:
        pair_m = _PAIR_RE.search(text)
        if not pair_m:
            return None
        symbol_usdt = pair_m.group(1).upper()

    entry = _find(text, _ENTRY_RE)
    sl = _find(text, _SL_RE)
    tps = _find_all_tps(text)
    tp = tps[0] if tps else None
    tp_extra = tps[1:]
    lev_m = _LEV_RE.search(text)
    leverage = int(lev_m.group(1)) if lev_m else 0  # 0 => caller applies default

    return RawSignal(
        symbol_usdt=symbol_usdt,
        symbol="",  # resolved by SymbolResolver in the orchestrator
        side=side,
        entry_usdt=entry,
        sl_usdt=sl,
        tp_usdt=tp,
        tp_usdt_extra=tp_extra,
        notional_usd=0.0,  # filled from margin budget by the orchestrator
        leverage=leverage,
        confidence=0.8,  # signals rarely state confidence; default high
        raw={"text": text},
        source="fattyfatclub",
        raw_text=text,
    )


# Management messages sometimes name the coin WITHOUT a $ / # sigil
# ("close pump at entry", "sl hit on XAI", "cancel PENGU limit"). These
# patterns pull the bare token out of the known phrasings.
_BARE_TOKEN_RES = (
    re.compile(r"\bclose\s+([A-Za-z0-9]{2,20})\b", re.IGNORECASE),
    re.compile(r"\bcancel\s+([A-Za-z0-9]{2,20})\s+limit\b", re.IGNORECASE),
    re.compile(r"\bsl\s+hit\s+(?:on\s+)?([A-Za-z0-9]{2,20})\b", re.IGNORECASE),
    re.compile(r"\bon\s+([A-Za-z0-9]{2,20})\b", re.IGNORECASE),
    re.compile(r"\bbook\s+profits?\s+(?:on\s+)?([A-Za-z0-9]{2,20})\b", re.IGNORECASE),
)
# Words that look like tokens in the bare patterns but never are.
_BARE_STOPWORDS = {
    "at", "the", "your", "our", "here", "now", "all", "half", "some",
    "sl", "tp", "entry", "limit", "profits", "profit", "trade", "position",
    "it", "this", "that", "in", "out", "to",
}


def extract_management_token(text: str) -> str | None:
    """Token for a management message: prefer ``$SYM``/``#SYM``, else bare word."""
    tok = extract_token(text or "")
    if tok:
        return tok
    for rx in _BARE_TOKEN_RES:
        m = rx.search(text or "")
        if m:
            cand = m.group(1)
            if cand.lower() in _BARE_STOPWORDS:
                continue
            return _normalize_token(cand.upper())
    return None


def parse_management(text: str) -> dict | None:
    """Parse a position-management message into a structured action, or None."""
    if not text:
        return None
    low = text.lower().strip()

    # --- cancel a pending limit entry: "cancel PENGU limit" ---------------
    if "cancel" in low and ("limit" in low or "order" in low or "entry" in low):
        return {"action": "cancel_entry"}

    # --- exchange already closed us: "sl hit on XAI" ----------------------
    if re.search(r"\bsl\s+hit\b|\bstop(?:loss)?\s+hit\b|\bstopped\s+out\b", low):
        return {"action": "sl_hit"}

    # --- flatten at entry (breakeven exit): "close pump at entry" ---------
    if re.search(r"\bclose[a-z]*\b", low) and ("at entry" in low or "at be" in low or "at breakeven" in low):
        return {"action": "close_at_entry"}

    # --- partial profit taking: "book profits on $ONDO" -------------------
    if re.search(r"\bbook(?:ing)?\s+profits?\b|\bpartial\b|\btake\s+partial", low):
        return {"action": "partial_close", "fraction": 0.5}

    if "sl to entry" in low or "move sl to entry" in low or "move stoploss to entry" in low or "updated sl" in low or "sl updated" in low:
        return {"action": "sl_to_entry"}
    if "sl be" in low or "sl breakeven" in low or "stoploss to entry" in low or "sl to be" in low:
        return {"action": "sl_be"}
    if "full tp" in low or "tp done" in low or "take profit done" in low or "tps done" in low or "booking profits" in low or "book profits" in low or "take profit" in low:
        return {"action": "tp_hit", "index": 0}  # all TPs / secure profit
    if "sl be" in low or "sl breakeven" in low or "stoploss to entry" in low or "sl to be" in low:
        return {"action": "sl_be"}
    if "break even" in low or "breakeven" in low or "be " in low:
        return {"action": "sl_be"}

    # Loose channel chatter that still directs an action on the open position:
    #  "$X up N% ... manage your trade" / "1R up" -> trail SL toward entry.
    if "manage your trade" in low or "manage trade" in low or "1r up" in low or "up almost" in low or "move sl" in low:
        return {"action": "manage"}

    sl_m = re.search(r"\b(?:stop[\s_-]?loss|sl)[\s:]*(?:to[\s:]*)?([0-9]+(?:[.,][0-9]+)?)", low)
    if sl_m and "sl" in low:
        return {"action": "sl_to", "price": _num(sl_m.group(1))}

    tp_m = re.search(r"\btp(\d*)[\s:]*(?:here|hit|taken|done)", low)
    if tp_m:
        return {"action": "tp_hit", "index": int(tp_m.group(1) or 1)}

    if "close" in low or "exit" in low or "closed" in low:
        return {"action": "close"}

    return None
