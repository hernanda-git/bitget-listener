"""LLM-backed signal + management parser.

Replaces the regex-only text parser as the PRIMARY reader of the source channel.
The LLM reads the raw message (trade call OR manual SL/TP/close instruction) and
returns a normalized dict in the SAME shape the regex parser produced, so the
rest of the pipeline is unchanged. The regex parser is kept as a FALLBACK (used
when the LLM is unconfigured or errors) and as the CROSS-CHECK partner: the
orchestrator compares the LLM result against the regex result and against the
chart-image vision result before it commits to a trade.

Endpoint is fully configurable (OpenAI-compatible):
  LLM_SIGNAL_BASE_URL  default https://inference-api.nousresearch.com/v1
  LLM_SIGNAL_MODEL     default tencent/hy3:free
  LLM_SIGNAL_API_KEY   required (no key -> parser is disabled, regex fallback)

Swap models freely via LLM_SIGNAL_MODEL (any OpenAI-compatible chat model).
"""

from __future__ import annotations

import json
import logging
import os
import re
from typing import Any

import httpx

log = logging.getLogger(__name__)

DEFAULT_BASE_URL = "https://inference-api.nousresearch.com/v1"
DEFAULT_MODEL = "tencent/hy3:free"

_SYSTEM = """You are a crypto signal parser for a trading bot. Read a Telegram \
message from a signal channel and return STRICT JSON only (no prose, no markdown \
fences). Decide the message kind, then fill the relevant fields.

Kinds:
- "signal": a trade entry call. Has a token, a side (LONG/SHORT), and usually \
entry/sl/tp prices.
- "management": an instruction on an OPEN position (move SL, take profit, close, \
partial close, cancel entry). Has an action.
- "bias": a market directional read (e.g. "BTC bias: BULLISH"), not a trade.
- "noise": anything else (greeting, meme, unrelated chatter).

Response shapes:
{
  "kind": "signal",
  "token": "BONK",
  "side": "LONG" | "SHORT",
  "entry": 0.002472,          // number or null
  "sl": 0.002402,             // number or null
  "tp": [0.002615],           // array of numbers (may be empty)
  "leverage": null            // number or null
}
{
  "kind": "management",
  "action": "sl_to_entry" | "sl_be" | "close_at_entry" | "partial_close" |
            "cancel_entry" | "tp_hit" | "sl_hit" | "close" | "manage",
  "token": "BONK",            // the coin the action targets (if stated)
  "fraction": 0.5,            // for partial_close (0..1), else null
  "price": null               // explicit price if the message states one
}
{
  "kind": "bias",
  "token": "BTC",
  "bias": "BULLISH" | "BEARISH" | "NEUTRAL"
}
{
  "kind": "noise"
}

Rules:
- token is the BASE ticker without USDT (e.g. "BONK", "BTC"). Use the $TOKEN or \
#TOKEN from the text.
- side is required for kind "signal". If absent, kind is not "signal".
- numbers must be plain floats, no commas, no quotes.
- management actions:
  * "sl to entry" / "move sl to entry" / "updated sl" -> "sl_to_entry"
  * "sl be" / "sl breakeven" / "stoploss to entry" / "breakeven" -> "sl_be"
  * "close X at entry" / "close at be" -> "close_at_entry"
  * "book profits" / "partial" / "take partial" -> "partial_close" (fraction 0.5 default)
  * "cancel X limit" / "cancel entry" -> "cancel_entry"
  * "tp hit" / "tp1 here" / "full tp" / "take profit done" -> "tp_hit"
  * "sl hit" / "stopped out" -> "sl_hit"
  * "close" / "exit" (on a position) -> "close"
  * "manage your trade" / "1R up" / "move sl" -> "manage"
- Return exactly one JSON object. Nothing else.
"""


def _clean_num(v: Any) -> float | None:
    if v is None:
        return None
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).strip().replace(",", "")
    try:
        return float(s)
    except ValueError:
        return None


def _normalize_signal(d: dict) -> dict:
    tps = d.get("tp") or []
    if not isinstance(tps, list):
        tps = [tps]
    return {
        "kind": "signal",
        "token": (d.get("token") or "").upper() or None,
        "side": (d.get("side") or "").upper() or None,
        "entry": _clean_num(d.get("entry")),
        "sl": _clean_num(d.get("sl")),
        "tp": [_clean_num(x) for x in tps if _clean_num(x) is not None],
        "leverage": _clean_num(d.get("leverage")),
    }


def _normalize_management(d: dict) -> dict:
    return {
        "kind": "management",
        "action": d.get("action"),
        "token": (d.get("token") or "").upper() or None,
        "fraction": _clean_num(d.get("fraction")),
        "price": _clean_num(d.get("price")),
    }


def _normalize_bias(d: dict) -> dict:
    return {
        "kind": "bias",
        "token": (d.get("token") or "").upper() or None,
        "bias": (d.get("bias") or "").upper() or None,
    }


def normalize_llm(d: dict) -> dict | None:
    """Coerce a raw LLM dict into a typed kind dict, or None if unusable."""
    if not isinstance(d, dict):
        return None
    kind = (d.get("kind") or "").lower()
    if kind == "signal":
        if not d.get("side"):
            return None
        return _normalize_signal(d)
    if kind == "management":
        if not d.get("action"):
            return None
        return _normalize_management(d)
    if kind == "bias":
        return _normalize_bias(d)
    return {"kind": "noise"}


class LLMSignalParser:
    """Calls an OpenAI-compatible chat endpoint to parse a source message."""

    def __init__(self, base_url: str | None = None, model: str | None = None,
                 api_key: str | None = None, timeout: int = 40):
        self.base_url = (base_url or os.getenv("LLM_SIGNAL_BASE_URL", DEFAULT_BASE_URL)).rstrip("/")
        self.model = os.getenv("LLM_SIGNAL_MODEL", model or DEFAULT_MODEL)
        self.api_key = api_key if api_key is not None else os.getenv("LLM_SIGNAL_API_KEY", "")
        self.timeout = timeout
        # Disabled when no key is configured -> caller uses regex fallback.
        self.enabled = bool(self.api_key)

    @classmethod
    def from_env(cls) -> "LLMSignalParser | None":
        p = cls()
        return p if p.enabled else None

    # --- the single network method (monkeypatchable in tests) --------- #
    async def _call(self, text: str) -> dict | None:
        url = f"{self.base_url}/chat/completions"
        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": _SYSTEM},
                {"role": "user", "content": text},
            ],
            "temperature": 0,
            "response_format": {"type": "json_object"},
        }
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            resp = await client.post(url, json=payload, headers=headers)
            resp.raise_for_status()
            data = resp.json()
        content = data["choices"][0]["message"]["content"]
        return self._parse_content(content)

    @staticmethod
    def _parse_content(content: str) -> dict | None:
        content = (content or "").strip()
        # Strip ```json fences if the model ignored response_format.
        if content.startswith("```"):
            content = re.sub(r"^```[a-zA-Z]*\n?", "", content)
            content = re.sub(r"\n?```$", "", content).strip()
        try:
            return json.loads(content)
        except (ValueError, TypeError):
            pass
        m = re.search(r"\{.*\}", content, re.S)
        if m:
            try:
                return json.loads(m.group(0))
            except (ValueError, TypeError):
                return None
        return None

    async def parse(self, text: str) -> dict | None:
        """Return a normalized kind dict, or None on any failure/unconfigured."""
        if not self.enabled or not text or not text.strip():
            return None
        try:
            raw = await self._call(text)
            return normalize_llm(raw)
        except Exception as e:  # LLM must never crash the pipeline
            log.warning("LLM signal parse failed: %s", e)
            return None
