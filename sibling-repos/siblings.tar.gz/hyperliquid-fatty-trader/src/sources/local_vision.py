"""Local chart-vision backend — NO LLM provider, fully offline.

Reads horizontal entry / sl / tp levels off a TradingView-style signal chart
using OpenCV + Tesseract OCR. No network, no API key.

How it works:
* The colored level tags (green = take-profit, red/purple = entry/stop) are
  located by COLOUR (robust to the countdown timer some entry boxes display).
* Each tag's own price is OCR'd from its rectangle (keeps the decimal point).
* Tags that show a timer instead of a price (entry boxes) get their price by
  interpolating the y->price line fitted from the other OCR'd tags + the grey
  price axis. This makes the entry recoverable even when its text is a clock.
* The side (LONG/SHORT) comes from the caption and decides which tag is entry
  vs stop vs target.

Conservative by design: returns tradeable levels only when >=2 distinct coloured
prices are found; otherwise ``has_chart_data=False`` and the orchestrator leaves
the signal as ``vision_pending`` (never traded).
"""

from __future__ import annotations

import logging
import re
from pathlib import Path

import cv2
import numpy as np
import pytesseract

log = logging.getLogger(__name__)

try:
    from src.sources.vision import EMPTY_STRUCT, _coerce
except Exception:  # pragma: no cover
    EMPTY_STRUCT = {
        "levels": {"entry": None, "sl": None, "tp": [], "support": [], "resistance": []},
        "trend": "", "setup_type": "", "wave": [], "arrows": [],
        "bias": {"primary": "", "secondary": "", "horizon": ""}, "has_chart_data": False,
    }

    def _coerce(struct):
        return dict(EMPTY_STRUCT)


def _clean_num(s: str) -> float | None:
    s = s.strip().replace(",", "")
    if not re.fullmatch(r"\d+(?:\.\d+)?|\.\d+", s):
        return None
    try:
        return float(s)
    except ValueError:
        return None


class LocalVisionExtractor:
    """Offline chart-level extractor (OpenCV + Tesseract)."""

    def __init__(self, config: dict | None = None):
        cfg = ((config or {}).get("agent") or {}).get("vision") or {}
        self.upscale = int(cfg.get("local_upscale", 2))
        self.axis_frac = float(cfg.get("axis_frac", 0.16))
        self.min_levels = int(cfg.get("min_levels", 2))

    @staticmethod
    def encode_image(path):
        return Path(path).read_bytes()

    async def extract(self, image_path: str | Path, caption: str = "") -> dict:
        path = Path(image_path)
        if not path.exists():
            log.warning("LocalVision: image missing at %s", path)
            return _coerce(None)
        try:
            return self._extract_sync(path, caption or "")
        except Exception as e:  # never crash the pipeline
            import traceback as _tb
            log.warning("LocalVision failed for %s: %s\n%s", path, e, "".join(_tb.format_tb(e.__traceback__)))
            return _coerce(None)

    # ------------------------------------------------------------------ #
    def _extract_sync(self, path: Path, caption: str) -> dict:
        img = cv2.imread(str(path))
        if img is None:
            return _coerce(None)
        h, w = img.shape[:2]
        if self.upscale > 1:
            img = cv2.resize(img, (w * self.upscale, h * self.upscale),
                             interpolation=cv2.INTER_CUBIC)
            h, w = img.shape[:2]

        strip_x0 = int(w * (1.0 - self.axis_frac))
        strip = img[:, strip_x0:]

        # Colored level tags: each -> (y_center, ocr_price|None)
        tags = self._colored_tags(strip)

        # Calibration anchors: OCR'd tag prices + grey axis numbers.
        anchors = [(y, p) for lst in tags.values() for (y, p) in lst if p is not None]
        anchors += [(y, p) for (y, p) in self._axis_anchors(img) if p is not None]
        slope, y0, ok = self._fit_line(anchors)

        # Resolve every tag's price (OCR first, else interpolate via the line).
        resolved: dict[str, list[float]] = {"green": [], "red": [], "purple": [], "orange": []}
        for color, ylist in tags.items():
            for y, p in ylist:
                price = p if p is not None else (slope * y + y0 if ok else None)
                if price is not None and price > 0:
                    resolved[color].append(round(float(price), 8))
        for c in resolved:
            resolved[c].sort()

        non_green = sorted(resolved["red"] + resolved["purple"] + resolved["orange"])
        side = "long" if re.search(r"\blong\b", caption, re.I) else (
            "short" if re.search(r"\bshort\b", caption, re.I) else None)
        out_levels = self._classify(resolved, non_green, side)

        found = [v for v in (out_levels.get("entry"), out_levels.get("sl")) if v is not None]
        found += out_levels.get("tp") or []
        if len(found) < self.min_levels:
            out = _coerce(None)
            out["levels"]["support"] = out_levels.get("support", [])
            out["levels"]["resistance"] = out_levels.get("resistance", [])
            # Only call it "chart data" if we actually saw colored level tags.
            any_tag = any(resolved[c] for c in ("green", "red", "purple", "orange"))
            out["has_chart_data"] = bool(ok) and any_tag
            return out

        out = _coerce(None)
        out["levels"]["entry"] = out_levels.get("entry")
        out["levels"]["sl"] = out_levels.get("sl")
        out["levels"]["tp"] = out_levels.get("tp") or []
        out["levels"]["support"] = out_levels.get("support", [])
        out["levels"]["resistance"] = out_levels.get("resistance", [])
        out["trend"] = "up" if side == "long" else ("down" if side == "short" else "")
        out["has_chart_data"] = True
        return out

    # ------------------------------------------------------------------ #
    def _colored_tags(self, strip: np.ndarray) -> dict[str, list[tuple[float, float | None]]]:
        """Locate colored level tags; OCR each tag's own price (keeps decimal)."""
        hsv = cv2.cvtColor(strip, cv2.COLOR_BGR2HSV)
        masks = {
            "green":  cv2.inRange(hsv, (35, 70, 70), (85, 255, 255)),
            "red":    cv2.bitwise_or(
                cv2.inRange(hsv, (0, 70, 70), (10, 255, 255)),
                cv2.inRange(hsv, (170, 70, 70), (180, 255, 255))),
            "purple": cv2.inRange(hsv, (125, 50, 50), (160, 255, 255)),
            "orange": cv2.inRange(hsv, (10, 120, 120), (25, 255, 255)),
        }
        out: dict[str, list[tuple[float, float | None]]] = {k: [] for k in masks}
        for color, mask in masks.items():
            cnts, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            for c in cnts:
                x, y, cw, ch = cv2.boundingRect(c)
                if cw * ch < 200 or ch < 8:
                    continue
                cy = y + ch / 2.0
                # Crop the tag box (text may extend left within the strip).
                bx0 = max(0, x - 60)
                bx1 = min(strip.shape[1], x + cw + 4)
                box = strip[y:y + ch, bx0:bx1]
                tg = cv2.cvtColor(box, cv2.COLOR_BGR2GRAY)
                _, tb = cv2.threshold(tg, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
                txt = pytesseract.image_to_string(
                    tb, config="--psm 7 -c tessedit_char_whitelist=0123456789.,")
                price = _clean_num(txt)
                out[color].append((cy, price))
        # De-dup nearby y-centers (within 6px).
        for color in out:
            items = sorted(out[color], key=lambda t: t[0])
            dedup = []
            for yv, p in items:
                if not dedup or abs(yv - dedup[-1][0]) > 6:
                    dedup.append((yv, p))
            out[color] = dedup
        return out

    def _axis_anchors(self, img: np.ndarray) -> list[tuple[float, float]]:
        """Grey price-axis numbers on the right edge (decimal often dropped by
        OCR, so we only keep them as coarse anchors when they parse as a 4-6
        digit cluster consistent with the colored tags' magnitude)."""
        sw = img.shape[1]
        x0 = int(sw * (1.0 - self.axis_frac))
        axis = img[:, x0:]
        gray = cv2.cvtColor(axis, cv2.COLOR_BGR2GRAY)
        _, binv = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
        data = pytesseract.image_to_data(
            binv, config="--psm 6 -c tessedit_char_whitelist=0123456789.",
            output_type=pytesseract.Output.DICT,
        )
        anchors = []
        for i, t in enumerate(data["text"]):
            n = _clean_num(t)
            if n is None or n <= 0:
                continue
            # Re-insert decimal: axis labels are like 0.0073xx but OCR drops the
            # dot -> "73xx". Recover by placing the decimal after the first digit
            # for 3-4 digit clusters (0.0xxx style). Best-effort only.
            s = t.strip().replace(",", "")
            if re.fullmatch(r"\d{3,4}", s):
                cand = float(s[0] + "." + s[1:])
                y = data["top"][i] + data["height"][i] / 2.0
                anchors.append((y, cand))
        return anchors

    @staticmethod
    def _fit_line(anchors: list[tuple[float, float]]) -> tuple[float, float, bool]:
        """Least-squares y->price line from (y, price) anchors."""
        anchors = [(y, p) for (y, p) in anchors if p is not None]
        if len(anchors) < 2:
            return 0.0, 0.0, False
        ys = np.array([a[0] for a in anchors], dtype=float)
        ps = np.array([a[1] for a in anchors], dtype=float)
        # robust: drop outliers > 6 median-abs-dev (protects against a bad OCR)
        med = np.median(ps)
        mad = np.median(np.abs(ps - med)) or 1e-9
        keep = np.abs(ps - med) < 6 * mad
        if keep.sum() < 2:
            keep = np.ones_like(keep, dtype=bool)
        ys, ps = ys[keep], ps[keep]
        A = np.polyfit(ys, ps, 1) if len(ys) >= 2 else (0.0, ps[0])
        return float(A[0]), float(A[1]), True

    @staticmethod
    def _classify(resolved: dict, non_green: list[float], side: str | None) -> dict:
        greens = resolved.get("green", [])
        out = {"entry": None, "sl": None, "tp": [], "support": [], "resistance": []}
        if side == "long":
            out["tp"] = greens
            if len(non_green) >= 2:
                out["sl"] = non_green[0]
                out["entry"] = non_green[-1]
            elif len(non_green) == 1:
                out["entry"] = non_green[0]
            out["support"] = [e for e in non_green if out["sl"] is None or e <= out["sl"]]
            out["resistance"] = [e for e in non_green if out["entry"] is None or e >= out["entry"]]
        elif side == "short":
            out["tp"] = greens
            if len(non_green) >= 2:
                out["entry"] = non_green[-2]
                out["sl"] = non_green[-1]
            elif len(non_green) == 1:
                out["entry"] = non_green[0]
            out["resistance"] = [e for e in non_green if out["sl"] is None or e >= out["sl"]]
            out["support"] = [e for e in non_green if out["entry"] is None or e <= out["entry"]]
        else:
            out["resistance"] = list(non_green)
            out["support"] = list(greens)
            out["tp"] = list(greens)
        return out
