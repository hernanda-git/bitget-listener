"""Orchestrator — wires the pipeline with dependency injection.

High-level module: depends only on the port interfaces, never on concrete adapters
(SOLID / DIP). Drives: source -> normalizer -> validator -> risk -> order ->
adapter, and consumes WS pushes (marks, positions, fills) to monitor SL.

A dry-run flag makes place_order a no-op log instead of a real call (for --dry-run
and paper mode).
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any

from src.domain.model import Position, RawSignal, Signal, Instrument, UsdNotional, Settlement, Side
from src.interfaces.ports import (
    ExchangeAdapter,
    MarketStream,
    Notifier,
    PegSource,
    SignalSource,
)
from src.services.normalizer import SignalNormalizer
from src.services.validator import SignalValidator, ValidationConfig
from src.services.risk import RiskManager, RiskConfig
from src.services.order import OrderService
from src.services.position import PositionManager
from src.sources.symbol_map import SymbolResolver
from src.sources.parser import parse_signal, parse_management, extract_token, extract_management_token
from src.sources.bias import parse_bias, BiasRecord
from src.sources.llm_signal import LLMSignalParser


@dataclass
class OrchestratorConfig:
    dry_run: bool = True
    min_confidence: float = 0.5
    default_notional_usd: float = 100.0  # per-trade budget when signal omits size
    testnet: bool = True  # symbol resolution uses the testnet perp universe by default


class Orchestrator:
    def __init__(
        self,
        source: SignalSource,
        peg: PegSource,
        adapter: ExchangeAdapter,
        market: MarketStream,
        notifier: Notifier,
        config: OrchestratorConfig | None = None,
        attachment_fetcher: Any = None,
        vision_extractor: Any = None,
        bias_recorder: Any = None,
    ):
        self.cfg = config or OrchestratorConfig()
        self.source = source
        self.adapter = adapter
        self.market = market
        self.notifier = notifier
        self.normalizer = SignalNormalizer(peg, max_depeg=0.005)
        self.validator = SignalValidator(ValidationConfig(min_confidence=self.cfg.min_confidence))
        self.risk = RiskManager(RiskConfig())
        # Per-coin min-notional floors come from the DB store (populated by
        # scripts/refresh_pair_min_notional.py). If the store/DB is unavailable,
        # OrderService.min_notional_for falls back to risk.cfg.min_notional_usd.
        try:
            from src.store.min_notional import MinNotionalStore
            min_store = MinNotionalStore()
        except Exception:
            min_store = None
        self.order_svc = OrderService(self.risk, min_notional_store=min_store)
        self.positions = PositionManager()
        self.attachment_fetcher = attachment_fetcher
        self.vision_extractor = vision_extractor
        self.bias_recorder = bias_recorder
        self.resolver = SymbolResolver(testnet=self.cfg.testnet)
        # LLM text parser (primary). None when LLM_SIGNAL_API_KEY is unset, in
        # which case the regex parser is used directly (and as cross-check).
        self.llm_signal = LLMSignalParser.from_env()

    async def handle_signal(self, raw: RawSignal) -> str:
        """Full pipeline for one raw signal. Returns a status string."""
        try:
            return await self._handle_signal_inner(raw)
        except Exception as e:  # top-level guard: never let one bad signal crash the loop
            import traceback
            tb = traceback.format_exc(limit=3)
            await self._safe_exc("handle_signal", f"{e}\n{tb}")
            return "error:exception"

    async def _handle_signal_inner(self, raw: RawSignal) -> str:
        # Apply default leverage when the signal omitted one (channel never states it).
        if raw.leverage and raw.leverage > 0:
            eff_lev = raw.leverage
        else:
            eff_lev = self.risk.cfg.default_leverage
        raw.leverage = eff_lev

        # Apply default margin budget when the source didn't size the trade.
        if raw.notional_usd <= 0:
            raw.notional_usd = self.risk.margin_to_notional()

        # 1) Structured text trade call? (e.g. "#PUMP $PUMP LONG TRADE ...")
        #    PRIMARY = LLM parser; REGEX = fallback + cross-check partner.
        regex_sig = parse_signal(raw.raw_text) if raw.raw_text else None
        llm = await self._llm_parse(raw.raw_text) if (self.llm_signal and raw.raw_text) else None

        # Choose the signal source + detect disagreement (so we never trade on a
        # misread). LLM wins when present and agreeing with regex; on conflict we
        # HOLD and alert instead of guessing.
        chosen = None          # "llm" | "regex" | None
        conflict = False
        if llm and llm.get("kind") == "signal":
            if regex_sig is not None:
                if self._signal_agree(llm, regex_sig):
                    chosen = "llm"
                else:
                    conflict = True
            else:
                chosen = "llm"
        elif regex_sig is not None:
            chosen = "regex"

        # Display symbol/side in the alert: prefer the chosen parser.
        disp_sym = (llm.get("token") if (chosen == "llm" and llm) else None) \
            or (regex_sig.symbol_usdt if regex_sig else None) \
            or raw.symbol_usdt or "?"
        disp_side = (llm.get("side") if (chosen == "llm" and llm) else None) \
            or (regex_sig.side.value if regex_sig else None) \
            or (raw.side.value if raw.side else "?")
        try:
            await self.notifier.signal_received(
                disp_sym, disp_side, raw.source, raw.message_id, raw.raw_text,
            )
        except Exception:
            pass

        if conflict:
            await self.notifier.send(
                f"⚠️ [needs_review] signal parse conflict for msg {raw.message_id}: "
                f"LLM={llm.get('token')}/{llm.get('side')} vs "
                f"regex={regex_sig.symbol_usdt}/{regex_sig.side.value}. Holding."
            )
            return "needs_review:signal_conflict"

        if chosen == "llm" and llm:
            # Build a RawSignal from the LLM result.
            sym = llm.get("token")
            side = Side.BUY if (llm.get("side") or "").upper() == "LONG" else Side.SELL
            tps = llm.get("tp") or []
            raw.symbol_usdt = sym or raw.symbol_usdt
            raw.side = side
            raw.entry_usdt = llm.get("entry")
            raw.sl_usdt = llm.get("sl")
            raw.tp_usdt = tps[0] if tps else None
            raw.tp_usdt_extra = tps[1:]
            # Keep the default 3x (set earlier) unless the LLM explicitly gives one.
            raw.leverage = llm.get("leverage") or raw.leverage
            return await self._trade_pipeline(raw)
        if chosen == "regex" and regex_sig is not None:
            raw.symbol_usdt = regex_sig.symbol_usdt
            return await self._trade_pipeline(raw)
        if (raw.entry_usdt is not None or raw.side != Side.BUY) and raw.symbol_usdt:
            # Pre-built signal (no parseable text): trade it directly.
            return await self._trade_pipeline(raw)

        # 2) Management message? (sl to entry, close, tp hit, ...)
        #    LLM primary, regex fallback + cross-check, same hold-on-conflict rule.
        regex_mgmt = parse_management(raw.raw_text) if raw.raw_text else None
        llm_mgmt = llm if (llm and llm.get("kind") == "management") else None
        mgmt_chosen = None
        mgmt_conflict = False
        if llm_mgmt:
            if regex_mgmt is not None:
                if (llm_mgmt.get("action") or "") == regex_mgmt.get("action"):
                    mgmt_chosen = "llm"
                else:
                    mgmt_conflict = True
            else:
                mgmt_chosen = "llm"
        elif regex_mgmt is not None:
            mgmt_chosen = "regex"

        if mgmt_conflict:
            await self.notifier.send(
                f"⚠️ [needs_review] management parse conflict for msg {raw.message_id}: "
                f"LLM={llm_mgmt.get('action')} vs regex={regex_mgmt.get('action')}. Holding."
            )
            return "needs_review:mgmt_conflict"
        if mgmt_chosen == "llm" and llm_mgmt:
            merged = dict(llm_mgmt)
            # token may be missing from LLM; backfill from regex if present.
            if not merged.get("token") and regex_mgmt:
                merged["token"] = regex_mgmt.get("token") or extract_management_token(raw.raw_text or "")
            raw.symbol_usdt = merged.get("token") or raw.symbol_usdt
            # Promote LLM management fields onto the RawSignal so _apply_management
            # (which reads raw.*) acts correctly.
            raw.leverage = merged.get("fraction") or 0
            return await self._apply_management_llm(raw, merged)
        if mgmt_chosen == "regex" and regex_mgmt is not None:
            return await self._apply_management(raw, regex_mgmt)

        # 2b) Market-bias call? (e.g. "BTC bias: BULLISH", "$ETH bearish")
        #     Recorded to the bias DB for later review; not traded. Prefer LLM
        #     bias, else regex. When the bias call carries a chart, enrich the
        #     record with the drawn-arrow direction + parsed S/R zones (see
        #     _read_chart_bias).
        bias_rec = None
        if llm and llm.get("kind") == "bias" and llm.get("token"):
            bias_rec = parse_bias(f"{llm.get('token')} bias: {llm.get('bias')}")
        if bias_rec is None:
            bias_rec = parse_bias(raw.raw_text)
        if bias_rec is not None:
            bias_rec.message_id = raw.message_id
            bias_rec.channel = raw.channel
            # Enrich with the chart (arrow direction + S/R zones) when present.
            chart = await self._read_chart_bias(raw)
            if chart:
                arrow = chart.get("arrow")
                if arrow and bias_rec.bias in ("NEUTRAL", ""):
                    # No explicit direction in text -> adopt the arrow's.
                    bias_rec.bias = arrow
                elif arrow and arrow != bias_rec.bias:
                    # Arrow and text disagree: text wins (explicit statement),
                    # but record the arrow so the divergence is visible.
                    await self.notifier.send(
                        f"⚠️ Bias arrow ({arrow}) disagrees with text "
                        f"({bias_rec.bias}) for {bias_rec.target or 'MARKET'}; "
                        f"keeping text."
                    )
                bias_rec.arrow = arrow
                bias_rec.levels_json = chart.get("levels_json")
                bias_rec.source = "text+chart" if bias_rec.source == "text" else bias_rec.source
            try:
                if self.bias_recorder is not None:
                    self.bias_recorder.record(bias_rec, raw.message_id, raw.channel)
                await self.notifier.send(
                    f"🧭 Bias logged: {bias_rec.target or 'MARKET'} — "
                    f"<b>{bias_rec.bias}</b>"
                    + (f" (arrow {bias_rec.arrow})" if bias_rec.arrow else "")
                )
            except Exception as e:  # never crash the loop on bias logging
                await self._safe_exc("bias_record", str(e))
            return "bias_logged"

        # 2c) Chart-only bias: a post with an image + a token but NO "bias" word
        #     in text. If the chart carries a drawn directional arrow, treat it
        #     as a bias read (record-only) instead of dropping it as
        #     vision_pending. A pure S/R chart with no arrow stays pending.
        if raw.has_media:
            chart = await self._read_chart_bias(raw)
            arrow = chart.get("arrow") if chart else None
            if arrow and raw.symbol_usdt:
                bias_rec = BiasRecord(
                    ts=0.0, bias=arrow, target=raw.symbol_usdt.upper(),
                    text=raw.raw_text, message_id=raw.message_id,
                    channel=raw.channel, arrow=arrow,
                    levels_json=chart.get("levels_json"), source="chart",
                )
                try:
                    if self.bias_recorder is not None:
                        self.bias_recorder.record(bias_rec, raw.message_id, raw.channel)
                    await self.notifier.send(
                        f"🧭 Bias logged (chart): {bias_rec.target} — "
                        f"<b>{bias_rec.bias}</b> (arrow)"
                    )
                except Exception as e:
                    await self._safe_exc("bias_chart_record", str(e))
                return "bias_logged"

        # 3) Media / chart image? Route to vision (downloaded by the source).
        #    When the LLM already produced trade levels from TEXT, cross-check
        #    them against the vision levels before trading.
        if raw.has_media:
            status = await self._try_attachment_scalp(raw, llm_signal=llm)
            if status is not None:
                return status
            await self.notifier.send(
                f"[vision-pending] image signal for {raw.symbol_usdt or '?'} "
                f"(msg {raw.message_id})"
            )
            return "vision_pending"

        # 4) Otherwise: ambient chatter / noise.
        return "noise"

    async def _llm_parse(self, text: str) -> dict | None:
        """Parse text via the LLM (returns normalized kind dict or None)."""
        if not self.llm_signal:
            return None
        return await self.llm_signal.parse(text)

    @staticmethod
    def _arrow_bias(rich: dict | None) -> str | None:
        """Direction implied by a drawn arrow on a bias chart.

        The rich vision payload lists `arrows[].movement_type`. A chart arrow is
        an annotation, NOT a trade instruction — but for a *bias* record (which
        is record-only, never traded) it is exactly the directional hint the
        analyst drew. Returns BULLISH / BEARISH / None.
        """
        if not rich:
            return None
        for a in rich.get("arrows") or []:
            if not isinstance(a, dict):
                continue
            mv = str(a.get("movement_type") or "").lower()
            if "up" in mv:
                return "BULLISH"
            if "down" in mv:
                return "BEARISH"
        return None

    @staticmethod
    def _bias_levels_json(struct: dict | None) -> str | None:
        """JSON of the support/resistance bounds parsed from a bias chart."""
        if not struct:
            return None
        lv = struct.get("levels") or {}
        support = lv.get("support") or []
        resistance = lv.get("resistance") or []
        if not support and not resistance:
            return None
        return json.dumps({"support": support, "resistance": resistance})

    async def _read_chart_bias(self, raw: RawSignal) -> dict | None:
        """Extract arrow direction + levels from an attached chart, if present.

        Returns {"arrow": ..., "levels_json": ...} or None when there is no
        chart / vision extractor, or the chart read failed. Safe: any exception
        is swallowed (a missing chart must never crash bias logging).
        """
        if not raw.has_media or not raw.image_path or not self.vision_extractor:
            return None
        try:
            struct = await self.vision_extractor.extract(
                image_path=raw.image_path, caption=raw.raw_text,
            )
        except Exception as e:  # vision is best-effort for bias
            await self._safe_exc("bias_chart_read", str(e))
            return None
        if not struct or not struct.get("has_chart_data"):
            return None
        return {
            "arrow": self._arrow_bias(struct.get("rich")),
            "levels_json": self._bias_levels_json(struct),
        }

    @staticmethod
    def _signal_agree(llm: dict, regex_sig) -> bool:
        """True when LLM and regex agree on the essentials (symbol + side).

        The LLM reports side as LONG/SHORT; the regex parser stores a Side enum
        (BUY/SELL). Normalize the LLM side before comparing so the two
        representations line up (as the orchestrator does when trading).
        """
        _side_map = {"LONG": "BUY", "SHORT": "SELL"}
        lsym = (llm.get("token") or "").upper()
        rsym = (regex_sig.symbol_usdt or "").upper()
        lside = _side_map.get((llm.get("side") or "").upper(), (llm.get("side") or "").upper())
        rside = regex_sig.side.value.upper() if regex_sig.side else ""
        if lsym and rsym and lsym != rsym:
            return False
        if lside and rside and lside != rside:
            return False
        return True

    @staticmethod
    def _levels_diverge(a: dict, b: dict) -> bool:
        """True when two independent level reads disagree beyond a tolerance.

        Compares entry/sl/tp that BOTH readers produced. A pair is divergent
        when the relative difference exceeds 5% (prices can be tiny, e.g. 0.0024,
        so absolute diffs are meaningless). Missing-on-one-side values are ignored
        (no conflict if only one reader saw a level).
        """
        def _rel(x, y):
            if x is None or y is None or x <= 0 or y <= 0:
                return None
            return abs(x - y) / max(abs(x), abs(y))
        for k in ("entry", "sl", "tp"):
            r = _rel(a.get(k), b.get(k))
            if r is not None and r > 0.05:
                return True
        return False

    async def _apply_management_llm(self, raw: RawSignal, merged: dict) -> str:
        """Apply an LLM-derived management action (same engine as regex path).

        ``merged`` carries action/token/fraction/price. We translate the LLM
        action into the shape ``_apply_management`` expects, backfilling the
        token from the message when the LLM omitted it.
        """
        token = merged.get("token") or extract_management_token(raw.raw_text or "")
        if token:
            raw.symbol_usdt = token
        # partial_close carries the fraction via raw.leverage slot (see caller);
        # _apply_management reads it through the mgmt dict, so rebuild that.
        mgmt = {
            "action": merged.get("action"),
            "fraction": merged.get("fraction") or 0.5,
            "price": merged.get("price"),
        }
        return await self._apply_management(raw, mgmt)

    async def _trade_pipeline(self, raw: RawSignal) -> str:
        """Resolve symbol, normalize, validate, and (dry-)place orders."""
        # Resolve the source token to a venue-listed perp ticker.
        # Skip (do not trade) symbols that aren't listed on the venue.
        resolved = await self.resolver.resolve(raw.symbol_usdt)
        if not resolved:
            await self.notifier.send(
                f"[skip] {raw.symbol_usdt} not listed on Hyperliquid perps"
            )
            await self._safe_notify("rejected", raw.symbol_usdt, "resolve", "not listed on Hyperliquid perps")
            return "skipped:unlisted"
        raw.symbol = resolved
        raw.venue = "hyperliquid"

        try:
            sig: Signal = await self.normalizer.normalize(raw)
        except Exception as e:  # NormalizationError (depeg) etc.
            await self.notifier.send(f"normalize failed: {e}")
            await self._safe_notify("rejected", raw.symbol_usdt, "normalize", str(e))
            return "rejected:normalize"
        try:
            self.validator.validate(sig)
        except Exception as e:  # ValidationError
            await self.notifier.send(f"invalid signal: {e}")
            await self._safe_notify("rejected", raw.symbol_usdt, "validate", str(e))
            return "rejected:validate"

        mark = self.market.mark_price(sig.instrument.symbol) or sig.entry or 0.0
        orders = self.order_svc.build_orders(sig, mark)
        if self.cfg.dry_run:
            await self.notifier.send(
                f"[dry-run] {sig.side.value} {sig.instrument.symbol} "
                f"entry={sig.entry} sl={sig.sl} tp={sig.tp} lev={sig.leverage} "
                f"orders={len(orders)}"
            )
            await self._safe_order(sig, orders, dry=True)
            return "dry-run"
        # Enforce the computed leverage on the exchange (cross margin) before
        # placing orders, so risk-based sizing is actually applied.
        try:
            await self.adapter.set_leverage(sig.instrument.symbol, sig.leverage, cross=True)
        except Exception as e:
            await self._safe_exc("set_leverage", str(e))
        for o in orders:
            await self.adapter.place_order(o)
        await self.notifier.send(
            f"{sig.side.value} {sig.instrument.symbol} placed ({len(orders)} orders)"
        )
        await self._safe_order(sig, orders, dry=False)
        await self._safe_opened(sig)
        return "placed"

    async def _try_attachment_scalp(self, raw: RawSignal, mark_price: float | None = None,
                                  llm_signal: dict | None = None) -> str | None:
        """If a chart image is present, extract tradeable levels via vision.

        Uses the caption token (e.g. '$BTC') to resolve the venue ticker, applies
        the same 3x / $1 defaults and unlisted-skip as text trades. Returns a
        status string when handled, or None to fall through (vision off / no
        tradeable levels in the chart).

        Cross-check: when ``llm_signal`` (the LLM text parse of the same message)
        also produced entry/sl/tp, we compare them against the vision levels. A
        large divergence means the two readers disagree on the trade -> we HOLD
        and alert instead of trading on a mismatched read.
        """
        if not raw.has_media:
            return None
        if not self.attachment_fetcher or not self.vision_extractor:
            return None
        if not raw.image_path:
            return None  # source failed to download the image

        # Resolve the caption token to a venue ticker (skip if unlisted).
        ticker = await self.resolver.resolve(raw.symbol_usdt) if raw.symbol_usdt else None
        if raw.symbol_usdt and not ticker:
            await self.notifier.send(
                f"[skip] {raw.symbol_usdt} not listed on Hyperliquid perps"
            )
            return "skipped:unlisted"

        vision_struct = await self.vision_extractor.extract(
            image_path=raw.image_path or "",
            caption=raw.raw_text,
        )
        if not vision_struct or not vision_struct.get("has_chart_data"):
            return None

        levels = vision_struct.get("levels") or {}
        entry = levels.get("entry")
        sl = levels.get("sl")
        tp = levels.get("tp") or []
        support = levels.get("support") or []
        resistance = levels.get("resistance") or []

        # Cross-check vision levels against the LLM text parse of the SAME
        # message. If both produced entry/sl/tp and they diverge a lot, the two
        # independent readers disagree -> hold and alert (never trade a mismatch).
        if llm_signal and llm_signal.get("kind") == "signal":
            lv = {
                "entry": llm_signal.get("entry"),
                "sl": llm_signal.get("sl"),
                "tp": (llm_signal.get("tp") or [None])[0],
            }
            bad = self._levels_diverge(lv, {"entry": entry, "sl": sl, "tp": (tp[0] if tp else None)})
            if bad:
                await self.notifier.send(
                    f"⚠️ [needs_review] image/text conflict for {raw.symbol_usdt or '?'} "
                    f"(msg {raw.message_id}): vision entry={entry}/sl={sl}/tp={tp} vs "
                    f"text entry={lv['entry']}/sl={lv['sl']}/tp={lv['tp']}. Holding."
                )
                return "needs_review:image_text_conflict"

        side = None
        trend = (vision_struct.get("trend") or "").lower()
        if trend in ("uptrend", "up"):
            side = Side.BUY
        elif trend in ("downtrend", "down"):
            side = Side.SELL

        if side is None and resistance and support:
            side = Side.BUY if resistance[-1] > support[-1] else Side.SELL

        if side is None:
            return None

        use_entry = entry if entry is not None else (mark_price or 0.0)
        use_sl = sl if sl is not None else (support[0] if side == Side.BUY and support else None)
        use_tp = tp[0] if tp else (resistance[0] if side == Side.BUY and resistance else None)

        if use_sl is None:
            return None

        instrument = (
            Instrument.from_ticker(ticker) if ticker else Instrument(symbol="UNKNOWN", base="UNKNOWN")
        )
        sig = Signal(
            instrument=instrument,
            side=side,
            entry=use_entry,
            sl=use_sl,
            tp=use_tp,
            notional=UsdNotional(amount_usd=self.risk.margin_to_notional()),
            leverage=self.risk.cfg.default_leverage,
            confidence=0.5,
            raw={"vision": vision_struct},
            source="attachment_scalp",
        )

        try:
            self.validator.validate(sig)
        except Exception as e:
            await self.notifier.send(f"invalid chart signal: {e}")
            await self._safe_notify("rejected", ticker or "?", "validate", str(e))
            return "rejected:validate"

        orders = self.order_svc.build_orders(sig, use_entry)
        if self.cfg.dry_run:
            await self.notifier.send(
                f"[dry-run] chart {sig.side.value} {sig.instrument.symbol} "
                f"entry={use_entry} sl={use_sl} tp={use_tp} lev={sig.leverage} "
                f"orders={len(orders)}"
            )
            await self._safe_order(sig, orders, dry=True)
            return "dry-run"
        for o in orders:
            await self.adapter.place_order(o)
        await self.notifier.send(
            f"chart {sig.side.value} {sig.instrument.symbol} placed ({len(orders)} orders)"
        )
        await self._safe_order(sig, orders, dry=False)
        await self._safe_opened(sig)
        return "placed"

    async def on_position(self, pos: Position) -> None:
        self.positions.apply_position_update(pos)

    # ---- notification helpers (tolerant of plain vs rich notifier) ----
    async def _safe_notify(self, kind: str, symbol: str, stage: str, reason: str) -> None:
        n = self.notifier
        if hasattr(n, "rejected"):
            try:
                await n.rejected(symbol, stage, reason)
                return
            except Exception:
                pass
        await n.send(f"[reject] {symbol or '?'} @ {stage}: {reason}")

    async def _safe_order(self, sig, orders, dry=False) -> None:
        n = self.notifier
        if hasattr(n, "order_placed"):
            try:
                await n.order_placed(
                    sig.instrument.symbol, sig.side.value, len(orders),
                    entry=sig.entry, sl=sig.sl, tp=sig.tp,
                    lev=sig.leverage, dry=dry)
                return
            except Exception:
                pass
        await n.send(
            f"[{'dry-run' if dry else 'live'}] {sig.side.value} "
            f"{sig.instrument.symbol} placed ({len(orders)} orders)")

    async def _safe_opened(self, sig) -> None:
        n = self.notifier
        if hasattr(n, "position_opened"):
            try:
                await n.position_opened(
                    sig.instrument.symbol, sig.side.value,
                    size=0.0, entry=sig.entry or 0.0,
                    lev=sig.leverage, margin=0.0)
            except Exception:
                pass

    async def _safe_mgmt(self, symbol: str, action: str, msg: str, dry=False) -> None:
        n = self.notifier
        if hasattr(n, "management"):
            try:
                await n.management(symbol, action, msg, dry=dry)
                return
            except Exception:
                pass
        await n.send(f"[{'dry-run ' if dry else ''}mgmt] {symbol}: {msg}")

    async def _safe_exc(self, where: str, err: str) -> None:
        n = self.notifier
        if hasattr(n, "exception"):
            try:
                await n.exception(where, err)
                return
            except Exception:
                pass
        await n.send(f"[error] {where}: {err}")

    async def _apply_management(self, raw: RawSignal, mgmt: dict) -> str:
        """Apply a parsed management action to a live position (dry-run safe)."""
        action = mgmt.get("action", "")
        price = mgmt.get("price")
        if action == "partial_close":
            # PositionManager reads the fraction through the ``price`` slot.
            price = mgmt.get("fraction", 0.5)

        # Resolve the message token to a venue ticker so we can find the
        # open position. Falls back to scanning all open positions' tokens.
        token = raw.symbol_usdt or extract_management_token(raw.raw_text or "")
        ticker = await self.resolver.resolve(token) if token else None
        pos = None
        if ticker:
            pos = self.positions.get(ticker)
        if pos is None:
            # Try matching by token substring against open positions.
            for p in self.positions.all():
                if token and token.upper() in (p.instrument.symbol.upper(), p.instrument.base.upper()):
                    pos = p
                    break

        # "cancel $PENGU limit" acts on a RESTING ENTRY ORDER, not a position.
        if action == "cancel_entry":
            if not ticker:
                await self.notifier.send("[mgmt] cancel limit — no symbol, ignored")
                return "management:no_symbol"
            if self.cfg.dry_run:
                await self.notifier.send(f"[dry-run mgmt] cancel resting entry order(s) for {ticker}")
                await self._safe_mgmt(ticker, action, f"cancel entry {ticker}", dry=True)
                return "dry-run:management"
            n = 0
            try:
                for o in await self.adapter.get_open_orders():
                    if o.instrument.symbol.upper() != ticker.upper():
                        continue
                    if getattr(o, "reduce_only", False):
                        continue  # never cancel the protective SL/TP
                    if o.client_order_id:
                        await self.adapter.cancel_order(o.instrument, o.client_order_id)
                        n += 1
            except Exception as e:  # noqa: BLE001
                await self.notifier.send(f"cancel entry failed: {e}")
                await self._safe_exc("cancel_entry", str(e))
                return "management:error"
            await self.notifier.send(f"[mgmt] cancelled {n} resting entry order(s) for {ticker}")
            await self._safe_mgmt(ticker, action, f"cancelled {n} entry order(s)", dry=False)
            return "management"

        if pos is None:
            await self.notifier.send(
                f"[mgmt] {action} for {token or '?'} — no open position, ignored"
            )
            return "management:no_position"

        plan = self.positions.apply_management(pos.instrument.symbol, action, price)
        if not plan["ok"]:
            await self.notifier.send(f"[mgmt] {plan['msg']} (msg {raw.message_id})")
            await self._safe_mgmt(pos.instrument.symbol, action, plan["msg"], dry=False)
            return "management:skip"

        if self.cfg.dry_run:
            await self.notifier.send(
                f"[dry-run mgmt] {plan['msg']} (msg {raw.message_id})"
            )
            await self._safe_mgmt(pos.instrument.symbol, action, plan["msg"], dry=True)
            return "dry-run:management"
        # Live: cancel the old SL order (if any) then place the new plan orders.
        for o in plan["orders"]:
            if o.client_order_id and pos.sl_order_id and o.client_order_id == pos.sl_order_id:
                try:
                    await self.adapter.cancel_order(o.instrument, o.client_order_id)
                except Exception as e:  # noqa: BLE001
                    await self.notifier.send(f"cancel SL failed: {e}")
                    await self._safe_exc("cancel_sl", str(e))
            elif o.size_coin and o.size_coin > 0:
                await self.adapter.place_order(o)
        await self.notifier.send(f"[mgmt] {plan['msg']} (msg {raw.message_id})")
        await self._safe_mgmt(pos.instrument.symbol, action, plan["msg"], dry=False)
        return "management"
