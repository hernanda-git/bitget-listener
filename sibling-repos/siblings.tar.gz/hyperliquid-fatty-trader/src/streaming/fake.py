"""Fake streams for tests — no network. Same surface as the WS streams.

MarketDataStream + UserEventStream equivalents that the test harness drives
manually to simulate pushes.
"""

from __future__ import annotations

from src.domain.model import Fill, Position


class FakeMarketStream:
    def __init__(self, symbols: list[str] | None = None):
        self._marks: dict[str, float] = {}

    def mark_price(self, symbol: str) -> float | None:
        return self._marks.get(symbol)

    async def start(self) -> None:
        pass

    async def stop(self) -> None:
        pass

    def push_mark(self, symbol: str, price: float) -> None:
        self._marks[symbol] = price


class FakeUserStream:
    def __init__(self, on_position=None, on_fill=None):
        self._on_position = on_position
        self._on_fill = on_fill

    async def start(self) -> None:
        pass

    async def stop(self) -> None:
        pass

    def push_position(self, pos: Position) -> None:
        if self._on_position:
            self._on_position(pos)

    def push_fill(self, fill: Fill) -> None:
        if self._on_fill:
            self._on_fill(fill)
