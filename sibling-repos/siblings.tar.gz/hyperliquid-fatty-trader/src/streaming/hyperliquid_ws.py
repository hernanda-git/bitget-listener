"""Hyperliquid websocket streams — market data + user events (zero REST weight).

Per HL docs: `wss://api.hyperliquid.xyz/ws` (testnet: .../ws).
- Public subs: `l2Book`, `allMids`, `bbo`, `trades`, `candle`.
- Private `userEvents` (webData2): after subscribing with the user address, the
  socket pushes positions, orders, and fills in real time. No listenKey/REST-refresh
  dance (unlike Binance) — the ban-prone retry storm cannot happen here.

Both streams reconnect with jittered exponential backoff.
"""

from __future__ import annotations

import asyncio
import json
import random
from typing import Callable

from src.domain.model import Position, Side, Settlement, Instrument, Fill


class MarketDataStream:
    def __init__(self, symbols: list[str], testnet: bool = False, base_ws: str | None = None):
        self._symbols = symbols
        self._ws_url = base_ws or (
            "wss://api.hyperliquid-testnet.xyz/ws" if testnet
            else "wss://api.hyperliquid.xyz/ws"
        )
        self._marks: dict[str, float] = {}
        self._ws = None
        self._task: asyncio.Task | None = None
        self._stop = False

    def mark_price(self, symbol: str) -> float | None:
        return self._marks.get(symbol)

    async def start(self) -> None:
        self._stop = False
        self._task = asyncio.create_task(self._run())

    async def stop(self) -> None:
        self._stop = True
        if self._ws is not None:
            await self._ws.close()
        if self._task:
            self._task.cancel()

    async def _run(self) -> None:
        import websockets
        backoff = 1.0
        while not self._stop:
            try:
                async with websockets.connect(self._ws_url) as ws:
                    self._ws = ws
                    backoff = 1.0
                    # subscribe to allMids (covers every symbol's mid)
                    await ws.send(json.dumps({"method": "subscribe", "subscription": {"type": "allMids"}}))
                    async for msg in ws:
                        if self._stop:
                            break
                        self._on_message(json.loads(msg))
            except Exception:
                if self._stop:
                    break
                await asyncio.sleep(backoff)
                backoff = min(backoff * 2, 30.0) * (0.5 + random.random())

    def _on_message(self, msg: dict) -> None:
        if msg.get("channel") == "allMids":
            mids = msg.get("data", {})
            for sym, px in mids.items():
                try:
                    self._marks[sym] = float(px)
                except (TypeError, ValueError):
                    pass


class UserEventStream:
    def __init__(self, account_address: str, on_position: Callable[[Position], None] | None = None,
                 on_fill: Callable[[Fill], None] | None = None, testnet: bool = False,
                 base_ws: str | None = None):
        self._address = account_address
        self._on_position = on_position
        self._on_fill = on_fill
        self._ws_url = base_ws or (
            "wss://api.hyperliquid-testnet.xyz/ws" if testnet
            else "wss://api.hyperliquid.xyz/ws"
        )
        self._ws = None
        self._task: asyncio.Task | None = None
        self._stop = False

    async def start(self) -> None:
        self._stop = False
        self._task = asyncio.create_task(self._run())

    async def stop(self) -> None:
        self._stop = True
        if self._ws is not None:
            await self._ws.close()
        if self._task:
            self._task.cancel()

    async def _run(self) -> None:
        import websockets
        backoff = 1.0
        while not self._stop:
            try:
                async with websockets.connect(self._ws_url) as ws:
                    self._ws = ws
                    backoff = 1.0
                    await ws.send(json.dumps({
                        "method": "subscribe",
                        "subscription": {"type": "webData2", "user": self._address},
                    }))
                    async for msg in ws:
                        if self._stop:
                            break
                        self._on_message(json.loads(msg))
            except Exception:
                if self._stop:
                    break
                await asyncio.sleep(backoff)
                backoff = min(backoff * 2, 30.0) * (0.5 + random.random())

    def _on_message(self, msg: dict) -> None:
        if msg.get("channel") != "webData2":
            return
        data = msg.get("data", {})
        # positions
        for p in data.get("fills", []):
            if self._on_fill:
                self._on_fill(_fill_from_ws(p))
        clearing = data.get("clearinghouseState") or {}
        for ap in clearing.get("assetPositions", []):
            pos = ap.get("position", {})
            if self._on_position:
                self._on_position(_position_from_ws(pos))


def _position_from_ws(pos: dict) -> Position:
    sym = pos.get("coin", "")
    szi = float(pos.get("szi", "0"))
    return Position(
        instrument=Instrument(symbol=sym, base=sym, quote=Settlement.USDC),
        side=Side.BUY if szi > 0 else Side.SELL,
        size_coin=abs(szi),
        entry_px=float(pos.get("entryPx", 0) or 0),
        leverage=int(float((pos.get("leverage", {}) or {}).get("value", 1))),
        margin_usd=float(pos.get("marginUsed", 0) or 0),
        unrealized_pnl_usd=float(pos.get("unrealizedPnl", 0) or 0),
        liquidation_px=float(pos.get("liquidationPx", 0) or 0) or None,
    )


def _fill_from_ws(f: dict) -> Fill:
    sym = f.get("coin", "")
    return Fill(
        instrument=Instrument(symbol=sym, base=sym, quote=Settlement.USDC),
        side=Side.BUY if f.get("side") == "B" else Side.SELL,
        price=float(f.get("px", 0)),
        size_coin=float(f.get("sz", 0)),
        fee_usd=float(f.get("fee", 0) or 0),
        ts_ms=int(f.get("time", 0)),
    )
