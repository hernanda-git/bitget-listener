"""RiskManager — dynamic, risk-based position sizing.

Pure logic: no IO. Implements the RiskPolicy port.

Sizing philosophy (proper, not hardcoded):
  We risk a FIXED FRACTION of live equity per trade (``risk_pct``), not a fixed
  notional. The position size is derived from the signal's actual stop-loss
  distance, so that hitting the SL loses exactly ``risk_usd``:

      risk_usd      = equity_usd * risk_pct
      sl_distance   = |entry - sl| / entry            (fraction)
      notional_usd  = risk_usd / sl_distance          (full-size to the stop)
      eff_lev       = clamp(notional_usd / free_margin_usd, 1, max_leverage)
      coin_size     = notional_usd / mark_price

  * Tight SL  -> larger position (same $ risk).
  * Wide SL   -> smaller position (same $ risk).
  * Tiny equity -> tiny risk_usd -> tiny positions. Self-scales with the account.

  When a signal omits an SL (can't compute distance), we fall back to a
  conservative default: risk the same $ amount at the default leverage with a
  synthetic 5% stop, so sizing never blows up.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from src.domain.model import UsdNotional


@dataclass
class RiskConfig:
    max_leverage: int = 20
    max_portfolio_usd: float = 1000.0        # total risk budget across positions
    default_leverage: int = 3                  # fallback when SL distance unknown
    risk_pct: float = 0.02                    # risk 2% of live equity per trade
    fallback_sl_pct: float = 0.05            # synthetic 5% stop when signal has no SL
    max_notional_usd: float = 1000.0          # hard cap on a single position notional
    min_notional_usd: float = 10.0            # HL per-order min notional floor;
                                              # if risk-sizing lands below this, notional
                                              # is lifted to the floor and leverage is raised
                                              # (within max_leverage) so margin fits free margin.
                                              # This is the "bump leverage to clear the min-notional
                                              # wall" behaviour the user authorized.
    default_margin_usd: float = 1.0           # legacy; kept for compatibility
    default_notional_usd: float = 100.0       # legacy; kept for compatibility


class RiskManager:
    def __init__(self, config: RiskConfig | None = None):
        self.cfg = config or RiskConfig()

    def compute_size(
        self,
        notional_usd: float,
        mark_price_usdc: float,
        max_leverage: int | None = None,
        equity_usd: float | None = None,
        sl_price: float | None = None,
        free_margin_usd: float | None = None,
        min_notional_usd: float | None = None,
    ) -> tuple[float, int]:
        """Return (coin_size, effective_leverage) sized from real inputs.

        ``notional_usd`` is normally 0 (signal omits size) -> we compute it from
        risk. If a caller passes a real notional, we still cap it to the risk
        limit. ``equity_usd`` is the live account equity (for risk_pct).
        ``sl_price`` is the signal stop; ``free_margin_usd`` caps leverage.
        ``min_notional_usd`` (defaults to ``RiskConfig.min_notional_usd``) is the
        HL per-order minimum notional floor. When the risk-sized notional lands
        below it, the notional is lifted to the floor and leverage is raised
        (within ``max_leverage``) so the required margin (notional/leverage)
        still fits inside ``free_margin_usd``. This is the explicit "bump
        leverage to clear the min-notional wall" behaviour the user authorized.
        """
        if mark_price_usdc <= 0:
            raise ValueError("mark_price must be positive")

        min_notional = min_notional_usd if min_notional_usd is not None else self.cfg.min_notional_usd

        equity = equity_usd if (equity_usd and equity_usd > 0) else max(notional_usd, 1.0)
        risk_usd = equity * self.cfg.risk_pct

        # Determine the stop-loss distance (as a price fraction).
        if sl_price and sl_price > 0 and mark_price_usdc > 0:
            sl_dist = abs(mark_price_usdc - sl_price) / mark_price_usdc
        else:
            sl_dist = self.cfg.fallback_sl_pct

        # Notional sized so that a hit-SL loss equals risk_usd.
        if sl_dist > 0:
            notional = risk_usd / sl_dist
        else:
            notional = risk_usd  # degenerate case: treat as full risk
        notional = min(notional, self.cfg.max_notional_usd)

        # Min-notional floor: lift the notional so HL won't reject the order for
        # being below the per-order minimum. Raise leverage (capped) to keep the
        # required margin within free margin.
        notional = max(notional, min_notional)

        cap = max_leverage or self.cfg.max_leverage

        # Effective leverage: start from the user's intent (default_leverage);
        # raise it only as far as needed to (a) fit margin and (b) stay <= cap.
        eff_lev = int(min(self.cfg.default_leverage, cap))
        if free_margin_usd and free_margin_usd > 0:
            # minimum leverage needed so notional/lev <= free margin
            lev_for_margin = int(-(-notional // free_margin_usd))  # ceil
            eff_lev = int(min(max(eff_lev, lev_for_margin), cap))
        eff_lev = max(1, eff_lev)

        coin_size = notional / mark_price_usdc
        return coin_size, eff_lev

    def margin_to_notional(self, margin_usd: float | None = None) -> float:
        """Legacy helper: margin * default leverage (kept for compatibility)."""
        margin = self.cfg.default_margin_usd if margin_usd is None else margin_usd
        return margin * self.cfg.default_leverage

    def within_budget(self, planned_usd: float, used_usd: float) -> bool:
        return (planned_usd + used_usd) <= self.cfg.max_portfolio_usd
