"""OrderService — translates a validated Signal into Hyperliquid OrderRequests.

Handles:
- entry order (limit at signal price, or market if frontrunned)
- frontrun split: if price is slightly frontrunned vs current mark, enter 25% at
  market immediately + 75% as a limit at the signal price (same SL/TP).
- child SL/TP trigger orders tied to the position (Hyperliquid tpsl).
"""

from __future__ import annotations

import uuid

from src.domain.model import (
    OrderRequest,
    OrderType,
    Signal,
)
from src.services.risk import RiskManager


class OrderService:
    def __init__(self, risk: RiskManager, frontrun_split: bool = True,
                 frontrun_threshold: float = 0.0015, market_frac: float = 0.25,
                 equity_usd: float = 0.0, free_margin_usd: float = 0.0,
                 prefer_maker: bool = True,
                 min_notional_store=None):
        self.risk = risk
        self.frontrun_split = frontrun_split
        self.frontrun_threshold = frontrun_threshold  # 0.15% past signal price
        self.market_frac = market_frac
        self.equity_usd = equity_usd          # live account equity (risk basis)
        self.free_margin_usd = free_margin_usd
        self.prefer_maker = prefer_maker      # post limit (ALO) entries to earn maker rebate
        # Optional MinNotionalStore: per-coin floor lookup; falls back to
        # risk.cfg.min_notional_usd when a coin isn't in the DB.
        self._min_notional_store = min_notional_store

    def min_notional_for(self, symbol: str) -> float:
        """Floor (USD notional) for a coin: DB-backed if available, else config."""
        if self._min_notional_store is not None:
            row = self._min_notional_store.get(symbol)
            if row is not None:
                return float(row["min_notional"])
        return float(self.risk.cfg.min_notional_usd)

    def set_equity(self, equity_usd: float, free_margin_usd: float = 0.0) -> None:
        """Update live equity + free margin so sizing is risk-based & current."""
        self.equity_usd = equity_usd
        self.free_margin_usd = free_margin_usd

    def _oid(self) -> str:
        return uuid.uuid4().hex[:16]

    def build_orders(self, sig: Signal, mark_price: float) -> list[OrderRequest]:
        """Return the list of orders to place for this signal.

        Size is DYNAMIC: risk a fixed % of live equity per trade, derived from the
        signal's actual stop-loss distance (see RiskManager.compute_size)."""
        coin_size, eff_lev = self.risk.compute_size(
            sig.notional.amount_usd, mark_price,
            max_leverage=self.risk.cfg.max_leverage,
            equity_usd=self.equity_usd or sig.notional.amount_usd,
            sl_price=sig.sl,
            free_margin_usd=self.free_margin_usd,
            min_notional_usd=self.min_notional_for(sig.instrument.symbol),
        )
        # reflect the computed (possibly risk-capped or min-notional-bumped) leverage on the signal
        eff_lev = max(1, min(eff_lev, self.risk.cfg.max_leverage))
        sig.leverage = eff_lev
        inst = sig.instrument
        orders: list[OrderRequest] = []

        entry = sig.entry or mark_price
        is_frontrunned = (
            self.frontrun_split
            and sig.entry is not None
            and self._is_frontrunned(sig.side.value, sig.entry, mark_price)
        )

        if is_frontrunned:
            # 25% at market now (urgent fill)
            mkt_size = round(coin_size * self.market_frac, 8)
            orders.append(OrderRequest(
                instrument=inst, side=sig.side, order_type=OrderType.MARKET,
                price=None, size_coin=mkt_size, is_market=True,
                client_order_id=self._oid(),
            ))
            # 75% as limit at signal price (maker when possible)
            lim_size = round(coin_size - mkt_size, 8)
            if lim_size > 0:
                orders.append(OrderRequest(
                    instrument=inst, side=sig.side, order_type=OrderType.LIMIT,
                    price=entry, is_market=False, size_coin=lim_size,
                    post_only=self.prefer_maker, client_order_id=self._oid(),
                ))
        else:
            # Single entry. Prefer a maker (post-only) limit at signal price so we
            # earn the maker rebate instead of paying taker fees. Fall back to
            # market only when no entry price is known (must cross to fill).
            if sig.entry is None:
                orders.append(OrderRequest(
                    instrument=inst, side=sig.side, order_type=OrderType.MARKET,
                    price=None, size_coin=coin_size, is_market=True,
                    client_order_id=self._oid(),
                ))
            else:
                orders.append(OrderRequest(
                    instrument=inst, side=sig.side, order_type=OrderType.LIMIT,
                    price=entry, size_coin=coin_size,
                    is_market=False, post_only=self.prefer_maker,
                    client_order_id=self._oid(),
                ))

        # Child SL/TP trigger orders (Hyperliquid tpsl)
        if sig.sl is not None:
            orders.append(OrderRequest(
                instrument=inst, side=sig.side, order_type=OrderType.TRIGGER,
                price=sig.sl, size_coin=coin_size, reduce_only=True,
                trigger_px=sig.sl, tpsl="sl", is_market=True,
                client_order_id=self._oid(),
            ))
        if sig.tp is not None:
            orders.append(OrderRequest(
                instrument=inst, side=sig.side, order_type=OrderType.TRIGGER,
                price=sig.tp, size_coin=coin_size, reduce_only=True,
                trigger_px=sig.tp, tpsl="tp", is_market=True,
                client_order_id=self._oid(),
            ))
        return orders

    def _is_frontrunned(self, side: str, signal_price: float, mark: float) -> bool:
        if mark <= 0 or signal_price <= 0:
            return False
        if side == "BUY":
            # mark moved UP above signal entry -> frontrunned long
            return (mark - signal_price) / signal_price > self.frontrun_threshold
        else:
            # mark moved DOWN below signal entry -> frontrunned short
            return (signal_price - mark) / signal_price > self.frontrun_threshold
