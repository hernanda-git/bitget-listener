"""Peg sources for USDT->USDC conversion (Dependency Inversion: PegSource port)."""

from __future__ import annotations

from src.interfaces.ports import PegSource


class ConstantPegSource:
    """Safe default: assumes 1 USDT == 1 USDC. Used when no live peg is wired."""

    def __init__(self, rate: float = 1.0):
        self._rate = rate

    async def peg_rate(self) -> float:
        return self._rate
