"""SignalNormalizer — the single USDT->USDC boundary.

Per docs/usdt-usdc-normalization.md, this is the ONLY place that knows about the
Bybit/USDT vs Hyperliquid/USDC mismatch. Everything downstream speaks USDC.
"""

from __future__ import annotations

from src.domain.model import (
    Instrument,
    RawSignal,
    Signal,
    UsdNotional,
    Settlement,
)


class NormalizationError(ValueError):
    pass


class SignalNormalizer:
    def __init__(self, peg_source, max_depeg: float = 0.005):
        # peg_source: object with async peg_rate() -> float (USDC per USDT)
        self._peg = peg_source
        self.max_depeg = max_depeg

    async def normalize(self, raw: RawSignal) -> Signal:
        peg = await self._peg.peg_rate()
        if abs(peg - 1.0) > self.max_depeg:
            raise NormalizationError(
                f"USDT/USDC depeg {peg:.4f} exceeds max {self.max_depeg}"
            )
        # Prefer the venue-resolved ticker; fall back to stripping a USDT pair.
        if raw.symbol:
            inst = Instrument.from_ticker(raw.symbol)
        else:
            inst = Instrument.from_usdt_pair(raw.symbol_usdt)
        return Signal(
            instrument=inst,
            side=raw.side,
            entry=self._cvt(raw.entry_usdt, peg),
            sl=self._cvt(raw.sl_usdt, peg),
            tp=self._cvt(raw.tp_usdt, peg),
            notional=UsdNotional(
                amount_usd=raw.notional_usd * peg, settlement=Settlement.USDC
            ),
            leverage=raw.leverage,
            confidence=raw.confidence,
            raw=dict(raw.raw),
            source=raw.source,
            message_id=raw.message_id,
            peg_rate=peg,
        )

    @staticmethod
    def _cvt(usdt_price: float | None, peg: float) -> float | None:
        if usdt_price is None:
            return None
        return round(usdt_price * peg, 8)
