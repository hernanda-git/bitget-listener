"""SignalValidator — structural + policy checks on a normalized Signal.

The depeg check already happened in SignalNormalizer. Here we enforce: entry/sl/tp
sanity, confidence floor, max age, and side-consistent sl/tp placement.
"""

from __future__ import annotations

from dataclasses import dataclass

from src.domain.model import Signal


class ValidationError(ValueError):
    pass


@dataclass
class ValidationConfig:
    min_confidence: float = 0.5
    max_signal_age_s: int = 300
    require_entry: bool = False       # if True, entry must be present
    require_sl: bool = False          # conservative: SL strongly recommended
    max_leverage: int = 20


class SignalValidator:
    def __init__(self, config: ValidationConfig | None = None):
        self.cfg = config or ValidationConfig()

    def validate(self, sig: Signal) -> Signal:
        if not (0.0 <= sig.confidence <= 1.0):
            raise ValidationError(f"confidence out of range: {sig.confidence}")
        if sig.confidence < self.cfg.min_confidence:
            raise ValidationError(
                f"confidence {sig.confidence} below floor {self.cfg.min_confidence}"
            )
        if sig.leverage > self.cfg.max_leverage:
            raise ValidationError(
                f"leverage {sig.leverage} exceeds cap {self.cfg.max_leverage}"
            )
        if self.cfg.require_entry and sig.entry is None:
            raise ValidationError("entry required but missing")
        if sig.entry is not None:
            if sig.sl is not None:
                self._check_sl(sig)
            if sig.tp is not None:
                self._check_tp(sig)
        return sig

    def _check_sl(self, sig: Signal) -> None:
        entry, sl = sig.entry, sig.sl
        if entry is None or sl is None:
            return
        # SL must be on the losing side of entry
        if sig.side.value == "BUY" and sl >= entry:
            raise ValidationError(f"SL {sl} must be below entry {entry} for BUY")
        if sig.side.value == "SELL" and sl <= entry:
            raise ValidationError(f"SL {sl} must be above entry {entry} for SELL")

    def _check_tp(self, sig: Signal) -> None:
        entry, tp = sig.entry, sig.tp
        if entry is None or tp is None:
            return
        if sig.side.value == "BUY" and tp <= entry:
            raise ValidationError(f"TP {tp} must be above entry {entry} for BUY")
        if sig.side.value == "SELL" and tp >= entry:
            raise ValidationError(f"TP {tp} must be below entry {entry} for SELL")
