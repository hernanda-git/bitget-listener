"""PositionManager — tracks live positions and applies management actions.

Network-free in-memory store. The WS layer (Phase 7) calls ``apply_*`` to update
state; ``reconcile`` replaces the full snapshot (e.g. from clearinghouseState on
reconnect).

``apply_management`` turns a parsed management action (``sl to entry``,
``sl to <price>``, ``close``, ``tp done``) into a concrete order plan that the
orchestrator executes (dry-run logs it; live mode would place the orders). It
never touches the network itself.
"""

from __future__ import annotations

import uuid

from src.domain.model import OrderRequest, OrderType, Position, Side


def _oid() -> str:
    return uuid.uuid4().hex[:16]


class PositionManager:
    def __init__(self) -> None:
        self._positions: dict[str, Position] = {}  # symbol -> Position

    def apply_position_update(self, pos: Position) -> None:
        if pos.size_coin == 0:
            self._positions.pop(pos.instrument.symbol, None)
        else:
            self._positions[pos.instrument.symbol] = pos

    def reconcile(self, positions: list[Position]) -> None:
        self._positions = {p.instrument.symbol: p for p in positions if p.size_coin != 0}

    def get(self, symbol: str) -> Position | None:
        return self._positions.get(symbol)

    def all(self) -> list[Position]:
        return list(self._positions.values())

    def has(self, symbol: str) -> bool:
        return symbol in self._positions

    # ------------------------------------------------------------------ #
    def apply_management(self, symbol: str, action: str, price: float | None = None) -> dict:
        """Apply a management action to the open position for ``symbol``.

        Returns a plan dict:
            {"ok": bool, "action": str, "orders": [OrderRequest...], "msg": str}
        The orchestrator decides whether to actually place the orders (dry-run
        vs live). This method only mutates the in-memory SL when the plan is
        accepted (``ok`` True).
        """
        pos = self._positions.get(symbol)
        if pos is None:
            return {"ok": False, "action": action, "orders": [],
                    "msg": f"no open position for {symbol}"}

        orders: list[OrderRequest] = []
        inst = pos.instrument

        if action in ("sl_to_entry", "sl_be"):
            # Move stop to entry (breakeven). Cancel old SL, place new at entry.
            if pos.sl_order_id:
                orders.append(OrderRequest(  # cancel is expressed via adapter.cancel_order
                    instrument=inst, side=pos.side, order_type=OrderType.TRIGGER,
                    price=pos.sl_px, size_coin=0.0, reduce_only=True,
                    trigger_px=pos.sl_px, tpsl="sl",
                    client_order_id=pos.sl_order_id,
                ))
            new_sl = pos.entry_px
            new_oid = _oid()
            orders.append(OrderRequest(
                instrument=inst, side=pos.side, order_type=OrderType.TRIGGER,
                price=new_sl, size_coin=pos.size_coin, reduce_only=True,
                trigger_px=new_sl, tpsl="sl", is_market=True,
                client_order_id=new_oid,
            ))
            pos.sl_px = new_sl
            pos.sl_order_id = new_oid
            return {"ok": True, "action": action, "orders": orders,
                    "msg": f"SL moved to entry {new_sl} for {symbol}"}

        if action == "sl_to":
            if price is None:
                return {"ok": False, "action": action, "orders": [],
                        "msg": "sl_to requires a price"}
            if pos.sl_order_id:
                orders.append(OrderRequest(
                    instrument=inst, side=pos.side, order_type=OrderType.TRIGGER,
                    price=pos.sl_px, size_coin=0.0, reduce_only=True,
                    trigger_px=pos.sl_px, tpsl="sl",
                    client_order_id=pos.sl_order_id,
                ))
            new_oid = _oid()
            orders.append(OrderRequest(
                instrument=inst, side=pos.side, order_type=OrderType.TRIGGER,
                price=price, size_coin=pos.size_coin, reduce_only=True,
                trigger_px=price, tpsl="sl", is_market=True,
                client_order_id=new_oid,
            ))
            pos.sl_px = price
            pos.sl_order_id = new_oid
            return {"ok": True, "action": action, "orders": orders,
                    "msg": f"SL moved to {price} for {symbol}"}

        if action == "tp_hit":
            # Take-profit / booking-profits reached: close the position at market.
            close_side = Side.SELL if pos.side == Side.BUY else Side.BUY
            orders.append(OrderRequest(
                instrument=inst, side=close_side, order_type=OrderType.MARKET,
                price=None, size_coin=pos.size_coin, reduce_only=True,
                is_market=True, client_order_id=_oid(),
            ))
            return {"ok": True, "action": action, "orders": orders,
                    "msg": f"TP/booking-profits -> close {symbol} at market"}

        if action == "manage":
            # Loose "manage your trade / up 1R" nudge: trail the SL to halfway
            # between the current SL and entry to lock in profit, if SL is
            # currently below entry (long) or above (short).
            if pos.sl_px is None:
                return {"ok": False, "action": action, "orders": [],
                        "msg": f"no SL to trail for {symbol}"}
            new_sl = (pos.sl_px + pos.entry_px) / 2.0
            # Only trail inward (never loosen risk).
            if pos.side == Side.BUY and new_sl <= pos.sl_px:
                return {"ok": False, "action": action, "orders": [],
                        "msg": f"SL already at/above trail point for {symbol}"}
            if pos.side == Side.SELL and new_sl >= pos.sl_px:
                return {"ok": False, "action": action, "orders": [],
                        "msg": f"SL already at/below trail point for {symbol}"}
            if pos.sl_order_id:
                orders.append(OrderRequest(
                    instrument=inst, side=pos.side, order_type=OrderType.TRIGGER,
                    price=pos.sl_px, size_coin=0.0, reduce_only=True,
                    trigger_px=pos.sl_px, tpsl="sl",
                    client_order_id=pos.sl_order_id,
                ))
            new_oid = _oid()
            orders.append(OrderRequest(
                instrument=inst, side=pos.side, order_type=OrderType.TRIGGER,
                price=new_sl, size_coin=pos.size_coin, reduce_only=True,
                trigger_px=new_sl, tpsl="sl", is_market=True,
                client_order_id=new_oid,
            ))
            pos.sl_px = new_sl
            pos.sl_order_id = new_oid
            return {"ok": True, "action": action, "orders": orders,
                    "msg": f"SL trailed to {new_sl} for {symbol}"}

        if action == "close_at_entry":
            # "close pump at entry" -> flatten the whole position with a
            # reduce-only LIMIT at the entry price (breakeven exit).
            close_side = Side.SELL if pos.side == Side.BUY else Side.BUY
            orders.append(OrderRequest(
                instrument=inst, side=close_side, order_type=OrderType.LIMIT,
                price=pos.entry_px, size_coin=pos.size_coin, reduce_only=True,
                is_market=False, client_order_id=_oid(),
            ))
            return {"ok": True, "action": action, "orders": orders,
                    "msg": f"close {symbol} at entry {pos.entry_px} (breakeven)"}

        if action == "partial_close":
            # "book profits on $ONDO" -> the signal never states a fraction;
            # default to half, at market, reduce-only.
            frac = price if price and 0 < price < 1 else 0.5
            size = round(pos.size_coin * frac, 8)
            if size <= 0:
                return {"ok": False, "action": action, "orders": [],
                        "msg": f"partial size resolves to 0 for {symbol}"}
            close_side = Side.SELL if pos.side == Side.BUY else Side.BUY
            orders.append(OrderRequest(
                instrument=inst, side=close_side, order_type=OrderType.MARKET,
                price=None, size_coin=size, reduce_only=True,
                is_market=True, client_order_id=_oid(),
            ))
            return {"ok": True, "action": action, "orders": orders,
                    "msg": f"book profits: close {frac:.0%} ({size}) of {symbol} at market"}

        if action == "sl_hit":
            # Exchange already closed us; nothing to send. Drop local state.
            self._positions.pop(symbol, None)
            return {"ok": True, "action": action, "orders": [],
                    "msg": f"SL hit on {symbol} — position closed by exchange, state cleared"}

        if action == "close":
            close_side = Side.SELL if pos.side == Side.BUY else Side.BUY
            orders.append(OrderRequest(
                instrument=inst, side=close_side, order_type=OrderType.MARKET,
                price=None, size_coin=pos.size_coin, reduce_only=True,
                is_market=True, client_order_id=_oid(),
            ))
            return {"ok": True, "action": action, "orders": orders,
                    "msg": f"close {symbol} at market"}

        return {"ok": False, "action": action, "orders": [],
                "msg": f"unknown management action {action}"}
