# AGENTS.md — operating manual for AI agents working on this repo

**Read this file before touching anything.** It is the contract for agents
(Claude Code, Codex, Hermes, OpenCode) working on `hyperliquid-fatty-trader`.
`CLAUDE.md` is a symlink to this file.

This bot **trades real money on Hyperliquid mainnet right now.** A careless change
here loses funds. The rules below are not style preferences.

---

## 1. What this is

An autonomous trading system that ingests trade signals from the Telegram channel
`@fattyfatclub` (titled *UNKNOWN TRADERS ACADEMY*, id `1252615519` — the odd title
is expected and confirmed correct) and executes them on **Hyperliquid USDC perps**.

Signals arrive as USDT-quoted calls; execution is USDC-settled. That mismatch is
handled in one audited place (`SignalNormalizer`), never ad hoc.

---

## 2. Hard safety rules (non-negotiable)

1. **Never place a real order to prove something works.** Use dry-run, the replay
   scripts, or testnet. There is no acceptable reason to send a live order as a test.
2. **The paper/live mode is a persisted `paper` flag in the config DB**, not a
   config-file default. `paper=1` == dry-run (no real orders); `paper=0` == live
   (real money). The user's `/toggle` chat command flips it and the new value is
   written back to the DB so it survives restarts. **Do not hard-code a bot's mode
   in code or assume it boots safe.** Always read the DB row before acting.
3. **Secrets live only in git-ignored `.env`.** Never echo a private key or token
   into chat/logs, never commit one. Verify with `git check-ignore .env`.
4. **A pasted crypto private key is permanently compromised** — keys cannot be
   rotated. Advise sweeping funds to a fresh wallet; never reuse the key.
5. **Never cancel `reduce_only` orders** when cancelling entries. Those are the
   protective SL/TP. Losing them turns a bounded loss into an unbounded one.
6. **Exactly one listener per Telegram bot token.** Each bot instance polls its
   own `TG_BOT_TOKEN`; two processes sharing a token get a `Conflict` getUpdates
   error and double-send alerts / can double-trade. `--all-bots` spawns one child
   process per enabled bot (each with a distinct token env var). Verify one process
   per bot after every deploy.

---

## 3. Environment (VPS "Sera")

- Repo: `~/workspace/repos/hyperliquid-fatty-trader`
- **Interpreter:** `/usr/local/lib/hermes-agent/venv/bin/python3` — the system
  `python3` lacks `telethon` and must not be used for TG scripts.
- Run modes:
  - `python3 -m src.main` — safe testnet connectivity check, zero orders
  - `python3 -m src.main --check-tg` — verify TG session + channel reach
  - `python3 -m src.main --live-dry` — real TG source, dry-run only (SAFE: hard
    coded testnet + dry-run, can never place a real order)
  - `python3 -m src.main --dashboard` — run the DEFAULT bot (`fatty-main`) — production
  - `python3 -m src.main --bot NAME` — run a specific bot from the config DB
  - `python3 -m src.main --all-bots` — launch every enabled bot as its own process
- Config is **DB-backed and multi-bot**: PostgreSQL `fatty_config` (`src/config/db.py`,
  `ConfigStore`) holds one row per bot (`paper`, `channel`, `testnet`, token env
  var, risk). Secrets (key, token) stay in `.env`. Create/manage bots with the
  config tool: `python3 scripts/configure_bot.py --name X --paper --channel ...`.
- Tests: `python3 -m pytest -q` (87 passing as of v0.1.10)
- `ModuleNotFoundError: No module named 'hyperliquid'` is **expected and
  harmless** — the adapter uses raw `httpx` + `websockets`. Do not `pip install
  hyperliquid`.

---

## 3b. Configuration is a PostgreSQL DB (multi-bot, externally accessible)

`fatty_config` is a **PostgreSQL 16** database running on the VPS ("Sera"), bound
to `0.0.0.0:5432`. It is a real client/server DB (not SQLite), so the config is
reachable from **outside the box** — your laptop, another container, or a
dashboard — over TCP, not trapped inside one filesystem.

`src/config/db.py` (`ConfigStore`) holds one row per bot:

| Column | Meaning |
|---|---|
| `name` | unique bot id (e.g. `fatty-main`) |
| `enabled` | 1 = launched by `--all-bots` |
| `paper` | **1 = dry-run (no real orders), 0 = LIVE (real money)** |
| `channel` | signal source channel (e.g. `fattyfatclub`) |
| `testnet` | 1 = HL testnet, 0 = mainnet |
| `tg_bot_token_env` | env var holding THIS bot's TG bot token |
| `tg_bot_chat_env` | env var holding THIS bot's alert-chat id |

A companion `risk` table holds per-bot sizing. **Secrets are never in this DB**
— only env-var *names*. The connection string lives in `.env` as `CONFIG_DB_URL`
(non-superuser `app` role, strong password). The `ConfigStore` opens one fresh
connection per operation (safe under asyncio; see the python-sqlite-async skill).

**Durable signal/trade ledger (same `fatty_config` DB, no SQLite files).**
The bot now records everything needed for later evaluation, all in Postgres so
it is queryable from outside the VPS:

| Table | What it stores |
|---|---|
| `signals_log` | every signal received (symbol, side, source, message_id, **raw_text**, status) |
| `trades_log` | every order/position: open (entry/sl/tp/lev/size/margin) and close (exit_px, **pnl**, close_reason, dry flag) |
| `bias_log` | market-bias calls from the source (was a local `data/bias.db` SQLite file — **migrated to Postgres**, no more SQLite anywhere) |

`src/store/ledger.py` (`Ledger`) is the signal/trade writer; the `BotDashboard`
notifier owns the writes (it is the single chokepoint for every pipeline event,
so the ledger stays in sync with the chat alerts). `/trades` reports the ledger
(win rate, net P&L, recent closes); `/bias` reports `bias_log`. Both `Ledger` and
`BiasRecorder` read `CONFIG_DB_TEST_URL` when set (tests) else `CONFIG_DB_URL`.

Manage bots with `scripts/configure_bot.py` (creates/updates rows). `/toggle` in
the chat flips `paper` and persists it.

**External access:** Postgres listens on all interfaces and UFW allows 5432. To
reach it from outside the VPS you must also open inbound 5432 in your provider's
**Security Group / edge firewall** (Tencent/Alibaba-style console) — that is
outside the OS. Use the `app` role (scoped to `fatty_config` only, md5).

---

## 4. Documentation contract (how history is kept)

| File | Role |
|---|---|
| `CHANGELOG.md` | **Canonical historical record.** Every behavior change, with the OLD behavior stated. |
| `AGENTS.md` / `CLAUDE.md` | This file — how to work here, and the invariants. |
| `ARCHITECTURE.md` | SOLID layer map and module responsibilities. |
| `README.md` | Human-facing project overview. |
| `docs/` | Deep dives: token audit, local vision, signal format, normalization. |
| `VERSION` | Deployed semver, reported in health checks. |

**Rule: any behavior change requires a `CHANGELOG.md` entry in the same commit.**
`./deploy.sh` enforces this — it blocks the deploy if `## [Unreleased]` is empty
and blocks if tests fail. Write the entry under `## [Unreleased]`; deploy promotes
it to a dated version section automatically.

When you record a change, **state what the behavior was before.** The changelog's
job is to stop a future agent from re-introducing a fixed bug.

---

## 5. The golden rule: validate against REAL data

Unit tests pass while the live path crashes. This has bitten us repeatedly:

- `_apply_management` used `extract_token` without importing it -> `NameError` on
  every live `sl to entry`. Tests were green.
- `VisionExtractor.extract` passed an undefined `config` -> `NameError` on every
  chart image. Tests were green.

**Before claiming any signal-handling feature works, replay real data through the
real orchestrator:**

```bash
python3 scripts/replay_real.py   # 100 real messages + 12 real chart images
python3 scripts/replay_mgmt.py   # real management messages, seeded positions
```

Fixtures: `docs/channel_sample.json`, `data/samples/*.jpg`.

---

## 6. Signal reality (do not design against assumptions)

**The signal is the source of truth. Never invent levels it did not state.**

Real full trade call format:

```
#BONK $BONK LONG TRADE
ENTRY: 0.002472
TARGET: 0.002615
STOPLOSS: 0.002402
```

- **There is exactly ONE target. Multi-TP does not exist in this channel** (0 of 11
  captured calls had multiple TPs). Scale-out was deliberately rejected — see
  CHANGELOG 0.1.8. Do not build it without new channel evidence.
- No leverage field; a configured default applies.
- The channel's risk management is *one target, then move SL to breakeven*.

Management messages and their actions (`src/sources/parser.py`):

| Message | Action | Effect |
|---|---|---|
| `sl to entry $ONDO`, `move sl to breakeven` | `sl_to_entry` / `sl_be` | cancel old SL, place new at entry |
| `close pump at entry` | `close_at_entry` | reduce-only LIMIT at entry |
| `book profits on $ONDO` | `partial_close` | reduce-only MARKET, **50% (our default, not stated by the signal)** |
| `cancel PENGU limit` | `cancel_entry` | cancel resting entry orders only |
| `sl hit on XAI` | `sl_hit` | no orders; clear local state |
| `$KAITO ... manage your trade` | `manage` | trail SL halfway toward entry, inward only |
| `full tp done` | `tp_hit` | close at market |

**Branch ordering in `parse_management` is load-bearing:** the specific actions
(`cancel_entry`, `sl_hit`, `close_at_entry`, `partial_close`) must be checked
*above* the generic `sl to entry` / `close` branches, or they get swallowed.

**Symbols are not 1:1.** `$TOKEN` resolves via exact match, then `k`-prefix
(`BONK` -> `kBONK`), else the token is unlisted and must be skipped. There is **no
`1000*` prefix on Hyperliquid** (that is a Binance-ism) and **max leverage anywhere
on the venue is 40x** — there are no 1000x contracts.

---

## 7. Sizing

Sizing is **risk-based, not fixed**. Every trade risks `equity × risk_pct` (2%),
sized from the signal's actual stop-loss distance. The risk parameters live in
`src/services/risk.py` (`RiskConfig`), applied per bot from the config DB `risk`
table (`ConfigStore.get_risk`). The old `risk:` block in `config.yaml` is **not**
read for sizing. Leverage is the margin multiplier we request
(`default_leverage`, 3); do not derive it from `notional / free_margin`, which
collapses to 1x on small positions (fixed in 0.1.7).

---

## 8. Known pitfalls (each one cost a debugging session)

- **`pkill -f "src.main --dashboard"` self-kills the shell** — the command's own
  line matches the pattern. Collect pids with `pgrep` and kill explicitly, or
  break the literal with `src[.]main`.
- **Any handler in `state.handlers` must be `async def`** — `bot.py` awaits them.
  A sync handler fails with `object NoneType can't be used in 'await' expression`
  and the action silently does nothing.
- **sqlite3 + asyncio:** open a fresh connection per operation and close it in
  a `finally`, or you get `Cannot operate on a closed database` on Python 3.11+.
  Same rule for PostgreSQL (`psycopg`): one `connect()` per operation.
- **Slash menu blank?** `bot.set_my_commands()` must be called at startup;
  registering handlers is not enough.
- **`parse_bias` must require the literal word "bias"** — a looser match swallowed
  chart captions like `$BTC range identified` so they were never traded.
  Guard: `tests/test_media_routing.py`.
- **Stale tests encode old behavior.** When you intentionally change a contract,
  update the test to the new semantics. Do **not** revert correct code to make an
  outdated assertion pass.
- **A valid-format API key is not proof of quota.** Probe with
  `scripts/verify_vision_key.py`; free-tier vision quota is exhausted.
- **Spot and perp are different balances.** `clearinghouseState` (perp) can read
  `0.0` while `spotClearinghouseState` holds funds. On a unified account, spot
  USDC *is* the perp margin and no transfer is needed.
- **Never confuse `usdClassTransfer` (internal spot<->perp) with `spotSend`**
  (external address). Confusing them pushes funds out of the wallet.

---

## 9. Workflow for a change

1. Read this file and the relevant `CHANGELOG.md` entries.
2. Make the change; keep modules single-responsibility (see `ARCHITECTURE.md`).
3. `python3 -m pytest -q` — all green.
4. Replay real data (`scripts/replay_real.py`, `scripts/replay_mgmt.py`).
5. Write the `## [Unreleased]` changelog entry, stating the old behavior.
6. `./deploy.sh` (guards run tests + changelog, restarts, health-checks).
7. Commit and push:
   ```bash
   GIT_CONFIG_COUNT=1 \
   GIT_CONFIG_KEY_0='credential.https://github.com.helper' \
   GIT_CONFIG_VALUE_0='!/usr/bin/gh auth git-credential' \
   git push origin HEAD:main
   ```
8. Confirm exactly one dashboard process is running.

---

## 10. Communication with the user (Hernanda)

- Non-technical about implementation: **execute the work end-to-end**, don't hand
  back instructions to run things himself.
- Prefers the **simplest viable control surface** — one command, one switch. Don't
  add tokens, flags, or confirmation steps he didn't ask for.
- Do not use em dashes; use backticks for emphasis and code terms.
- He may relax security ("no need to worry"). **The safety rules in section 2
  still apply** — execute the mechanics, keep the guardrails.
