#!/usr/bin/env python3
"""
Auth for Learnernoearner Listener.
Usage: TG_API_ID=... TG_API_HASH=... python auth.py +62xxxxxxxxxx
Reads Telegram API credentials from the environment (or .env), never hardcoded.
"""

import asyncio
import os
import sys
from telethon import TelegramClient
from pathlib import Path

API_ID = int(os.getenv("TG_API_ID", "0"))
API_HASH = os.getenv("TG_API_HASH", "")
SESSION_DIR = Path(__file__).parent / "sessions"
SESSION_DIR.mkdir(exist_ok=True)

async def main(phone):
    if not API_ID or not API_HASH:
        print("Set TG_API_ID and TG_API_HASH in the environment first.")
        sys.exit(1)
    client = TelegramClient(str(SESSION_DIR / "learnernoearner"), API_ID, API_HASH)
    await client.start(phone=phone)
    me = await client.get_me()
    print(f"\nAuthenticated as: {me.first_name} (ID: {me.id})")
    print("Session saved. You can now run: python src\\listener.py")
    await client.disconnect()

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python auth.py +62xxxxxxxxxx")
        sys.exit(1)
    asyncio.run(main(sys.argv[1]))
