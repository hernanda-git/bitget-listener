# AGENTS.md — learnernoearner-listener

> **An AI agent's complete guide to this project.**
> Read this _before_ making any changes. It covers architecture, conventions, known traps, and workflows.

---

## 📌 Identity Card

```
Project    : learnernoearner-listener
What       : Real-time Telegram signal → LLM analysis → automated Binance Futures trading
Owner      : valarion
Channel    : @fattyfatclub (UNKNOWN TRADERS ACADEMY)
Exchange   : Binance USDⓈ-M Futures (mainnet)
LLM        : mindai/macaron-v1-tall via opengateway.gitlawb.com
Fallback   : nvidia/nemotron-3-ultra-550b-a55b:free
Deployed   : Tencent Lighthouse VPS "sera" (43.157.208.115, ap-jakarta)
Version    : v110 (2026-07-27)
Status     : 🚀 YOLO auto-trade ($1.00 port, 10% risk, 10 concurrent, ISOLATED)
```

---

## 🏗 Architecture

### Pipeline Flow

```mermaid
flowchart TB
    subgraph Telegram
        TC[fattyfatclub Channel]
        TB[Bot Notifications]
    end
    subgraph Bot
        L[listener.py<br/>Telethon + Bot API]
        O[orchestrator.py<br/>Pipeline Coordinator]
        PM[position_manager.py<br/>10s Monitor Loop]
        API[FastAPI :9090<br/>API Bridge]
    end
    subgraph Processing
        P[parser.py<br/>Regex 1ms]
        G1[Gate 1<br/>Pre-LLM Safety]
        AG[agent.py<br/>LLM Brain]
        G2[Gate 2<br/>Hard Clamps]
        OS[order_service.py<br/>Execute]
    end
    subgraph Storage
        DB[(SQLite<br/>/data/trades.db)]
    end
    subgraph External
        BIN[Binance Futures]
    end
    TC --> L --> O
    O --> P --> G1 --> AG --> G2 --> OS --> BIN
    O --> PM --> DB
    OS --> DB --> TB
    API --> DB
```

### Directory Layout

```
src/
├── main.py                      # Entry point — wires everything
├── orchestrator.py              # Pipeline coordinator (signal → LLM → execute)
├── listener.py                  # Telethon listener + Telegram bot commands
├── version.py                   # Current version string
│
├── agent/                       # AI brain
│   ├── parser.py                # Regex pre-parse (~1ms)
│   ├── agent.py                 # LLM brain (macaron-v1-tall via opengateway)
│   └── gate.py                  # Safety Gates 1 (pre-LLM) & 2 (post-LLM)
│
├── exchange/                    # Exchange adapters
│   ├── base.py                  # Abstract Exchange ABC
│   ├── binance.py               # Binance REST API (~1376 lines)
│   ├── paper.py                 # Paper trading simulator
│   ├── validation.py            # Pre-submission order validation
│   └── symbol_registry.py       # Dynamic symbol cache via exchangeInfo
│
├── execution/                   # Trade execution
│   ├── order_service.py         # Decision → exchange order + SL/TP
│   └── position_manager.py      # Background monitoring loop
│
├── state/                       # Persistence
│   ├── database.py              # SQLite: connection, schema, migrations
│   └── repositories.py          # Repository pattern (11 repos)
│
├── api/                         # HTTP API bridge
│   ├── server.py                # FastAPI server (15+ endpoints)
│   ├── auth.py                  # API key + HMAC + rate limiter
│   └── webhook.py               # Trade event webhook emitter
│
├── domain/models.py             # Typed dataclasses (12 models)
├── events/bus.py                # In-process pub/sub event bus
├── health/reporter.py           # Periodic 6h health checks
├── notifier/telegram.py         # Bot API notifications (Markdown-safe)
└── config/loader.py             # YAML + .env merger
```

---

## 📐 Code Conventions

### Async Everywhere
- **All** I/O is `async def` — use `httpx.AsyncClient`, never sync
- `await` every HTTP call, DB call, exchange method
- Never block the event loop

### Domain Models
- `TradeSignal` — raw parsed signal (frozen dataclass)
- `TradeDecision` — LLM output (frozen, includes leverage)
- `Position` — mutable (state changes over time)
- `ExecutionResult`, `OrderInfo`, `BalanceInfo` — exchange responses

### Error Handling
| Error | Category | Action |
|-------|----------|--------|
| Binance 401/403 | `AUTH` | Fail-fast, don't retry |
| Binance 429 | `RATE_LIMIT` | Retry with backoff |
| Binance 5xx | `SERVER` | Retryable |
| Network errors | `NETWORK` | Return `PENDING` |
| Order failure | `OrderInfo(status="FAILED")` | Always return, never crash |

### Datetime Standard
- **Always** `datetime.now(timezone.utc)` — NEVER `datetime.utcnow()`
- SQLite stores UTC via `CURRENT_TIMESTAMP`
- All model default factories: `lambda: datetime.now(timezone.utc)`

### Gate Safety Philosophy
- **Gate 1** (pre-LLM): cheap saves — idempotency, whitelist, cooldown, media filter
- **Gate 2** (post-LLM): hard clamps — size, leverage, daily loss, portfolio cap
- Gate 2 runs ONLY for `ENTER` decisions
- **SL direction check**: Gate 2 only — LONG sl < entry, SHORT sl > entry

### Management Commands (Skip LLM)
| Pattern | Action | Handler |
|---------|--------|---------|
| `sl to entry` / `breakeven` | Move SL to entry price | `_handle_management()` |
| `tp1 booked` / `partial` | Close 50% → SL to entry → TP remainder | `_handle_tp1_booked()` |
| `closed at entry` / `cutting` / `full` | Full market close | `_handle_full_close()` |
| `tp1 <price>` / `tp2 <price>` | Modify TP level | `_handle_management()` |

### Correlation ID Tracing
- Every pipeline run gets a `correlation_id` (12-char hex)
- Flows through: signal → decision → order → position → trade_logs → position_events
- Query: `SELECT * FROM trade_logs WHERE correlation_id = ?`

---

## 🐛 Known Pitfalls (MUST READ)

| Pitfall | Symptom | Fix |
|---------|---------|-----|
| **Binance -4120** | `Order type not supported` | Conditional orders blocked for this pair. **SL: price-monitored by position manager. TP: LIMIT fallback** in Basic tab. Algo API endpoint returns 404 (URL wrong for mainnet). |
| **StepSize rounding failure** | `-1111 Precision error` | Fix: `_enter_position()` now uses `exchange._round_quantity()` as PRIMARY rounding path. Falls back manually if that fails. `validate_order()` 3x threshold. |
| **Orphaned position after modify** | Orders cancelled but new SL/TP not placed | Fix v109: `_modify_position()` saves old SL/TP before cancelling, restores on failure. Self-heal now retries with 60s cooldown. |
| **1000x contract scale** | BONK → 1000BONKUSDT | `SymbolRegistry` auto-maps. Quantity is integer (stepSize=1). Min notional = $5. |
| **Edited Telegram messages** | Duplicate signals | `signal_repo.claim(message_id)` blocks re-processing. |
| **LLM returns text not JSON** | Parse error | `response_format: {"type": "json_object"}` enforced. 3 fallback parsers. |
| **HMAC signing mismatch** | POST 401 | Client and server must have same `API_HMAC_SECRET`. |
| **Rate limited (API bridge)** | 429 | 30 req/min/IP — wait 60s or reduce frequency. |
| **DB migration skipped columns** | New columns NULL | Safe — `_run_migrations()` uses try/except for ALTER TABLE. |
| **Webhook not set** | Events not pushed | Set `WEBHOOK_URL` env var. Fire-and-forget, non-blocking. |
| **Health report markup error** | Telegram "can't parse entities" | All dynamic fields escaped with `_md_escape()`. |
| **Uvicorn fails to start** | API not available | Port conflict. Bot continues without API. |
| **KAITOUSDT orphaned** | 30h+ no SL/TP orders | Fix v109: self-heal now retries via 60s cooldown + reset `_protection_placed`. |

### ⚠️ -4120 Contract Quirks
Binance rejects `STOP`/`TAKE_PROFIT` conditional orders for some pairs:
```
PUMPUSDT, KAITOUSDT, AAVEUSDT → -4120 on conditional endpoints
```
**Fallback behavior (v109+):**
- **SL**: No exchange order. Position manager polls mark price every 10s. `current ≤ sl_price (LONG)` → market close.
- **TP**: Resting `LIMIT` order in Basic tab at the TP price (not Conditional).
- **Algo API**: `/fapi/v1/algo/order` returns 404 on mainnet — the endpoint URL is wrong for this account/bucket. Falls through to the fallback above.

---

## 🔧 Agentic Workflows

### 1. Health Check
```bash
cd /opt/bots
docker compose ps
docker logs bots-listener -n 20
curl -s -o /dev/null -w "HTTP %{http_code}\n" http://localhost:9090/health
```

### 2. Live Debug via Docker Exec
```bash
cd /opt/bots
docker compose exec bots-listener python3 -c "
import asyncio, os, sys
sys.path.insert(0,'/app')
from src.exchange.binance import BinanceExchange
from src.config.loader import load_config
cfg = load_config()
bc = cfg['exchange']['binance']
e = BinanceExchange(os.environ.get(bc['api_key_env']), os.environ.get(bc['api_secret_env']), testnet=False, futures=True)
async def r():
    ps = await e.get_positions()
    for p in ps:
        if p.size > 0: print(f'{p.symbol}: {p.direction} size={p.size} entry={p.entry_price}')
asyncio.run(r())
"
```

### 3. Deploy New Version
```bash
cd /opt/bots/listener/src

# Verify
python3 -m py_compile src/*.py src/**/*.py && echo "compile OK"

# Bump version
python3 scripts/bump_version.py

# Commit + push
git add -A
git commit -m "description"
git push origin listener-local

# Rebuild and restart
cd /opt/bots
docker compose up -d --build bots-listener

# Verify live
sleep 5
curl -s -o /dev/null -w "HTTP %{http_code}\n" http://localhost:9090/health
docker compose ps bots-listener
```

### 4. Debug Failed Trade
```bash
cd /opt/bots
docker compose exec bots-listener python3 -c "
import sqlite3; c=sqlite3.connect('/data/trades.db')
for r in c.execute('SELECT substr(created_at,1,19),level,substr(message,1,200) FROM trade_logs ORDER BY id DESC LIMIT 5'): print(r)
"

# Full pipeline trace via API
curl -s -H "X-API-Key: *** " http://localhost:9090/api/v1/logs/{correlation_id}
```

### 5. Pipeline Trace via Correlation ID
Every run generates a correlation_id. Full trace:
```bash
curl -s -H "X-API-Key: *** " http://localhost:9090/api/v1/logs/{correlation_id}
# Returns: structured logs + signal + decision + positions for that run
```

### 6. Post-Mortem Flow
1. `GET /api/v1/trades/{id}` — full trade with LLM interaction + position events
2. Check `trade_logs[]` for ERROR entries
3. Examine `llm_interaction.user_prompt` — see what the LLM was told
4. Compare with `config_snapshot` — what risk settings were active

---

## ⚙️ Config Reference

See [`config.yaml`](config.yaml) for all settings. Key highlights:

| Key | Default | Description |
|-----|---------|-------------|
| `exchange.active` | `paper` | `paper`, `binance`, `binance_testnet` |
| `risk.max_position_size_usdt` | `$1.00` | Margin budget per trade (port_usdt) |
| `risk.risk_per_trade_percent` | `10%` | % of balance to risk per trade |
| `risk.max_concurrent_positions` | `10` | Max open positions at once |
| `risk.max_leverage` | `20×` | Ceiling for dynamic leverage |
| `risk.port_usdt` | `$1.00` | Margin budget per trade |
| `risk.margin_type` | `ISOLATED` | ISOLATED or CROSSED |
| `agent.auto_trade` | `true` | YOLO mode — enable real trading |
| `agent.llm.model` | `mindai/macaron-v1-tall` | LLM model via opengateway.gitlawb.com |
| `monitoring.check_interval_seconds` | `10` | Position manager loop interval |

---

## 📦 Deployment

**Host:** Tencent Lighthouse VPS "sera" (43.157.208.115, ap-jakarta, Ubuntu 24.04)
**Stack:** Docker Compose — 4 containers: `bots-listener` (:9090), `bots-gateway` (:8000), `bots-wsproxy` (:8888), `bots-caddy` (:80)

### Secrets Required
```
TELEGRAM_BOT_TOKEN, NOTIFY_CHAT_ID
BINANCE_API_KEY, BINANCE_API_SECRET
GITLAWB_API_KEY
TG_API_ID, TG_API_HASH, SESSION_STRING
CHANNEL_USERNAME
API_KEY, API_HMAC_SECRET (for HTTP bridge)
```

### Persistent Data
| Path | Content |
|------|---------|
| `/data/trades.db` | SQLite (14 tables) |
| `/data/sessions/` | Telethon session |
| `/data/logs/` | Debug logs |

---

## 🔗 Quick Links

| File | Purpose |
|------|---------|
| [README.md](README.md) | Project overview + quick start |
| [config.yaml](config.yaml) | All configuration |
| [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) | Full architecture + DB schema |
| [docs/DEPLOYMENT.md](docs/DEPLOYMENT.md) | Docker Compose + local deployment |
| [docs/RISK_MANAGEMENT.md](docs/RISK_MANAGEMENT.md) | Safety gates + risk rules |
| [docs/API.md](docs/API.md) | Exchange adapter API reference |
| [docs/SIGNAL_PARSING.md](docs/SIGNAL_PARSING.md) | Regex patterns for signal formats |
| [src/api/server.py](src/api/server.py) | API bridge (15+ endpoints) |
| [CHANGELOG.md](CHANGELOG.md) | Version history |