#!/usr/bin/env python3
"""Validate an upstream egress proxy for Binance BEFORE going live.

Why: sera's Tencent ap-jakarta egress range is throttled by Binance (every
request returns 418, even public ping). Routing ALL Binance REST + WS through
a clean-IP proxy makes the bot ban-proof. This script proves the proxy works
for BOTH transports before you enable it in config.

Usage:
    BINANCE_EGRESS_PROXY='http://user:pass@host:port' \
        python3 src/scripts/test_egress_proxy.py

Or pass inline:
    python3 src/scripts/test_egress_proxy.py 'socks5://host:port'

It checks:
  1. REST  -> GET https://fapi.binance.com/fapi/v1/ping via proxy == 200
  2. WS    -> wss://fstream.binance.com/ws/btcusdt@markPrice via proxy yields a mark price
  3. (optional) signed account call will use the same proxy at runtime.

Exit 0 = proxy good, safe to set BINANCE_EGRESS_PROXY in listener/.env and
restart the container. Exit 1 = proxy not usable; do NOT enable it.
"""
import asyncio
import os
import sys

import httpx


def proxy_from_args_or_env(argv) -> str | None:
    if len(argv) > 1:
        return argv[1].strip()
    return os.environ.get("BINANCE_EGRESS_PROXY", "").strip() or None


async def test_rest(proxy: str) -> bool:
    print(f"[REST] GET fapi.binance.com/fapi/v1/ping via {proxy.split('@')[-1]}")
    try:
        async with httpx.AsyncClient(timeout=15, proxy=proxy) as c:
            r = await c.get("https://fapi.binance.com/fapi/v1/ping")
        print(f"       -> HTTP {r.status_code}")
        return r.status_code == 200
    except Exception as e:
        print(f"       -> FAILED: {type(e).__name__}: {str(e)[:160]}")
        return False


async def test_ws(proxy: str) -> bool:
    print(f"[WS]   wss://fstream.binance.com/ws/btcusdt@markPrice via proxy")
    try:
        import websockets
        async with websockets.connect(
                "wss://fstream.binance.com/ws/btcusdt@markPrice",
                ping_interval=10, ping_timeout=10, close_timeout=5,
                proxy=proxy) as ws:
            msg = await asyncio.wait_for(ws.recv(), timeout=12)
            import json
            d = json.loads(msg)
            price = d.get("p") or d.get("data", {}).get("p")
            print(f"       -> WS OK, mark price = {price}")
            return price is not None
    except Exception as e:
        print(f"       -> FAILED: {type(e).__name__}: {str(e)[:160]}")
        return False


async def main() -> int:
    proxy = proxy_from_args_or_env(sys.argv)
    if not proxy:
        print("No proxy supplied. Set BINANCE_EGRESS_PROXY or pass it as arg.")
        print("Example: python3 src/scripts/test_egress_proxy.py 'http://user:pass@host:port'")
        return 1
    print("=" * 60)
    print("Egress proxy self-test")
    print("=" * 60)
    rest_ok = await test_rest(proxy)
    ws_ok = await test_ws(proxy)
    print("=" * 60)
    if rest_ok and ws_ok:
        print("PASS — proxy carries both REST and WS. Safe to enable.")
        print("Set in listener/.env:  BINANCE_EGRESS_PROXY=<your url>")
        print("then: docker compose up -d --force-recreate listener")
        return 0
    if rest_ok and not ws_ok:
        print("PARTIAL — REST works but WS failed. If your proxy does not")
        print("support CONNECT tunneling, the mark/user-data WS streams")
        print("will not connect. Pick a proxy that supports WS tunneling.")
        return 1
    print("FAIL — proxy does not reach Binance. Do NOT enable it.")
    return 1


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
