#!/usr/bin/env bash
# Run this ON YOUR LAPTOP (the Hermes machine). It:
#   1. starts the tiny egress proxy (residential IP) on :8080, and
#   2. opens a persistent reverse SSH tunnel to sera so sera's
#      127.0.0.1:8080 forwards to this proxy.
#
# Requires: python3, and ssh access to sera (sshd on port 2222).
# Replace SERA_HOST below with sera's reachable address (its public IP
# 43.173.11.172, or a hostname/DNS that reaches it).
#
# The tunnel auto-reconnects (the loop restarts ssh if it drops). Keep this
# terminal open (or run with nohup) while you want the bot to trade via the
# laptop. If the laptop sleeps / closes, the bot loses Binance egress.

set -u
PORT="${1:-8080}"
SERA_HOST="${SERA_HOST:-43.173.11.172}"   # override: export SERA_HOST=...
SERA_PORT="${SERA_PORT:-2222}"
SERA_USER="${SERA_USER:-root}"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROXY_PY="${PROXY_PY:-$SCRIPT_DIR/laptop_egress_proxy.py}"

echo "[laptop] starting egress proxy on 127.0.0.1:$PORT ..."
python3 "$PROXY_PY" "$PORT" &
PROXY_PID=$!
sleep 1

cleanup() {
    echo "[laptop] shutting down ..."
    kill "$PROXY_PID" 2>/dev/null
    pkill -f "ssh -N -R $PORT:127.0.0.1:$PORT" 2>/dev/null
    exit 0
}
trap cleanup INT TERM

echo "[laptop] opening reverse tunnel -> $SERA_USER@$SERA_HOST:$SERA_PORT (sera:127.0.0.1:$PORT)"
while true; do
    ssh -N -o ServerAliveInterval=20 -o ServerAliveCountMax=3 \
        -o ExitOnForwardFailure=yes \
        -R "$PORT:127.0.0.1:$PORT" \
        "$SERA_USER@$SERA_HOST" -p "$SERA_PORT"
    echo "[laptop] tunnel dropped, retrying in 5s ..."
    sleep 5
done
