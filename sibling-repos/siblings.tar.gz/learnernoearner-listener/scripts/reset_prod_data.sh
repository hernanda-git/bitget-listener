#!/usr/bin/env bash
#
# reset_prod_data.sh — Fresh deployment from the clean workspace copy.
#
# SAFETY FIRST:
#   - Refuses to wipe production data while ANY position is open (unless --force).
#   - Never touches secrets (.env) or the live container until the wipe step.
#   - Copies clean source BEFORE stopping the container, so a failure mid-run
#     leaves the old bot still running.
#
# This script does NOT run on its own. Execute only when you explicitly want a
# clean redeploy from /root/workspace/repos/learnernoearner-listener.
#
# Usage:
#   ./scripts/reset_prod_data.sh            # normal: abort if positions open
#   ./scripts/reset_prod_data.sh --force     # wipe even if positions open (DANGER)
#   ./scripts/reset_prod_data.sh --dry-run   # show what would happen, no changes
#
set -euo pipefail

# ─── Config (override via env vars) ───────────────────────────────────────────
WORKSPACE_SRC="${WORKSPACE_SRC:-/root/workspace/repos/learnernoearner-listener}"
SERA_HOST="${SERA_HOST:-root@43.157.208.115}"
SERA_KEY="${SERA_KEY:-/root/.ssh/termius-iphone}"
REMOTE_SRC="${REMOTE_SRC:-/opt/bots/listener/src}"
REMOTE_DATA="${REMOTE_DATA:-/data}"
COMPOSE_DIR="${COMPOSE_DIR:-/opt/bots}"
SERVICE="${SERVICE:-bots-listener}"
HEALTH_URL="${HEALTH_URL:-http://localhost:9090/health}"

FORCE=0
DRYRUN=0
for a in "$@"; do
  case "$a" in
    --force) FORCE=1 ;;
    --dry-run) DRYRUN=1 ;;
    *) echo "unknown arg: $a" >&2; exit 2 ;;
  esac
done

# run: in dry-run, print the command and return success (exit 0) without executing.
#      in real mode, execute the command and return its output/exit status.
run() {
  if [ "$DRYRUN" -eq 1 ]; then
    echo "[dry-run] $*"
    return 0
  fi
  eval "$@"
}
# caprun: capture stdout. In dry-run, print the preview to STDERR and return ""
#          so callers (e.g. OPEN_COUNT) get a clean empty value, not the preview text.
caprun() {
  if [ "$DRYRUN" -eq 1 ]; then
    echo "[dry-run] $*" >&2
    return 0
  fi
  eval "$@"
}
step() { echo "==> $*"; }

SSH="ssh -i $SERA_KEY -o StrictHostKeyChecking=no -o ConnectTimeout=10 $SERA_HOST"
RSYNC="rsync -az --delete"

# exclude secrets + runtime state + venv/caches from the copy
EXCLUDES=(
  --exclude='.git'        # keep production's own git, don't overwrite
  --exclude='.env' --exclude='.env.*'
  --exclude='data/' --exclude='sessions/' --exclude='logs/'
  --exclude='__pycache__/' --exclude='*.pyc' --exclude='.venv/'
  --exclude='.hermes/' --exclude='*.db' --exclude='*.db-shm' --exclude='*.db-wal'
)

# ─── 0. Preflight ────────────────────────────────────────────────────────────
step "preflight checks"
[ -d "$WORKSPACE_SRC" ] || { echo "ERROR: workspace source missing: $WORKSPACE_SRC" >&2; exit 1; }
command -v rsync >/dev/null || { echo "ERROR: rsync not installed locally" >&2; exit 1; }
run "$SSH 'echo sera-reachable && command -v docker && command -v dockercompose >/dev/null 2>&1 || command -v docker'" >/dev/null
echo "  workspace: $WORKSPACE_SRC"
echo "  target   : $SERA_HOST:$REMOTE_SRC"

# ─── 1. Copy clean source to production (safe while bot runs) ─────────────────
step "copy clean source -> $SERA_HOST:$REMOTE_SRC"
run "$RSYNC ${EXCLUDES[*]} $WORKSPACE_SRC/ $SERA_HOST:$REMOTE_SRC/"

# ─── 2. Check for open positions ─────────────────────────────────────────────
step "check for open positions on production"
OPEN_COUNT=$(caprun "$SSH \"docker exec $SERVICE python3 -c \\\"import sqlite3;c=sqlite3.connect('$REMOTE_DATA/trades.db');print(sum(1 for r in c.execute(\\\"SELECT id FROM positions WHERE status NOT IN ('CLOSED','closed')\\\")))\\\"\"" 2>/dev/null || echo "0")
echo "  open positions: ${OPEN_COUNT:-0}"
if [ "${OPEN_COUNT:-0}" -gt 0 ] && [ "$FORCE" -ne 1 ]; then
  echo "ABORT: $OPEN_COUNT open position(s) detected. Close them first, or rerun with --force." >&2
  exit 3
fi
[ "$FORCE" -eq 1 ] && echo "  WARNING: --force set, wiping despite open positions." >&2

# ─── 3. Stop the container ────────────────────────────────────────────────────
step "stop $SERVICE"
run "$SSH \"cd $COMPOSE_DIR && docker compose stop $SERVICE\""

# ─── 4. Wipe trade data + sessions (fresh start) ──────────────────────────────
step "wipe $REMOTE_DATA (trades.db, sessions)"
run "$SSH \"rm -f $REMOTE_DATA/trades.db $REMOTE_DATA/trades.db-shm $REMOTE_DATA/trades.db-wal; rm -rf $REMOTE_DATA/sessions/* $REMOTE_DATA/logs/*\""

# ─── 5. Rebuild + restart the stack ───────────────────────────────────────────
step "rebuild + restart stack"
run "$SSH \"cd $COMPOSE_DIR && docker compose up -d --build $SERVICE\""

# ─── 6. Verify health ─────────────────────────────────────────────────────────
step "verify health endpoint"
for i in $(seq 1 10); do
  CODE=$(caprun "$SSH \"curl -s -o /dev/null -w '%{http_code}' $HEALTH_URL\"" 2>/dev/null || echo "000")
  if [ "$CODE" = "200" ]; then echo "  health OK (HTTP 200) after ${i}s"; break; fi
  [ "$DRYRUN" -eq 1 ] && { echo "  [dry-run] would poll health"; break; }
  sleep 1
done
[ "${CODE:-000}" != "200" ] && [ "$DRYRUN" -ne 1 ] && { echo "WARN: health not 200 (got ${CODE:-000})"; exit 4; }

echo "==> done. fresh deploy complete (data reset to zero)."
