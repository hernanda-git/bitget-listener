#!/usr/bin/env python3
"""Tiny HTTP/HTTPS (CONNECT) proxy that egresses from THIS machine's own IP.

Purpose: route sera's Binance traffic through your laptop's residential IP so
Binance stops returning 418 (the Tencent ap-jakarta datacenter range is
throttled; a home/residential IP is not). Run this on the laptop, then open a
reverse SSH tunnel to sera so sera can reach this proxy on 127.0.0.1:<port>.

Usage:
    python3 laptop_egress_proxy.py [port]      # default 8080

Then on the laptop, open the tunnel to sera (replace HOST/PORT with sera's
reachable ssh address; sera's sshd listens on 2222):

    ssh -N -R 8080:127.0.0.1:8080 root@<sera-host> -p 2222

On sera, set in listener/.env:
    BINANCE_EGRESS_PROXY=http://127.0.0.1:8080
and restart the listener container.

Only CONNECT (HTTPS / WebSocket / TLS) is supported — that's all Binance
needs. No logging of payloads. Bind loopback only (the tunnel exposes it).
"""
import socket
import sys
import threading

PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 8080
BUFFER = 65536


def handle(client: socket.socket) -> None:
    try:
        client.settimeout(30)
        req = client.recv(4096)
        if not req:
            return
        # Parse the request line: "CONNECT host:port HTTP/1.1" or
        # "GET http://... HTTP/1.1" (we only handle CONNECT properly).
        first = req.split(b"\r\n", 1)[0].decode("latin-1", "replace")
        parts = first.split()
        if len(parts) < 2:
            return
        method, target = parts[0], parts[1]
        if method.upper() != "CONNECT":
            # Plain HTTP proxying not needed for Binance (all TLS). Refuse.
            client.sendall(b"HTTP/1.1 405 Method Not Allowed\r\n\r\n")
            return
        host, _, port = target.partition(":")
        port = int(port) if port else 443
        remote = socket.create_connection((host, port), timeout=30)
        client.sendall(b"HTTP/1.1 200 Connection Established\r\n\r\n")
        a2b = threading.Thread(target=_pipe, args=(client, remote), daemon=True)
        b2a = threading.Thread(target=_pipe, args=(remote, client), daemon=True)
        a2b.start()
        b2a.start()
        a2b.join()
        b2a.join()
    except Exception:
        pass
    finally:
        try:
            client.close()
        except Exception:
            pass


def _pipe(src: socket.socket, dst: socket.socket) -> None:
    try:
        while True:
            data = src.recv(BUFFER)
            if not data:
                break
            dst.sendall(data)
    except Exception:
        pass
    finally:
        for s in (src, dst):
            try:
                s.shutdown(socket.SHUT_RDWR)
            except Exception:
                pass
            try:
                s.close()
            except Exception:
                pass


def main() -> None:
    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    # Bind loopback only: the SSH reverse tunnel is what exposes it to sera.
    srv.bind(("127.0.0.1", PORT))
    srv.listen(128)
    print(f"[laptop-egress-proxy] listening on 127.0.0.1:{PORT} "
          f"(egress via this machine's IP). Ctrl-C to stop.")
    try:
        while True:
            conn, _ = srv.accept()
            threading.Thread(target=handle, args=(conn,), daemon=True).start()
    except KeyboardInterrupt:
        print("\n[laptop-egress-proxy] stopped")


if __name__ == "__main__":
    main()
