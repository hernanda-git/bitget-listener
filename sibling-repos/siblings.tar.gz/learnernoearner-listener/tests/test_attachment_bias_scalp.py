"""Tests for the attachment/bias plan + the scalp_watch addendum.

Covers the 4 mandated addendum tests plus schema, repository and
bias-accuracy coverage, all against a temp sqlite.
"""

from __future__ import annotations

import sys
from dataclasses import dataclass
from pathlib import Path
from unittest.mock import AsyncMock

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from src.agent.level_resolver import extract_text_numbers, resolve_scalp_levels
from src.agent.parser import classify_signal_shape
from src.execution.order_service import OrderService
from src.state.bias_accuracy import bias_weight, run_bias_accuracy_job, score_bias
from src.state.database import get_connection
from src.state.repositories import AttachmentReadRepository, BtcBiasReadRepository

PUMP_TEXT = (
    "$PUMP watching for a possible short scalp from the current levels "
    "all the way down to 0.0023"
)

PUMP_VISION = {
    "levels": {"entry": None, "sl": None, "tp": [],
               "support": [0.00219], "resistance": [0.00251]},
    "trend": "down",
    "setup_type": "reversal",
    "has_chart_data": True,
}


@pytest.fixture()
def conn(tmp_path):
    c = get_connection(tmp_path / "test.db")
    yield c
    c.close()


@dataclass
class FakeSignalRow:
    id: int = 1
    raw_text: str = PUMP_TEXT
    side: str = "SHORT"
    signal_shape: str = "scalp_watch"
    symbol_resolved: str = "PUMPUSDT"
    entry_price: float | None = None
    chart_setup_type: str = ""


def make_service(exchange):
    cfg = {"risk": {"port_usdt": 1.0, "max_leverage": 20}, "execution": {}}
    return OrderService(exchange, cfg, None, None, None, None)


# ── schema ────────────────────────────────────────────────────────────────

def test_schema_has_addendum_columns(conn):
    cols = {r["name"] for r in conn.execute("PRAGMA table_info(attachment_reads)")}
    for c in ("signal_shape", "text_levels", "resolved_entry_price",
              "resolved_entry_source", "resolved_target_price",
              "resolved_sl_price", "resolution_confidence"):
        assert c in cols, f"missing column {c}"

    bias_cols = {r["name"] for r in conn.execute("PRAGMA table_info(btc_bias_reads)")}
    assert "bias_primary" in bias_cols
    assert "btc_price_at_post" in bias_cols
    # Distinct data classes: bias table must NOT carry chart-setup fields.
    assert "chart_setup_type" not in bias_cols


# ── addendum test 1 ───────────────────────────────────────────────────────

def test_classify_scalp_watch():
    assert classify_signal_shape(PUMP_TEXT) == "scalp_watch"


def test_classify_formal_setup_unchanged():
    text = "#BTC $BTC LONG TRADE\nENTRY: 64000\nTARGET: 68000\nSTOPLOSS: 63000"
    assert classify_signal_shape(text) == "formal_setup"


def test_classify_btc_bias_falls_through():
    assert classify_signal_shape("$BTC bottom not in, range identified") is None


# ── addendum test 2 ───────────────────────────────────────────────────────

def test_resolve_scalp_levels_worked_example():
    r = resolve_scalp_levels(PUMP_TEXT, PUMP_VISION, "SHORT", 0.00246)
    assert r.entry == pytest.approx(0.00251)
    assert r.entry_source == "chart_level"
    assert r.target == pytest.approx(0.0023)
    assert r.stop is None
    assert r.confidence == pytest.approx(0.8)


def test_resolve_long_with_valid_stop():
    vision = {"levels": {"support": [98.0], "resistance": [110.0]}, "trend": "up"}
    r = resolve_scalp_levels("long scalp up to 120", vision, "LONG", 100.0)
    assert r.entry == pytest.approx(98.0)
    assert r.target == pytest.approx(120.0)
    # resistance 110 is above entry 98 -> not a valid LONG stop
    assert r.stop is None


def test_resolve_stop_accepted_when_beyond_entry():
    vision = {"levels": {"support": [100.0], "resistance": [95.0]}, "trend": "up"}
    r = resolve_scalp_levels("long scalp up to 130", vision, "LONG", 101.0)
    assert r.entry == pytest.approx(100.0)
    assert r.stop == pytest.approx(95.0)
    assert r.confidence == pytest.approx(1.0)


def test_extract_text_numbers():
    assert extract_text_numbers("down to 0.0023 and 1.5") == [0.0023, 1.5]


def test_fallback_to_mark_when_no_chart_levels():
    r = resolve_scalp_levels("short scalp down to 5", {}, "SHORT", 10.0)
    assert r.entry == pytest.approx(10.0)
    assert r.entry_source == "current_mark_fallback"
    assert r.stop is None


# ── addendum test 3 ───────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_no_stop_no_trade():
    exchange = AsyncMock()
    svc = make_service(exchange)
    result = await svc.place_entry(FakeSignalRow(), PUMP_VISION, 0.00246)
    assert result is None
    assert exchange.place_limit_order.call_count == 0


@pytest.mark.asyncio
async def test_low_confidence_no_trade():
    exchange = AsyncMock()
    svc = make_service(exchange)
    row = FakeSignalRow(raw_text="short scalp", side="SHORT")
    # no target, no chart levels -> confidence 0.0
    result = await svc.place_entry(row, {}, 10.0)
    assert result is None
    assert exchange.place_limit_order.call_count == 0


@pytest.mark.asyncio
async def test_scalp_with_stop_does_trade():
    exchange = AsyncMock()
    svc = make_service(exchange)
    vision = {"levels": {"support": [100.0], "resistance": [95.0]}, "trend": "up"}
    row = FakeSignalRow(raw_text="long scalp up to 130", side="LONG")
    await svc.place_entry(row, vision, 101.0)
    assert exchange.place_limit_order.call_count == 1
    kwargs = exchange.place_limit_order.call_args.kwargs
    assert kwargs["price"] == pytest.approx(100.0)
    assert kwargs["reduce_only"] is False


@pytest.mark.asyncio
async def test_kaito_guard_blocks_fakeout():
    exchange = AsyncMock()
    svc = make_service(exchange)
    vision = {"levels": {"support": [100.0], "resistance": [95.0]},
              "trend": "up", "setup_type": "fakeout"}
    row = FakeSignalRow(raw_text="long scalp up to 130", side="LONG")
    assert await svc.place_entry(row, vision, 101.0) is None
    assert exchange.place_limit_order.call_count == 0


@pytest.mark.asyncio
async def test_regime_filter_blocks_long_in_bearish():
    exchange = AsyncMock()
    svc = make_service(exchange)
    vision = {"levels": {"support": [100.0], "resistance": [95.0]}, "trend": "up"}
    row = FakeSignalRow(raw_text="long scalp up to 130", side="LONG")
    result = await svc.place_entry(row, vision, 101.0,
                                   latest_bias={"bias_primary": "BEARISH"})
    assert result is None
    assert exchange.place_limit_order.call_count == 0


# ── addendum test 4 ───────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_sizing_unchanged():
    vision = {"levels": {"support": [100.0], "resistance": [95.0]}, "trend": "up"}

    ex_scalp = AsyncMock()
    await make_service(ex_scalp).place_entry(
        FakeSignalRow(raw_text="long scalp up to 130", side="LONG",
                      signal_shape="scalp_watch"),
        vision, 101.0,
    )

    ex_formal = AsyncMock()
    await make_service(ex_formal).place_entry(
        FakeSignalRow(raw_text="#X $X LONG TRADE ENTRY 100 TARGET 130 STOPLOSS 95",
                      side="LONG", signal_shape="formal_setup",
                      entry_price=100.0),
        vision, 101.0,
    )

    qty_scalp = ex_scalp.place_limit_order.call_args.kwargs["qty"]
    qty_formal = ex_formal.place_limit_order.call_args.kwargs["qty"]
    assert qty_scalp == qty_formal == 20.0


# ── repositories ──────────────────────────────────────────────────────────

def test_attachment_repo_roundtrip_and_resolution(conn):
    repo = AttachmentReadRepository(conn)
    row_id = repo.save(
        source_id=7, message_id=101, channel="fattyfatclub",
        symbol_resolved="PUMPUSDT", signal_shape="scalp_watch",
        chart_support=[0.00219], chart_resistance=[0.00251],
        chart_trend="down", vision_struct=PUMP_VISION,
        text_levels=[{"value": 0.0023, "role": "target_hint"}],
    )
    assert row_id > 0

    levels = resolve_scalp_levels(PUMP_TEXT, PUMP_VISION, "SHORT", 0.00246)
    repo.persist_resolution(row_id, levels)

    row = repo.get(row_id)
    assert row["signal_shape"] == "scalp_watch"
    assert row["resolved_entry_price"] == pytest.approx(0.00251)
    assert row["resolved_entry_source"] == "chart_level"
    assert row["resolved_target_price"] == pytest.approx(0.0023)
    assert row["resolved_sl_price"] is None
    assert row["resolution_confidence"] == pytest.approx(0.8)
    assert repo.by_source(7)[0]["id"] == row_id


def test_bias_repo_latest_and_scoring(conn):
    repo = BtcBiasReadRepository(conn)
    repo.save(message_id=1, channel="fattyfatclub", bias_primary="RANGE",
              btc_price_at_post=64000.0, support=[63000], resistance=[66000])
    latest = repo.latest()
    assert latest is not None and latest["bias_primary"] == "RANGE"

    repo.score(latest["id"], 64100.0, 1.0, "FLAT")
    n, rate = repo.hit_rate("RANGE")
    assert n == 1 and rate == pytest.approx(1.0)


# ── bias accuracy job ─────────────────────────────────────────────────────

def test_score_bias_noise_floor():
    assert score_bias("BULLISH", 100.0, 102.0) == 1.0
    assert score_bias("BULLISH", 100.0, 97.0) == -1.0
    assert score_bias("BULLISH", 100.0, 100.5) == 0.0
    assert score_bias("BEARISH", 100.0, 97.0) == 1.0
    assert score_bias("RANGE", 100.0, 100.5) == 1.0
    assert score_bias("RANGE", 100.0, 110.0) == -1.0


@pytest.mark.asyncio
async def test_orchestrator_chart_gated_scalp_places():
    """Unclear text + media + clear chart => scalp_watch LIMIT tried via chart."""
    import tempfile, pathlib
    from src.orchestrator import TradeOrchestrator
    from src.execution.order_service import OrderService

    db = pathlib.Path(tempfile.mkdtemp()) / "orch.db"
    conn = get_connection(db)

    fake_ex = AsyncMock()
    real_os = OrderService(fake_ex, {"risk": {"port_usdt": 1.0, "max_leverage": 20}},
                           None, None, None, None)

    class FakeSignalRepo:
        def __init__(self, c): self.conn = c; self._id = 0
        def claim(self, *a, **k): return True
        def save(self, *a, **k): self._id += 1; return self._id
        def mark_processed(self, *a, **k): pass

    class FakeExchange:
        async def get_mark_price(self, s): return 0.00246

    v = {"has_chart_data": True, "trend": "down",
         "levels": {"support": [0.00219], "resistance": [0.00251]},
         "setup_type": "reversal"}

    class FakeVision:
        async def extract(self, path, caption): return v

    class FakeFetcher:
        async def download(self, client, message, channel):
            return ("/tmp/fake.png", "photo")

    orch = TradeOrchestrator.__new__(TradeOrchestrator)
    orch.config = {"risk": {"port_usdt": 1.0, "max_leverage": 20}, "agent": {}}
    orch.signal_repo = FakeSignalRepo(conn)
    orch.trade_log_repo = None
    orch.gate1 = type("G", (), {"check": lambda self, sig: (True, "")})()
    orch.agent = type("A", (), {"decide": lambda self, *a, **k: None})()
    orch.order_service = real_os
    orch.position_repo = type("P", (), {"get_open_positions": lambda self: []})()
    orch.pending_signal_repo = None
    orch.exchange = FakeExchange()
    orch.attachment_fetcher = FakeFetcher()
    orch.vision_extractor = FakeVision()
    orch.attachment_local_path = "/tmp/fake.png"
    orch._dry_run = False
    orch.event_bus = None

    res = await orch._try_attachment_scalp(
        "corr", 999, "fattyfatclub", "$PUMP looking heavy here", 1)
    assert res is not None, "chart-gated scalp should fire"
    # stop is None here (support below entry) -> skipped, but recorded as audit
    assert res["action"] == "scalp_skipped"
    row = conn.execute(
        "SELECT signal_shape, resolved_entry_price, resolved_sl_price FROM attachment_reads"
    ).fetchone()
    assert row["signal_shape"] == "scalp_watch"
    assert row["resolved_entry_price"] == pytest.approx(0.00251)
    assert row["resolved_sl_price"] is None


@pytest.mark.asyncio
async def test_orchestrator_chart_gated_disabled_returns_none():
    from src.orchestrator import TradeOrchestrator
    orch = TradeOrchestrator.__new__(TradeOrchestrator)
    orch.attachment_fetcher = None
    orch.vision_extractor = None
    orch.signal_repo = None
    assert await orch._try_attachment_scalp("c", 1, "ch", "x", 1) is None


# ── chart-gated scalp promotion (unclear text + clear chart) ────────────────

def test_vague_text_promoted_when_chart_rich():
    v = {"has_chart_data": True, "trend": "down",
         "levels": {"support": [0.00219], "resistance": [0.00251]},
         "setup_type": "reversal"}
    assert classify_signal_shape("this looks heavy, watch it", vision_struct=v) == "scalp_watch"


def test_vague_text_not_promoted_when_chart_empty():
    v = {"has_chart_data": False, "trend": "", "levels": {}}
    assert classify_signal_shape("this looks heavy, watch it", vision_struct=v) == "formal_setup"


def test_chart_rich_rejects_pnl_card():
    from src.agent.parser import is_chart_rich
    v = {"has_chart_data": True, "trend": "up",
         "levels": {"support": [1.0]}, "setup_type": "pnl_card"}
    assert is_chart_rich(v) is False


def test_chart_rich_rejects_no_trend():
    from src.agent.parser import is_chart_rich
    assert is_chart_rich({"has_chart_data": True, "trend": "", "levels": {"support": [1.0]}}) is False


def test_formal_still_wins_over_chart_gate():
    v = {"has_chart_data": True, "trend": "down", "levels": {"resistance": [1.0]}}
    text = "#X $X LONG TRADE\nENTRY 1\nTARGET 2\nSTOPLOSS 0.9"
    assert classify_signal_shape(text, vision_struct=v) == "formal_setup"



@pytest.mark.asyncio
async def test_bias_accuracy_job_scores_old_rows(conn):
    repo = BtcBiasReadRepository(conn)
    repo.save(message_id=42, channel="c", bias_primary="BULLISH",
              btc_price_at_post=60000.0)
    conn.execute("UPDATE btc_bias_reads SET created_at = datetime('now','-30 days')")
    conn.commit()

    exchange = AsyncMock()
    exchange.get_mark_price.return_value = 70000.0

    summary = await run_bias_accuracy_job(repo, exchange)
    assert summary["scored"] == 1
    assert summary["hit_rates"]["BULLISH"] == (1, pytest.approx(1.0))
    assert bias_weight(repo, "BULLISH") == 1.0  # below MIN_SAMPLES -> neutral


@pytest.mark.asyncio
async def test_handle_signal_vague_media_goes_attachment_scalp():
    """End-to-end: vague $PAIR post WITH media hits the chart-gated scalp path
    and is persisted, instead of being dropped or sent to the LLM brain."""
    import tempfile, pathlib
    from src.orchestrator import TradeOrchestrator
    from src.execution.order_service import OrderService

    db = pathlib.Path(tempfile.mkdtemp()) / "hs.db"
    conn = get_connection(db)
    fake_ex = AsyncMock()
    real_os = OrderService(fake_ex, {"risk": {"port_usdt": 1.0, "max_leverage": 20}},
                           None, None, None, None)

    class FakeSignalRepo:
        def __init__(self, c): self.conn = c; self._id = 0; self.processed = []
        def claim(self, *a, **k): return True
        def save(self, *a, **k): self._id += 1; return self._id
        def mark_processed(self, mid, rt): self.processed.append(mid)

    class FakeExchange:
        async def get_mark_price(self, s): return 0.00246

    v = {"has_chart_data": True, "trend": "down",
         "levels": {"support": [0.00219], "resistance": [0.00251]},
         "setup_type": "reversal"}

    class FakeVision:
        async def extract(self, path, caption): return v
    class FakeFetcher:
        async def download(self, client, message, channel):
            return ("/tmp/fake.png", "photo")

    orch = TradeOrchestrator.__new__(TradeOrchestrator)
    orch.config = {"risk": {"port_usdt": 1.0, "max_leverage": 20}, "agent": {}}
    orch.signal_repo = FakeSignalRepo(conn)
    orch.trade_log_repo = None
    orch.gate1 = type("G", (), {"check": lambda self, sig: (True, "")})()
    orch.agent = type("A", (), {"decide": lambda self, *a, **k: None})()
    orch.order_service = real_os
    orch.position_repo = type("P", (), {"get_open_positions": lambda self: []})()
    orch.pending_signal_repo = None
    orch.exchange = FakeExchange()
    orch.attachment_fetcher = FakeFetcher()
    orch.vision_extractor = FakeVision()
    orch.attachment_local_path = "/tmp/fake.png"
    orch._dry_run = False
    orch.event_bus = None

    # has_media=True, text vague (no formal setup) but contains $PUMP
    res = await orch.handle_signal(1234, "fattyfatclub", "$PUMP looking heavy here",
                                   has_media=True)
    assert res["action"] == "scalp_skipped", res
    assert res["scalp_watch"] is True
    # the signal was recorded (audit) and the attachment_read row exists
    assert 1234 in orch.signal_repo.processed
    row = conn.execute(
        "SELECT signal_shape FROM attachment_reads WHERE message_id=1234"
    ).fetchone()
    assert row is not None and row["signal_shape"] == "scalp_watch"


@pytest.mark.asyncio
async def test_handle_signal_vague_no_media_falls_through_to_brain():
    """Without media, a vague post is NOT claimed by the attachment path and the
    orchestrator proceeds to the LLM brain (we just assert it didn't scalp)."""
    import tempfile, pathlib
    from src.orchestrator import TradeOrchestrator
    from src.execution.order_service import OrderService

    db = pathlib.Path(tempfile.mkdtemp()) / "hs2.db"
    conn = get_connection(db)

    class FakeSignalRepo:
        def __init__(self, c): self.conn = c; self._id = 0
        def claim(self, *a, **k): return True
        def save(self, *a, **k): self._id += 1; return self._id
        def mark_processed(self, *a, **k): pass

    class FakeExchange:
        async def get_mark_price(self, s): return 1.0

    orch = TradeOrchestrator.__new__(TradeOrchestrator)
    orch.config = {"risk": {"port_usdt": 1.0, "max_leverage": 20}, "agent": {}}
    orch.signal_repo = FakeSignalRepo(conn)
    orch.trade_log_repo = None
    orch.gate1 = type("G", (), {"check": lambda self, sig: (True, "")})()
    orch.agent = type("A", (), {"decide": lambda self, *a, **k: None})()
    orch.order_service = OrderService(AsyncMock(), orch.config, None, None, None, None)
    orch.position_repo = type("P", (), {"get_open_positions": lambda self: []})()
    orch.pending_signal_repo = None
    orch.exchange = FakeExchange()
    orch.attachment_fetcher = None  # pipeline disabled
    orch.vision_extractor = None
    orch._dry_run = False
    orch.event_bus = None

    res = await orch.handle_signal(555, "fattyfatclub", "some vague text no pair",
                                   has_media=False)
    # should NOT be a scalp action; pipeline disabled -> falls through (action set
    # by the brain path / gate). Key assertion: it did not scalp.
    assert res.get("scalp_watch") is not True


def test_main_wiring_builds_pipeline_when_enabled():
    """main.py builds fetcher+vision from config and passes them to the orchestrator
    (and would attach the listener client). Verified against fakes, no network."""
    import types
    from src.agent.attachment_fetcher import AttachmentFetcher
    from src.agent.vision import VisionExtractor
    from src.orchestrator import TradeOrchestrator

    # Minimal config that "enables" the pipeline.
    cfg = {"attachment": {"enabled": True, "media_dir": "/tmp/att"},
           "agent": {"vision": {}}, "risk": {}}

    # Stub the two constructors so no real key/network is touched.
    made = {}
    real_fetcher = AttachmentFetcher.__init__
    real_vision = VisionExtractor.__init__
    def _fetcher_init(self, **k):
        made["fetcher"] = True
    def _vision_init(self, c=None, **k):
        made["vision"] = True
    AttachmentFetcher.__init__ = _fetcher_init
    VisionExtractor.__init__ = _vision_init

    # Replicate main.py's exact wiring inline (mirrors src/main.py).
    attachment_cfg = cfg.get("attachment", {}) or {}

    fetcher = vision = None
    if attachment_cfg.get("enabled", False):
        vision = VisionExtractor(cfg)
        fetcher = AttachmentFetcher(media_dir=attachment_cfg.get("media_dir", "/data/attachments"))

    orch = TradeOrchestrator.__new__(TradeOrchestrator)
    orch.attachment_fetcher = fetcher
    orch.vision_extractor = vision
    orch.telegram_client = object()  # would be listener.client in main.py

    assert made.get("fetcher") and made.get("vision")
    assert orch.attachment_fetcher is not None
    assert orch.vision_extractor is not None
    # With pipeline enabled + a client, the _try path is live.
    assert orch.telegram_client is not None

    AttachmentFetcher.__init__ = real_fetcher
    VisionExtractor.__init__ = real_vision


def test_main_wiring_disabled_by_default():
    """Without attachment.enabled, the pipeline stays None (production untouched)."""
    from src.orchestrator import TradeOrchestrator
    cfg = {}  # no attachment block
    attachment_cfg = cfg.get("attachment", {}) or {}
    fetcher = vision = None
    if attachment_cfg.get("enabled", False):
        pass
    orch = TradeOrchestrator.__new__(TradeOrchestrator)
    orch.attachment_fetcher = fetcher
    orch.vision_extractor = vision
    assert orch.attachment_fetcher is None
    assert orch.vision_extractor is None


def test_rate_limit_circuit_breaker_and_cache():
    """Unit: Binance breaker pauses REST on IP ban; mark-price cache avoids
    per-tick REST. No network."""
    import asyncio
    from src.exchange.binance import BinanceExchange, RateLimited

    ex = BinanceExchange.__new__(BinanceExchange)
    ex._ban_until_ms = 0.0
    ex._rate_limited_until_ms = 0.0
    ex._consecutive_429 = 0
    ex._mark_cache = {}
    ex._mark_cache_ttl_ms = 5000
    ex._mark_cache_refreshing = False
    ex.futures = True
    ex._base = "https://fapi.binance.com"

    # 1) Simulate an IP ban from a -1003 error message.
    ex._note_rate_limit(418, '{"code":-1003,"msg":"Way too many requests; IP(1.2.3.4) banned until 9999999999999"}')
    assert ex._ban_until_ms == 9999999999999
    # While banned, _assert_not_banned must raise (so the loop stops hitting REST)
    try:
        ex._assert_not_banned()
        assert False, "should have raised RateLimited"
    except RateLimited:
        pass

    # 2) mark-price cache: a banned refresh returns stale-free None but does NOT
    #    call REST. Feed a cached price and confirm get_mark_price serves it
    #    without network while banned.
    ex._mark_cache["BTCUSDT"] = (0.00123, 1234567890000)
    # patch _public_request to assert it is NEVER called
    called = []
    async def fake_public(*a, **k):
        called.append(1)
        return [{"symbol": "BTCUSDT", "lastPrice": "0.00125"}]
    ex._public_request = fake_public
    price = asyncio.run(ex.get_mark_price("BTCUSDT"))
    assert price == 0.00123, price
    assert called == [], f"REST must NOT be called while banned, got {called}"

    # 3) After ban clears, a refresh happens via one batched call.
    ex._ban_until_ms = 0.0
    price = asyncio.run(ex.get_mark_price("BTCUSDT"))
    assert called == [1], f"expected exactly 1 batched refresh, got {called}"
    assert price == 0.00125, price
def test_self_learning_raises_bar_for_chronic_loser():
    """Unit: when self-learning on + pair is a chronic loser, threshold rises."""
    import asyncio
    from unittest.mock import MagicMock
    from src.agent.agent import AgentBrain
    from src.domain.models import TradeSignal, TradeDecision

    brain = AgentBrain.__new__(AgentBrain)
    brain.model = "test"; brain.fallback_model = ""
    brain.api_key = ""
    brain.timeout = 5
    brain.confidence_threshold = 0.6
    brain.self_learning_enabled = True
    brain.self_learning_min_n = 5
    brain.self_learning_skip_win_rate = 0.35
    brain._async_client = None

    # Simulate LLM returning a mid-confidence ENTER for a chronic-loser pair
    async def fake_call(prompt, model=None):
        return ('{"action":"ENTER","pair":"BONKUSDT","direction":"LONG",'
                '"order_type":"MARKET","entry_price":100,"sl_price":98,'
                '"tp_prices":[105],"confidence":0.7,"reason":"x"}', 100, 50, 200)
    brain._call_llm_async = fake_call

    sig = TradeSignal(message_id=1, channel="c", raw_text="buy", pair="BONKUSDT")
    history = {"n": 20, "wins": 3, "losses": 17, "win_rate": 0.15,
               "fee_adjusted_net": -5.0, "avg_r_multiple": -0.5}
    # monkeypatch decide's internal _call_llm_async already set; call decide
    dec = asyncio.run(brain.decide(sig, [], {"balance": 100}, None, pair_history=history))
    # 0.7 < raised threshold (0.85) -> SKIP
    assert dec.action == "SKIP", dec.action
    assert "self-learn" in dec.reason, dec.reason


def test_ws_stream_mark_price_cache_and_fallback():
    """Unit: MarketDataStream serves mark price from push; getters fall back."""
    import asyncio
    from src.exchange.ws_stream import MarketDataStream
    from src.exchange.binance import BinanceExchange

    ws = MarketDataStream()
    ws.mark_cache["BTCUSDT"] = (0.00123, __import__("time").time() * 1000)
    assert ws.get_mark_price("BTCUSDT") == 0.00123
    # stale mark should be ignored
    ws.mark_cache["X"] = (9.9, 0)
    assert ws.get_mark_price("X") is None

    # BinanceExchange with WS enabled routes get_mark_price through the stream
    ex = BinanceExchange.__new__(BinanceExchange)
    ex._ws = ws
    ex._mark_cache = {}
    ex._mark_cache_ttl_ms = 5000
    ex._ban_until_ms = 0.0
    ex._mark_cache_refreshing = False
    price = asyncio.run(ex.get_mark_price("BTCUSDT"))
    assert price == 0.00123, price

    # With no WS, get_open_orders fast-path is simply skipped (REST path used
    # by the live bot under the breaker). We only assert the WS path above.


def test_egress_proxy_is_wired_into_clients():
    """Unit: BinanceExchange passes egress_proxy to httpx + WS stream."""
    from src.exchange.binance import BinanceExchange
    from src.exchange.ws_stream import MarketDataStream

    ex = BinanceExchange.__new__(BinanceExchange)
    ex.api_key = "k"; ex.api_secret = "s"; ex.testnet = False
    ex.futures = True; ex.leverage = 1; ex.recv_window = 5000
    ex.proxy = {}; ex.proxy_enabled = False; ex.proxy_url = ""; ex.proxy_secret = ""
    ex.egress_proxy = "http://proxy.example:8080"
    urls = {"mainnet": "https://fapi.binance.com"}
    ex._base = urls["mainnet"]
    # _client must be created with the proxy (httpx 0.28 uses proxy=)
    import httpx as _httpx
    # httpx 0.28 accepts the proxy= kwarg (singular); constructing with it must
    # not raise, confirming the wiring point is correct.
    ex._client = _httpx.AsyncClient(base_url=ex._base, timeout=10,
                                    proxy=ex.egress_proxy)
    # WS manager should receive the proxy too
    ws = MarketDataStream(proxy=ex.egress_proxy)
    assert ws.proxy == "http://proxy.example:8080"


def test_paper_mode_does_not_fetch_live_exchangeinfo():
    """Unit: in paper mode the SymbolRegistry skips the live Binance fetch."""
    import os
    from src.exchange.symbol_registry import SymbolRegistry

    reg = SymbolRegistry(seed_path=None)
    reg.live_fetch_enabled = False  # mirrors main.py paper-mode setting
    import asyncio
    # initialize must NOT raise / hit network; goes to built-in seed.
    asyncio.run(reg.initialize())
    assert reg._initialized is True
    assert reg.symbol_count > 0, "paper mode should still load seed symbols"
