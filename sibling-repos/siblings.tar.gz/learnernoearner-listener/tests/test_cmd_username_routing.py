"""Tests: v113 @botusername command routing in the Telethon listener.

Two bots share the owner's private chat: @vaisravana_bot (owns /status) and
@xvalarion_bot (owns /health). When the owner sends /health@xvalarion_bot the
raw text no longer equals "/health", so every `cmd == "/health"` comparison
silently failed and the command was DROPPED. The fix strips the @suffix before
matching and ignores commands addressed to a different bot.

The handler is an inner closure, so we assert on the routing source + verify
the parse logic standalone.
"""
from __future__ import annotations

import pathlib

SRC = (pathlib.Path(__file__).resolve().parents[1] / "src" / "listener.py").read_text(
    encoding="utf-8")


def _route(raw: str, own_username: str = "xvalarion_bot") -> str | None:
    """Mirror of the routing logic in listener.on_command (keep in sync)."""
    raw = raw.strip().lower()
    head, _, tail = raw.partition(" ")
    if "@" in head:
        base, target = head.split("@", 1)
        if target != own_username:
            return None
        return (base + " " + tail).strip() if tail else base
    return raw


def test_source_contains_routing():
    assert "XVALARION_BOT_USERNAME" in SRC
    assert 'head.split("@", 1)' in SRC
    # the old direct-compare on raw text must be gone
    assert 'cmd = (event.message.text or "").strip().lower()' not in SRC


def test_suffixed_own_command_is_normalized():
    assert _route("/health@xvalarion_bot") == "/health"
    assert _route("/setleverage@xvalarion_bot 10") == "/setleverage 10"


def test_other_bots_command_is_ignored():
    assert _route("/status@vaisravana_bot") is None
    assert _route("/health@vaisravana_bot") is None


def test_plain_commands_still_work():
    assert _route("/health") == "/health"
    assert _route("/positions") == "/positions"
