@echo off
echo ========================================
echo   Learnernoearner Listener - Running
echo ========================================
echo.
cd /d "%~dp0"
"C:\Users\it26\AppData\Local\hermes\hermes-agent\venv\Scripts\python.exe" src\listener.py
pause
