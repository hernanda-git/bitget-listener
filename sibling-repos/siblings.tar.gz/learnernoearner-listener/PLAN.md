# PLAN.md — learnernoearner-listener

> **⚠️ HISTORICAL — DO NOT USE AS ACTIVE PLAN**
> This document is preserved for reference only. The bot is now running on Tencent Lighthouse VPS "sera" via docker-compose. All vaisravana main/wave/alpha bots were fully removed Aug 5. Only fatty bot (learnernoearner-listener) remains.
>
> For current architecture and workflows, see [AGENTS.md](AGENTS.md).

---

## 📌 Historical Context

This plan was written when the bot was deployed on Fly.io (Singapore) and multiple bot variants (main, wave, alpha) were active. The architecture and deployment have since changed:

- **Deployed:** Fly.io → Tencent Lighthouse VPS "sera" (43.157.208.115, ap-jakarta) via docker-compose
- **Bots:** vaisravana main/wave/alpha fully removed; only fatty bot (learnernoearner-listener) remains
- **Channel:** @fattyfatclub (UNKNOWN TRADERS ACADEMY) — note the correct name is "UNKNOWN TRADERS ACADEMY", not "Learnernoearner"
- **LLM:** deepseek-v4-flash → mindai/macaron-v1-tall via opengateway.gitlawb.com

---

## 📐 Historical Plan Items (Archived)

The following items were part of the original planning but are now superseded by the current architecture:

- [x] Separate wave bot into its own private GitHub repo and set as default workspace
- [x] Improve main bot alpha vs wave bot (CVD divergence entry, regime-adaptive TP)
- [x] Create vaisravana-alpha
- [x] Document everything including knowledge bases and methods
- [x] Propose best architecture for autonomous agentic works
- [x] Collect realtime crypto coin data with universe ranking
- [x] Make balance grow with aggressive scalping (the core goal)

---

## 🔄 Current Active Work

For current active work, see the bot's [CHANGELOG.md](CHANGELOG.md) and recent git commits. The bot is now in autonomous operation on sera.