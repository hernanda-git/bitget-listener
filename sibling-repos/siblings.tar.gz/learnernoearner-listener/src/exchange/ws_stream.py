"""Binance Futures WebSocket market-data + user-data stream.

Why this exists
---------------
The position monitor used to call REST every tick (get_mark_price,
get_open_orders, get_position_risk) per open position. On a shared VPS IP that
trips Binance's IP-ban (418 / -1003) and the bot can't trade.

This module replaces that with push-based websockets:
  * ``<symbol>@markPrice``  -> live mark price (no REST weight at all)
  * user-data ``@listenKey`` -> account/position/order updates (one REST call
    every ~55 min to refresh the listen key; everything else is push)

Mark prices are PUBLIC — they work even while REST is IP-banned, which is
exactly the failure mode we are eliminating.

The stream is resilient: on any connection drop it reconnects with backoff.
If it is disabled or not yet connected, the exchange getters transparently
fall back to their existing REST path (which the circuit breaker still guards).
"""

from __future__ import annotations

import asyncio
import json
import logging
import time

import websockets

log = logging.getLogger("exchange.ws")

WS_BASE = "wss://fstream.binance.com"
LISTEN_KEY_PATH = "/fapi/v1/listenKey"
MARK_TTL_MS = 10_000          # accept a cached mark price if < 10s old
USER_CACHE_TTL_MS = 15_000    # accept cached positions/orders if < 15s old


class MarketDataStream:
    """Push-based Binance Futures market + user data feed."""

    def __init__(self, api_key: str = "", api_secret: str = "",
                 rest_base: str = "https://fapi.binance.com",
                 ws_base: str = WS_BASE,
                 proxy: str | None = None):
        self.api_key = api_key
        self.api_secret = api_secret
        self.rest_base = rest_base.rstrip("/")
        self.ws_base = ws_base
        # Upstream egress proxy (HTTP/HTTPS) — tunnels REST (listenKey) and WS
        # (mark + user streams) through a clean IP so the bot is immune to
        # host-IP / datacenter-range throttling (e.g. Tencent ap-jakarta block).
        # websockets 15 supports proxy= (CONNECT tunnel); httpx supports proxy=.
        self.proxy = (proxy or "").strip() or None
        self.mark_cache: dict[str, tuple[float, float]] = {}      # SYM -> (price, ts_ms)
        self.positions: dict[str, dict] = {}                      # SYM -> position dict
        self.open_orders: dict[str, dict] = {}                    # orderId -> order dict
        self._symbols: set[str] = set()
        self._running = False
        self._mark_task: asyncio.Task | None = None
        self._user_task: asyncio.Task | None = None
        self._refresh_task: asyncio.Task | None = None
        self._listen_key: str | None = None
        self._listen_key_exp = 0.0
        self._listen_backoff_until = 0.0   # epoch sec; don't fire listenKey REST before this
        self._listen_backoff_secs = 300    # current backoff window (grows on repeat bans)
        self._rebuild_needed = False        # mark stream needs rebuild after add_symbol (loop-safe; avoids asyncio.Event loop-binding warning)
        # last successful contact with each stream (for freshness checks)
        self._mark_ts = 0.0
        self._user_ts = 0.0
        self.on_account_update = None  # optional callback(dict)

    # ── public API ────────────────────────────────────────────────────────
    def add_symbol(self, symbol: str) -> None:
        s = symbol.upper()
        if s not in self._symbols:
            self._symbols.add(s)
            self._rebuild_needed = True   # rebuild the mark stream with the new symbol

    def get_mark_price(self, symbol: str) -> float | None:
        s = symbol.upper()
        hit = self.mark_cache.get(s)
        if hit and (time.time() * 1000 - hit[1]) < MARK_TTL_MS:
            return hit[0]
        return None

    def get_open_orders(self, symbol: str | None = None) -> list[dict]:
        if time.time() * 1000 - self._user_ts > USER_CACHE_TTL_MS:
            return []
        if symbol:
            s = symbol.upper()
            return [o for o in self.open_orders.values()
                    if (o.get("symbol") or "").upper() == s]
        return list(self.open_orders.values())

    def get_positions(self) -> list[dict]:
        if time.time() * 1000 - self._user_ts > USER_CACHE_TTL_MS:
            return []
        return [p for p in self.positions.values()
                if float(p.get("pa", 0)) != 0]

    def mark_stream_alive(self) -> bool:
        return (time.time() * 1000 - self._mark_ts) < MARK_TTL_MS * 3

    def user_stream_alive(self) -> bool:
        return (time.time() * 1000 - self._user_ts) < USER_CACHE_TTL_MS * 3

    # ── lifecycle ─────────────────────────────────────────────────────────
    async def start(self) -> None:
        self._running = True
        self._mark_task = asyncio.create_task(self._run_mark_stream())
        self._user_task = asyncio.create_task(self._run_user_stream())
        self._refresh_task = asyncio.create_task(self._refresh_listen_key_loop())

    async def stop(self) -> None:
        self._running = False
        for t in (self._mark_task, self._user_task, self._refresh_task):
            if t:
                t.cancel()
        for t in (self._mark_task, self._user_task, self._refresh_task):
            try:
                if t:
                    await t
            except (asyncio.CancelledError, Exception):
                pass

    # ── mark-price stream (PUBLIC, no REST) ──────────────────────────────
    async def _run_mark_stream(self) -> None:
        while self._running:
            try:
                streams = "/".join(f"{s.lower()}@markPrice" for s in self._symbols)
                if not streams:
                    await asyncio.sleep(5)
                    continue
                url = f"{self.ws_base}/stream?streams={streams}"
                async with websockets.connect(
                        url, ping_interval=20, ping_timeout=20,
                        close_timeout=5, proxy=self.proxy) as ws:
                    log.info("WS mark stream connected (%d symbols)", len(self._symbols))
                    self._rebuild_needed = False
                    async for raw in ws:
                        try:
                            msg = json.loads(raw)
                        except json.JSONDecodeError:
                            continue
                        d = msg.get("data", msg)
                        sym = d.get("s")
                        price = d.get("p") or d.get("c")
                        if sym and price:
                            self.mark_cache[sym.upper()] = (float(price),
                                                           time.time() * 1000)
                            self._mark_ts = time.time() * 1000
                        if self._rebuild_needed:
                            break  # symbol set changed; reconnect with new list
            except asyncio.CancelledError:
                break
            except Exception as e:
                if not self._running:
                    break
                log.warning("WS mark stream error: %s", e)
                await asyncio.sleep(5)

    # ── user-data stream (needs listen key) ──────────────────────────────
    async def _run_user_stream(self) -> None:
        while self._running:
            try:
                lk = await self._get_listen_key()
                if not lk:
                    # No key (e.g. REST IP-banned). Back off until the ban
                    # clears instead of hammering the banned endpoint every
                    # 30s — hammering is exactly what *extends* the ban.
                    wait = self._listen_backoff_secs or 300
                    log.warning("WS user-data: no listen key, backing off %.0fs "
                                "(ban-aware, will retry after cooldown)", wait)
                    await asyncio.sleep(wait)
                    continue
                url = f"{self.ws_base}/ws/{lk}"
                async with websockets.connect(
                        url, ping_interval=20, ping_timeout=20,
                        close_timeout=5, proxy=self.proxy) as ws:
                    log.info("WS user-data stream connected")
                    async for raw in ws:
                        try:
                            self._handle_user_msg(json.loads(raw))
                        except json.JSONDecodeError:
                            continue
            except asyncio.CancelledError:
                break
            except Exception as e:
                if not self._running:
                    break
                log.warning("WS user-data stream error: %s", e)
                await asyncio.sleep(5)

    async def _get_listen_key(self) -> str | None:
        """Create/refresh a listen key via one REST call (weight 1).

        Returns None on failure (e.g. during a REST IP-ban) so the caller just
        retries later — the mark stream keeps working regardless. On a -1003 IP
        ban we record the ban-until timestamp and back off until it clears
        instead of retrying every loop and *extending* the ban.
        """
        now = time.time()
        if self._listen_key and now < self._listen_key_exp - 60:
            return self._listen_key
        # If we're inside a known ban window, don't even fire the REST call.
        if now < self._listen_backoff_until:
            return self._listen_key
        try:
            import httpx
            headers = {"X-MBX-APIKEY": self.api_key} if self.api_key else {}
            async with httpx.AsyncClient(timeout=10, proxy=self.proxy) as c:
                if self._listen_key:
                    r = await c.put(f"{self.rest_base}{LISTEN_KEY_PATH}",
                                    headers=headers)
                else:
                    r = await c.post(f"{self.rest_base}{LISTEN_KEY_PATH}",
                                     headers=headers)
                if r.status_code == 200:
                    self._listen_key = r.json().get("listenKey")
                    self._listen_key_exp = now + 55 * 60
                    self._listen_backoff_until = 0.0
                    self._listen_backoff_secs = 300
                    return self._listen_key
                if r.status_code in (418, 429) or "IP" in r.text:
                    # Parse ban-until from -1003 / 418 payload and back off.
                    try:
                        msg = r.json().get("msg", "") if r.content else ""
                    except Exception:
                        msg = ""
                    ban_ts = None
                    import re
                    m = re.search(r"banned until (\d+)", msg)
                    if m:
                        ban_ts = int(m.group(1)) / 1000.0
                    if ban_ts and ban_ts > now:
                        self._listen_backoff_until = ban_ts + 5
                        self._listen_backoff_secs = max(
                            60, int(ban_ts - now) + 10)
                    else:
                        self._listen_backoff_secs = min(
                            self._listen_backoff_secs * 2, 1800)
                    log.warning("listenKey banned (HTTP %s) — backing off %.0fs",
                                r.status_code, self._listen_backoff_secs)
        except Exception as e:
            log.debug("listenKey request error: %s", e)
        return self._listen_key  # best effort: keep using it until expiry

    async def _refresh_listen_key_loop(self) -> None:
        while self._running:
            try:
                await asyncio.sleep(55 * 60)
                if self._running:
                    await self._get_listen_key()
            except asyncio.CancelledError:
                break
            except Exception:
                pass

    def _handle_user_msg(self, data: dict) -> None:
        event = data.get("e")
        self._user_ts = time.time() * 1000
        if event == "ACCOUNT_UPDATE":
            for p in data.get("a", {}).get("P", []):
                sym = p.get("s")
                if sym and float(p.get("pa", 0)) == 0:
                    self.positions.pop(sym, None)
                elif sym:
                    self.positions[sym] = p
            if self.on_account_update:
                try:
                    self.on_account_update(data)
                except Exception:
                    pass
        elif event == "executionReport":
            oid = str(data.get("i"))
            status = data.get("X")
            if status in ("CANCELED", "REJECTED", "FILLED", "EXPIRED", "NEW"):
                if status == "NEW":
                    self.open_orders[oid] = data
                else:
                    self.open_orders.pop(oid, None)
