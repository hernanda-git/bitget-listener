"""Binance exchange adapter — REST API for both Spot and USDⓈ-M Futures.

Supports:
  - Spot trading (api.binance.com)
  - USDⓈ-M Futures (fapi.binance.com)
  - Testnet for both (testnet.binance.vision / testnet futures)
"""

from __future__ import annotations

import hashlib
import hmac
import json
import logging
import os
import re
import time
from datetime import datetime, timezone
from enum import Enum
from math import log10
from typing import Any
from urllib.parse import urlencode

from src.exchange.ws_stream import MarketDataStream


class RateLimited(Exception):
    """Raised when Binance has IP-banned / rate-limited this client.

    The caller should treat this as a signal to back off, NOT to retry
    immediately (retrying extends the ban). The exchange client tracks the
    ban-until timestamp and auto-clears it.
    """

import httpx

from src.exchange.base import BalanceInfo, Exchange, OrderInfo, PositionInfo

log = logging.getLogger("exchange.binance")


# ─── Gateway relay client (used only when proxy mode is enabled) ──────────────
# Mirrors src.signing on the gateway: signs (method, path, query, body) with the
# shared HMAC secret so the gateway can verify + replay-protect. Sends the
# Binance request on behalf of the listener — the listener never sees the key.
def _gw_sign(secret: str, method: str, path: str,
             query: dict | None, body: bytes | None):
    ts = int(time.time())
    q = urlencode(query or {}, doseq=True)
    canon = f"{method.upper()}\n{path}\n{q}\n{(body or b'').decode('utf-8', 'replace')}"
    sig = hmac.new(secret.encode("utf-8"), canon.encode("utf-8"), hashlib.sha256).hexdigest()
    return {"X-Gateway-Sig": sig, "X-Gateway-Ts": str(ts)}


class BinanceErrorCategory(Enum):
    AUTH = "auth"        # 401/403 — bad key, no permission
    RATE_LIMIT = "rate"  # 429 — backoff needed
    SERVER = "server"    # 5xx — Binance internal error
    VALIDATION = "validation"  # 400 — bad request params
    NETWORK = "network"  # timeout / connection
    UNKNOWN = "unknown"


# ─── Binance error code → user-friendly message ─────────────────────────────
_ERROR_MESSAGES: dict[int, str] = {
    -1100: "Illegal characters in request — possible symbol or quantity format issue",
    -1013: "Order value too small — increase quantity or use higher leverage",
    -1102: "Missing required parameter — contact developer",
    -1111: "Price/quantity precision too high for this pair — rounding issue",
    -1121: "Invalid symbol — this pair may not exist on Binance Futures",
    -2019: "Insufficient margin — not enough free USDT for this position size",
    -2020: "Order would immediately fill — try a different price or order type",
    -4003: "Quantity must be greater than zero",
    -4004: "Quantity too large for this pair",
    -4164: "Order notional too small — minimum $5 on Binance Futures (increase quantity or leverage)",
    -4120: "Order type not supported for this contract — SL/TP handled by position manager",
    -4136: "Invalid order type/parameters for this contract",
    -4188: "Reduce-only order would increase position — check order side",
}


def _parse_binance_error(response_text: str) -> tuple[int, str]:
    """Extract Binance error code and message from JSON response body.

    Returns (code, message). Falls back to raw text if not JSON.
    """
    try:
        data = json.loads(response_text)
        code = int(data.get("code", 0))
        msg = str(data.get("msg", ""))
        return code, msg
    except (json.JSONDecodeError, ValueError, TypeError):
        return 0, response_text[:200]


def _format_order_error(symbol: str, side: str, order_type: str,
                        quantity: float, price: float | None,
                        leverage: int, status_code: int,
                        response_text: str) -> str:
    """Build a user-friendly, traceable error message for a failed order.

    Includes: what was attempted, why it failed, and what to do about it.
    """
    code, binance_msg = _parse_binance_error(response_text)
    friendly = _ERROR_MESSAGES.get(code, binance_msg or f"HTTP {status_code}")

    # Compute notional for context
    ref_price = price or 0
    notional = quantity * ref_price if ref_price > 0 else 0

    parts = [
        f"❌ **Failed to place order — {symbol}**",
        f"   ├ Side: `{side}` | Type: `{order_type}`",
        f"   ├ Qty: `{quantity}`",
    ]
    if ref_price > 0:
        parts.append(f"   ├ Price: `{ref_price}` | Notional: `${notional:.2f}`")
    if leverage > 1:
        parts.append(f"   ├ Leverage: `{leverage}x`")
    parts.append(f"   ├ Error code: `{code}`" if code else f"   ├ HTTP: `{status_code}`")
    parts.append(f"   └ {friendly}")

    return "\n".join(parts)


def _categorize_error(status_code: int | None, error_text: str,
                      exception: Exception | None) -> BinanceErrorCategory:
    if status_code == 401 or status_code == 403:
        return BinanceErrorCategory.AUTH
    if status_code == 429:
        return BinanceErrorCategory.RATE_LIMIT
    if status_code and 500 <= status_code < 600:
        return BinanceErrorCategory.SERVER
    if status_code == 400:
        return BinanceErrorCategory.VALIDATION
    if isinstance(exception, (httpx.TimeoutException, httpx.ConnectError,
                               httpx.RemoteProtocolError, httpx.TransportError)):
        return BinanceErrorCategory.NETWORK
    return BinanceErrorCategory.UNKNOWN

# ─── Base URLs ────────────────────────────────────────────────────────────────
SPOT_URLS = {
    "mainnet": "https://api.binance.com",
    "testnet": "https://testnet.binance.vision",
}
FUTURES_URLS = {
    "mainnet": "https://fapi.binance.com",
    "testnet": "https://testnet.binancefuture.com",
}

# ─── Order type mapping (spot -> futures equivalent) ─────────────────────────
FUTURES_ORDER_TYPES = {
    "MARKET": "MARKET",
    "LIMIT": "LIMIT",
    "STOP_LOSS": "STOP_MARKET",       # spot STOP_LOSS → futures STOP_MARKET
    "STOP_LOSS_LIMIT": "STOP",        # conditional STOP-LIMIT (futures "STOP")
    "TAKE_PROFIT_LIMIT": "TAKE_PROFIT",  # conditional TP-LIMIT (futures "TAKE_PROFIT")
    "TAKE_PROFIT": "TAKE_PROFIT_MARKET",  # spot TP → market (no price protection)
}

# ─── Symbol mapping: user-facing pair → actual Binance Futures symbol + price multiplier ──
# Some low-price tokens are listed as 1000x contracts on Binance Futures
# (e.g., 1 contract = 1000 BONK tokens)
# CRITICAL: The price on 1000x contracts is QUOTED in the base asset price (e.g. BONK = 0.0044),
# NOT multiplied by 1000. The lot multiplier handles the conversion internally.
# QUANTITY is also in base asset tokens (e.g. BONK), not divided by 1000.
# The "1000" in the symbol name only affects the CONTRACT MULTIPLIER for PnL calc.
# (symbol, price_multiplier, qty_divisor)
SYMBOL_MAP: dict[str, tuple[str, float, float]] = {
    # (actual_symbol, price_multiplier, qty_divisor)
    # Both price and quantity remain in base asset (BONK) terms
    "BONKUSDT":   ("1000BONKUSDT", 1.0, 1.0),
    "PEPEUSDT":   ("1000PEPEUSDT", 1.0, 1.0),
    "SHIBUSDT":   ("1000SHIBUSDT", 1.0, 1.0),
    "FLOKIUSDT":  ("1000FLOKIUSDT", 1.0, 1.0),
    "1000BONK":   ("1000BONKUSDT", 1.0, 1.0),
    "1000PEPE":   ("1000PEPEUSDT", 1.0, 1.0),
    "1000SHIB":   ("1000SHIBUSDT", 1.0, 1.0),
    "1000FLOKI":  ("1000FLOKIUSDT", 1.0, 1.0),
}

def _resolve_futures_symbol(raw_symbol: str) -> tuple[str, float, float]:
    """Resolve a user-facing symbol to the actual Binance Futures symbol + multipliers.

    Uses the dynamic SymbolRegistry first (populated from live exchangeInfo),
    falling back to the static SYMBOL_MAP for known 1000x contracts.

    1000x contracts (e.g. 1000BONKUSDT, 1000PEPEUSDT):
    - The "1000" prefix is a CONTRACT MULTIPLIER for PnL calculation only.
    - PRICE is quoted in base asset terms (e.g. BONK = 0.0044), NOT multiplied by 1000.
    - QUANTITY is also in base asset tokens (e.g. BONK), NOT divided by 1000.
    - STOP/STOP_MARKET orders are BLOCKED by Binance for 1000x contracts (error -4120).
    - LIMIT orders (TP) work fine on 1000x contracts.

    Args:
        raw_symbol: User-facing symbol (e.g. 'BONKUSDT', 'PEPEUSDT', '1000BONKUSDT')

    Returns:
        (resolved_symbol, price_multiplier, qty_divisor)
        - price_multiplier: always 1.0 (price stays in base asset terms)
        - qty_divisor: always 1.0 (quantity stays in base asset terms)
    """
    s = raw_symbol.upper().strip()

    # Try dynamic SymbolRegistry first (live exchangeInfo data)
    try:
        from src.exchange.symbol_registry import get_registry
        registry = get_registry()
        if registry and registry.is_ready:
            info = registry.get_symbol_info(s)
            if info:
                return info.symbol, 1.0, 1.0
            # Try resolving via the registry's resolve text-based method
            resolved_symbol, resolved_info = registry.resolve(s)
            if resolved_symbol and resolved_info:
                return resolved_symbol, 1.0, 1.0
    except Exception:
        pass

    # Fall back to static SYMBOL_MAP for known 1000x contracts
    if s in SYMBOL_MAP:
        mapped, pm, qd = SYMBOL_MAP[s]
        return mapped, pm, qd
    # Try without 'USDT' suffix for coin-only names
    base = s.replace("USDT", "").replace("USD", "")
    if base in SYMBOL_MAP:
        mapped, pm, qd = SYMBOL_MAP[base]
        return mapped, pm, qd
    # Check if already 1000x prefixed
    if s.startswith("1000"):
        return s, 1.0, 1.0
    # Default: use the symbol as-is
    return s, 1.0, 1.0


class BinanceExchange(Exchange):
    """Binance API adapter for Spot or USDⓈ-M Futures.

    Args:
        api_key: Binance API key.
        api_secret: Binance API secret.
        testnet: If True, use testnet endpoints.
        futures: If True, use Futures API (fapi) instead of Spot API.
        leverage: Futures leverage (default 1 = no leverage). Ignored for Spot.
        recv_window: Binance recvWindow param.
    """

    def __init__(self, api_key: str, api_secret: str, testnet: bool = True,
                 futures: bool = False, leverage: int = 1,
                 recv_window: int = 5000, proxy: dict | None = None,
                 ws_enabled: bool = False,
                 egress_proxy: str | None = None):
        self.api_key = api_key
        self.api_secret = api_secret
        self.testnet = testnet
        self.futures = futures
        self.leverage = max(1, leverage)  # fallback default
        self.recv_window = min(int(recv_window), 60000)
        # Upstream egress proxy (HTTP/HTTPS) — routes ALL Binance traffic
        # (REST + WS) through a clean IP so the bot is immune to host-IP /
        # datacenter-range throttling (e.g. the Tencent ap-jakarta block).
        self.egress_proxy = (egress_proxy or "").strip() or None

        # Proxy mode: route Binance calls through a signed gateway relay.
        # When enabled, the Binance api_key/secret are NOT required locally.
        self.proxy = proxy or {}
        self.proxy_enabled = bool(self.proxy.get("enabled"))
        self.proxy_url = (self.proxy.get("url") or "").rstrip("/")
        # Secret may be given directly or via an env var (preferred — keeps the
        # secret out of config.yaml / git history).
        proxy_secret = self.proxy.get("hmac_secret", "")
        proxy_secret_env = self.proxy.get("hmac_secret_env", "")
        if not proxy_secret and proxy_secret_env:
            proxy_secret = os.environ.get(proxy_secret_env, "")
        self.proxy_secret = proxy_secret
        if self.proxy_enabled:
            if not self.proxy_url or not self.proxy_secret:
                log.warning("Proxy enabled but GATEWAY_URL/HMAC_SECRET missing — "
                            "falling back to direct Binance calls")
                self.proxy_enabled = False
            else:
                log.info("Binance calls routed through gateway relay: %s", self.proxy_url)

        urls = FUTURES_URLS if futures else SPOT_URLS
        base_url = urls["testnet"] if testnet else urls["mainnet"]
        self._base = base_url
        self._client = httpx.AsyncClient(base_url=base_url, timeout=10,
                                          proxy=self.egress_proxy) if not self.proxy_enabled else None

        # A testnet API key/secret (testnet.binancefuture.com / testnet.binance.vision)
        # may be configured with active: binance instead of binance_testnet, so
        # derive the authoritative testnet flag from the chosen base URL as well.
        # This keeps the Algo Order API (mainnet-only) OFF on testnet and avoids
        # 404s + rejected-order spam for pairs that need it.
        self.testnet = self.testnet or "testnet" in base_url
        # Algo Order API (conditional STOP/TAKE_PROFIT for -4120 pairs like
        # XPLUSDT) is opt-in: its exact endpoint route differs per environment
        # and a wrong route 404s. Enable via env BINANCE_ALGO_ORDERS=1 once the
        # correct endpoint is confirmed for the target account/environment.
        self._algo_enabled = (os.environ.get("BINANCE_ALGO_ORDERS") == "1")
        # Cache symbol rules: stepSize/minQty/maxQty/valid
        self._filters: dict[str, dict] = {}
        self._invalid_symbols: dict[str, datetime] = {}

        # ── Rate-limit circuit breaker ────────────────────────────────────
        # When Binance IP-bans this host (error -1003 / HTTP 418) we record the
        # ban-until timestamp (parsed from the error message) and REFUSE further
        # REST calls until it clears. This stops the monitor loop from hammering
        # the API and re-extending the ban. Auto-clears when time passes.
        self._ban_until_ms: float = 0.0
        self._rate_limited_until_ms: float = 0.0  # softer backoff for 429/-1006
        self._consecutive_429 = 0

        # ── Mark-price cache ───────────────────────────────────────────────
        # SL monitoring reads from here instead of calling REST every tick.
        # Refreshed lazily via a single batched ticker call (weight 50) rather
        # than N per-symbol calls. Keyed by resolved futures symbol.
        self._mark_cache: dict[str, tuple[float, float]] = {}  # sym -> (price, ts_ms)
        self._mark_cache_ttl_ms: int = 5000  # refresh cache if older than 5s
        self._mark_cache_refreshing = False

        # ── Websocket market-data stream ────────────────────────────────────
        # When enabled, mark prices + positions/orders are pushed via WS (zero
        # REST weight). getters fall back to REST (breaker-guarded) when WS is
        # absent/stale. This is the real fix for the persistent IP-ban.
        self._ws: "MarketDataStream | None" = None
        # Configure the websocket stream now so it's ready to start() at boot.
        self._configure_ws(ws_enabled, api_key, api_secret)

        # Leverage is set per-symbol dynamically before each trade.
        # No startup leverage call needed.

    @property
    def name(self) -> str:
        prefix = "binance"
        if self.testnet:
            prefix += "_testnet"
        if self.futures:
            prefix += "_futures"
        return prefix

    # ─── Auth ──────────────────────────────────────────────────────────────────

    def _sign(self, params: dict) -> str:
        """Create HMAC-SHA256 signature for the params."""
        query = urlencode(params)
        return hmac.new(
            self.api_secret.encode("utf-8"),
            query.encode("utf-8"),
            hashlib.sha256,
        ).hexdigest()

    # ── Rate-limit circuit breaker ──────────────────────────────────────────
    def _assert_not_banned(self) -> None:
        """Raise RateLimited if we are inside a Binance ban/backoff window."""
        now = time.time() * 1000
        if self._ban_until_ms and now < self._ban_until_ms:
            secs = (self._ban_until_ms - now) / 1000.0
            raise RateLimited(f"IP banned until {self._ban_until_ms} (~{secs:.0f}s left)")
        if self._rate_limited_until_ms and now < self._rate_limited_until_ms:
            raise RateLimited(f"rate-limited backoff until {self._rate_limited_until_ms}")
        # Auto-clear expired bans so normal calls resume.
        if self._ban_until_ms and now >= self._ban_until_ms:
            log.info("Binance IP ban window elapsed — resuming REST calls")
            self._ban_until_ms = 0
        if self._rate_limited_until_ms and now >= self._rate_limited_until_ms:
            self._rate_limited_until_ms = 0
            self._consecutive_429 = 0

    def _note_rate_limit(self, status_code: int, text: str,
                         headers: dict | None = None) -> None:
        """Record a ban/backoff window from a Binance error response."""
        now = time.time() * 1000
        low = (text or "").lower()
        # Hard IP ban: -1003 "Way too many requests; IP(x) banned until <ts>"
        if status_code in (418, 429) or "-1003" in text or "banned until" in low \
                or "too many requests" in low:
            m = re.search(r"banned until (\d+)", text or "")
            if m:
                self._ban_until_ms = int(m.group(1))
                log.warning("Binance IP BAN recorded until %d (%.0f min) — "
                            "pausing REST to avoid extending it",
                            self._ban_until_ms,
                            (self._ban_until_ms - now) / 60000.0)
                # Persist a local marker so /binancestatus can report the last
                # known ban without ever pinging Binance.
                try:
                    from datetime import datetime as _dt
                    marker = "/data/binance_ban_status.txt"
                    line = (f"{_dt.utcnow().isoformat()}Z ban until "
                            f"{self._ban_until_ms} "
                            f"(~{round((self._ban_until_ms-now)/60000.0)}min) "
                            f"ip={os.environ.get('HOST_IP','?')}")
                    with open(marker, "a") as fh:
                        fh.write(line + "\n")
                except Exception:
                    pass
            else:
                # No explicit timestamp: back off 60s (429) or 120s (418).
                backoff = 120000 if status_code == 418 else 60000
                self._rate_limited_until_ms = now + backoff
                log.warning("Binance rate-limit (HTTP %s) — backing off %ds",
                            status_code, backoff // 1000)
        # Weight/timeouts (-1006 disconnect, -1007 timeout): short backoff.
        elif "-1006" in text or "-1007" in text or status_code == 418:
            self._consecutive_429 += 1
            backoff = min(30000 * self._consecutive_429, 120000)
            self._rate_limited_until_ms = now + backoff
            log.warning("Binance transient error — backing off %ds",
                        backoff // 1000)
        # Respect Retry-After header if present.
        if headers:
            ra = headers.get("Retry-After")
            if ra and str(ra).isdigit():
                self._rate_limited_until_ms = max(
                    self._rate_limited_until_ms, now + int(ra) * 1000 + 1000)

    def _headers(self) -> dict:
        return {"X-MBX-APIKEY": self.api_key}

    async def _signed_request(self, method: str, path: str,
                        params: dict | None = None) -> dict:
        """Send a signed request to Binance API.

        In proxy mode, the request is forwarded (already signed with the local
        Binance key) to the gateway relay, which swaps in its own key. The local
        key is still used to sign `params` so behaviour is identical.
        """
        params = params or {}
        params["timestamp"] = int(time.time() * 1000)
        params["recvWindow"] = self.recv_window
        params["signature"] = self._sign(params)

        # ── Circuit breaker: refuse REST while IP-banned / backing off ──
        self._assert_not_banned()

        # ── Proxy mode: forward through the gateway relay ────────────────
        if self.proxy_enabled:
            body = json.dumps(params).encode("utf-8")
            headers = _gw_sign(self.proxy_secret, method, path, params, body)
            headers["Content-Type"] = "application/json"
            async with httpx.AsyncClient(timeout=15) as client:
                resp = await client.request(
                    method, f"{self.proxy_url}{path}",
                    params=params, headers=headers,
                )
        else:
            resp = await self._client.request(method, path, params=params,
                                        headers=self._headers())

        if resp.status_code != 200:
            self._note_rate_limit(resp.status_code, resp.text,
                                  dict(resp.headers))
            category = _categorize_error(resp.status_code, resp.text, None)
            log.error("Binance API error %s [%s]: %s", resp.status_code, category.value, resp.text)
            if category == BinanceErrorCategory.AUTH:
                raise httpx.HTTPStatusError(
                    f"Binance auth failed ({resp.status_code}): {resp.text}",
                    request=resp.request, response=resp,
                )
            body = ""
            try:
                body = resp.text
            except Exception:
                pass
            resp.raise_for_status()
        return resp.json()

    async def _public_request(self, method: str, path: str,
                        params: dict | None = None) -> dict:
        """Send a public request (no auth required).

        In proxy mode, public market-data calls are also relayed so the listener
        never talks to Binance directly.
        """
        if self.proxy_enabled:
            headers = _gw_sign(self.proxy_secret, method, path, params, None)
            async with httpx.AsyncClient(timeout=15) as client:
                resp = await client.request(
                    method, f"{self.proxy_url}{path}",
                    params=params, headers=headers,
                )
            resp.raise_for_status()
            return resp.json()
        # ── Circuit breaker: refuse REST while IP-banned / backing off ──
        self._assert_not_banned()
        resp = await self._client.request(method, path, params=params)
        if resp.status_code != 200:
            self._note_rate_limit(resp.status_code, resp.text,
                                  dict(resp.headers))
        resp.raise_for_status()
        return resp.json()

    def _order_path(self) -> str:
        return "/fapi/v1/order" if self.futures else "/api/v3/order"

    def _map_type(self, order_type: str) -> str:
        """Map spot order type to futures equivalent if needed."""
        if self.futures:
            return FUTURES_ORDER_TYPES.get(order_type.upper(), order_type.upper())
        return order_type.upper()

    async def max_leverage_for(self, symbol: str) -> int:
        """Return the pair's real Binance max leverage (from leverageBrackets).

        Falls back to the configured ``max_leverage`` when the registry is
        unavailable, so callers can always use it as a safe ceiling.
        """
        try:
            from src.exchange.symbol_registry import get_registry
            reg = get_registry()
            if reg and reg.is_ready:
                resolve_sym, _, _ = _resolve_futures_symbol(symbol)
                info = reg.get_symbol_info(resolve_sym)
                if info is not None and getattr(info, "max_leverage", 0) > 0:
                    return int(info.max_leverage)
        except Exception as e:  # noqa: BLE001 — best-effort
            log.debug("max_leverage_for(%s) registry lookup failed: %s", symbol, e)
        return int(self.config.get("risk", {}).get("max_leverage", 20))

    async def set_symbol_leverage(self, symbol: str, leverage: int):
        """Set leverage for a specific symbol before trading.

        Clamps ``leverage`` to the pair's real Binance max (from
        leverageBrackets) so we never send an invalid value (Binance -4021).
        """
        if not self.futures:
            return
        resolve_sym, _, _ = _resolve_futures_symbol(symbol)
        pair_max = await self.max_leverage_for(symbol)
        leverage = max(1, min(int(leverage), pair_max, 125))
        try:
            params = {
                "symbol": resolve_sym,
                "leverage": leverage,
            }
            result = await self._signed_request("POST", "/fapi/v1/leverage", params)
            self._last_leverage = leverage
            log.info("Leverage set: %s -> %s %dx", symbol, resolve_sym, leverage)
        except Exception as e:
            log.warning("Failed to set leverage for %s: %s", symbol, e)

    async def set_margin_type(self, symbol: str, margin_type: str = "ISOLATED"):
        """Set margin type (ISOLATED or CROSSED) for futures position."""
        if not self.futures:
            return
        resolve_sym, _, _ = _resolve_futures_symbol(symbol)
        try:
            params = {
                "symbol": resolve_sym,
                "marginType": margin_type.upper(),
            }
            await self._signed_request("POST", "/fapi/v1/marginType", params)
            log.info("Margin type: %s -> %s %s", symbol, resolve_sym, margin_type.upper())
        except Exception as e:
            # Error -4008 means already set, ignore
            log.info("Margin type %s for %s (may already be set)", margin_type, symbol)

    # ─── Balance ───────────────────────────────────────────────────────────────

    async def get_balance(self) -> BalanceInfo:
        """Get account balance.

        For futures: returns available wallet balance in USDT.
        For spot: returns total USDT + asset values.
        """
        if self.futures:
            return await self._get_futures_balance()
        return await self._get_spot_balance()

    async def _get_spot_balance(self) -> BalanceInfo:
        """Get spot account balance."""
        data = await self._signed_request("GET", "/api/v3/account")
        assets = {}
        free_usdt = 0.0
        total_usdt = 0.0

        for bal in data.get("balances", []):
            asset = bal["asset"]
            free = float(bal["free"])
            locked = float(bal["locked"])
            if free > 0 or locked > 0:
                assets[asset] = {"free": free, "locked": locked}
                if asset == "USDT":
                    free_usdt = free
                    total_usdt = free + locked
                else:
                    try:
                        ticker_path = "/api/v3/ticker/price"
                        ticker = await self._public_request(
                            "GET", ticker_path,
                            {"symbol": f"{asset}USDT"},
                        )
                        price = float(ticker.get("price", 0))
                        total_usdt += (free + locked) * price
                    except Exception:
                        pass

        return BalanceInfo(
            total_usdt=round(total_usdt, 2),
            free_usdt=round(free_usdt, 2),
            assets=assets,
        )
    async def _get_futures_balance(self) -> BalanceInfo:
        """Get futures account balance.

        Returns available balance in USDT (wallet balance).
        """
        data = await self._signed_request("GET", "/fapi/v2/account")

        assets = {}
        free_usdt = 0.0
        total_usdt = 0.0

        for bal in data.get("assets", []):
            asset = bal["asset"]
            wallet = float(bal.get("walletBalance", 0))
            cross = float(bal.get("crossWalletBalance", 0))
            margin = float(bal.get("marginBalance", 0))
            # Unrealized PnL
            upnl = float(bal.get("unrealizedProfit", 0))
            if wallet > 0 or margin > 0 or asset == "USDT":
                assets[asset] = {
                    "wallet": wallet,
                    "cross": cross,
                    "margin": margin,
                    "unrealized_pnl": upnl,
                }
                if asset == "USDT":
                    free_usdt = cross   # available for trading
                    total_usdt = margin  # total equity including unrealized PnL

        return BalanceInfo(
            total_usdt=round(total_usdt, 2),
            free_usdt=round(free_usdt, 2),
            assets=assets,
        )

    # ─── Symbol filters/cache ──────────────────────────────────────────────────

    async def _load_futures_filters(self, symbol: str) -> dict | None:
        """Get symbol trading rules from exchange info, with caching."""
        resolve_sym, _, _ = _resolve_futures_symbol(symbol)
        now = datetime.now(timezone.utc)
        # Reuse if recent
        cached = self._filters.get(resolve_sym)
        if cached:
            if (now - cached["_updated"]).total_seconds() < 600:
                return cached
            if not cached.get("valid", True):
                return None
        # Reject recently known invalid symbols
        rejected = self._invalid_symbols.get(symbol)
        if rejected:
            if (now - rejected).total_seconds() < 3600:
                return None
        # Fetch
        try:
            data = await self._public_request("GET", "/fapi/v1/exchangeInfo", {"symbol": resolve_sym})
            rules = data.get("symbols", [])
            if not rules:
                self._invalid_symbols[resolve_sym] = now
                log.info("Binance futures symbol not found: %s (from %s)", resolve_sym, symbol)
                return None
            # Match the requested symbol by resolved name, then exact raw
            # symbol, then fall back to the first element. NEVER blindly take
            # rules[0] — for APEUSDT the response's first element was BTCUSDT,
            # which produced a wrong minPrice and triggered Binance -1111.
            s = None
            for cand in rules:
                if cand.get("symbol") == resolve_sym:
                    s = cand
                    break
            if s is None:
                s = next((c for c in rules if c.get("symbol") == symbol.upper()), rules[0])
            out = {"_updated": now, "valid": True}
            for f in s.get("filters", []):
                ft = f.get("filterType")
                if ft == "PRICE_FILTER":
                    out["tickSize"] = float(f.get("tickSize", 0))
                    out["minPrice"] = float(f.get("minPrice", 0))
                    out["maxPrice"] = float(f.get("maxPrice", 0))
                elif ft == "LOT_SIZE":
                    out["minQty"] = float(f.get("minQty", 0))
                    out["maxQty"] = float(f.get("maxQty", 0))
                    out["stepSize"] = float(f.get("stepSize", 1))
                elif ft == "MARKET_LOT_SIZE":
                    out["mktMinQty"] = float(f.get("minQty", 0))
                    out["mktMaxQty"] = float(f.get("maxQty", 0))
                    out["mktStepSize"] = float(f.get("stepSize", 1))
                elif ft == "MIN_NOTIONAL":
                    # Some pairs expose "notional", older ones "minNotional".
                    mn = f.get("notional", f.get("minNotional", 0))
                    if mn:
                        out["minNotional"] = float(mn)
            status = s.get("status")
            out["status"] = status
            if status != "TRADING":
                out["valid"] = False
                self._invalid_symbols[resolve_sym] = now
                log.info("Binance symbol not trading: %s (%s)", resolve_sym, status)
                return None
            self._filters[resolve_sym] = out
            return out
        except Exception as e:
            log.debug("exchangeInfo lookup failed for %s: %s", symbol, e)
            return None

    async def _round_quantity(self, symbol: str, quantity: float,
                             price_ref: float | None = None) -> tuple[float, dict | None]:
        """Round quantity to exchange precision for symbol.

        Lazily loads filters on cache miss (async) for reliability.
        Falls back to integer rounding for low-price coins if filters unavailable.

        Args:
            symbol: Trading symbol.
            quantity: Desired quantity.
            price_ref: Reference price used to enforce the exchange MIN_NOTIONAL
                       filter (qty * price_ref >= minNotional). Optional; when
                       omitted the minNotional loop is skipped.

        Returns (rounded_quantity, rules_or_None).
        """
        if quantity <= 0:
            return quantity, None

        # Lazy-load filters if not cached
        rules = self._filters.get(symbol)
        if not rules:
            filters = await self._load_futures_filters(symbol)
            if filters:
                rules = filters
            else:
                # Fallback: integer rounding for low-price coins (< 1 USDT per token)
                if quantity > 0 and quantity < 10000000:
                    qty = round(quantity)
                    prec = max(0, -int(round(log10(1))) if 1 < 1 else 0)
                    qty = float(f"{qty:.{prec}f}")
                    return qty, None
                return round(quantity), None

        step = rules.get("stepSize") or rules.get("mktStepSize") or 1.0
        rounded = round(quantity / step) * step
        if rounded <= 0 and step > 0:
            rounded = step
        if "minQty" in rules:
            rounded = max(rounded, rules["minQty"])
        if "mktMinQty" in rules:
            rounded = max(rounded, rules["mktMinQty"])
        # Meet the exchange MIN_NOTIONAL using the real filter value, not a
        # hardcoded constant. Bump the lot until qty * price_ref >= minNotional.
        mn = rules.get("minNotional")
        if mn and price_ref and price_ref > 0:
            guard = 0
            while rounded * price_ref < mn and guard < 1_000_000:
                rounded += step
                guard += 1
        prec = max(0, -int(round(log10(step))) if step < 1 else 0)
        rounded = float(f"{rounded:.{prec}f}")
        return rounded, rules

    async def _round_price(self, symbol: str, price: float) -> tuple[float, dict | None]:
        """Round price to exchange tick-size precision for symbol.

        Uses PRICE_FILTER.tickSize from the cached exchangeInfo filters.
        Falls back to 6-decimal rounding if filters are unavailable.
        Returns (rounded_price, rules_or_None).

        This is the root-cause guard against Binance error -1111
        ("Precision is over the maximum defined for this asset") — outgoing
        LIMIT/STOP/TP prices must align to the pair's tick size.
        """
        if price is None or price <= 0:
            return price, None

        rules = self._filters.get(symbol)
        if not rules:
            filters = await self._load_futures_filters(symbol)
            if filters:
                rules = filters

        if rules and rules.get("tickSize"):
            step = float(rules["tickSize"])
            rounded = round(price / step) * step
            if rounded <= 0 and step > 0:
                rounded = step
            # Clamp to exchange price bounds when known.
            # Only clamp DOWN to the floor when the rounded price is genuinely
            # below it. A minPrice that is >10x the requested price signals a
            # bad filter (e.g. a leaked rules[0] from another symbol) — do NOT
            # inflate the price, which would flip its order of magnitude and
            # trigger Binance -1111.
            if rules.get("minPrice") is not None:
                band_lo = rules["minPrice"]
                if rounded < band_lo and band_lo <= price * 10:
                    rounded = band_lo
            if rules.get("maxPrice") is not None and rounded > rules["maxPrice"]:
                rounded = rules["maxPrice"]
            prec = max(0, -int(round(log10(step))) if step < 1 else 0)
            rounded = float(f"{rounded:.{prec}f}")
            return rounded, rules

        # Fallback: 6 decimals (safe for most futures pairs)
        return float(f"{price:.6f}"), None

    async def _preflight_symbol(self, symbol: str) -> bool:
        """Ensure a futures symbol can be traded; loads filters if needed."""
        resolve_sym, _, _ = _resolve_futures_symbol(symbol)
        if resolve_sym in self._filters or resolve_sym in self._invalid_symbols:
            return bool(self._filters.get(resolve_sym, {}).get("valid") is True)
        rules = await self._load_futures_filters(resolve_sym)
        return bool(rules)

    async def get_open_position(self, symbol: str) -> PositionInfo | None:
        """Authoritative single-symbol open-position lookup from Binance.

        Uses the per-symbol futures position endpoint so management commands
        resolve against the exchange of record even when the local DB row is
        missing/stale (the /positions desync bug). Returns None when flat.
        """
        if not self.futures:
            return None
        try:
            sym = symbol.replace("#", "").replace("$", "").upper()
            if not sym.endswith("USDT"):
                sym += "USDT"
            data = await self._signed_request(
                "GET", "/fapi/v2/positionRisk", params={"symbol": sym}
            )
            if not isinstance(data, list):
                return None
            for pos in data:
                size = float(pos.get("positionAmt", 0))
                if abs(size) > 0 and pos.get("symbol", "").upper() == sym:
                    return PositionInfo(
                        symbol=pos.get("symbol", ""),
                        direction="LONG" if size > 0 else "SHORT",
                        size=abs(size),
                        entry_price=float(pos.get("entryPrice", 0)),
                        mark_price=float(pos.get("markPrice", 0)),
                        liquidation_price=float(pos.get("liquidationPrice", 0)),
                        unrealized_pnl=float(pos.get("unRealizedProfit", 0)),
                        margin=float(pos.get("isolatedWallet", 0)),
                        leverage=int(float(pos.get("leverage", 1))),
                        notional=abs(float(pos.get("notional", 0))),
                    )
        except Exception as e:
            log.warning("get_open_position(%s) failed: %s", symbol, e)
        return None

    async def get_positions(self) -> list[PositionInfo]:
        """Get all open futures positions from the exchange."""
        if not self.futures:
            return []
        try:
            data = await self._signed_request("GET", "/fapi/v2/account")
            positions: list[PositionInfo] = []
            for pos in data.get("positions", []):
                size = float(pos.get("positionAmt", 0))
                if size == 0:
                    continue
                direction = "LONG" if size > 0 else "SHORT"
                positions.append(PositionInfo(
                    symbol=pos.get("symbol", ""),
                    direction=direction,
                    size=abs(size),
                    entry_price=float(pos.get("entryPrice", 0)),
                    mark_price=float(pos.get("markPrice", 0)),
                    liquidation_price=float(pos.get("liquidationPrice", 0)),
                    unrealized_pnl=float(pos.get("unrealizedProfit", 0)),
                    margin=float(pos.get("isolatedWallet", 0)),
                    leverage=int(float(pos.get("leverage", 1))),
                    notional=abs(float(pos.get("notional", 0))),
                ))
            return positions
        except Exception as e:
            log.error("Failed to fetch positions: %s", e)
            return []

    # ─── Price / Candles ──────────────────────────────────────────────────

    async def get_klines(self, symbol: str, interval: str = "4h",
                         limit: int = 100) -> list[list]:
        """Get full OHLCV klines from Binance Futures.

        Each candle: [open_time, open, high, low, close, volume, close_time,
                      quote_vol, trades, taker_buy_vol, taker_buy_quote_vol, ignore].

        Returns the raw Binance array (excluding the still-forming last candle).
        """
        resolve_sym, _, _ = _resolve_futures_symbol(symbol)
        try:
            params = {"symbol": resolve_sym, "interval": interval, "limit": limit + 1}
            resp = await self._public_request(
                "GET",
                "/fapi/v1/klines" if self.futures else "/api/v3/klines",
                params,
            )
            # Drop the last candle (still forming) — only closed candles
            data = resp if isinstance(resp, list) else []
            return data[:-1] if len(data) > 1 else data
        except Exception as e:
            log.warning("Failed to fetch klines for %s %s: %s", symbol, interval, e)
            return []

    async def get_klines_close(self, symbol: str, interval: str = "4h") -> float | None:
        """Get the latest closed candle close price from Binance Futures klines.

        Args:
            symbol: Trading pair (e.g. 'BONKUSDT')
            interval: Candle interval (1m, 5m, 15m, 30m, 1h, 2h, 4h, 6h, 12h, 1d, etc.)

        Returns:
            Close price of the most recently closed candle, or None on error.
        """
        resolve_sym, _, _ = _resolve_futures_symbol(symbol)
        try:
            params = {"symbol": resolve_sym, "interval": interval, "limit": 2}
            resp = await self._public_request("GET", "/fapi/v1/klines" if self.futures else "/api/v3/klines", params)
            # Last item is the forming candle; second-to-last is the last closed one
            if len(resp) >= 2:
                close_price = float(resp[-2][4])  # index 4 = close
                return close_price
            if len(resp) == 1:
                return float(resp[0][4])
            return None
        except httpx.HTTPStatusError as e:
            # 400 Bad Request — symbol/interval unavailable on this exchange tier
            if e.response.status_code == 400:
                log.debug("Klines unavailable for %s %s (HTTP 400)", symbol, interval)
            else:
                log.warning("Failed to fetch klines for %s %s: %s", symbol, interval, e)
            return None
        except Exception as e:
            log.warning("Failed to fetch klines for %s %s: %s", symbol, interval, e)
            return None

    async def start_ws(self, symbol: str | None = None) -> None:
        """Start the websocket market-data + user-data stream (zero REST weight).

        The mark-price stream is PUBLIC and works even while REST is IP-banned.
        Call once at startup; add symbols via ``add_ws_symbol`` as trades open.
        Safe to call when ws is disabled — it simply does nothing if not set up.
        """
        if self._ws is None:
            return
        if symbol:
            self._ws.add_symbol(symbol)
        if not getattr(self._ws, "_running", False):
            await self._ws.start()

    def add_ws_symbol(self, symbol: str) -> None:
        if self._ws is not None:
            self._ws.add_symbol(symbol)

    async def stop_ws(self) -> None:
        if self._ws is not None:
            await self._ws.stop()

    def _configure_ws(self, enabled: bool, api_key: str = "",
                      api_secret: str = "") -> None:
        """Create (or clear) the WS stream manager. Call once at init."""
        if enabled:
            base = self._base
            self._ws = MarketDataStream(
                api_key=api_key, api_secret=api_secret,
                rest_base=base if base.startswith("http") else "https://fapi.binance.com",
                proxy=self.egress_proxy,
            )
        else:
            self._ws = None

    async def get_mark_price(self, symbol: str) -> float | None:
        """Get the current mark price, served from a local cache.

        SL monitoring calls this every tick. To avoid hammering Binance REST
        (which triggers IP bans on shared VPS IPs), the price is read from an
        in-memory cache that is refreshed lazily via a SINGLE batched ticker
        call (no ``symbol`` param → one request returns all symbols, weight 50)
        instead of one REST call per symbol per tick. While an IP ban is active
        the cache is served as-is (possibly stale) so the monitor loop never
        re-hits the banned endpoint.

        Args:
            symbol: Trading pair (e.g. 'BONKUSDT')

        Returns:
            Current price, or None if unavailable and cache empty.
        """
        resolve_sym, _, _ = _resolve_futures_symbol(symbol)
        now = time.time() * 1000
        # ── WS fast-path: live push price, zero REST weight ────────────────
        ws = getattr(self, "_ws", None)
        if ws is not None:
            ws_price = ws.get_mark_price(resolve_sym)
            if ws_price is not None:
                self._mark_cache[resolve_sym] = (ws_price, now)
                return ws_price
        cached = self._mark_cache.get(resolve_sym)
        if cached is not None and (now - cached[1]) < self._mark_cache_ttl_ms:
            return cached[0]
        # Cache stale (or missing) → try a batched refresh, but only if not
        # currently banned. If banned, serve stale cache rather than extend ban.
        if self._ban_until_ms and now < self._ban_until_ms:
            return cached[0] if cached is not None else None
        await self._refresh_mark_cache()
        cached = self._mark_cache.get(resolve_sym)
        return cached[0] if cached is not None else None

    async def _refresh_mark_cache(self) -> None:
        """Refresh mark prices for ALL symbols via one batched ticker call.

        Uses /fapi/v1/ticker/24hr with no symbol (returns every symbol in one
        request, weight 50) — far cheaper than per-symbol polling. Failures are
        swallowed so the monitor loop keeps running on stale data.
        """
        if self._mark_cache_refreshing:
            return  # a refresh is already in flight
        self._mark_cache_refreshing = True
        try:
            self._assert_not_banned()
            if self.futures:
                resp = await self._public_request("GET", "/fapi/v1/ticker/24hr")
            else:
                resp = await self._public_request("GET", "/api/v3/ticker/24hr")
            if isinstance(resp, list):
                now = time.time() * 1000
                for row in resp:
                    sym = (row.get("symbol") or "").upper()
                    price = row.get("lastPrice") or row.get("close") or row.get("price")
                    if sym and price:
                        try:
                            self._mark_cache[sym] = (float(price), now)
                        except (TypeError, ValueError):
                            pass
        except RateLimited:
            pass  # serve stale cache; don't extend the ban
        except Exception as e:
            log.debug("mark-price cache refresh failed: %s", e)
        finally:
            self._mark_cache_refreshing = False

    async def get_ticker(self, symbol: str) -> "Ticker | None":
        """Get 24h ticker stats for a symbol from Binance Futures.

        Returns a Ticker with last/mark price, 24h % change, high/low, and
        quote volume. On a lookup failure returns a Ticker with ``error`` set
        (never raises) so command handlers can surface a clean message.
        """
        from src.exchange.base import Ticker
        resolve_sym, _, _ = _resolve_futures_symbol(symbol)
        try:
            if self.futures:
                resp = await self._public_request(
                    "GET", "/fapi/v1/ticker/24hr", {"symbol": resolve_sym}
                )
            else:
                resp = await self._public_request(
                    "GET", "/api/v3/ticker/24hr", {"symbol": resolve_sym}
                )
            if isinstance(resp, list):
                # Binance can return a list when no symbol is passed; guard.
                resp = resp[0] if resp else {}
            if not resp:
                return Ticker(symbol=resolve_sym, error=f"Empty ticker for {resolve_sym}")
            return Ticker(
                symbol=resolve_sym,
                last_price=float(resp.get("lastPrice", 0)),
                mark_price=float(resp.get("markPrice", resp.get("lastPrice", 0))),
                change_pct_24h=float(resp.get("priceChangePercent", 0)),
                high_24h=float(resp.get("highPrice", 0)),
                low_24h=float(resp.get("lowPrice", 0)),
                volume_24h=float(resp.get("quoteVolume", 0)),
            )
        except Exception as e:
            log.warning("Failed to fetch ticker for %s: %s", symbol, e)
            return Ticker(symbol=resolve_sym, error=str(e))

    # ─── Orders ────────────────────────────────────────────────────────────────

    async def _place_order(self, symbol: str, side: str, order_type: str,
                     quantity: float, price: float | None = None,
                     stop_price: float | None = None,
                     reduce: bool = False) -> OrderInfo:
        """Place an order on Binance (Spot or Futures).

        For futures:
          - STOP_LOSS → STOP_MARKET (triggers market order)
          - Limit orders work the same
          - 1000x symbols (e.g. BONKUSDT → 1000BONKUSDT) are auto-resolved

        1000x contract notes:
        - PRICE is in base asset terms (e.g. BONK = 0.0044), NOT multiplied by 1000
        - QUANTITY is in base asset tokens (e.g. BONK), NOT divided by 1000
        - The "1000" prefix is the CONTRACT MULTIPLIER for PnL calculation only
        - No price/qty scaling is needed — multipliers are both 1.0

        NOTE: Call set_symbol_leverage() BEFORE this method for futures.
        """
        resolve_sym, price_mult, qty_div = _resolve_futures_symbol(symbol)
        # 1000x symbols (1000BONKUSDT etc.): multipliers are always 1.0 because
        # PRICE is in base asset terms (e.g. BONK = 0.0044) and QUANTITY is in
        # base asset tokens (e.g. BONK). The "1000" is the contract multiplier
        # for PnL calculation only — no price/qty scaling is needed.
        # Guard clauses below keep this safe if SYMBOL_MAP ever changes.
        if qty_div > 1.0:
            quantity = quantity / qty_div
            quantity = round(quantity)
        if price is not None:
            price = price * price_mult
        if stop_price is not None:
            stop_price = stop_price * price_mult

        mapped_type = self._map_type(order_type)
        symbol_key = resolve_sym

        # Allowed futures order types. STOP (conditional STOP-LIMIT) and
        # TAKE_PROFIT (conditional TAKE_PROFIT-LIMIT) are valid Binance Futures
        # types that appear in the "Conditional" tab and fill as LIMITs — this is
        # exactly what stop_loss()/take_profit() intend. The market variants
        # (STOP_MARKET / TAKE_PROFIT_MARKET) are allowed too but are NOT what
        # SL/TP use here (they'd fill at market, no price protection).
        _ALLOWED_FUTURES_TYPES = {
            "MARKET", "LIMIT", "STOP", "TAKE_PROFIT",
            "STOP_MARKET", "TAKE_PROFIT_MARKET", "TRAILING_STOP_MARKET",
        }
        if self.futures and mapped_type not in _ALLOWED_FUTURES_TYPES:
            return OrderInfo(
                order_id="", symbol=symbol_key, side=side.upper(), type=mapped_type,
                quantity=quantity, status="FAILED",
                error=f"Unsupported futures order type: {mapped_type}",
            )

        if self.futures and mapped_type == "STOP_MARKET":
            # Binance algo-close orders must use the CLOSE side, not the open side.
            side_upper = side.upper()
            if side_upper not in {"SELL", "BUY"}:
                return OrderInfo(
                    order_id="", symbol=symbol_key, side=side_upper, type=mapped_type,
                    quantity=quantity, status="FAILED",
                    error=f"Invalid side for stop order: {side_upper}",
                )
        else:
            side_upper = side.upper()

        if self.futures and not await self._preflight_symbol(symbol_key):
            return OrderInfo(
                order_id="", symbol=symbol_key, side=side_upper, type=mapped_type,
                quantity=quantity, status="FAILED",
                error=f"Symbol not available for futures trading: {symbol_key}",
            )

        qty = quantity
        if self.futures:
            qty, rules = await self._round_quantity(symbol_key, qty, price_ref=price)
            # Round price to tick-size precision (prevents -1111 precision rejections)
            if price is not None:
                price, _ = await self._round_price(symbol_key, price)
            # For 1000x contracts where LOT_SIZE.stepSize = 1,
            # _round_quantity already handles integer rounding.
            # For very low-price coins with cache miss, the fallback
            # in _round_quantity applies integer rounding.

        params = {
            "symbol": symbol_key,
            "side": side_upper,
            "type": mapped_type,
            "quantity": qty,
        }
        if price and mapped_type in ("LIMIT", "STOP", "TAKE_PROFIT"):
            params["price"] = price
        if stop_price:
            params["stopPrice"] = stop_price

        if mapped_type in ("LIMIT", "STOP", "TAKE_PROFIT"):
            params["timeInForce"] = "GTC"
            # reduceOnly is NEVER inferred from the order TYPE — it is an
            # explicit per-call intent. Plain LIMIT is used for BOTH entry
            # (opening) and exit (maker-close / TP-fallback): an opening order
            # MUST NOT carry reduceOnly or Binance rejects it with -2022
            # ("ReduceOnly Order is rejected"), while a closing order MUST carry
            # it so it can only reduce — never flip — the position. Callers pass
            # reduce=True for genuine exits (stop_loss / take_profit / closes);
            # entry helpers default to reduce=False.
            if reduce:
                params["reduceOnly"] = "true"

        try:
            data = await self._signed_request("POST", self._order_path(), params)
            return OrderInfo(
                order_id=str(data.get("orderId", "")),
                symbol=data.get("symbol", symbol),
                side=data.get("side", side),
                type=data.get("type", mapped_type),
                quantity=float(data.get("origQty", quantity)),
                price=float(data.get("price", 0)) if data.get("price") else 0.0,
                status=data.get("status", "NEW"),
                filled_quantity=float(data.get("executedQty", 0)),
                avg_price=float(data.get("avgPrice", 0)) or (
                    float(data.get("cummulativeQuoteQty", 0)) / max(float(data.get("executedQty", 1)), 0.001)
                    if float(data.get("executedQty", 0)) > 0 else 0.0
                ),
            )
        except httpx.HTTPStatusError as e:
            status = e.response.status_code
            category = _categorize_error(status, e.response.text, e)
            error_msg = _format_order_error(
                symbol, side_upper, mapped_type, quantity, price,
                getattr(self, "_last_leverage", 1), status, e.response.text,
            )
            log.error("Order failed [%s]: %s", category.value, error_msg)
            return OrderInfo(
                order_id="", symbol=symbol, side=side, type=order_type,
                quantity=quantity, status="FAILED" if category != BinanceErrorCategory.NETWORK else "PENDING",
                error=error_msg,
            )
        except Exception as e:
            category = _categorize_error(None, "", e)
            log.error("Order failed [%s]: %s", category.value, e)
            return OrderInfo(
                order_id="", symbol=symbol, side=side, type=order_type,
                quantity=quantity, status="FAILED" if category != BinanceErrorCategory.NETWORK else "PENDING",
                error=f"[{category.value}] {e}",
            )

    async def market_buy(self, symbol: str, quantity: float) -> OrderInfo:
        return await self._place_order(symbol, "BUY", "MARKET", quantity)

    async def market_sell(self, symbol: str, quantity: float) -> OrderInfo:
        return await self._place_order(symbol, "SELL", "MARKET", quantity)

    async def market_close(self, symbol: str, quantity: float,
                           side: str = "SELL") -> OrderInfo:
        """Close (reduce) a position at market with reduceOnly=true.

        Unlike a maker LIMIT close at mark price (which often won't fill on a
        thin book), a MARKET close fills immediately. reduceOnly guarantees it
        can only reduce — never flip — the open position.
        """
        resolve_sym, _, _ = _resolve_futures_symbol(symbol)
        side_upper = side.upper()
        if side_upper not in ("SELL", "BUY"):
            return OrderInfo(order_id="", symbol=symbol, side=side_upper,
                             type="MARKET", quantity=quantity, status="FAILED",
                             error=f"Invalid close side: {side_upper}")
        if self.futures and not await self._preflight_symbol(resolve_sym):
            return OrderInfo(order_id="", symbol=symbol, side=side_upper,
                             type="MARKET", quantity=quantity, status="FAILED",
                             error="Symbol not available for futures trading")
        qty = quantity
        if self.futures:
            qty, _ = await self._round_quantity(resolve_sym, qty, price_ref=None)
        params = {
            "symbol": resolve_sym,
            "side": side_upper,
            "type": "MARKET",
            "quantity": qty,
            "reduceOnly": "true",
        }
        try:
            data = await self._signed_request("POST", self._order_path(), params)
            return OrderInfo(
                order_id=str(data.get("orderId", "")),
                symbol=data.get("symbol", resolve_sym),
                side=data.get("side", side_upper),
                type=data.get("type", "MARKET"),
                quantity=float(data.get("origQty", qty)),
                status=data.get("status", "FILLED"),
                filled_quantity=float(data.get("executedQty", 0)),
                avg_price=float(data.get("avgPrice", 0)) or (
                    float(data.get("cummulativeQuoteQty", 0)) / max(float(data.get("executedQty", 1)), 0.001)
                    if float(data.get("executedQty", 0)) > 0 else 0.0
                ),
            )
        except httpx.HTTPStatusError as e:
            # -2022 "ReduceOnly Order is rejected" can fire if the rounded qty
            # exceeds the live reducible size (e.g. rounding up past the open
            # position). Retry WITHOUT reduceOnly using the exact size — resting
            # SL/TP were already cancelled by the caller, so no flip risk.
            text = e.response.text
            if e.response.status_code == 400 and '"-2022"' in text:
                log.warning("reduceOnly close rejected (-2022) for %s; retrying without reduceOnly", resolve_sym)
                params.pop("reduceOnly", None)
                try:
                    data = await self._signed_request("POST", self._order_path(), params)
                    return OrderInfo(
                        order_id=str(data.get("orderId", "")),
                        symbol=data.get("symbol", resolve_sym),
                        side=data.get("side", side_upper),
                        type=data.get("type", "MARKET"),
                        quantity=float(data.get("origQty", qty)),
                        status=data.get("status", "FILLED"),
                        filled_quantity=float(data.get("executedQty", 0)),
                        avg_price=float(data.get("avgPrice", 0)) or (
                            float(data.get("cummulativeQuoteQty", 0)) / max(float(data.get("executedQty", 1)), 0.001)
                            if float(data.get("executedQty", 0)) > 0 else 0.0
                        ),
                    )
                except Exception as e2:
                    log.error("Market close retry failed: %s", e2)
            error_msg = _format_order_error(
                symbol, side_upper, "MARKET", qty, None,
                getattr(self, "_last_leverage", 1),
                e.response.status_code, text,
            )
            log.error("Market close failed: %s", error_msg)
            return OrderInfo(order_id="", symbol=symbol, side=side_upper,
                             type="MARKET", quantity=qty, status="FAILED",
                             error=error_msg)
        except Exception as e:
            log.error("Market close failed: %s", e)
            return OrderInfo(order_id="", symbol=symbol, side=side_upper,
                             type="MARKET", quantity=qty, status="FAILED",
                             error=str(e))

    async def limit_buy(self, symbol: str, quantity: float, price: float,
                      reduce: bool = False) -> OrderInfo:
        return await self._place_order(symbol, "BUY", "LIMIT", quantity,
                                       price=price, reduce=reduce)

    async def limit_sell(self, symbol: str, quantity: float, price: float,
                       reduce: bool = False) -> OrderInfo:
        return await self._place_order(symbol, "SELL", "LIMIT", quantity,
                                       price=price, reduce=reduce)

    async def reduce_only_limit_stop(self, symbol: str, quantity: float,
                                      stop_price: float, side: str = "SELL") -> "OrderInfo":
        """Real exchange-side stop when conditional STOP is rejected.

        Places a RESTING reduce-only LIMIT at the SL price. Unlike a conditional
        STOP (which triggers then fills), this is a plain limit order sitting on
        the book: if price reaches the SL, the limit fills and closes the
        position. It is a genuine exchange order (visible on Binance) — not just
        a software timer — so it catches fast gaps that a poll would miss.

        Trade-off: a LIMIT exactly at SL can fill early on a wick. That is the
        desired behavior (close at SL, never liquidate). It is strictly safer
        than leaving the position with NO exchange-side stop.

        `side` is SELL for LONG (close long) / BUY for SHORT (close short).
        """
        resolve_sym, _, _ = _resolve_futures_symbol(symbol)
        log.info("Placing reduce-only LIMIT stop for %s @ %s (qty=%s, side=%s)",
                 resolve_sym, stop_price, quantity, side)
        return await self._place_order(symbol, side, "LIMIT", quantity,
                                       price=stop_price, reduce=True)

    async def stop_loss(self, symbol: str, quantity: float, stop_price: float,
                        side: str = "SELL") -> OrderInfo:
        """Place a stop-loss as a conditional STOP-LIMIT order.

        Uses STOP (not STOP_MARKET) so it appears in the Conditional tab
        and fills as a LIMIT order at the specified price — no slippage.

        For pairs where the standard endpoint rejects conditional STOP (-4120:
        1000x contracts AND small/new futures like XPLUSDT that require the
        Algo Order API), retries via the algo endpoint so a REAL conditional
        SL is placed (visible in the Conditional tab) instead of leaving the
        position unprotected.

        NOTE: the Algo Order API (``/fapi/v1/algo/order``) is ONLY available on
        Binance **mainnet**. On **testnet** it returns 404, so for testnet the
        -4120 case falls back to position-manager price monitoring (the SL is
        still enforced — the bot closes the position if price hits the SL).
        """
        resolve_sym, _, _ = _resolve_futures_symbol(symbol)
        is_1000x = resolve_sym.startswith("1000")

        # STOP-LIMIT: triggers at stop_price, fills as LIMIT at stop_price.
        # This is a closing (reduce-only) order.
        result = await self._place_order(symbol, side, "STOP", quantity,
                                         price=stop_price, stop_price=stop_price,
                                         reduce=True)
        # Conditional STOP not supported on the standard endpoint for this pair
        # (small/new futures like XPLUSDT, 1000x contracts, or other
        # conditional-rejection pairs) — Binance rejects it. The Algo Order API
        # is the preferred fallback when enabled. When it's rejected for ANY
        # reason (not only -4120), we still want a REAL exchange-side stop, so
        # we place a resting reduce-only LIMIT at the SL price. That is a genuine
        # order on the book (visible on Binance) — not just a software timer —
        # and it closes the position if price reaches the SL, including fast
        # gaps a poll would miss. The monitor still price-watches as backstop.
        if result.status == "FAILED" and self._is_4120(result):
            if self._algo_enabled:
                log.info("STOP rejected for %s (-4120) — retrying via Algo Order API", resolve_sym)
                return await self._algo_order(symbol, side, "STOP", quantity,
                                              stop_price, price=stop_price, reduce=True)
            log.info("STOP rejected for %s (-4120) — placing reduce-only LIMIT stop", resolve_sym)
            lim = await self.reduce_only_limit_stop(symbol, quantity, stop_price, side)
            if lim.order_id:
                return lim
            return OrderInfo(
                order_id="", symbol=symbol, side=side.upper(),
                type="STOP", quantity=quantity,
                status="UNPROTECTED",
                error="STOP + LIMIT stop both failed; SL handled by position manager",
            )
        # Non--4120 STOP failure (e.g. pair not supporting conditional STOP on
        # the standard endpoint): still place a real reduce-only LIMIT stop so
        # the position is never left with NO exchange-side protection.
        if result.status == "FAILED":
            log.info("STOP rejected for %s (%s) — placing reduce-only LIMIT stop",
                     resolve_sym, result.error)
            lim = await self.reduce_only_limit_stop(symbol, quantity, stop_price, side)
            if lim.order_id:
                return lim
            return OrderInfo(
                order_id="", symbol=symbol, side=side.upper(),
                type="STOP", quantity=quantity,
                status="UNPROTECTED",
                error="STOP + LIMIT stop both failed; SL handled by position manager",
            )
        return result

    async def take_profit(self, symbol: str, quantity: float, tp_price: float,
                          side: str = "SELL") -> OrderInfo:
        """Place a take-profit as a conditional TAKE_PROFIT-LIMIT order.

        Uses TAKE_PROFIT (not TAKE_PROFIT_MARKET) so it appears in the
        Conditional tab and fills as a LIMIT order — no slippage.

        For pairs where the standard endpoint rejects conditional TP (-4120:
        small/new futures like XPLUSDT, 1000x contracts), the supported path is
        the Algo Order API. When that is disabled (default — its exact route
        differs per environment), the caller falls back to a plain resting
        LIMIT (maker close) which still fills at the TP price (visible in the
        Basic orders tab).
        """
        # TAKE_PROFIT-LIMIT: triggers at tp_price, fills as LIMIT at tp_price.
        # Routed through the "TAKE_PROFIT_LIMIT" key so _map_type produces the
        # conditional-limit Futures type (TAKE_PROFIT), NOT the market variant.
        # This is a closing (reduce-only) order.
        result = await self._place_order(symbol, side, "TAKE_PROFIT_LIMIT", quantity,
                                         price=tp_price, stop_price=tp_price,
                                         reduce=True)
        if result.status == "FAILED" and self._is_4120(result):
            if self._algo_enabled:
                log.info("TP rejected for %s (-4120) — retrying via Algo Order API", symbol)
                return await self._algo_order(symbol, side, "TAKE_PROFIT", quantity,
                                              tp_price, price=tp_price, reduce=True)
            # Algo disabled — caller places a plain resting LIMIT (works).
            return result
        return result

    @staticmethod
    def _is_4120(result: OrderInfo) -> bool:
        """True when the exchange rejected with -4120 (conditional order not
        on the standard endpoint — needs the Algo Order API).

        The error may arrive either as the raw code ``-4120`` in ``error`` or as
        the friendly message ``"...Please use the Algo Order API endpoints"``.
        """
        if not result.error:
            return False
        return "-4120" in result.error or "Algo Order API" in result.error

    async def cancel_order(self, symbol: str, order_id: str) -> bool:
        resolve_sym, _, _ = _resolve_futures_symbol(symbol)
        try:
            await self._signed_request("DELETE", self._order_path(), {
                "symbol": resolve_sym,
                "orderId": order_id,
            })
            return True
        except Exception:
            return False

    async def get_order(self, symbol: str, order_id: str) -> OrderInfo:
        resolve_sym, _, _ = _resolve_futures_symbol(symbol)
        try:
            data = await self._signed_request("GET", self._order_path(), {
                "symbol": resolve_sym,
                "orderId": order_id,
            })
            return OrderInfo(
                order_id=str(data.get("orderId", "")),
                symbol=data.get("symbol", ""),
                side=data.get("side", ""),
                type=data.get("type", ""),
                quantity=float(data.get("origQty", 0)),
                price=float(data.get("price", 0)) if data.get("price") else 0.0,
                status=data.get("status", ""),
                filled_quantity=float(data.get("executedQty", 0)),
                avg_price=float(data.get("avgPrice", 0)) or (
                    float(data.get("cummulativeQuoteQty", 0)) / max(float(data.get("executedQty", 1)), 0.001)
                    if float(data.get("executedQty", 0)) > 0 else 0.0
                ),
            )
        except Exception:
            return OrderInfo()

    async def get_open_orders(self, symbol: str | None = None) -> list[OrderInfo]:
        # ── WS fast-path: positions/orders pushed via user-data stream ──────
        ws = getattr(self, "_ws", None)
        if ws is not None and ws.user_stream_alive():
            raw = ws.get_open_orders(symbol)
            if raw:
                return [
                    OrderInfo(
                        order_id=str(o.get("i", o.get("orderId", ""))),
                        symbol=o.get("s", o.get("symbol", "")),
                        side=o.get("S", o.get("side", "")),
                        type=o.get("o", o.get("type", "")),
                        quantity=float(o.get("q", o.get("origQty", 0))),
                        price=float(o.get("p", o.get("price", 0)) or 0),
                        status=o.get("X", o.get("status", "")),
                        filled_quantity=float(o.get("z", o.get("executedQty", 0)) or 0),
                        avg_price=float(o.get("ap", o.get("avgPrice", 0)) or 0),
                    )
                    for o in raw
                ]
            # WS alive but no orders for this symbol → genuinely no open orders
            return []
        open_path = "/fapi/v1/openOrders" if self.futures else "/api/v3/openOrders"
        params = {}
        if symbol:
            resolve_sym, _, _ = _resolve_futures_symbol(symbol)
            params["symbol"] = resolve_sym
        try:
            data = await self._signed_request("GET", open_path, params)
            orders = []
            for o in data:
                orders.append(OrderInfo(
                    order_id=str(o.get("orderId", "")),
                    symbol=o.get("symbol", ""),
                    side=o.get("side", ""),
                    type=o.get("type", ""),
                    quantity=float(o.get("origQty", 0)),
                    price=float(o.get("price", 0)) if o.get("price") else 0.0,
                    status=o.get("status", ""),
                    filled_quantity=float(o.get("executedQty", 0)),
                    avg_price=float(o.get("avgPrice", 0)) or 0.0,
                ))
            return orders
        except Exception:
            return []

    async def _algo_order(self, symbol: str, side: str, algo_type: str,
                         quantity: float, stop_price: float,
                         price: float | None = None,
                         reduce: bool = True) -> OrderInfo:
        """Place a conditional STOP/TAKE_PROFIT via the Binance Algo Order API.

        Some pairs (small/new futures like XPLUSDT, and 1000x contracts) reject
        conditional STOP/TP on the standard ``/fapi/v1/order`` endpoint with
        -4120 ("use the Algo Order API"). The algo endpoint
        (POST /fapi/v1/algo/order) is the supported path for those pairs and
        produces a REAL conditional order the user sees in the Conditional tab.

        Args:
            symbol: Trading pair (e.g. 'XPLUSDT').
            side: 'BUY'/'SELL'.
            algo_type: 'STOP' or 'TAKE_PROFIT' (conditional limit variants).
            quantity: Order quantity (base tokens).
            stop_price: Trigger price.
            price: Limit price (for STOP/TAKE_PROFIT limit). Defaults to stop_price.
            reduce: Attach reduceOnly so the order can only close, never flip.
        """
        resolve_sym, _, _ = _resolve_futures_symbol(symbol)
        side_upper = side.upper()
        qty = quantity
        if self.futures:
            qty, _ = await self._round_quantity(resolve_sym, qty, price_ref=price or stop_price)
            if price is not None:
                price, _ = await self._round_price(resolve_sym, price)
            stop_price, _ = await self._round_price(resolve_sym, stop_price)

        params = {
            "symbol": resolve_sym,
            "side": side_upper,
            "type": algo_type,
            "quantity": qty,
            "stopPrice": stop_price,
            "urgency": "LOW",
        }
        if price is not None:
            params["price"] = price
        if reduce:
            params["reduceOnly"] = "true"

        try:
            data = await self._signed_request("POST", "/fapi/v1/algoOrder", params)
            algo_id = data.get("clientAlgoId") or data.get("algoId") or ""
            return OrderInfo(
                order_id=str(algo_id),
                symbol=data.get("symbol", resolve_sym),
                side=side_upper,
                type=algo_type,
                quantity=float(data.get("origQty", qty)),
                price=float(data.get("price", price or 0)) if data.get("price") else (price or 0.0),
                status="NEW",
                filled_quantity=0.0,
                avg_price=0.0,
            )
        except httpx.HTTPStatusError as e:
            status = e.response.status_code
            category = _categorize_error(status, e.response.text, e)
            error_msg = _format_order_error(
                symbol, side_upper, algo_type, qty, price,
                getattr(self, "_last_leverage", 1), status, e.response.text,
            )
            log.error("Algo order failed [%s]: %s", category.value, error_msg)
            return OrderInfo(
                order_id="", symbol=symbol, side=side, type=algo_type,
                quantity=qty, status="FAILED", error=error_msg,
            )
        except Exception as e:
            log.error("Algo order failed: %s", e)
            return OrderInfo(
                order_id="", symbol=symbol, side=side, type=algo_type,
                quantity=qty, status="FAILED", error=str(e),
            )

    async def get_algo_open_orders(self, symbol: str | None = None) -> list[OrderInfo]:
        """List open algo (conditional) orders via the Algo Order API.

        Algo orders do NOT appear in the standard /fapi/v1/openOrders response,
        so the monitor must query this endpoint to know whether a conditional
        SL/TP is already live (idempotency / self-heal).

        The Algo Order API is opt-in (_algo_enabled) because its exact route
        differs per environment and a wrong route 404s. When disabled we return
        [] (the monitor's standard openOrders check is authoritative).
        """
        if not self._algo_enabled:
            return []
        params = {}
        if symbol:
            resolve_sym, _, _ = _resolve_futures_symbol(symbol)
            params["symbol"] = resolve_sym
        try:
            data = await self._signed_request("GET", "/fapi/v1/algoOrder", params)
            orders = []
            for o in data:
                orders.append(OrderInfo(
                    order_id=str(o.get("algoId", o.get("clientAlgoId", ""))),
                    symbol=o.get("symbol", ""),
                    side=o.get("side", ""),
                    type=o.get("type", ""),
                    quantity=float(o.get("origQty", o.get("quantity", 0)) or 0),
                    price=float(o.get("price", 0)) if o.get("price") else 0.0,
                    status=o.get("status", ""),
                    filled_quantity=0.0,
                    avg_price=0.0,
                ))
            return orders
        except Exception:
            return []

    async def cancel_algo_order(self, symbol: str, algo_id: str) -> bool:
        """Cancel a single algo (conditional) order by its algoId.

        No-op unless the Algo Order API is enabled (_algo_enabled).
        """
        if not self._algo_enabled or not algo_id:
            return False
        resolve_sym, _, _ = _resolve_futures_symbol(symbol)
        try:
            await self._signed_request("DELETE", "/fapi/v1/algo/order",
                                       {"symbol": resolve_sym, "algoId": algo_id})
            return True
        except Exception:
            return False

    async def cancel_all_orders(self, symbol: str) -> int:
        """Cancel all open orders for a symbol — standard AND algo (conditional).

        Returns the total number of orders cancelled.
        """
        count = 0
        # Standard resting orders (Basic tab / openOrders).
        for o in await self.get_open_orders(symbol):
            if await self.cancel_order(symbol, o.order_id):
                count += 1
        # Algo conditional orders (STOP/TAKE_PROFIT placed via the algo API).
        try:
            for o in await self.get_algo_open_orders(symbol):
                if await self.cancel_algo_order(symbol, o.order_id):
                    count += 1
        except Exception:
            pass
        return count
