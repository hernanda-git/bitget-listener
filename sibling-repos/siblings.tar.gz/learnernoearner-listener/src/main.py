#!/usr/bin/env python3
"""Auto-trade system entry point.

Wires the entire pipeline and starts the Telegram listener.

Usage:
    python -m src.main
    python src/main.py

Environment:
    TELEGRAM_BOT_TOKEN  — from .env or environment
    NOTIFY_CHAT_ID      — from .env or environment
    TG_API_ID           — from .env
    TG_API_HASH         — from .env
"""

from __future__ import annotations

import asyncio
import logging
import os
import sys
from pathlib import Path
from typing import Any

# Used in shutdown for api_task cancellation

# Ensure project root is on path
ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.agent.agent import AgentBrain
from src.agent.gate import SafetyGate1, SafetyGate2
from src.config.loader import get_log_dir, load_config
from src.config.validator import validate_config
from src.config.watcher import ConfigWatcher
from src.events.bus import EventBus
from src.exchange.binance import BinanceExchange
from src.exchange.paper import PaperExchange
from src.exchange.symbol_registry import SymbolRegistry, set_registry
from src.execution.order_service import OrderService
from src.execution.position_manager import PositionManager
from src.listener import SignalListener
from src.notifier.telegram import TelegramNotifier
from src.health.reporter import HealthReporter
from src.orchestrator import TradeOrchestrator
from src.agent.attachment_fetcher import AttachmentFetcher
from src.agent.vision import VisionExtractor
from src.state.database import get_connection
from src.state.repositories import (
    ConfigSnapshotRepository,
    DecisionRepository,
    EventRepository,
    LLMInteractionRepository,
    OrderRepository,
    PendingMgmtRepository,
    PendingSignalRepository,
    PositionEventRepository,
    PositionRepository,
    SignalRepository,
    TradeLogRepository,
    StrategyPerfRepository,
)

log = logging.getLogger("main")


def _merge_surface(cfg: dict[str, Any], surface: dict[str, Any]) -> dict[str, Any]:
    """Merge an orchestrator surface config into the bot's config.

    The orchestrator writes a flat surface dict (max_leverage, port_usdt,
    confidence_threshold, etc.) that maps onto the bot's config sections.
    This function merges those deltas into the live config without touching
    secrets or unrelated sections.
    """
    merged = dict(cfg)

    # The orchestrator writes deltas wrapped in a "deltas" key. Unwrap it.
    surface = dict(surface)
    if "deltas" in surface:
        surface = dict(surface["deltas"])

    # Surface keys map to the bot's config sections.
    surface_to_section: dict[str, str] = {
        "max_leverage": "risk",
        "max_concurrent_positions": "risk",
        "max_portfolio_leverage": "risk",
        "port_usdt": "risk",
        "min_cooldown_minutes": "risk",
        "max_position_hold_hours": "risk",
        "max_port_pct": "risk",
        "max_position_size_usdt": "risk",
        "risk_per_trade_percent": "risk",
        "daily_loss_limit_percent": "risk",
        "margin_usage_pct": "risk",
        "confidence_threshold": "agent",
    }

    for key, value in surface.items():
        if key == "weights":
            existing = merged.get("weights", {})
            if isinstance(existing, dict) and isinstance(value, dict):
                merged["weights"] = {**existing, **value}
            else:
                merged["weights"] = value
        elif key in surface_to_section:
            section = surface_to_section[key]
            if section not in merged:
                merged[section] = {}
            merged[section][key] = value
        else:
            # Unknown surface key — record it at the top level so it's visible
            # in the config but does not break the bot.
            merged[key] = value

    return merged


def setup_logging():
    """Configure logging to stdout + file."""
    log_dir = get_log_dir()
    log_dir.mkdir(parents=True, exist_ok=True)

    fmt = "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
    logging.basicConfig(
        level=logging.INFO,
        format=fmt,
        handlers=[
            logging.StreamHandler(sys.stdout),
            logging.FileHandler(log_dir / "trading.log"),
        ],
    )


async def main():
    """Main entry point."""
    setup_logging()

    # ── Load config ──────────────────────────────────────────────────────
    cfg = load_config()
    validate_config(cfg)
    log.info("Config loaded (exchange=%s, auto_trade=%s)",
             cfg["exchange"]["active"], cfg["agent"]["auto_trade"])

    # ── Load Telegram secrets from environment ────────────────────────────
    # .env was loaded by load_config() above — os.environ is already populated.
    bot_token = os.getenv("TELEGRAM_BOT_TOKEN", "")
    notify_chat_id = os.getenv("NOTIFY_CHAT_ID", "5894116684")

    # ── Database ─────────────────────────────────────────────────────────
    conn = get_connection()

    # ── Symbol Registry ─────────────────────────────────────────────────
    # Dynamic pair resolution from live exchangeInfo. Falls back to seed data.
    seed_path = str(ROOT / "data" / "symbols_seed.json")
    symbol_registry = SymbolRegistry(seed_path=seed_path)
    # Paper mode: never hit the live Binance exchangeInfo endpoint so the bot
    # makes ZERO network calls to Binance (no ban risk while waiting it out).
    if (cfg.get("exchange", {}).get("active") or "").lower() == "paper":
        symbol_registry.live_fetch_enabled = False
    await symbol_registry.initialize()
    set_registry(symbol_registry)  # makes it available to parser and other modules
    if symbol_registry.live_fetch_enabled:
        symbol_registry.start_background_refresh(interval_minutes=15)
    log.info("Symbol registry ready: %d pairs cached%s",
             symbol_registry.symbol_count,
             "" if symbol_registry.live_fetch_enabled else " (paper mode: no live fetch)")

    # ── Repositories ─────────────────────────────────────────────────────
    signal_repo = SignalRepository(conn)
    decision_repo = DecisionRepository(conn)
    order_repo = OrderRepository(conn)
    position_repo = PositionRepository(conn)
    event_repo = EventRepository(conn)
    pending_signal_repo = PendingSignalRepository(conn)
    pending_mgmt_repo = PendingMgmtRepository(conn)
    strategy_perf_repo = StrategyPerfRepository(conn)
    llm_repo = LLMInteractionRepository(conn)
    trade_log_repo = TradeLogRepository(conn)
    position_event_repo = PositionEventRepository(conn)
    config_snapshot_repo = ConfigSnapshotRepository(conn)

    # ── Event Bus ────────────────────────────────────────────────────────
    event_bus = EventBus()

    # ── Exchange ─────────────────────────────────────────────────────────
    exchange_mode = cfg["exchange"]["active"]
    if exchange_mode == "paper":
        exchange = PaperExchange(cfg.get("exchange", {}).get("paper", {}))
        log.info("Using PAPER exchange (simulated)")
    elif exchange_mode in ("binance", "binance_testnet"):
        binance_cfg = cfg["exchange"]["binance"]
        exchange = BinanceExchange(
                api_key=binance_cfg["api_key"],
                api_secret=binance_cfg["api_secret"],
                testnet=(exchange_mode == "binance_testnet"),
                futures=binance_cfg.get("futures", False),
                recv_window=binance_cfg.get("recv_window", 5000),
                proxy=binance_cfg.get("proxy"),
                ws_enabled=bool((cfg.get("exchange", {}).get("ws", {}) or {}).get("enabled", False)),
            )
        # Resolve the upstream egress proxy (tunnels ALL Binance REST+WS through a
        # clean IP — ban-proof against host/datacenter-range throttling). Prefer an
        # env var (keeps the URL out of git); fall back to a direct config value.
        _egress_proxy_env = (binance_cfg.get("egress_proxy_env") or "").strip()
        _egress_proxy = os.environ.get(_egress_proxy_env, "").strip() if _egress_proxy_env \
            else (binance_cfg.get("egress_proxy") or "").strip()
        if _egress_proxy:
            exchange.egress_proxy = _egress_proxy
            log.info("Binance traffic will egress via upstream proxy (ban-proof): %s",
                     _egress_proxy.split("@")[-1] if "://" in _egress_proxy else _egress_proxy)
        mode_label = "BINANCE"
        if exchange_mode == "binance_testnet":
            mode_label += " TESTNET"
        if binance_cfg.get("futures"):
            mode_label += " FUTURES"
        log.info("Using %s exchange", mode_label)
    else:
        log.error("Unknown exchange mode: %s", exchange_mode)
        sys.exit(1)

    # ── Agent ────────────────────────────────────────────────────────────
    agent = AgentBrain(cfg)

    # ── Safety Gates ─────────────────────────────────────────────────────
    gate1 = SafetyGate1(cfg, signal_repo, position_repo)
    gate2 = SafetyGate2(cfg, position_repo)

    # ── Order Service ────────────────────────────────────────────────────
    order_service = OrderService(exchange, cfg, signal_repo, decision_repo, order_repo, position_repo, agent=agent)

    # ── Notifier ─────────────────────────────────────────────────────────
    notifier = TelegramNotifier(bot_token=bot_token, chat_id=notify_chat_id)

    # Determine version for /version + startup banner + traded telemetry.
    # The canonical version is a PLAIN INTEGER (e.g. 62) — not a git SHA and
    # not a "v"-prefixed string. Primary source is APP_VERSION (injected at
    # build time via `flyctl deploy --build-arg APP_VERSION=...`), falling back
    # to the frozen src/version.py (local dev / no build arg). The container
    # image has no git binary, so runtime git resolution was removed on purpose.
    app_version = os.environ.get("APP_VERSION")
    if not app_version:
        try:
            from src.version import __version__  # type: ignore[import-untyped]
            app_version = str(__version__)
        except Exception:
            app_version = "0"
    # Integer-only version (src/version.py stores plain integer, e.g. "104").
    version_str = str(app_version) or "0"

    if bot_token:
        log.info("Telegram notifier ready (chat_id=%s)", notify_chat_id)
        await notifier.set_commands()
    else:
        log.warning("TELEGRAM_BOT_TOKEN not set — notifications disabled")

    # ── Position Manager ─────────────────────────────────────────────────
    position_manager = PositionManager(exchange, cfg, position_repo,
                                       pending_signal_repo=pending_signal_repo,
                                       position_event_repo=position_event_repo,
                                       order_repo=order_repo,
                                       decision_repo=decision_repo,
                                       signal_repo=signal_repo,
                                       notifier=notifier)

    # ── API Server (background task) ──────────────────────────────────────
    api_task = None
    if cfg.get("api", {}).get("enabled", True):
        try:
            import asyncio
            import uvicorn
            from src.api.server import app as api_app

            api_host = cfg.get("api", {}).get("host", "0.0.0.0")
            api_port = cfg.get("api", {}).get("port", 9090)

            async def start_api():
                config = uvicorn.Config(api_app, host=api_host, port=api_port, log_level="info")
                server = uvicorn.Server(config)
                await server.serve()

            api_task = asyncio.create_task(start_api())
            log.info("API bridge starting on %s:%d", api_host, api_port)
        except Exception as e:
            log.warning("API bridge not started: %s", e)

    # ── Web UI (dashboard + WebSocket + password-protected control panel) ──
    web_task = None
    web_state = None

    def _set_bot_mode(mode: str) -> None:
        """Flip exchange.active in config.yaml and restart the bot service.

        Called by the dashboard's live/paper toggle. Restarting the systemd
        unit re-reads config.yaml so the new mode (paper | binance) takes
        effect. Safe + idempotent.
        """
        mode = (mode or "").lower()
        cfg_path = ROOT / "config.yaml"
        try:
            import re as _re
            txt = cfg_path.read_text() if cfg_path.exists() else ""
            new_txt = _re.sub(
                r"(?m)^(exchange:\s*\n(?:[ \t]*#.*\n)*[ \t]*active:\s*)\S+",
                lambda m: m.group(1) + mode,
                txt, count=1,
            )
            cfg_path.write_text(new_txt)
            log.info("Config updated: exchange.active -> %s", mode)
        except Exception as e:  # noqa: BLE001
            log.error("Failed to update config.yaml for mode switch: %s", e)
            return
        try:
            import os, subprocess
            # Detach the restart so we don't SIGTERM ourselves mid-request (which
            # wedges systemd in "deactivating"). Spawn the restart in a new session
            # and hard-exit this process; systemd respawns a fresh instance.
            subprocess.Popen(
                ["systemctl", "restart", "learnernoearner-listener"],
                start_new_session=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            )
            log.info("Scheduled restart of learnernoearner-listener to apply mode=%s", mode)
            # Give the request a moment to flush, then exit so systemd can restart us.
            import time as _t
            _t.sleep(0.4)
            os._exit(0)
        except Exception as e:  # noqa: BLE001
            log.warning("Could not restart service (apply manually): %s", e)
    if cfg.get("web", {}).get("enabled", True):
        try:
            from src.config.loader import get_data_dir
            from src.web.dashboard_state import DashboardState
            from src.web.app import attach_dashboard, create_app

            web_state = DashboardState(
                exchange=exchange,
                db_path=get_data_dir() / "trades.db",
                market_symbols=tuple(
                    (cfg.get("web", {}).get("market_symbols")
                     or ["BTCUSDT", "ETHUSDT", "SOLUSDT", "BNBUSDT"])
                ),
                poll_interval=float(cfg.get("web", {}).get("poll_interval", 10)),
                paper=(exchange_mode == "paper"),
                bot_name="learnernoearner",
            )
            web_state.start()
            attach_dashboard(
                web_state, event_bus,
                exchange=exchange,
                order_service=order_service,
                registry=symbol_registry,
                set_mode=_set_bot_mode,
            )

            web_host = cfg.get("web", {}).get("host", "0.0.0.0")
            web_port = int(cfg.get("web", {}).get("port", 9091))

            web_app = create_app(web_state)

            async def start_web():
                import uvicorn
                server = uvicorn.Server(
                    uvicorn.Config(web_app, host=web_host, port=web_port, log_level="info")
                )
                await server.serve()

            web_task = asyncio.create_task(start_web())
            log.info("Web UI starting on %s:%d", web_host, web_port)
        except Exception as e:  # noqa: BLE001
            log.warning("Web UI not started: %s", e)

    # ── Attachment pipeline (chart-gated scalp path) ─────────────────────
    # Opt-in: built from config; passed into the orchestrator. The live Telegram
    # client (for read-only media fetch) is wired onto the orchestrator after the
    # listener is constructed below, so the same StringSession is reused.
    attachment_cfg = cfg.get("attachment", {}) or {}
    attachment_fetcher = None
    vision_extractor = None
    if attachment_cfg.get("enabled", False):
        try:
            vision_extractor = VisionExtractor(cfg)
            # Surface a clear warning if no API key will be available at call time,
            # so a misconfig is obvious instead of failing silently per-message.
            _vk = (attachment_cfg.get("vision", {}) or {}).get("api_key_env") \
                or cfg.get("agent", {}).get("vision", {}).get("api_key_env") \
                or "GITLAWB_API_KEY"
            import os as _os
            if not _os.environ.get(_vk):
                log.warning("Attachment pipeline: vision API key (%s) not in env — "
                            "scalp-on-chart will skip until the key is provided", _vk)
            attachment_fetcher = AttachmentFetcher(
                media_dir=attachment_cfg.get("media_dir", "/data/attachments")
            )
            log.info("Attachment pipeline enabled (vision + fetcher)")
        except Exception as e:
            log.warning("Attachment pipeline init failed, disabled: %s", e)
            attachment_fetcher = None
            vision_extractor = None

    # ── Orchestrator ─────────────────────────────────────────────────────
    orchestrator = TradeOrchestrator(
        config=cfg,
        exchange=exchange,
        agent=agent,
        gate1=gate1,
        gate2=gate2,
        order_service=order_service,
        position_manager=position_manager,
        notifier=notifier,
        signal_repo=signal_repo,
        decision_repo=decision_repo,
        order_repo=order_repo,
        position_repo=position_repo,
        event_repo=event_repo,
        llm_repo=llm_repo,
        trade_log_repo=trade_log_repo,
        position_event_repo=position_event_repo,
        config_snapshot_repo=config_snapshot_repo,
        event_bus=event_bus,
        pending_signal_repo=pending_signal_repo,
        pending_mgmt_repo=pending_mgmt_repo,
        strategy_perf_repo=strategy_perf_repo,
        app_version=version_str or "",
        attachment_fetcher=attachment_fetcher,
        vision_extractor=vision_extractor,
    )

    # Wire orchestrator to position manager for trigger auto-entry
    position_manager._orchestrator = orchestrator

    # ── Listener ─────────────────────────────────────────────────────────
    listener = SignalListener(orchestrator, cfg, exchange=exchange,
                              version=version_str or None, notifier=notifier,
                              config_path=str(ROOT / "config.yaml"))

    # Reuse the listener's read-only StringSession client for attachment fetch.
    if attachment_fetcher is not None:
        orchestrator.telegram_client = listener.client

    # ── Health Reporter (periodic /health post every 6h) ───────────────────
    health_interval = cfg.get("monitoring", {}).get("health_report_hours", 6)
    health_reporter = HealthReporter(listener, interval_hours=float(health_interval))

    # ── Orchestrator Surface Config Watcher ───────────────────────────────
    # Watches /opt/bots/listener/config/surface.json written by the vaisravana
    # orchestrator. When a new surface is detected, merges it into the bot's
    # config and signals the orchestrator to re-evaluate.
    surface_config_path = os.environ.get(
        "SURFACE_CONFIG_PATH", "/opt/bots/listener/config/surface.json"
    )
    reload_flag_path = os.environ.get(
        "RELOAD_FLAG_PATH", "/opt/bots/listener/config/reload.flag"
    )

    def _on_surface_change(surface: dict[str, Any]) -> None:
        """Apply a new orchestrator surface config to the live bot config."""
        nonlocal cfg
        try:
            # Merge surface deltas into the bot's config. The orchestrator writes
            # a flat surface dict (weights, entry_threshold, sl_atr_mult, etc.)
            # that maps directly onto the bot's config structure.
            cfg = _merge_surface(cfg, surface)
            log.info("ConfigWatcher: applied surface config (keys: %s)", list(surface.keys()))
        except Exception:
            log.exception("ConfigWatcher: failed to apply surface config")

    config_watcher = ConfigWatcher(
        surface_path=surface_config_path,
        reload_flag_path=reload_flag_path,
        on_change=_on_surface_change,
        check_interval=10.0,
    )

    # ── Start ────────────────────────────────────────────────────────────
    # NOTE: listener.start() blocks in run_until_disconnected() for the life
    # of the process, so the health reporter must be launched as a concurrent
    # background task *before* it — otherwise it would never start.
    health_task: asyncio.Task | None = None
    try:
        await position_manager.start()
        # WS stream only exists on the Binance adapter (zero REST weight). The
        # PaperExchange has no start_ws, so guard with getattr.
        ws_starter = getattr(exchange, "start_ws", None)
        if callable(ws_starter):
            await ws_starter()  # zero REST weight: mark price + account push
        health_task = asyncio.create_task(health_reporter.start())
        await config_watcher.start()
        await listener.start()
    except KeyboardInterrupt:
        log.info("Shutting down...")
    finally:
        await config_watcher.stop()
        await health_reporter.stop()
        await listener.stop()
        await position_manager.stop()
        if api_task:
            api_task.cancel()
            try:
                await api_task
            except (asyncio.CancelledError, Exception):
                pass
        if web_task:
            web_task.cancel()
            try:
                await web_task
            except (asyncio.CancelledError, Exception):
                pass
        if web_state is not None:
            try:
                web_state.stop()
            except Exception:  # noqa: BLE001
                pass
        ws_stopper = getattr(exchange, "stop_ws", None)
        if callable(ws_stopper):
            try:
                await ws_stopper()
            except Exception:
                pass
        if health_task and not health_task.done():
            try:
                await health_task
            except (asyncio.CancelledError, Exception):
                pass
        await symbol_registry.stop()
        conn.close()
        log.info("Goodbye.")


if __name__ == "__main__":
    asyncio.run(main())
