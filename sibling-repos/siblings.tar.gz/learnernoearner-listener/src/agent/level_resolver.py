"""Level resolver for `scalp_watch` signals.

Resolves an actionable (entry, target, stop) triple by merging:
  (a) explicit numbers found in the post's raw_text,
  (b) support/resistance/trend extracted from the chart attachment (vision_struct),
  (c) the current mark price as a last-resort anchor.

Never invents a stop-loss. If no stop can be derived the caller
(`order_service.place_entry`) refuses the trade outright — a missing stop is
never treated as "trade without a stop".

See docs/PLAN_attachment_bias_ADDENDUM_scalp_levels.md §3.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any

NUM_RE = re.compile(r"(?<![\w.])(\d{1,6}(?:\.\d{1,8})?)(?![\w])")

# Phrases that mark a loose "watching this level" scalp call rather than a
# formal ENTRY/TARGET/STOPLOSS setup.
SCALP_WORDS = (
    "scalp",
    "watching for",
    "possible short",
    "possible long",
    "current levels",
    "from current",
    "down to",
    "up to",
)


@dataclass(frozen=True)
class ResolvedLevels:
    """Outcome of level resolution for one scalp_watch signal."""

    entry: float | None
    entry_source: str
    target: float | None
    stop: float | None
    confidence: float


def extract_text_numbers(raw_text: str) -> list[float]:
    """Pull every standalone numeric literal out of the post text."""
    return [float(n) for n in NUM_RE.findall(raw_text or "")]


def _levels(vision_struct: dict[str, Any] | None, key: str) -> list[float]:
    if not vision_struct:
        return []
    raw = (vision_struct.get("levels") or {}).get(key) or []
    out: list[float] = []
    for value in raw:
        try:
            out.append(float(value))
        except (TypeError, ValueError):
            continue
    return out


def resolve_scalp_levels(
    raw_text: str,
    vision_struct: dict[str, Any] | None,
    side: str,
    current_mark_price: float,
) -> ResolvedLevels:
    """Resolve entry/target/stop for a scalp_watch signal.

    Args:
        raw_text: the original post text.
        vision_struct: the vision-extracted chart JSON (audit shape).
        side: "LONG" or "SHORT" from the existing keyword match.
        current_mark_price: live mark price, the fallback entry anchor.
    """
    side = (side or "").upper()
    text_nums = extract_text_numbers(raw_text)
    support = _levels(vision_struct, "support")
    resistance = _levels(vision_struct, "resistance")
    trend = (vision_struct or {}).get("trend")

    # --- target: the extreme text number in the direction of the trade ---
    target: float | None = None
    if text_nums:
        target = min(text_nums) if side == "SHORT" else max(text_nums)

    # --- entry: "current levels" phrasing anchors to the chart, not the text ---
    entry_source = "current_mark_fallback"
    chart_levels = resistance if side == "SHORT" else support
    if chart_levels:
        candidates = [
            lvl
            for lvl in chart_levels
            if (lvl >= current_mark_price if side == "SHORT" else lvl <= current_mark_price)
        ] or chart_levels
        entry = min(candidates, key=lambda lvl: abs(lvl - current_mark_price))
        entry_source = "chart_level"
    else:
        entry = current_mark_price
        entry_source = "current_mark_fallback"

    # --- stop: only from the chart, never fabricated out of the text ---
    stop: float | None = None
    opposite_levels = support if side == "SHORT" else resistance
    if opposite_levels:
        stop = max(opposite_levels) if side == "SHORT" else min(opposite_levels)
        # A stop must sit beyond entry in the adverse direction, or it isn't a stop.
        if side == "SHORT" and stop <= entry:
            stop = None
        elif side == "LONG" and stop >= entry:
            stop = None

    # --- heuristic confidence score ---
    confidence = 0.0
    if entry_source == "chart_level":
        confidence += 0.4
    if target is not None:
        confidence += 0.3
    if stop is not None:
        confidence += 0.3
    if trend and ((side == "SHORT" and trend == "down") or (side == "LONG" and trend == "up")):
        confidence = min(1.0, confidence + 0.1)

    return ResolvedLevels(
        entry=entry,
        entry_source=entry_source,
        target=target,
        stop=stop,
        confidence=round(confidence, 6),
    )
