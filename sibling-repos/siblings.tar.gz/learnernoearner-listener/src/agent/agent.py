"""Agent brain — single LLM call via OpenCode Go for trade decisions.

Takes raw signal text + regex pre-parse fields + open positions + balance context.
Returns a structured TradeDecision (ENTER / CLOSE / SKIP).
"""

from __future__ import annotations

import json
import logging
import os
from pathlib import Path
from typing import Any

import httpx

from src.domain.models import TradeDecision, TradeSignal

log = logging.getLogger("agent.brain")

# System prompt for the trading agent
SYSTEM_PROMPT = """You are a crypto trading signal analyst on Binance USDⓈ-M Futures. Your goal is to maximize profit while strictly limiting risk.

Rules:
- If the signal looks valid, output ENTER with entry_price, sl_price, and tp_prices. DO NOT calculate quantity — the safety gate computes it automatically from your SL distance to cap risk at 10% of balance.
- You MUST provide sl_price for every ENTER decision — the system uses SL distance to size the position. No SL = no trade.
- Set order_type to MARKET for immediate entry, or LIMIT if a specific entry price is critical.
- If already in a position for that pair, output CLOSE.
- If signal is unclear / low quality, output SKIP.
- If the message is position management advice (e.g. "move SL to entry", "trail SL", "take partial profit") for an existing open position, output MODIFY with the pair, the new sl_price, and/or new tp_prices as specified. The MODIFY action cancels existing SL/TP orders and places new ones.
- If the signal is a conditional/setup signal (e.g. "look for long after 4h close above X", "wait for breakout above Y"), output CONDITIONAL with pair, direction, entry_price as the trigger price, and reason describing the condition and timeframe (e.g. "4h"). The system will monitor the price and enter automatically when the condition is met.

CRITICAL SCALPING RULES:
- Every trade MUST have a real stop loss. sl_price must be strictly below entry_price for LONG and strictly above entry_price for SHORT. Never set sl_price equal to entry_price.
- Minimum risk-reward ratio: sl_distance must be at least 2x smaller than tp_distance (R:R >= 2:1). If you cannot set a TP that gives R:R >= 2:1, SKIP the trade.
- Do not enter into crowded trades. If the signal is a generic "buy the dip" or "moon" with no technical basis, SKIP.
- Consider funding rate: entering a LONG when funding is very positive means you pay to hold. Entering a SHORT when funding is very negative means you pay to hold. Avoid these.
- Be selective. Quality over quantity. If the setup is not clear, SKIP.

Output *only* a valid JSON object — no text before, no text after, no markdown fences, no tables, no bold, no headers, no explanations.

**CRITICAL**: Your ENTIRE response must be ONLY the JSON object. No explanations, no reasoning, no markdown formatting — just the raw JSON starting with `{` and ending with `}`.

Example:
{"action":"ENTER","pair":"BTCUSDT","direction":"LONG","order_type":"MARKET","quantity":0,"entry_price":65000,"sl_price":64000,"tp_prices":[67000,68000],"reason":"Clear support bounce with good R/R","confidence":0.8}
"""""


def _build_prompt(signal: TradeSignal, open_positions: list[dict],
                  balance: dict[str, Any] | None = None,
                  ta_context: str | None = None) -> str:
    """Build a concise prompt for the LLM with all relevant context."""
    lines = [
        "## Signal Text",
        signal.raw_text,
        "",
        "## Regex Pre-Parse",
        f"  Pair: {signal.pair}",
        f"  Direction: {signal.direction}",
        f"  Entry: {signal.entry_price}",
        f"  SL: {signal.sl_price}",
        f"  TP: {signal.tp_prices}",
        "",
    ]

    # Inject real market structure when the signal has no SL/TP
    if ta_context:
        lines.append(ta_context)
        lines.append("")

    if open_positions:
        lines.append("## Open Positions")
        for pos in open_positions:
            lines.append(f"  {pos['direction']} {pos['pair']} @ {pos['entry_price']} qty={pos['quantity']}")
        lines.append("")

    if balance:
        lines.append("## Account")
        for asset, val in balance.items():
            if isinstance(val, (int, float)) and val > 0:
                lines.append(f"  {asset}: {val}")
        lines.append("")

    lines.append("## Decision")
    return "\n".join(lines)


def _parse_decision(raw: str) -> TradeDecision | None:
    """Parse LLM response into a TradeDecision.

    Tries: raw JSON -> code-fenced JSON -> regex JSON extraction from full text.
    Normalizes LLM alias field names (stop_loss→sl_price, take_profit→tp_prices,
    OPEN_LONG→ENTER, EXECUTE_LONG→ENTER, etc.) so any model variant works.
    """
    text = raw.strip()

    # Try 1: Strip markdown code fences
    if text.startswith("```"):
        text = text.split("\n", 1)[-1]
        text = text.rsplit("```", 1)[0]
    text = text.strip()

    # Try 2: Direct JSON parse
    try:
        data = json.loads(text)
    except json.JSONDecodeError:
        # Try 3: Find JSON-like object anywhere in the text
        import re as _re
        match = _re.search(r'\{[\s\S]*?"action"\s*:\s*"(ENTER|CLOSE|SKIP|MODIFY|CONDITIONAL|OPEN_LONG|OPEN_SHORT|EXECUTE_LONG|EXECUTE_SHORT|HOLD|WAIT|SETUP)"[\s\S]*?\}', text)
        if match:
            try:
                data = json.loads(match.group(0))
            except json.JSONDecodeError:
                log.warning("Found JSON-like block but failed to parse: %s", match.group(0)[:100])
                return None
        else:
            log.warning("LLM returned invalid JSON: %s", raw[:200])
            return None

    # Normalize action aliases
    action = data.get("action", "SKIP")
    action_map = {
        "OPEN_LONG": "ENTER", "OPEN_SHORT": "ENTER",
        "EXECUTE_LONG": "ENTER", "EXECUTE_SHORT": "ENTER",
        "SETUP": "CONDITIONAL", "HOLD": "SKIP", "WAIT": "SKIP",
    }
    action = action_map.get(action, action)
    if action not in ("ENTER", "CLOSE", "SKIP", "MODIFY", "CONDITIONAL"):
        action = "SKIP"

    direction = data.get("direction", "LONG")
    if direction not in ("LONG", "SHORT"):
        direction = "LONG"

    order_type = data.get("order_type", "MARKET")
    if order_type not in ("MARKET", "LIMIT"):
        order_type = "MARKET"

    # Normalize SL aliases: sl_price, stop_loss, sl, stop_loss_price
    sl_price = None
    for key in ("sl_price", "stop_loss", "sl", "stop_loss_price", "stoploss"):
        if data.get(key) is not None:
            sl_price = float(data[key])
            break

    # Normalize TP aliases: tp_prices, take_profit, tp, take_profit_prices, tps
    tp_prices = []
    for key in ("tp_prices", "take_profit", "tp", "take_profit_prices", "tps"):
        val = data.get(key)
        if val is not None:
            if isinstance(val, (int, float)):
                tp_prices = [float(val)]
            elif isinstance(val, list):
                tp_prices = [float(tp) for tp in val if tp]
            break

    return TradeDecision(
        action=action,
        pair=data.get("pair", ""),
        direction=direction,
        order_type=order_type,
        quantity=float(data.get("quantity", 0)),
        entry_price=float(data["entry_price"]) if data.get("entry_price") else None,
        sl_price=sl_price,
        tp_prices=tp_prices,
        reason=data.get("reason", ""),
        confidence=float(data.get("confidence", 0)),
    )


class AgentBrain:
    """LLM-powered trading agent using OpenCode Go (or any OpenAI-compatible API).

    Supports fallback to a secondary model on the same provider if the primary
    model call fails (HTTP error or parse failure).
    """

    def __init__(self, config: dict):
        agent_cfg = config.get("agent", {})
        llm_cfg = agent_cfg.get("llm", {})
        self.api_url = llm_cfg.get("api_url", "https://opencode.ai/zen/go/v1/chat/completions")
        self.model = llm_cfg.get("model", "deepseek-v4-flash")

        # Fallback model: same provider, different model (e.g. nemotron)
        self.fallback_model = llm_cfg.get("fallback_model", "")

        # API key: try api_key field first, then api_key_env env var, then env file
        self.api_key = llm_cfg.get("api_key", "")
        if not self.api_key:
            env_var = llm_cfg.get("api_key_env", "")
            if env_var:
                self.api_key = os.environ.get(env_var, "")
                if not self.api_key:
                    # Try loading from .env
                    from dotenv import load_dotenv
                    load_dotenv(Path(__file__).resolve().parent.parent.parent / ".env")
                    self.api_key = os.environ.get(env_var, "")

        self.timeout = llm_cfg.get("timeout", 30)
        self.auto_trade = agent_cfg.get("auto_trade", False)
        self.confidence_threshold = agent_cfg.get("confidence_threshold", 0.6)
        # Self-learning: feed per-pair historical win-rate back into decisions.
        # OFF by default — the running day-test is unaffected until enabled.
        self_learning = agent_cfg.get("self_learning", {}) or {}
        self.self_learning_enabled = bool(self_learning.get("enabled", False))
        self.self_learning_min_n = int(self_learning.get("min_trades", 5))
        self.self_learning_skip_win_rate = float(self_learning.get("skip_below_win_rate", 0.35))
        # Shared async HTTP client (created lazily on first async call so it
        # binds to the running event loop). Reusing one client pools connections
        # and keeps the event loop unblocked during LLM round-trips.
        self._async_client: "httpx.AsyncClient | None" = None

    def _build_reinforce_prompt(self, original_prompt: str,
                                 bad_response: str) -> str:
        """Build a reinforced prompt telling the LLM its last response was invalid."""
        return (
            "Your previous response was NOT valid JSON. "
            "You MUST return ONLY a valid JSON object this time.\n\n"
            "## CRITICAL — READ CAREFULLY\n"
            "- Your ENTIRE response must be a single JSON object.\n"
            "- Start with `{` and end with `}`.\n"
            "- DO NOT include any text before or after the JSON.\n"
            "- DO NOT use markdown code fences (```).\n"
            "- DO NOT include explanations, reasoning, or analysis.\n"
            "- ONLY the raw JSON object.\n\n"
            "## Your invalid response (DO NOT repeat this)\n"
            f"{bad_response[:500]}\n\n"
            "## The original request\n"
            f"{original_prompt}\n\n"
            "## Decision\n"
            "Output ONLY the JSON object now:"
        )

    async def decide(self, signal: TradeSignal,
               open_positions: list[dict] | None = None,
               balance: dict[str, Any] | None = None,
               ta_context: str | None = None,
               pair_history: dict | None = None) -> TradeDecision:
        """Analyze a signal and return a trade decision.

        Async: the LLM round-trip uses a shared AsyncClient so the event loop
        (position monitor, SL checks, other signals) is never blocked.

        ``pair_history`` (optional) is the per-pair win-rate dict from
        StrategyPerfRepository — used only when self-learning is enabled, as a
        soft confidence scaler (chronic losers get a higher bar; the LLM still
        makes the call).
        """
        prompt = _build_prompt(signal, open_positions or [], balance, ta_context)

        # Try 1: normal call
        response = ""
        self._last_interaction: dict | None = None
        try:
            response, tokens_in, tokens_out, latency = await self._call_llm_async(prompt)
            decision = _parse_decision(response)
            self._last_interaction = {
                "model": self.model,
                "system_prompt": SYSTEM_PROMPT,
                "user_prompt": prompt,
                "raw_response": response,
                "parsed_decision_json": json.dumps({
                    "action": decision.action if decision else "SKIP",
                    "pair": decision.pair if decision else "",
                    "direction": decision.direction if decision else "LONG",
                }, default=str) if decision else "{}",
                "prompt_tokens": tokens_in,
                "completion_tokens": tokens_out,
                "latency_ms": latency,
                "success": decision is not None,
                "error": None,
            }
        except Exception as e:
            log.error("LLM call failed: %s", e)
            decision = None
            self._last_interaction = {
                "model": self.model,
                "system_prompt": SYSTEM_PROMPT,
                "user_prompt": prompt,
                "raw_response": response or str(e),
                "parsed_decision_json": "{}",
                "prompt_tokens": 0,
                "completion_tokens": 0,
                "latency_ms": 0,
                "success": False,
                "error": str(e),
            }

        # Try 2: retry with reinforced prompt if first attempt failed to parse
        if decision is None:
            log.warning("LLM response invalid, retrying with reinforced prompt...")
            reinforce = self._build_reinforce_prompt(prompt, response or "(no response)")
            try:
                response2, tokens_in2, tokens_out2, latency2 = await self._call_llm_async(reinforce)
                decision = _parse_decision(response2)
                if decision is not None:
                    log.info("Retry succeeded — LLM returned valid JSON on second attempt")
                    self._last_interaction = {
                        "model": self.model,
                        "system_prompt": SYSTEM_PROMPT,
                        "user_prompt": reinforce,
                        "raw_response": response2,
                        "parsed_decision_json": json.dumps({
                            "action": decision.action,
                            "pair": decision.pair,
                            "direction": decision.direction,
                        }, default=str),
                        "prompt_tokens": tokens_in2,
                        "completion_tokens": tokens_out2,
                        "latency_ms": latency2,
                        "success": True,
                        "error": None,
                    }
            except Exception as e:
                log.error("LLM retry also failed: %s", e)
                decision = None

        # Try 3: fallback to secondary model on same provider
        if decision is None and self.fallback_model:
            log.warning("Primary model failed, trying fallback model: %s", self.fallback_model)
            try:
                response3, tokens_in3, tokens_out3, latency3 = await self._call_llm_async(prompt, model=self.fallback_model)
                decision = _parse_decision(response3)
                if decision is not None:
                    log.info("Fallback model succeeded — LLM returned valid JSON")
                    self._last_interaction = {
                        "model": self.fallback_model,
                        "system_prompt": SYSTEM_PROMPT,
                        "user_prompt": prompt,
                        "raw_response": response3,
                        "parsed_decision_json": json.dumps({
                            "action": decision.action,
                            "pair": decision.pair,
                            "direction": decision.direction,
                        }, default=str),
                        "prompt_tokens": tokens_in3,
                        "completion_tokens": tokens_out3,
                        "latency_ms": latency3,
                        "success": True,
                        "error": None,
                    }
            except Exception as e:
                log.error("Fallback model also failed: %s", e)
                decision = None

        if decision is None:
            return TradeDecision(
                action="SKIP", pair=signal.pair or "", direction="LONG",
                reason="Failed to parse LLM response", confidence=0.0,
            )

        # Apply confidence threshold (with optional self-learning scaler)
        effective_threshold = self.confidence_threshold
        learn_note = ""
        if self.self_learning_enabled and pair_history:
            wr = pair_history.get("win_rate", 0.0)
            n = pair_history.get("n", 0)
            if n >= self.self_learning_min_n and wr < self.self_learning_skip_win_rate:
                # Chronic loser: raise the bar so only high-conviction entries
                # survive. Soft — the LLM's own confidence still decides.
                effective_threshold = max(self.confidence_threshold,
                                          0.85 if wr < 0.25 else 0.75)
                learn_note = (f" [self-learn: {signal.pair} win_rate={wr:.0%} "
                              f"over {n} trades — raising confidence bar]")
        if decision.confidence < effective_threshold and decision.action == "ENTER":
            return TradeDecision(
                action="SKIP", pair=decision.pair, direction=decision.direction,
                reason=f"Confidence {decision.confidence:.2f} below threshold {effective_threshold:.2f}{learn_note}",
                confidence=decision.confidence,
            )

        # In dry-run mode, log but don't enter
        if not self.auto_trade and decision.action == "ENTER":
            log.info("Dry-run: would ENTER %s %s qty=%.4f (reason: %s)",
                     decision.direction, decision.pair, decision.quantity, decision.reason)
            return TradeDecision(
                action="SKIP", pair=decision.pair, direction=decision.direction,
                reason=f"[DRY-RUN] Would enter: {decision.reason}",
                confidence=decision.confidence,
            )

        return decision

    async def ping(self) -> dict:
        """Lightweight health check — one minimal chat completion call.

        Returns a dict with ``status`` (ok|error), the model/url used, any
        error text, and round-trip latency in ms. Does not count against
        trade logic (no retries, minimal tokens).
        """
        import time

        result: dict = {
            "status": "unknown",
            "model": self.model,
            "url": self.api_url,
            "error": None,
            "latency_ms": 0,
        }
        if not self.api_key:
            result["status"] = "error"
            result["error"] = "API key not configured"
            return result

        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}",
        }
        payload = {
            "model": self.model,
            "messages": [{"role": "user", "content": "ping"}],
            "max_tokens": 5,
        }
        t0 = time.monotonic()
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                resp = await client.post(self.api_url, json=payload, headers=headers)
            result["latency_ms"] = int((time.monotonic() - t0) * 1000)
            if resp.status_code == 200:
                result["status"] = "ok"
            else:
                result["status"] = "error"
                result["error"] = f"HTTP {resp.status_code}: {resp.text[:200]}"
        except Exception as e:  # noqa: BLE001 — health must never raise
            result["status"] = "error"
            result["error"] = f"{type(e).__name__}: {e}"
            result["latency_ms"] = int((time.monotonic() - t0) * 1000)
        return result

    def _call_llm(self, prompt: str, model: str | None = None) -> tuple[str, int, int, int]:
        """Synchronous LLM call (used by the sync health-check ping only)."""
        return self._call_llm_sync(prompt, model)

    def _call_llm_sync(self, prompt: str, model: str | None = None) -> tuple[str, int, int, int]:
        """Call the LLM via OpenAI-compatible chat completions endpoint (sync).

        Returns (response_text, prompt_tokens, completion_tokens, latency_ms).
        If ``model`` is provided, use it instead of ``self.model``.
        """
        import time
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"

        target_model = model or self.model
        payload = {
            "model": target_model,
            # NOTE: mindai/macaron-v1-tall does NOT support structured-outputs
            # on the GitLawB gateway — sending response_format triggers a 400.
            # The system prompt already instructs raw JSON output, so we rely
            # on that + the parser fallbacks instead.
            "messages": [
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": prompt},
            ],
            "temperature": 0.1,
            "max_tokens": 4096,
        }

        log.info("Calling LLM: %s with model %s", self.api_url, target_model)
        t0 = time.monotonic()
        with httpx.Client(timeout=self.timeout) as client:
            resp = client.post(self.api_url, json=payload, headers=headers)
            resp.raise_for_status()
            data = resp.json()
            latency = int((time.monotonic() - t0) * 1000)
            usage = data.get("usage", {})
            prompt_tokens = usage.get("prompt_tokens", 0)
            completion_tokens = usage.get("completion_tokens", 0)
            msg = data["choices"][0]["message"]
            # Reasoning models may put JSON in content or reasoning_content
            content = msg.get("content", "") or ""
            rc = msg.get("reasoning_content", "") or msg.get("reasoning", "") or ""
            # Try content first (it's the actual response), fall back to full text
            if content.strip():
                return content, prompt_tokens, completion_tokens, latency
            return content + "\n" + rc, prompt_tokens, completion_tokens, latency

    async def _call_llm_async(self, prompt: str, model: str | None = None) -> tuple[str, int, int, int]:
        """Async LLM call using a shared AsyncClient (event-loop friendly).

        Returns (response_text, prompt_tokens, completion_tokens, latency_ms).
        Reuses ``self._async_client`` so connections are pooled and the event
        loop is never blocked during the (multi-second) model round-trip.
        """
        import time
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"

        target_model = model or self.model
        payload = {
            "model": target_model,
            "messages": [
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": prompt},
            ],
            "temperature": 0.1,
            "max_tokens": 4096,
        }

        if self._async_client is None:
            self._async_client = httpx.AsyncClient(timeout=self.timeout)
        client = self._async_client
        log.info("Calling LLM (async): %s with model %s", self.api_url, target_model)
        t0 = time.monotonic()
        resp = await client.post(self.api_url, json=payload, headers=headers)
        resp.raise_for_status()
        data = resp.json()
        latency = int((time.monotonic() - t0) * 1000)
        usage = data.get("usage", {})
        prompt_tokens = usage.get("prompt_tokens", 0)
        completion_tokens = usage.get("completion_tokens", 0)
        msg = data["choices"][0]["message"]
        content = msg.get("content", "") or ""
        rc = msg.get("reasoning_content", "") or msg.get("reasoning", "") or ""
        if content.strip():
            return content, prompt_tokens, completion_tokens, latency
        return content + "\n" + rc, prompt_tokens, completion_tokens, latency

