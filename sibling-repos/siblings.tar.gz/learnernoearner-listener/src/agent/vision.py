"""Vision extraction — turn a chart image into the structured vision_struct JSON.

The prompt is deliberately specific (not "describe this image"): it asks for
every horizontal line with an exact price, the trend, the setup type, the
drawn wave as ordered waypoints, every arrow with a meaning, and — for BTC
posts — the directional bias.

Output shape (docs/PLAN_attachment_bias.md):

    {"levels": {"entry":null,"sl":null,"tp":[],"support":[...],"resistance":[...]},
     "trend":"uptrend", "setup_type":"pullback",
     "wave":[{"idx":0,"price":...,"label":"swing_low"}],
     "arrows":[{"at":{"idx":1,"price":...},"dir":"right","meaning":"continuation"}],
     "bias":{"primary":"BULLISH","secondary":"","horizon":""},
     "has_chart_data":true}
"""

from __future__ import annotations

import base64
import json
import logging
import os
import re
from pathlib import Path
from typing import Any

import httpx

log = logging.getLogger(__name__)

VISION_PROMPT = """You are reading a crypto trading chart screenshot.

Return ONLY a JSON object, no prose, with exactly this shape:
{
  "levels": {"entry": null, "sl": null, "tp": [],
             "support": [], "resistance": []},
  "trend": "",
  "setup_type": "",
  "wave": [],
  "arrows": [],
  "bias": {"primary": "", "secondary": "", "horizon": ""},
  "has_chart_data": true
}

Rules:
- levels.support / levels.resistance: every horizontal line drawn on the chart,
  as exact numeric prices. Support = below current price, resistance = above.
- levels.entry / sl / tp: only if the chart explicitly labels them.
- trend: one of uptrend, downtrend, range, chop, up, down.
- setup_type: one of pullback, breakout, reversal, fakeout, pnl_card.
- wave: the drawn projected trajectory as ordered waypoints,
  [{"idx":0,"price":123.4,"label":"swing_low"}, ...].
  Labels: swing_low, swing_high, current, projected_target.
- arrows: [{"at":{"idx":1,"price":123.4},"dir":"right","meaning":"continuation"}].
  meaning is one of entry_trigger, target, continuation, reversal_pending.
- bias.primary: BULLISH, BEARISH, NEUTRAL, RANGE, or NO_CHASE. Only fill this
  in for market-bias/BTC posts; leave "" for ordinary trade setups.
- has_chart_data: false if this is a meme, a screenshot with no price levels,
  or a PnL card rather than a chart.
"""

EMPTY_STRUCT: dict[str, Any] = {
    "levels": {"entry": None, "sl": None, "tp": [], "support": [], "resistance": []},
    "trend": "",
    "setup_type": "",
    "wave": [],
    "arrows": [],
    "bias": {"primary": "", "secondary": "", "horizon": ""},
    "has_chart_data": False,
}

_JSON_BLOCK_RE = re.compile(r"\{.*\}", re.S)


def _coerce(struct: Any) -> dict[str, Any]:
    """Normalize a model response into the canonical vision_struct shape."""
    if not isinstance(struct, dict):
        return json.loads(json.dumps(EMPTY_STRUCT))

    out = json.loads(json.dumps(EMPTY_STRUCT))
    levels = struct.get("levels") or {}
    if isinstance(levels, dict):
        for key in ("entry", "sl"):
            try:
                out["levels"][key] = float(levels[key]) if levels.get(key) is not None else None
            except (TypeError, ValueError):
                out["levels"][key] = None
        for key in ("tp", "support", "resistance"):
            vals = levels.get(key) or []
            nums: list[float] = []
            for v in vals if isinstance(vals, list) else []:
                try:
                    nums.append(float(v))
                except (TypeError, ValueError):
                    continue
            out["levels"][key] = nums

    out["trend"] = str(struct.get("trend") or "")
    out["setup_type"] = str(struct.get("setup_type") or "")
    out["wave"] = struct.get("wave") if isinstance(struct.get("wave"), list) else []
    out["arrows"] = struct.get("arrows") if isinstance(struct.get("arrows"), list) else []

    bias = struct.get("bias") or {}
    if isinstance(bias, dict):
        out["bias"] = {
            "primary": str(bias.get("primary") or "").upper(),
            "secondary": str(bias.get("secondary") or ""),
            "horizon": str(bias.get("horizon") or ""),
        }

    out["has_chart_data"] = bool(struct.get("has_chart_data", True))
    return out


def parse_vision_response(raw: str) -> dict[str, Any]:
    """Extract and normalize the JSON object from a vision model response."""
    if not raw:
        return _coerce(None)
    try:
        return _coerce(json.loads(raw))
    except (ValueError, TypeError):
        pass
    match = _JSON_BLOCK_RE.search(raw)
    if match:
        try:
            return _coerce(json.loads(match.group(0)))
        except (ValueError, TypeError):
            pass
    log.warning("Vision response was not parseable JSON")
    return _coerce(None)


class VisionExtractor:
    """Calls a vision-capable LLM endpoint and returns vision_struct."""

    def __init__(self, config: dict | None = None):
        cfg = ((config or {}).get("agent") or {}).get("vision") or {}
        self.api_url = cfg.get(
            "api_url", "https://opengateway.gitlawb.com/v1/chat/completions"
        )
        self.model = cfg.get("model", "google/gemini-3.1-flash-lite")
        self.timeout = int(cfg.get("timeout", 60))
        self.api_key = cfg.get("api_key", "")
        if not self.api_key:
            self.api_key = os.environ.get(
                cfg.get("api_key_env", "GITLAWB_API_KEY"), ""
            )

    @staticmethod
    def encode_image(path: str | Path) -> str:
        return base64.b64encode(Path(path).read_bytes()).decode("ascii")

    async def extract(self, image_path: str | Path,
                      caption: str = "") -> dict[str, Any]:
        """Read a chart image and return the structured vision_struct dict."""
        path = Path(image_path)
        if not path.exists():
            log.warning("Vision: image missing at %s", path)
            return _coerce(None)
        if not self.api_key:
            log.warning("Vision: no API key configured, skipping extraction")
            return _coerce(None)

        prompt = VISION_PROMPT
        if caption:
            prompt += f"\n\nThe post's caption was: {caption!r}"

        payload = {
            "model": self.model,
            "messages": [{
                "role": "user",
                "content": [
                    {"type": "text", "text": prompt},
                    {"type": "image_url", "image_url": {
                        "url": f"data:image/jpeg;base64,{self.encode_image(path)}"
                    }},
                ],
            }],
            "temperature": 0,
        }

        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                resp = await client.post(
                    self.api_url,
                    headers={"Authorization": f"Bearer {self.api_key}"},
                    json=payload,
                )
                resp.raise_for_status()
                raw = resp.json()["choices"][0]["message"]["content"]
        except Exception as e:  # noqa: BLE001 — vision must never crash the pipeline
            log.warning("Vision extraction failed for %s: %s", path, e)
            return _coerce(None)

        return parse_vision_response(raw)
