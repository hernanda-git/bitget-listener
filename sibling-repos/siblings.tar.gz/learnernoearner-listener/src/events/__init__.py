"""In-process event bus."""
