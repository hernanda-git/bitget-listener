"""Domain models and enums."""
