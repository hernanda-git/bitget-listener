"""Setup-quality and market-regime filters (plan deliverables #4 and #5).

Both are go/no-go gates. Neither ever touches quantity — sizing stays exactly
where it already lives (gate.py / TradeDecision.quantity).
"""

from __future__ import annotations

import logging
from typing import Any

log = logging.getLogger(__name__)

# Bias values that stand a long setup down entirely.
_BLOCKING_BIASES = {"NO_CHASE"}


def passes_kaito_guard(signal_row: Any, vision_struct: dict | None) -> bool:
    """KAITO GUARD: refuse breakdown-bounce / bull-trap setups.

    Named after the KAITO long that liquidated at -19.96 on a dead-cat bounce
    the clean 1:5.6 R/R text completely hid. If the chart read says ``fakeout``,
    do not take the trade.
    """
    setup_type = ""
    if vision_struct:
        setup_type = str(vision_struct.get("setup_type") or "").lower()
    if not setup_type:
        setup_type = str(getattr(signal_row, "chart_setup_type", "") or "").lower()

    if setup_type == "fakeout":
        log.info("KAITO guard: setup_type=fakeout — refusing entry")
        return False
    return True


def passes_regime_filter(signal_row: Any, latest_bias: dict | None = None) -> bool:
    """Market-regime filter driven by the latest BTC bias read (<=24h old).

        BEARISH  -> block longs
        RANGE    -> block breakout-longs, allow pullback-longs
        NO_CHASE -> stand aside entirely
        BULLISH / no data -> normal
    """
    if not latest_bias:
        return True

    bias = str(latest_bias.get("bias_primary") or "").upper()
    side = str(getattr(signal_row, "side", "") or
               getattr(signal_row, "direction", "") or "").upper()
    setup_type = str(getattr(signal_row, "chart_setup_type", "") or "").lower()

    if bias in _BLOCKING_BIASES:
        log.info("Regime filter: bias=%s — standing aside", bias)
        return False

    if bias == "BEARISH" and side == "LONG":
        log.info("Regime filter: BEARISH regime blocks LONG entry")
        return False

    if bias == "RANGE" and side == "LONG" and setup_type == "breakout":
        log.info("Regime filter: RANGE regime blocks breakout-LONG entry")
        return False

    return True
