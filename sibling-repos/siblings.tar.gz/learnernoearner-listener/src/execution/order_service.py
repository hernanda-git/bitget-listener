"""Order service — translates TradeDecision → exchange orders with idempotency."""

from __future__ import annotations

import logging
import uuid
from typing import Any, TYPE_CHECKING

from src.domain.models import ExecutionResult, OrderRequest, TradeSignal, TradeDecision
from src.exchange.base import Exchange
from src.exchange.validation import validate_order
from src.agent.gate import _snap_leverage
from src.agent.level_resolver import resolve_scalp_levels
from src.execution.filters import passes_kaito_guard, passes_regime_filter
from src.state.repositories import DecisionRepository, OrderRepository, PositionRepository, SignalRepository

if TYPE_CHECKING:
    from src.agent.agent import AgentBrain

log = logging.getLogger("execution.order_service")


class OrderService:
    """Bridge between TradeDecision and the exchange.

    Generates idempotent client_order_ids, places orders via the exchange,
    and records everything in state.
    """

    def __init__(self, exchange: Exchange, config: dict,
                 signal_repo: SignalRepository,
                 decision_repo: DecisionRepository,
                 order_repo: OrderRepository,
                 position_repo: PositionRepository,
                 agent: "AgentBrain | None" = None):
        self.exchange = exchange
        self.config = config
        self.signal_repo = signal_repo
        self.decision_repo = decision_repo
        self.order_repo = order_repo
        self.position_repo = position_repo
        self.agent = agent
        self._max_retries = config.get("execution", {}).get("max_retries", 3)

    def _generate_client_id(self, decision_id: int) -> str:
        """Generate a unique, idempotent client order ID."""
        return f"lnr_{decision_id}_{uuid.uuid4().hex[:8]}"

    def compute_notional_qty(self, port_usdt: float, max_leverage: float) -> float:
        """Notional sizing. UNCHANGED — identical for every signal shape.

        Deliberately the single sizing entry point so scalp_watch and
        formal_setup can never diverge. Do not special-case anything here.
        """
        return port_usdt * max_leverage

    async def place_entry(self, signal_row: Any, vision_struct: dict | None,
                          current_mark_price: float,
                          attachment_repo: Any = None,
                          latest_bias: dict | None = None) -> Any:
        """Place an entry order for a parsed signal row.

        For ``scalp_watch`` shapes the entry price comes from the level
        resolver and the order rests as a LIMIT at that chart level. Sizing is
        computed by :meth:`compute_notional_qty` exactly as on every other
        path — this method never touches quantity.

        See docs/PLAN_attachment_bias_ADDENDUM_scalp_levels.md §4.
        """
        risk = self.config.get("risk", {})
        port_usdt = risk.get("port_usdt", 1.0)
        max_leverage = risk.get("max_leverage", 20)
        qty = self.compute_notional_qty(port_usdt, max_leverage)  # UNCHANGED

        if getattr(signal_row, "signal_shape", "formal_setup") == "scalp_watch":
            levels = resolve_scalp_levels(
                getattr(signal_row, "raw_text", ""),
                vision_struct,
                getattr(signal_row, "side", "") or getattr(signal_row, "direction", ""),
                current_mark_price,
            )
            # Persisted for EVERY scalp_watch, including skips — near-miss audit trail.
            if attachment_repo is not None and getattr(signal_row, "id", None):
                attachment_repo.persist_resolution(signal_row.id, levels)

            if levels.stop is None:
                log.info("scalp_watch %s: no derivable stop, refusing entry",
                         getattr(signal_row, "id", "?"))
                return None

            if levels.confidence < 0.6:
                log.info("scalp_watch %s: confidence %.2f below threshold, skipping",
                         getattr(signal_row, "id", "?"), levels.confidence)
                return None

            # KAITO guard and regime filter run unchanged, same order, no bypass.
            if not passes_kaito_guard(signal_row, vision_struct):
                return None
            if not passes_regime_filter(signal_row, latest_bias):
                return None

            return await self.exchange.place_limit_order(
                symbol=getattr(signal_row, "symbol_resolved", "")
                or getattr(signal_row, "pair", ""),
                side=getattr(signal_row, "side", "")
                or getattr(signal_row, "direction", ""),
                price=levels.entry,   # LIMIT at the resolved chart level, not MARKET
                qty=qty,              # UNCHANGED sizing
                reduce_only=False,
            )

        # ── formal_setup path: unchanged ────────────────────────────────
        if not passes_kaito_guard(signal_row, vision_struct):
            return None
        if not passes_regime_filter(signal_row, latest_bias):
            return None

        return await self.exchange.place_limit_order(
            symbol=getattr(signal_row, "symbol_resolved", "")
            or getattr(signal_row, "pair", ""),
            side=getattr(signal_row, "side", "")
            or getattr(signal_row, "direction", ""),
            price=getattr(signal_row, "entry_price", None) or current_mark_price,
            qty=qty,
            reduce_only=False,
        )

    async def _get_filters(self, symbol: str) -> dict | None:
        """Load exchange filters for a symbol (delegates to the exchange adapter).

        Returns the filter dict (with tickSize/minPrice/maxPrice/stepSize/
        minQty/minNotional) or None if unavailable (validation is then skipped
        rather than blocking — the exchange is the final authority).
        """
        try:
            loader = getattr(self.exchange, "_load_futures_filters", None)
            if loader is not None:
                return await loader(symbol)
        except Exception as e:
            log.debug("Could not load filters for %s: %s", symbol, e)
        return None

    async def execute(self, signal_id: int, decision: TradeDecision,
                      decision_id: int | None = None) -> ExecutionResult:
        """Execute a trade decision and return the result.

        Args:
            signal_id: The DB ID of the signal triggering this decision.
            decision: The trade decision to execute.
            decision_id: Optional pre-saved decision ID. If None, the decision
                         is saved internally and a new ID is created.
        """
        # Save decision if not pre-saved
        if decision_id is None:
            decision_id = self.decision_repo.save(signal_id, decision)

        if decision.action == "SKIP":
            return ExecutionResult(success=True, status="SKIPPED",
                                   error=f"Skipped: {decision.reason}")

        if decision.action == "CLOSE":
            return await self._close_position(decision_id, decision)

        if decision.action == "MODIFY":
            return await self._modify_position(decision_id, decision)

        return await self._enter_position(decision_id, decision)

    async def _enter_position(self, decision_id: int,
                              decision: TradeDecision) -> ExecutionResult:
        """Open a new position."""
        symbol = decision.pair.replace("#", "").replace("$", "").upper()
        if not symbol.endswith("USDT"):
            symbol += "USDT"

        quantity = decision.quantity
        client_id = self._generate_client_id(decision_id)
        side = "BUY" if decision.direction == "LONG" else "SELL"

        # ─── Idempotency: never place a second active entry for the same decision ──
        existing = self.order_repo.get_active_for_decision(decision_id, symbol, side)
        if existing:
            log.info("Idempotency: decision %d already has active %s %s order %s (%s) — skip",
                     decision_id, symbol, side, existing.get("exchange_order_id"), existing.get("status"))
            return ExecutionResult(success=True, status="DUPLICATE_SKIPPED",
                                   order_id=existing.get("exchange_order_id"),
                                   symbol=symbol, side=side,
                                   error=f"Duplicate entry skipped: decision {decision_id} already has active order")

        # Set futures leverage and margin type before placing the entry order
        if decision.leverage > 1:
            await self.exchange.set_symbol_leverage(symbol, decision.leverage)
            margin_type = self.config.get("risk", {}).get("margin_type", "ISOLATED")
            await self.exchange.set_margin_type(symbol, margin_type)

        # ─── Pre-flight: leverage sanity check ──────────────────────────
        # Gate2 already validates this, but double-check before hitting the API
        if decision.leverage > 1:
            try:
                bal = await self.exchange.get_balance()
                margin_budget = bal.free_usdt * (
                    self.config.get("risk", {}).get("margin_usage_pct", 50) / 100.0
                )
                notional_value = decision.quantity * (decision.entry_price or 0)
                margin_needed = notional_value / decision.leverage
                if margin_needed > margin_budget * 1.1:  # 10% tolerance
                    log.warning(
                        "Pre-flight margin check: needed=$%.2f budget=$%.2f (%.1f%% over)",
                        margin_needed, margin_budget,
                        (margin_needed / margin_budget - 1) * 100,
                    )
            except Exception as e:
                log.debug("Pre-flight balance check skipped: %s", e)

        # ─── Pre-submission validation gate ──────────────────────────────
        # Never send an order that violates the symbol's exchange filters.
        # This guarantees "no order submitted without passing validation".
        filters = await self._get_filters(symbol)

        # Validate minimum notional (Binance requirement) — scale quantity up if below
        price_ref = decision.entry_price or 0
        min_notional = self.config.get("risk", {}).get("min_notional_usdt", 1.0)
        notional_check = quantity * price_ref
        if notional_check < min_notional and notional_check > 0:
            scale = min_notional / notional_check
            quantity = quantity * scale
            log.info("Scaled quantity by %.4fx to meet min notional $%.2f (was $%.2f)",
                     scale, min_notional, notional_check)

        # Round quantity to exchange stepSize using the exchange's authoritative
        # _round_quantity method (handles lazy filter loading, integer fallback
        # for low-price coins, and minNotional enforcement). Always used as the
        # PRIMARY rounding path — the manual stepSize rounding below is kept as
        # a fast-path for when filters are already cached.
        try:
            quantity, _ = await self.exchange._round_quantity(symbol, quantity, price_ref=price_ref)
        except Exception:
            log.debug("_round_quantity fallback for %s: using manual rounding", symbol)
            # Manual fallback when _round_quantity fails
            if filters:
                step = filters.get("stepSize")
                if step and step > 0:
                    quantity = round(quantity / step) * step
                mn = filters.get("minNotional")
                if step and step > 0 and mn and mn > 0 and price_ref and price_ref > 0:
                    guard = 0
                    while quantity * price_ref < mn and guard < 1_000_000:
                        quantity += step
                        guard += 1
                    quantity = round(quantity / step) * step

        val_err = validate_order(symbol, side, decision.entry_price, quantity, filters or {})
        if val_err:
            log.warning("Validation gate BLOCKED entry %s %s %s qty=%.4f @ %.8f: %s",
                        symbol, side, decision.order_type, quantity, decision.entry_price, val_err)
            return ExecutionResult(
                success=False, status="VALIDATION_SKIP", error=val_err,
                symbol=symbol, side=side,
            )

        # ─── Entry order (always LIMIT, never MARKET) ───────────────────
        entry_price = decision.entry_price
        if not entry_price or entry_price <= 0:
            # No entry price provided — use current mark price
            try:
                entry_price = await self.exchange.get_mark_price(symbol)
            except Exception:
                entry_price = None
            if not entry_price or entry_price <= 0:
                return ExecutionResult(
                    success=False, status="FAILED",
                    error=f"Cannot determine entry price for {symbol}",
                )

        # Do NOT adjust entry_price to current market — that defeats the
        # purpose of a LIMIT order. The order rests on the book at the
        # specified price and fills when the market comes to it.

        # ─── Frontrun-split entry (draft-and-cancel hedge) ───────────────
        # If the market has already moved adversely past the signal entry
        # (frontrunned), a pure limit at the signal entry may never fill. Enter
        # a small market portion immediately to guarantee entry, then rest a
        # limit for the remainder at the original signal price. If price pulls
        # back to the signal entry, the limit fills and we get the better price.
        fs = self.config.get("risk", {}).get("frontrun_split", {}) or {}
        if fs.get("enabled", False):
            try:
                mark = await self.exchange.get_mark_price(symbol)
            except Exception:
                mark = None
            if mark and entry_price and mark > 0 and entry_price > 0:
                adverse = (mark - entry_price) / entry_price if side == "BUY" else (entry_price - mark) / entry_price
                thr = float(fs.get("frontrun_threshold_pct", 0.5)) / 100.0
                if adverse > thr:
                    log.info("Frontrun detected %s: mark=%.8f entry=%.8f adverse=%.2f%% > %.2f%% — split entry",
                             symbol, mark, entry_price, adverse * 100, thr * 100)
                    return await self._enter_split(
                        decision_id, decision, symbol, side, quantity,
                        entry_price, mark, filters, client_id, fs,
                    )

        order = await self.exchange.limit_buy(symbol, quantity, entry_price) if side == "BUY" \
            else await self.exchange.limit_sell(symbol, quantity, entry_price)

        # If already filled (price was at or through the limit), done.
        # Otherwise the order rests on the book — save it as PENDING.
        if order.order_id and order.status != "FILLED":
            import asyncio as _aio
            # Quick check: did it fill in the first few seconds?
            for _attempt in range(5):
                await _aio.sleep(1)
                try:
                    check = await self.exchange.get_order(symbol, order.order_id)
                    if check.status == "FILLED":
                        order = check
                        break
                    if check.status in ("CANCELED", "EXPIRED", "REJECTED"):
                        return ExecutionResult(
                            success=False, status=check.status,
                            error=f"Entry order {check.status}: {check.error or ''}",
                        )
                except Exception:
                    pass
            else:
                # Order didn't fill in quick check — it's resting on the book
                log.info("LIMIT resting on book: %s %s qty=%.4f @ %.8f (order %s)",
                         symbol, side, quantity, entry_price, order.order_id)

        # Save order
        order_db_id = self.order_repo.save(
            decision_id=decision_id, exchange=self.exchange.name,
            symbol=symbol, side=side, order_type="LIMIT",
            quantity=quantity, price=order.price,
            client_order_id=client_id,
        )

        if order.status in ("FAILED", "REJECTED", "EXPIRED"):
            self.order_repo.update_status(order_db_id, order.status, order.order_id)

            # ── Deterministic repair (NO LLM) ──
            # Re-derive qty/price/leverage from the symbol's filters + Gate2,
            # validate, and resubmit exactly once. If the repaired order still
            # cannot pass validation, we SKIP rather than invent parameters.
            repair = await self._repair_order(decision_id, decision, symbol, side, order.error)
            if repair is not None:
                return repair

            return ExecutionResult(
                success=False, status=order.status, error=order.error or "Order rejected",
            )

        # If not yet filled, the order is resting on the book — return PENDING
        if order.status != "FILLED":
            self.order_repo.update_status(order_db_id, "PENDING", order.order_id)
            log.info("LIMIT order resting: %s %s qty=%.4f @ %.8f — waiting for price",
                     symbol, side, quantity, entry_price)
            return ExecutionResult(
                success=True,
                order_id=order.order_id,
                symbol=symbol,
                side=side,
                filled_quantity=0,
                avg_price=entry_price,
                status="PENDING",
                error=f"⏳ LIMIT order placed @ {entry_price} — waiting for price to reach it",
            )

        # Order is FILLED — save position and place SL/TP
        self.order_repo.update_status(order_db_id, "FILLED", order.order_id)

        # Save position
        from src.domain.models import Position
        pos = Position(
            pair=symbol,
            direction=decision.direction,
            entry_price=order.avg_price or decision.entry_price or 0,
            quantity=order.filled_quantity or quantity,
            sl_price=decision.sl_price,
            tp_prices=decision.tp_prices,
            entry_order_id=order.order_id,
            leverage=decision.leverage,
            margin_usdt=decision.quantity * (decision.entry_price or 0) / max(decision.leverage, 1),
            confidence=decision.confidence,
        )
        pos_id = self.position_repo.create(pos)

        # Place SL order
        sl_placed = False
        if decision.sl_price:
            sl_side = "SELL" if decision.direction == "LONG" else "BUY"
            sl_err = validate_order(symbol, sl_side, decision.sl_price, quantity, filters or {})
            if sl_err:
                log.warning("Validation gate SKIPPED SL %s @ %s: %s", symbol, decision.sl_price, sl_err)
            else:
                sl_order = await self.exchange.stop_loss(symbol, quantity, decision.sl_price, sl_side)
                if sl_order.order_id:
                    sl_placed = True
                    log.info("SL placed: %s @ %s (conditional)", symbol, decision.sl_price)
                    # Subscribe this pair to the live websocket mark-price stream
                    # (zero REST weight for SL monitoring). No-op if unsupported.
                    add_sym = getattr(self.exchange, "add_ws_symbol", None)
                    if callable(add_sym):
                        try:
                            add_sym(symbol)
                        except Exception:
                            pass
                elif sl_order.status == "UNPROTECTED":
                    log.warning("SL NOT placed for %s @ %s — position monitored by position manager",
                                symbol, decision.sl_price)
                else:
                    log.warning("SL NOT placed for %s @ %s — position UNPROTECTED (%s)",
                                symbol, decision.sl_price, sl_order.error)

        # Place TP orders — divide quantity evenly across TP levels
        # so TP1 doesn't close the full position.
        tp_levels = decision.tp_prices[:3]
        tp_qty_base = quantity / len(tp_levels) if len(tp_levels) > 1 else quantity
        for i, tp_price in enumerate(tp_levels):
            tp_side = "SELL" if decision.direction == "LONG" else "BUY"
            tp_err = validate_order(symbol, tp_side, tp_price, tp_qty_base, filters or {})
            if tp_err:
                log.warning("Validation gate SKIPPED TP%d %s @ %s: %s", i + 1, symbol, tp_price, tp_err)
                continue
            tp_order = await self.exchange.take_profit(symbol, tp_qty_base, tp_price, tp_side)
            if tp_order.order_id:
                log.info("TP%d placed: %s @ %s (conditional)", i + 1, symbol, tp_price)
            else:
                # Some contracts block conditional TP (-4120). Fall back to a
                # resting Basic-tab LIMIT at the TP price so TP still works.
                log.warning("TP%d conditional blocked (%s) — falling back to Basic LIMIT @ %s",
                            i + 1, tp_order.error, tp_price)
                if tp_side == "SELL":
                    fb = await self.exchange.limit_sell(symbol, tp_qty_base, tp_price, reduce=True)
                else:
                    fb = await self.exchange.limit_buy(symbol, tp_qty_base, tp_price, reduce=True)
                if fb.order_id:
                    log.info("TP%d placed (Basic LIMIT fallback): %s @ %s", i + 1, symbol, tp_price)

        log.info("Position opened: %s %s %s qty=%.4f", decision.direction, symbol, decision.order_type, quantity)

        return ExecutionResult(
            success=True,
            order_id=order.order_id,
            symbol=symbol,
            side=side,
            filled_quantity=order.filled_quantity or quantity,
            avg_price=order.avg_price or decision.entry_price or 0,
            status="FILLED",
        )

    async def _enter_split(self, decision_id: int, decision: TradeDecision, symbol: str,
                          side: str, quantity: float, entry_price: float, mark: float,
                          filters: dict, client_id: str, fs: dict) -> ExecutionResult:
        """Frontrun-split entry: market portion now + limit portion at signal entry.

        - market_qty enters immediately at current price (guaranteed fill).
        - limit_qty rests as a LIMIT at the original signal entry_price.
        The open Position reflects ONLY the market portion (actual exposure).
        The resting limit is tracked via pending_limit_order_id/qty so a later
        management command (breakeven / tp1) can cancel it and act on the open
        portion alone.
        """
        market_pct = float(fs.get("market_pct", 0.25))
        limit_pct = float(fs.get("limit_pct", 0.75))

        # Round each leg to the exchange stepSize independently.
        mkt_qty = quantity * market_pct
        lim_qty = quantity * limit_pct
        try:
            mkt_qty, _ = await self.exchange._round_quantity(symbol, mkt_qty, price_ref=mark)
            lim_qty, _ = await self.exchange._round_quantity(symbol, lim_qty, price_ref=entry_price)
        except Exception:
            pass

        # 1) Market portion — guaranteed entry.
        mkt_order = await self.exchange.market_buy(symbol, mkt_qty) if side == "BUY" \
            else await self.exchange.market_sell(symbol, mkt_qty)
        if not mkt_order.order_id or mkt_order.status == "FAILED":
            log.error("Frontrun-split: market leg failed %s: %s", symbol, mkt_order.error)
            return ExecutionResult(
                success=False, status=mkt_order.status or "FAILED",
                error=f"Split market leg failed: {mkt_order.error}", symbol=symbol, side=side,
            )
        mkt_avg = mkt_order.avg_price or mark
        log.info("Frontrun-split: market leg FILLED %s qty=%.4f @ %.8f", symbol, mkt_qty, mkt_avg)

        # 2) Limit portion — rest at the original signal entry price.
        lim_order = await self.exchange.limit_buy(symbol, lim_qty, entry_price) if side == "BUY" \
            else await self.exchange.limit_sell(symbol, lim_qty, entry_price)
        lim_oid = lim_order.order_id or ""
        log.info("Frontrun-split: limit leg %s qty=%.4f @ %.8f (oid=%s)",
                 "resting" if lim_oid else "failed", lim_qty, entry_price, lim_oid)

        # 3) Create the position for the OPEN (market) portion only.
        from src.domain.models import Position
        pos = Position(
            pair=symbol,
            direction=decision.direction,
            entry_price=mkt_avg,
            quantity=mkt_qty,
            sl_price=decision.sl_price,
            tp_prices=decision.tp_prices,
            entry_order_id=mkt_order.order_id,
            leverage=decision.leverage,
            margin_usdt=mkt_qty * mkt_avg / max(decision.leverage, 1),
            confidence=decision.confidence,
            pending_limit_order_id=lim_oid,
            pending_limit_qty=lim_qty,
        )
        pos_id = self.position_repo.create(pos)

        # 4) Save both orders, stamped to the position.
        mkt_db = self.order_repo.save(
            decision_id=decision_id, exchange=self.exchange.name, symbol=symbol,
            side=side, order_type="MARKET", quantity=mkt_qty, price=mkt_avg,
            client_order_id=client_id,
        )
        self.order_repo.update_status(mkt_db, "FILLED", mkt_order.order_id)
        self.position_repo.stamp_order_position(mkt_db, pos_id)
        if lim_oid:
            lim_db = self.order_repo.save(
                decision_id=decision_id, exchange=self.exchange.name, symbol=symbol,
                side=side, order_type="LIMIT", quantity=lim_qty, price=entry_price,
                client_order_id=self._generate_client_id(decision_id) + "_split",
            )
            self.order_repo.update_status(lim_db, "PENDING", lim_oid)
            self.position_repo.stamp_order_position(lim_db, pos_id)

        # 5) Place SL/TP for the OPEN portion (market leg qty).
        sl_placed = False
        if decision.sl_price:
            sl_side = "SELL" if decision.direction == "LONG" else "BUY"
            sl_err = validate_order(symbol, sl_side, decision.sl_price, mkt_qty, filters or {})
            if sl_err:
                log.warning("Split: Validation gate SKIPPED SL %s @ %s: %s", symbol, decision.sl_price, sl_err)
            else:
                sl_order = await self.exchange.stop_loss(symbol, mkt_qty, decision.sl_price, sl_side)
                if sl_order.order_id:
                    sl_placed = True
                    log.info("Split: SL placed: %s @ %s (conditional)", symbol, decision.sl_price)
                elif sl_order.status == "UNPROTECTED":
                    log.warning("Split: SL NOT placed %s @ %s — monitored by position manager",
                                symbol, decision.sl_price)
                else:
                    log.warning("Split: SL NOT placed %s @ %s — %s", symbol, decision.sl_price, sl_order.error)
        tp_levels = decision.tp_prices[:3]
        tp_qty_base = mkt_qty / len(tp_levels) if len(tp_levels) > 1 else mkt_qty
        for i, tp_price in enumerate(tp_levels):
            tp_side = "SELL" if decision.direction == "LONG" else "BUY"
            tp_err = validate_order(symbol, tp_side, tp_price, tp_qty_base, filters or {})
            if tp_err:
                log.warning("Split: Validation SKIPPED TP%d %s @ %s: %s", i + 1, symbol, tp_price, tp_err)
                continue
            tp_order = await self.exchange.take_profit(symbol, tp_qty_base, tp_price, tp_side)
            if tp_order.order_id:
                log.info("Split: TP%d placed: %s @ %s", i + 1, symbol, tp_price)
            else:
                log.warning("Split: TP%d blocked (%s) — Basic LIMIT fallback @ %s", i + 1, tp_order.error, tp_price)
                if tp_side == "SELL":
                    await self.exchange.limit_sell(symbol, tp_qty_base, tp_price, reduce=True)
                else:
                    await self.exchange.limit_buy(symbol, tp_qty_base, tp_price, reduce=True)
        log.info("Frontrun-split position opened: %s qty=%.4f (market) + %.4f (pending limit @ %.8f)",
                 symbol, mkt_qty, lim_qty, entry_price)

        return ExecutionResult(
            success=True,
            order_id=mkt_order.order_id,
            symbol=symbol,
            side=side,
            filled_quantity=mkt_qty,
            avg_price=mkt_avg,
            status="FILLED",
            error=f"⚡ Frontrun-split entry: {mkt_qty} @ market + {lim_qty} limit @ {entry_price}",
        )

    async def _repair_order(self, decision_id: int, decision: TradeDecision,
                            symbol: str, side: str,
                            error_message: str | None) -> ExecutionResult | None:
        """Deterministic repair of a rejected entry order — NO LLM.

        On a FAILED/REJECTED/EXPIRED entry we re-derive the order parameters
        from the symbol's real exchange filters and the config-driven leverage
        rules, validate them through the same gate every order passes, and
        resubmit exactly once. If the repaired parameters still can't pass
        validation, we return a VALIDATION_SKIP result — we never invent or
        guess parameters the way the old LLM fallback did.

        Returns an ExecutionResult on a successful repair, or None if repair
        was not possible (caller then returns the original failure).
        """
        try:
            filters = await self._get_filters(symbol)
            if not filters:
                log.warning("Repair skipped for %s: no filters available", symbol)
                return None

            # Re-round price + quantity to the symbol's real precision.
            price = decision.entry_price
            if price:
                price, _ = await self.exchange._round_price(symbol, price)
            qty = decision.quantity
            qty, _ = await self.exchange._round_quantity(symbol, qty, price_ref=price)

            # Recompute leverage deterministically (config-driven, no literals):
            # enough to meet the exchange minNotional from the configured margin.
            risk = self.config.get("risk", {})
            port_usdt = risk.get("port_usdt", 1.0)
            max_lev = risk.get("max_leverage", 50)
            increase_pct = risk.get("max_leverage_increase_pct", 10)
            min_notional = filters.get("minNotional") or risk.get("min_notional_usdt", 1.0)
            pos_value = qty * (price or 0)
            raw_lev = (pos_value / port_usdt) if port_usdt > 0 else 1
            lev_cap = _snap_leverage(raw_lev * (1 + increase_pct / 100.0), max_lev)
            new_lev = min(_snap_leverage(raw_lev, max_lev), lev_cap, max_lev)
            if new_lev != decision.leverage:
                try:
                    await self.exchange.set_symbol_leverage(symbol, new_lev)
                except Exception as e:
                    log.debug("Repair: set_symbol_leverage failed: %s", e)

            # Validate before resubmitting — never send an invalid order.
            val_err = validate_order(symbol, side, price, qty, filters)
            if val_err:
                log.warning("Repair for %s still invalid after re-round: %s", symbol, val_err)
                return ExecutionResult(
                    success=False, status="VALIDATION_SKIP",
                    error=f"Repair failed validation: {val_err}",
                    symbol=symbol, side=side,
                )

            log.info("Repair %s %s: qty=%.6f price=%.8f lev=%d (orig error: %s)",
                     symbol, side, qty, price or 0, new_lev, error_message)

            retry = await self.exchange.limit_buy(symbol, qty, price) if side == "BUY" \
                else await self.exchange.limit_sell(symbol, qty, price)

            if retry.order_id and retry.status != "FILLED":
                # Resting on the book — record and return PENDING.
                repair_db_id = self.order_repo.save(
                    decision_id=decision_id, exchange=self.exchange.name,
                    symbol=symbol, side=side, order_type="LIMIT",
                    quantity=qty, price=retry.price, client_order_id=self._generate_client_id(decision_id),
                )
                self.order_repo.update_status(repair_db_id, "PENDING", retry.order_id)
                return ExecutionResult(
                    success=True, order_id=retry.order_id, symbol=symbol, side=side,
                    filled_quantity=0, avg_price=price or 0, status="PENDING",
                    error=f"⏳ Repaired LIMIT resting @ {price} — waiting for price",
                )

            if retry.status == "FILLED":
                from src.domain.models import Position
                pos = Position(
                    pair=symbol, direction=decision.direction,
                    entry_price=retry.avg_price or price or 0,
                    quantity=retry.filled_quantity or qty,
                    sl_price=decision.sl_price, tp_prices=decision.tp_prices,
                    entry_order_id=retry.order_id,
                    leverage=decision.leverage,
                    margin_usdt=qty * (price or 0) / max(decision.leverage, 1),
                    confidence=decision.confidence,
                )
                self.position_repo.create(pos)
                # Divide TP quantity across levels
                tp_levels = decision.tp_prices[:3]
                tp_qty = qty / len(tp_levels) if len(tp_levels) > 1 else qty
                for tp_price in tp_levels:
                    tp_side = "SELL" if decision.direction == "LONG" else "BUY"
                    await self.exchange.take_profit(symbol, tp_qty, tp_price, tp_side)
                return ExecutionResult(
                    success=True, order_id=retry.order_id, symbol=symbol, side=side,
                    filled_quantity=retry.filled_quantity or qty,
                    avg_price=retry.avg_price or price or 0, status="FILLED",
                    error=f"✅ Repaired order filled @ {price}",
                )

            # Repair resubmission also failed.
            log.warning("Repair resubmission failed for %s: %s", symbol, retry.error)
            return None

        except Exception as e:
            log.warning("Repair raised: %s", e)
            return None

    async def _close_position(self, decision_id: int,
                              decision: TradeDecision) -> ExecutionResult:
        """Close an open position."""
        symbol = decision.pair.replace("#", "").replace("$", "").upper()
        if not symbol.endswith("USDT"):
            symbol += "USDT"

        position = self.position_repo.get_open_by_pair(symbol)
        if not position:
            return ExecutionResult(success=False, status="NOT_FOUND",
                                   error=f"No open position for {symbol}")

        side = "SELL" if position.direction == "LONG" else "BUY"

        # Always LIMIT close — fetch current price for the LIMIT
        try:
            close_price = await self.exchange.get_mark_price(symbol)
        except Exception:
            close_price = None
        if not close_price or close_price <= 0:
            return ExecutionResult(
                success=False, status="FAILED",
                error=f"Cannot determine close price for {symbol}",
            )

        order = await self.exchange.limit_sell(symbol, position.quantity, close_price, reduce=True) if side == "SELL" \
            else await self.exchange.limit_buy(symbol, position.quantity, close_price, reduce=True)

        # Wait for close fill (up to 30s)
        if order.order_id and order.status != "FILLED":
            import asyncio as _aio
            for _ in range(15):
                await _aio.sleep(2)
                try:
                    check = await self.exchange.get_order(symbol, order.order_id)
                    if check.status == "FILLED":
                        order = check
                        break
                    if check.status in ("CANCELED", "EXPIRED", "REJECTED"):
                        return ExecutionResult(
                            success=False, status=check.status,
                            error=f"Close order {check.status}",
                        )
                except Exception:
                    pass
            else:
                try:
                    await self.exchange.cancel_order(symbol, order.order_id)
                except Exception:
                    pass
                return ExecutionResult(
                    success=False, status="TIMEOUT",
                    error=f"Close LIMIT not filled within 30s for {symbol}",
                )

        # Calculate P&L
        entry_cost = position.entry_price * position.quantity
        exit_value = (order.avg_price or 0) * position.quantity
        pnl = (exit_value - entry_cost) if position.direction == "LONG" else (entry_cost - exit_value)

        self.position_repo.close_position(
            position.id, exit_price=order.avg_price or 0,
            pnl=pnl, reason=decision.reason, closed_by="TRIGGER",
        )

        log.info("Position closed: %s %s PnL=%.2f", position.direction, symbol, pnl)

        return ExecutionResult(
            success=True,
            order_id=order.order_id,
            symbol=symbol,
            side=side,
            filled_quantity=position.quantity,
            avg_price=order.avg_price or 0,
            status="CLOSED",
        )

    async def _modify_position(self, decision_id: int,
                               decision: TradeDecision) -> ExecutionResult:
        """Modify an existing position — cancel old SL/TP, place new ones."""
        symbol = decision.pair.replace("#", "").replace("$", "").upper()
        if not symbol.endswith("USDT"):
            symbol += "USDT"

        position = self.position_repo.get_open_by_pair(symbol)
        if not position:
            return ExecutionResult(
                success=False, status="NOT_FOUND",
                error=f"No open position for {symbol} to modify",
            )

        log.info("Modifying %s %s: cancel old SL/TP → place new", position.direction, symbol)

        # ── FIX: save old protection BEFORE cancelling so we can restore if needed ──
        old_sl = position.sl_price
        old_tp = position.tp_prices or []

        # Cancel existing SL/TP orders
        cancelled = await self.exchange.cancel_all_orders(symbol)
        log.info("Cancelled %d existing orders for %s", cancelled, symbol)

        # Place new SL order if specified
        sl_placed = False
        if decision.sl_price and decision.sl_price > 0:
            sl_side = "SELL" if position.direction == "LONG" else "BUY"
            sl_order = await self.exchange.stop_loss(
                symbol, position.quantity, decision.sl_price, sl_side
            )
            if sl_order.order_id:
                sl_placed = True
                log.info("New SL placed: %s @ %s", symbol, decision.sl_price)
            elif sl_order.status == "UNPROTECTED":
                # Binance rejected conditional order (-4120). The position manager's
                # price-monitor will enforce the new SL price. The DB is updated below
                # with the new SL so the monitor uses the correct level.
                log.warning("New SL monitored by position manager: %s @ %s", symbol, decision.sl_price)
            else:
                log.warning("New SL NOT placed for %s @ %s (%s)", symbol, decision.sl_price, sl_order.error)

        # Place new TP orders if specified — divide quantity across levels
        tp_placed = 0
        tp_levels = decision.tp_prices[:3]
        tp_qty_base = position.quantity / len(tp_levels) if len(tp_levels) > 1 else position.quantity
        for i, tp_price in enumerate(tp_levels):
            if tp_price <= 0:
                continue
            tp_side = "SELL" if position.direction == "LONG" else "BUY"
            tp_order = await self.exchange.take_profit(symbol, tp_qty_base, tp_price, tp_side)
            if tp_order.order_id:
                tp_placed += 1
                log.info("New TP%d placed: %s @ %s", i + 1, symbol, tp_price)
            else:
                fb = await self.exchange.limit_sell(symbol, tp_qty_base, tp_price, reduce=True) if tp_side == "SELL" \
                    else await self.exchange.limit_buy(symbol, tp_qty_base, tp_price, reduce=True)
                if fb.order_id:
                    tp_placed += 1
                    log.info("New TP%d placed (Basic LIMIT fallback): %s @ %s", i + 1, symbol, tp_price)
                else:
                    # Both TAKE_PROFIT and LIMIT fallback failed — position is orphaned.
                    # Try to restore the OLD TP if we had one.
                    log.warning("New TP%d ALL failed for %s — trying to restore old TP", i + 1, symbol)
                    if i < len(old_tp) and old_tp[i] and old_tp[i] > 0:
                        try:
                            restore = await self.exchange.limit_sell(
                                symbol, tp_qty_base, old_tp[i], reduce=True
                            ) if tp_side == "SELL" else await self.exchange.limit_buy(
                                symbol, tp_qty_base, old_tp[i], reduce=True
                            )
                            if restore.order_id:
                                tp_placed += 1
                                log.info("Old TP%d restored: %s @ %s", i + 1, symbol, old_tp[i])
                        except Exception as re:
                            log.warning("Failed to restore old TP%d: %s", i + 1, re)

        # Update position SL/TP in database
        self.position_repo.update_sl_tp(
            position.id,
            sl_price=decision.sl_price,
            tp_prices=decision.tp_prices,
        )

        pnl_after = decision.sl_price or position.sl_price or 0
        log.info("Position modified: %s %s SL→%.6f TP→%s",
                 position.direction, symbol, pnl_after, decision.tp_prices)

        return ExecutionResult(
            success=True,
            symbol=symbol,
            status="MODIFIED",
            error=(
                f"SL placed={'✅' if sl_placed else '❌'}, "
                f"TP placed={tp_placed}/{len(decision.tp_prices) if decision.tp_prices else 0}"
            ),
        )
