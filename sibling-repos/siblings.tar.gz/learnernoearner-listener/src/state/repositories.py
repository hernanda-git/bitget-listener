"""Repository layer — business logic never touches SQL directly."""

from __future__ import annotations

import hashlib
import json
import logging
import sqlite3
from datetime import datetime, timezone
from typing import Any

from src.domain.models import (
    ConfigSnapshot,
    LLMInteraction,
    PendingSignal,
    Position,
    PositionEvent,
    TradeDecision,
    TradeLogEntry,
    TradeSignal,
)
from src.state.database import get_connection, json_dumps, json_loads

log = logging.getLogger("state.repositories")

# ═════════════════════════════════════════════════════════════════════════════
# Signal Repository
# ═════════════════════════════════════════════════════════════════════════════


class SignalRepository:
    def __init__(self, conn: sqlite3.Connection | None = None):
        self.conn = conn or get_connection()

    def save(self, signal: TradeSignal) -> int:
        self.conn.execute(
            """INSERT OR IGNORE INTO signals
               (message_id, channel, raw_text, pair, direction, entry_price, sl_price, tp_prices)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                signal.message_id,
                signal.channel,
                signal.raw_text,
                signal.pair,
                signal.direction,
                signal.entry_price,
                signal.sl_price,
                json_dumps(signal.tp_prices),
            ),
        )
        self.conn.commit()
        cursor = self.conn.execute("SELECT id FROM signals WHERE message_id = ?", (signal.message_id,))
        row = cursor.fetchone()
        return row["id"] if row else 0

    def get_by_id(self, signal_id: int) -> dict | None:
        cursor = self.conn.execute("SELECT * FROM signals WHERE id = ?", (signal_id,))
        row = cursor.fetchone()
        return dict(row) if row else None

    def get_by_message_id(self, message_id: int) -> dict | None:
        cursor = self.conn.execute("SELECT * FROM signals WHERE message_id = ?", (message_id,))
        row = cursor.fetchone()
        return dict(row) if row else None

    def is_processed(self, message_id: int, raw_text: str) -> bool:
        """Check if signal has already been processed (idempotency)."""
        h = hashlib.sha256(raw_text.encode()).hexdigest()
        cursor = self.conn.execute(
            "SELECT 1 FROM processed_signals WHERE message_id = ? AND signal_hash = ?",
            (message_id, h),
        )
        return cursor.fetchone() is not None

    def mark_processed(self, message_id: int, raw_text: str) -> None:
        h = hashlib.sha256(raw_text.encode()).hexdigest()
        self.conn.execute(
            "INSERT OR IGNORE INTO processed_signals (message_id, signal_hash) VALUES (?, ?)",
            (message_id, h),
        )
        self.conn.commit()

    def claim(self, message_id: int, raw_text: str = "", window_seconds: int = 300) -> bool:
        """Atomically reserve a message_id at the start of processing.

        Returns ``True`` if THIS call is the first/owner of the message (so it
        should proceed), ``False`` if the message was already claimed or is
        already in-flight (so the caller must skip it to avoid duplicate work
        and duplicate Telegram notifications).

        Two duplicate-delivery patterns are caught:

          1. **Same message_id** — a channel post immediately followed by an
             edit event on the *same* id (Telegram often emits both). The
             ``message_id`` PK makes the second insert a no-op.

          2. **Same content, different id** — the channel emits a new message_id
             (edit/forward/republish) carrying the *identical* text within a
             short window. These are near-simultaneous (seconds), so a time
             window (default 5 min) reliably collapses them while still letting
             legitimately identical text recur much later (e.g. a daily
             greeting) be processed normally.

        The method is await-free, so under asyncio's single-threaded event loop
        it runs to completion without yielding — making it atomic with respect
        to concurrent event handlers and reconnect replays.
        """
        h = hashlib.sha256(raw_text.encode()).hexdigest()

        # Pattern 1 — same message_id already claimed.
        cur = self.conn.execute(
            "SELECT 1 FROM processed_signals WHERE message_id = ?", (message_id,)
        )
        if cur.fetchone():
            return False

        # Pattern 2 — identical content delivered from a different id recently.
        cur = self.conn.execute(
            "SELECT 1 FROM processed_signals "
            "WHERE signal_hash = ? AND processed_at >= datetime('now', ?)",
            (h, f"-{window_seconds} seconds"),
        )
        if cur.fetchone():
            return False

        self.conn.execute(
            "INSERT OR IGNORE INTO processed_signals (message_id, signal_hash) VALUES (?, ?)",
            (message_id, h),
        )
        self.conn.commit()
        return True


# ═════════════════════════════════════════════════════════════════════════════
# Decision Repository
# ═════════════════════════════════════════════════════════════════════════════


class DecisionRepository:
    def __init__(self, conn: sqlite3.Connection | None = None):
        self.conn = conn or get_connection()

    def save(self, signal_id: int, decision: TradeDecision) -> int:
        self.conn.execute(
            """INSERT INTO decisions (signal_id, action, pair, direction, quantity, confidence, reason)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (
                signal_id,
                decision.action,
                decision.pair,
                decision.direction,
                decision.quantity,
                decision.confidence,
                decision.reason,
            ),
        )
        self.conn.commit()
        return self.conn.execute("SELECT last_insert_rowid()").fetchone()[0]


    def get_by_id(self, decision_id: int) -> dict | None:
        """Fetch a stored decision by its primary key.

        Used by the position manager to reconcile a resting PENDING LIMIT
        entry that filled later — the SL/TP/direction it needs to build
        the position row live in the original decision, which is the only
        durable record of them once the synchronous entry path has returned.
        """
        cur = self.conn.execute("SELECT * FROM decisions WHERE id = ?", (decision_id,))
        row = cur.fetchone()
        return dict(row) if row else None

    def update_quantity(self, decision_id: int, quantity: float,
                        leverage: int) -> None:
        """Persist the Gate2-clamped quantity/leverage.

        The orchestrator saves the decision BEFORE Gate2 clamps the real
        size, so the stored ``quantity`` would otherwise stay 0.0. This
        corrects the persisted row in place (no duplicate), so analytics /
        daily_stats see the true traded size. Idempotent.
        """
        self.conn.execute(
            "UPDATE decisions SET quantity = ?, leverage = ? WHERE id = ?",
            (quantity, leverage, decision_id),
        )
        self.conn.commit()


# ═══════════════════════════════════════════════════════════════
# Order Repository
# ═════════════════════════════════════════════════════════════════════════════


class OrderRepository:
    def __init__(self, conn: sqlite3.Connection | None = None):
        self.conn = conn or get_connection()

    def save(self, decision_id: int, exchange: str, symbol: str, side: str,
             order_type: str, quantity: float, price: float | None = None,
             client_order_id: str = "") -> int:
        self.conn.execute(
            """INSERT INTO orders (decision_id, client_order_id, exchange, symbol, side, order_type, quantity, price)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (decision_id, client_order_id, exchange, symbol, side, order_type, quantity, price),
        )
        self.conn.commit()
        return self.conn.execute("SELECT last_insert_rowid()").fetchone()[0]

    def update_status(self, order_id: int, status: str, exchange_order_id: str = "") -> None:
        if exchange_order_id:
            self.conn.execute(
                "UPDATE orders SET status = ?, exchange_order_id = ? WHERE id = ?",
                (status, exchange_order_id, order_id),
            )
        else:
            self.conn.execute("UPDATE orders SET status = ? WHERE id = ?", (status, order_id))
        self.conn.commit()

    def get_active_for_decision(self, decision_id: int, symbol: str, side: str) -> dict | None:
        """Return the most recent active entry order for a (decision, symbol, side).

        Active = not yet terminal (PENDING / NEW / FILLED). A FILLED entry means
        the position is open, so re-entry is still blocked until the position is
        closed (status moves out of this set). Returns None if no active order —
        i.e. it's safe to place a new entry.

        Used by OrderService to make entry idempotent: the same decision can
        never produce two resting LIMIT orders.
        """
        cur = self.conn.execute(
            "SELECT * FROM orders WHERE decision_id=? AND symbol=? AND side=? "
            "AND status IN ('PENDING','NEW','FILLED') ORDER BY id DESC LIMIT 1",
            (decision_id, symbol, side),
        )
        row = cur.fetchone()
        return dict(row) if row else None


# ═════════════════════════════════════════════════════════════════════════════
# Position Repository
# ═════════════════════════════════════════════════════════════════════════════


class PositionRepository:
    def __init__(self, conn: sqlite3.Connection | None = None):
        self.conn = conn or get_connection()

    def create(self, position: Position) -> int:
        # Persist entry_time explicitly as a tz-aware UTC ISO string. Relying on
        # the column DEFAULT CURRENT_TIMESTAMP stores a NAIVE local string, which
        # Python 3.11's datetime.fromisoformat parses as tz-naive — and the
        # monitor's age check then treats it as "just now" (age ~0), so the
        # 30-min auto-close / time-exit would never fire. Always store UTC.
        entry_time = position.entry_time
        # entry_time may be a datetime or an already-serialized ISO string.
        if isinstance(entry_time, str):
            try:
                entry_time = datetime.fromisoformat(entry_time)
            except ValueError:
                entry_time = datetime.now(timezone.utc)
        if entry_time.tzinfo is None:
            entry_time = entry_time.replace(tzinfo=timezone.utc)

        # Ensure DB has the new columns (leverage, margin_usdt, confidence,
        # pending_limit_order_id, pending_limit_qty) for older databases.
        self._ensure_position_columns()

        self.conn.execute(
            """INSERT INTO positions (pair, direction, entry_price, quantity, sl_price, tp_prices, entry_order_id, entry_time, leverage, margin_usdt, confidence, pending_limit_order_id, pending_limit_qty)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                position.pair,
                position.direction,
                position.entry_price,
                position.quantity,
                position.sl_price,
                json_dumps(position.tp_prices),
                position.entry_order_id,
                entry_time.isoformat(),
                position.leverage,
                position.margin_usdt,
                position.confidence,
                position.pending_limit_order_id,
                position.pending_limit_qty,
            ),
        )
        self.conn.commit()
        return self.conn.execute("SELECT last_insert_rowid()").fetchone()[0]

    def _ensure_position_columns(self) -> None:
        """Add leverage, margin_usdt, confidence columns if missing (migration)."""
        try:
            self.conn.execute("ALTER TABLE positions ADD COLUMN leverage INTEGER DEFAULT 1")
        except Exception:
            pass  # column already exists
        try:
            self.conn.execute("ALTER TABLE positions ADD COLUMN margin_usdt REAL DEFAULT 0.0")
        except Exception:
            pass
        try:
            self.conn.execute("ALTER TABLE positions ADD COLUMN confidence REAL DEFAULT 0.0")
        except Exception:
            pass
        try:
            self.conn.execute("ALTER TABLE positions ADD COLUMN pending_limit_order_id TEXT DEFAULT ''")
        except Exception:
            pass
        try:
            self.conn.execute("ALTER TABLE positions ADD COLUMN pending_limit_qty REAL DEFAULT 0.0")
        except Exception:
            pass

    def get_open_positions(self) -> list[Position]:
        cursor = self.conn.execute(
            "SELECT * FROM positions WHERE status = 'OPEN' ORDER BY entry_time DESC"
        )
        return [self._row_to_position(row) for row in cursor.fetchall()]

    def get_open_by_pair(self, pair: str) -> Position | None:
        cursor = self.conn.execute(
            "SELECT * FROM positions WHERE status = 'OPEN' AND pair = ? ORDER BY entry_time DESC LIMIT 1",
            (pair,),
        )
        row = cursor.fetchone()
        return self._row_to_position(row) if row else None

    def close_position(self, position_id: int, exit_price: float, pnl: float,
                       reason: str = "", closed_by: str = "MANUAL") -> None:
        self.conn.execute(
            """UPDATE positions SET status = 'CLOSED', exit_price = ?, pnl = ?,
               exit_time = CURRENT_TIMESTAMP, reason = ?, closed_by = ?
               WHERE id = ?""",
            (exit_price, pnl, reason, closed_by, position_id),
        )
        self.conn.commit()

    def stamp_order_position(self, order_id: int, position_id: int) -> None:
        self.conn.execute(
            "UPDATE orders SET position_id = ? WHERE id = ?", (position_id, order_id)
        )
        self.conn.commit()

    def clear_pending_limit_leg(self, position_id: int) -> None:
        """Clear the frontrun-split pending limit leg for a position.

        Called when a management command (breakeven / tp1) cancels the resting
        75% limit and converts the trade to a single running open portion.
        """
        self._ensure_position_columns()
        self.conn.execute(
            "UPDATE positions SET pending_limit_order_id = '', pending_limit_qty = 0.0 WHERE id = ?",
            (position_id,),
        )
        self.conn.commit()

    def update_entry_price(self, position_id: int, entry_price: float) -> None:
        """Update a position's entry price (used when a split leg fills and the
        blended entry must be recomputed)."""
        self.conn.execute(
            "UPDATE positions SET entry_price = ? WHERE id = ?", (entry_price, position_id)
        )
        self.conn.commit()

    def finalize_position_metrics(self, position_id: int, exit_type: str = "",
                                  liquidation_price: float | None = None,
                                  decision_latency_ms: int = 0,
                                  execution_latency_ms: int = 0) -> dict:
        """Roll up fees + compute fee-adjusted PnL, R-multiple, risk for a closed
        position. Writes to position_metrics. Returns the computed metrics dict.

        Safe to call once per close. Reads the position row + its executions.
        """
        row = self.conn.execute(
            "SELECT pair, direction, entry_price, quantity, sl_price, exit_price "
            "FROM positions WHERE id = ?", (position_id,)
        ).fetchone()
        if not row:
            return {}
        pair, direction, entry_price, qty, sl_price, exit_price = row
        entry_price = entry_price or 0.0
        qty = qty or 0.0
        exit_price = exit_price or 0.0

        # Roll up fees stamped to this position's orders.
        fee_row = self.conn.execute(
            "SELECT COALESCE(SUM(fee),0.0) FROM executions WHERE position_id = ?",
            (position_id,),
        ).fetchone()
        total_fee = fee_row[0] if fee_row else 0.0
        # If no executions stamped yet (legacy/edge), fall back to a fee_model estimate.
        notional = entry_price * qty
        if total_fee == 0.0 and notional > 0:
            # fee_model row 1 holds maker/taker; assume taker/taker (worst case) 7bps.
            fm = self.conn.execute(
                "SELECT maker_fee, taker_fee FROM fee_model LIMIT 1"
            ).fetchone()
            if fm:
                total_fee = notional * (fm[0] + fm[1])

        gross = (exit_price - entry_price) * qty if direction == "LONG" \
            else (entry_price - exit_price) * qty
        net = gross - total_fee
        sl_distance = 0.0
        if sl_price and entry_price:
            sl_distance = abs(entry_price - sl_price) / entry_price
        risk_usdt = notional * sl_distance
        r_multiple = (net / risk_usdt) if risk_usdt > 0 else 0.0

        metrics = {
            "open_fee": total_fee / 2.0,
            "close_fee": total_fee / 2.0,
            "gross_pnl": gross,
            "net_pnl": net,
            "notional_usdt": notional,
            "sl_distance_pct": sl_distance,
            "r_multiple": r_multiple,
            "risk_usdt": risk_usdt,
            "exit_type": exit_type,
            "liquidation_price": liquidation_price,
            "decision_latency_ms": decision_latency_ms,
            "execution_latency_ms": execution_latency_ms,
        }
        cols = ["position_id"] + list(metrics.keys())
        placeholders = ["?"] * len(cols)
        self.conn.execute(
            f"INSERT OR REPLACE INTO position_metrics ({', '.join(cols)}) "
            f"VALUES ({', '.join(placeholders)})",
            [position_id] + list(metrics.values()),
        )
        self.conn.commit()
        return metrics

    def update_sl_tp(self, position_id: int, sl_price: float | None = None,
                     tp_prices: list[float] | None = None) -> None:
        """Update SL and/or TP for an open position."""
        if sl_price is not None:
            self.conn.execute(
                "UPDATE positions SET sl_price = ? WHERE id = ?",
                (sl_price, position_id),
            )
        if tp_prices is not None:
            self.conn.execute(
                "UPDATE positions SET tp_prices = ? WHERE id = ?",
                (json_dumps(tp_prices), position_id),
            )
        self.conn.commit()

    def update_quantity(self, position_id: int, quantity: float) -> None:
        """Update the remaining quantity of an open position (e.g. after partial close)."""
        self.conn.execute(
            "UPDATE positions SET quantity = ? WHERE id = ?",
            (quantity, position_id),
        )
        self.conn.commit()

    def get_daily_pnl(self) -> float:
        """Sum P&L of positions closed today."""
        cursor = self.conn.execute(
            "SELECT COALESCE(SUM(pnl), 0) FROM positions WHERE date(exit_time) = date('now')"
        )
        return cursor.fetchone()[0]

    def get_open_count(self) -> int:
        cursor = self.conn.execute("SELECT COUNT(*) FROM positions WHERE status = 'OPEN'")
        return cursor.fetchone()[0]

    def get_last_closed_by_pair(self, pair: str) -> Position | None:
        """Get the most recently CLOSED position for a pair.

        Used by Gate1 cooldown to check time elapsed since last trade
        (even when no position is currently OPEN).
        """
        cursor = self.conn.execute(
            "SELECT * FROM positions WHERE status = 'CLOSED' AND pair = ? "
            "ORDER BY exit_time DESC LIMIT 1",
            (pair,),
        )
        row = cursor.fetchone()
        return self._row_to_position(row) if row else None

    def get_total_notional_usdt(self) -> float:
        """Sum the notional value (entry_price × quantity) of all open positions.

        Used by SafetyGate2 to enforce a portfolio-level notional cap.
        """
        cursor = self.conn.execute(
            "SELECT COALESCE(SUM(entry_price * quantity), 0) FROM positions WHERE status = 'OPEN'"
        )
        return cursor.fetchone()[0]

    def _row_to_position(self, row: sqlite3.Row) -> Position:
        d = dict(row)
        tp_raw = d.pop("tp_prices", None)
        # Only pass fields the Position dataclass accepts
        valid = {f.name for f in Position.__dataclass_fields__.values()}
        filtered = {k: v for k, v in d.items() if k in valid and v is not None}
        return Position(
            tp_prices=json_loads(tp_raw) or [],
            **filtered,
        )


# ═════════════════════════════════════════════════════════════════════════════
# Event Repository
# ═════════════════════════════════════════════════════════════════════════════


class EventRepository:
    def __init__(self, conn: sqlite3.Connection | None = None):
        self.conn = conn or get_connection()

    def save_event(self, event_type: str, payload: dict) -> None:
        self.conn.execute(
            "INSERT INTO events (event_type, payload) VALUES (?, ?)",
            (event_type, json_dumps(payload)),
        )
        self.conn.commit()


# ═════════════════════════════════════════════════════════════════════════════
# Pending Signal Repository
# ═════════════════════════════════════════════════════════════════════════════


class PendingSignalRepository:
    def __init__(self, conn: sqlite3.Connection | None = None):
        self.conn = conn or get_connection()

    def save(self, signal: PendingSignal) -> int:
        self.conn.execute(
            """INSERT INTO pending_signals
               (pair, direction, condition_type, trigger_price, timeframe, raw_text, message_id)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (signal.pair, signal.direction, signal.condition_type,
             signal.trigger_price, signal.timeframe, signal.raw_text, signal.message_id),
        )
        self.conn.commit()
        return self.conn.execute("SELECT last_insert_rowid()").fetchone()[0]

    def get_pending(self) -> list[PendingSignal]:
        cursor = self.conn.execute(
            "SELECT * FROM pending_signals WHERE status = 'PENDING' ORDER BY created_at ASC"
        )
        return [self._row_to_signal(row) for row in cursor.fetchall()]

    def mark_triggered(self, signal_id: int) -> None:
        self.conn.execute(
            "UPDATE pending_signals SET status = 'TRIGGERED', triggered_at = CURRENT_TIMESTAMP WHERE id = ?",
            (signal_id,),
        )
        self.conn.commit()

    def mark_expired(self, signal_id: int) -> None:
        self.conn.execute(
            "UPDATE pending_signals SET status = 'EXPIRED' WHERE id = ?",
            (signal_id,),
        )
        self.conn.commit()

    def cancel(self, signal_id: int) -> bool:
        """Cancel a pending signal. Returns True if it was pending."""
        cur = self.conn.execute(
            "UPDATE pending_signals SET status = 'CANCELLED' WHERE id = ? AND status = 'PENDING'",
            (signal_id,),
        )
        self.conn.commit()
        return cur.rowcount > 0

    def cancel_all(self) -> int:
        """Cancel all pending signals. Returns count cancelled."""
        cur = self.conn.execute(
            "UPDATE pending_signals SET status = 'CANCELLED' WHERE status = 'PENDING'"
        )
        self.conn.commit()
        return cur.rowcount

    def _row_to_signal(self, row: sqlite3.Row) -> PendingSignal:
        return PendingSignal(**dict(row))


# ═════════════════════════════════════════════════════════════════════════════
# Pending Management Intent Repository
# ═════════════════════════════════════════════════════════════════════════════

class PendingMgmtRepository:
    """Stores management commands (sl to entry / tpN / full) that arrived
    before their target position existed, so they can be replayed once the
    position becomes active (late LIMIT fill / manual open)."""

    def __init__(self, conn: sqlite3.Connection | None = None):
        self.conn = conn or get_connection()

    def save(self, intent: "PendingMgmt") -> int:
        from src.domain.models import PendingMgmt
        cur = self.conn.execute(
            """INSERT INTO pending_mgmt
               (pair, action, sl_price, tp_index, tp_price, raw_text, message_id)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (intent.pair, intent.action, intent.sl_price, intent.tp_index,
             intent.tp_price, intent.raw_text, intent.message_id),
        )
        self.conn.commit()
        return cur.lastrowid

    def get_pending(self) -> list:
        from src.domain.models import PendingMgmt
        cur = self.conn.execute(
            "SELECT * FROM pending_mgmt WHERE status = 'PENDING' "
            "ORDER BY created_at ASC"
        )
        return [PendingMgmt(**dict(r)) for r in cur.fetchall()]

    def get_pending_for_pair(self, pair: str) -> list:
        from src.domain.models import PendingMgmt
        s = pair.replace("#", "").replace("$", "").upper()
        if not s.endswith("USDT"):
            s += "USDT"
        cur = self.conn.execute(
            "SELECT * FROM pending_mgmt WHERE status = 'PENDING' AND pair = ? "
            "ORDER BY created_at ASC", (s,)
        )
        return [PendingMgmt(**dict(r)) for r in cur.fetchall()]

    def mark_applied(self, intent_id: int) -> None:
        self.conn.execute(
            "UPDATE pending_mgmt SET status = 'APPLIED', "
            "applied_at = CURRENT_TIMESTAMP WHERE id = ?", (intent_id,)
        )
        self.conn.commit()

    def expire(self, intent_id: int) -> None:
        self.conn.execute(
            "UPDATE pending_mgmt SET status = 'EXPIRED' WHERE id = ?", (intent_id,)
        )
        self.conn.commit()

    def cancel(self, intent_id: int) -> bool:
        cur = self.conn.execute(
            "UPDATE pending_mgmt SET status = 'CANCELLED' "
            "WHERE id = ? AND status = 'PENDING'", (intent_id,)
        )
        self.conn.commit()
        return cur.rowcount > 0

    def expire_older_than(self, minutes: int) -> int:
        """Expire PENDING intents older than ``minutes`` (zombie guard)."""
        cur = self.conn.execute(
            "UPDATE pending_mgmt SET status = 'EXPIRED' "
            "WHERE status = 'PENDING' AND "
            "datetime('now') > datetime(created_at, ?)",
            (f"+{minutes} minutes",),
        )
        self.conn.commit()
        return cur.rowcount



# LLM Interaction Repository
# ═════════════════════════════════════════════════════════════════════════════


class LLMInteractionRepository:
    def __init__(self, conn: sqlite3.Connection | None = None):
        self.conn = conn or get_connection()

    def save(self, interaction: LLMInteraction) -> int:
        self.conn.execute(
            """INSERT INTO llm_interactions
               (decision_id, model, system_prompt, user_prompt, raw_response,
                parsed_decision_json, prompt_tokens, completion_tokens,
                latency_ms, success, error)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                interaction.decision_id,
                interaction.model,
                interaction.system_prompt,
                interaction.user_prompt,
                interaction.raw_response,
                interaction.parsed_decision_json,
                interaction.prompt_tokens,
                interaction.completion_tokens,
                interaction.latency_ms,
                1 if interaction.success else 0,
                interaction.error,
            ),
        )
        self.conn.commit()
        return self.conn.execute("SELECT last_insert_rowid()").fetchone()[0]

    def get_by_decision_id(self, decision_id: int) -> list[LLMInteraction]:
        cursor = self.conn.execute(
            "SELECT * FROM llm_interactions WHERE decision_id = ? ORDER BY created_at",
            (decision_id,),
        )
        return [LLMInteraction(**dict(r)) for r in cursor.fetchall()]

    def get_all(self, limit: int = 50) -> list[LLMInteraction]:
        cursor = self.conn.execute(
            "SELECT * FROM llm_interactions ORDER BY created_at DESC LIMIT ?",
            (limit,),
        )
        return [LLMInteraction(**dict(r)) for r in cursor.fetchall()]


# ═════════════════════════════════════════════════════════════════════════════
# Trade Log Repository
# ═════════════════════════════════════════════════════════════════════════════


class TradeLogRepository:
    def __init__(self, conn: sqlite3.Connection | None = None):
        self.conn = conn or get_connection()

    def log(self, correlation_id: str, level: str, module: str,
            message: str, metadata: dict | None = None) -> int:
        self.conn.execute(
            """INSERT INTO trade_logs (correlation_id, level, module, message, metadata_json)
               VALUES (?, ?, ?, ?, ?)""",
            (correlation_id, level, module, message, json_dumps(metadata or {})),
        )
        self.conn.commit()
        return self.conn.execute("SELECT last_insert_rowid()").fetchone()[0]

    def get_by_correlation(self, correlation_id: str) -> list[dict]:
        cursor = self.conn.execute(
            "SELECT * FROM trade_logs WHERE correlation_id = ? ORDER BY created_at",
            (correlation_id,),
        )
        return [dict(r) for r in cursor.fetchall()]

    def get_by_level(self, level: str, limit: int = 50) -> list[dict]:
        cursor = self.conn.execute(
            "SELECT * FROM trade_logs WHERE level = ? ORDER BY created_at DESC LIMIT ?",
            (level, limit),
        )
        return [dict(r) for r in cursor.fetchall()]

    def get_by_module(self, module: str, limit: int = 50) -> list[dict]:
        cursor = self.conn.execute(
            "SELECT * FROM trade_logs WHERE module = ? ORDER BY created_at DESC LIMIT ?",
            (module, limit),
        )
        return [dict(r) for r in cursor.fetchall()]

    def get_recent(self, limit: int = 50) -> list[dict]:
        cursor = self.conn.execute(
            "SELECT * FROM trade_logs ORDER BY created_at DESC LIMIT ?",
            (limit,),
        )
        return [dict(r) for r in cursor.fetchall()]


# ═════════════════════════════════════════════════════════════════════════════
# Position Event Repository
# ═════════════════════════════════════════════════════════════════════════════


class PositionEventRepository:
    def __init__(self, conn: sqlite3.Connection | None = None):
        self.conn = conn or get_connection()

    def save_event(self, position_id: int, event_type: str,
                   details: str = "", metadata: dict | None = None) -> int:
        self.conn.execute(
            """INSERT INTO position_events (position_id, event_type, details, metadata_json)
               VALUES (?, ?, ?, ?)""",
            (position_id, event_type, details, json_dumps(metadata or {})),
        )
        self.conn.commit()
        return self.conn.execute("SELECT last_insert_rowid()").fetchone()[0]

    def get_by_position(self, position_id: int) -> list[dict]:
        cursor = self.conn.execute(
            "SELECT * FROM position_events WHERE position_id = ? ORDER BY created_at",
            (position_id,),
        )
        return [dict(r) for r in cursor.fetchall()]

    def get_by_type(self, event_type: str, limit: int = 50) -> list[dict]:
        cursor = self.conn.execute(
            "SELECT * FROM position_events WHERE event_type = ? ORDER BY created_at DESC LIMIT ?",
            (event_type, limit),
        )
        return [dict(r) for r in cursor.fetchall()]


# ═════════════════════════════════════════════════════════════════════════════
# Config Snapshot Repository
# ═════════════════════════════════════════════════════════════════════════════


class ConfigSnapshotRepository:
    def __init__(self, conn: sqlite3.Connection | None = None):
        self.conn = conn or get_connection()

    def save(self, config_hash: str, config_yaml: str,
             app_version: str = "") -> int:
        self.conn.execute(
            """INSERT INTO config_snapshots (config_hash, config_yaml, app_version)
               VALUES (?, ?, ?)""",
            (config_hash, config_yaml, app_version),
        )
        self.conn.commit()
        return self.conn.execute("SELECT last_insert_rowid()").fetchone()[0]

    def get_by_id(self, snap_id: int) -> dict | None:
        cursor = self.conn.execute(
            "SELECT * FROM config_snapshots WHERE id = ?", (snap_id,)
        )
        row = cursor.fetchone()
        return dict(row) if row else None

    def get_all(self, limit: int = 20) -> list[dict]:
        cursor = self.conn.execute(
            "SELECT * FROM config_snapshots ORDER BY created_at DESC LIMIT ?",
            (limit,),
        )
        return [dict(r) for r in cursor.fetchall()]


# ═════════════════════════════════════════════════════════════════════════════
# Evaluation & Monitoring repositories (additive; safe on existing DBs)
# ═════════════════════════════════════════════════════════════════════════════


class EquitySnapshotRepository:
    def __init__(self, conn: sqlite3.Connection | None = None):
        self.conn = conn or get_connection()

    def save(self, balance_usdt: float, available_usdt: float | None = None,
             unrealized_pnl: float = 0.0, open_positions: int = 0,
             source: str = "exchange", note: str = "") -> int:
        self.conn.execute(
            """INSERT INTO equity_snapshots
               (balance_usdt, available_usdt, unrealized_pnl, open_positions, source, note)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (balance_usdt, available_usdt, unrealized_pnl, open_positions, source, note),
        )
        self.conn.commit()
        return self.conn.execute("SELECT last_insert_rowid()").fetchone()[0]

    def latest(self) -> dict | None:
        row = self.conn.execute(
            "SELECT * FROM equity_snapshots ORDER BY ts DESC LIMIT 1"
        ).fetchone()
        return dict(row) if row else None

    def series(self, limit: int = 500) -> list[dict]:
        cur = self.conn.execute(
            "SELECT ts, balance_usdt, unrealized_pnl, open_positions FROM equity_snapshots ORDER BY ts LIMIT ?",
            (limit,),
        )
        return [dict(r) for r in cur.fetchall()]


class PositionMetricsRepository:
    def __init__(self, conn: sqlite3.Connection | None = None):
        self.conn = conn or get_connection()

    def save(self, position_id: int, **fields) -> None:
        cols = ["position_id"] + list(fields.keys())
        placeholders = ["?"] * len(cols)
        vals = [position_id] + list(fields.values())
        self.conn.execute(
            f"INSERT OR REPLACE INTO position_metrics ({', '.join(cols)}) VALUES ({', '.join(placeholders)})",
            vals,
        )
        self.conn.commit()

    def get(self, position_id: int) -> dict | None:
        row = self.conn.execute(
            "SELECT * FROM position_metrics WHERE position_id = ?", (position_id,)
        ).fetchone()
        return dict(row) if row else None


class SignalPopularityRepository:
    def __init__(self, conn: sqlite3.Connection | None = None):
        self.conn = conn or get_connection()

    def save(self, pair: str, signal_id: int | None = None, channel: str = "",
             reaction_lag_ms: int = 0, concurrent_mentions: int = 1,
             pre_signal_vol_z: float = 0.0, post_signal_impact_pct: float = 0.0,
             crowd_density_score: float = 0.0, note: str = "") -> int:
        self.conn.execute(
            """INSERT INTO signal_popularity
               (signal_id, pair, channel, reaction_lag_ms, concurrent_mentions,
                pre_signal_vol_z, post_signal_impact_pct, crowd_density_score, note)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (signal_id, pair, channel, reaction_lag_ms, concurrent_mentions,
             pre_signal_vol_z, post_signal_impact_pct, crowd_density_score, note),
        )
        self.conn.commit()
        return self.conn.execute("SELECT last_insert_rowid()").fetchone()[0]

    def crowd_avg(self, pair: str, since_hours: int = 24) -> float:
        row = self.conn.execute(
            """SELECT COALESCE(AVG(crowd_density_score), 0.0) FROM signal_popularity
               WHERE pair = ? AND detected_at >= datetime('now', ?)""",
            (pair, f"-{since_hours} hours"),
        ).fetchone()
        return row[0] if row else 0.0


class ParamLogRepository:
    def __init__(self, conn: sqlite3.Connection | None = None):
        self.conn = conn or get_connection()

    def log(self, param_name: str, old_value: str = "", new_value: str = "",
            source: str = "manual", reason: str = "", correlation_id: str = "") -> int:
        self.conn.execute(
            """INSERT INTO param_log
               (param_name, old_value, new_value, source, reason, correlation_id)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (param_name, str(old_value), str(new_value), source, reason, correlation_id),
        )
        self.conn.commit()
        return self.conn.execute("SELECT last_insert_rowid()").fetchone()[0]

    def recent(self, limit: int = 50) -> list[dict]:
        cur = self.conn.execute(
            "SELECT ts, param_name, old_value, new_value, source, reason FROM param_log ORDER BY ts DESC LIMIT ?",
            (limit,),
        )
        return [dict(r) for r in cur.fetchall()]


class EvalSnapshotRepository:
    def __init__(self, conn: sqlite3.Connection | None = None):
        self.conn = conn or get_connection()

    def save(self, window: str = "all", regime: str = "", n_trades: int = 0,
             win_rate: float = 0.0, avg_win: float = 0.0, avg_loss: float = 0.0,
             expectancy_usdt: float = 0.0, fee_adjusted_expectancy_usdt: float = 0.0,
             max_drawdown: float = 0.0, sharpe: float = 0.0, note: str = "") -> int:
        self.conn.execute(
            """INSERT INTO eval_snapshots
               (window, regime, n_trades, win_rate, avg_win, avg_loss,
                expectancy_usdt, fee_adjusted_expectancy_usdt, max_drawdown, sharpe, note)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (window, regime, n_trades, win_rate, avg_win, avg_loss,
             expectancy_usdt, fee_adjusted_expectancy_usdt, max_drawdown, sharpe, note),
        )
        self.conn.commit()
        return self.conn.execute("SELECT last_insert_rowid()").fetchone()[0]

    def latest(self, window: str = "all") -> dict | None:
        row = self.conn.execute(
            "SELECT * FROM eval_snapshots WHERE window = ? ORDER BY ts DESC LIMIT 1",
            (window,),
        ).fetchone()
        return dict(row) if row else None


class StrategyPerfRepository:
    def __init__(self, conn: sqlite3.Connection | None = None):
        self.conn = conn or get_connection()

    def upsert(self, pair: str, direction: str, net_pnl: float, fee_adjusted_net: float,
               is_win: bool, r_multiple: float = 0.0) -> None:
        cur = self.conn.execute(
            "SELECT n, wins, losses, net_pnl, fee_adjusted_net, avg_r_multiple FROM strategy_perf WHERE pair = ? AND direction = ?",
            (pair, direction),
        ).fetchone()
        if cur is None:
            self.conn.execute(
                """INSERT INTO strategy_perf
                   (pair, direction, n, wins, losses, net_pnl, fee_adjusted_net, avg_r_multiple, last_trade_ts)
                   VALUES (?, ?, 1, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)""",
                (pair, direction, 1 if is_win else 0, 0 if is_win else 1,
                 net_pnl, fee_adjusted_net, r_multiple),
            )
        else:
            n, wins, losses, old_net, old_fee, old_r = cur
            new_n = n + 1
            new_wins = wins + (1 if is_win else 0)
            new_losses = losses + (0 if is_win else 1)
            new_avg_r = (old_r * n + r_multiple) / new_n
            self.conn.execute(
                """UPDATE strategy_perf SET n=?, wins=?, losses=?, net_pnl=net_pnl+?,
                   fee_adjusted_net=fee_adjusted_net+?, avg_r_multiple=?, last_trade_ts=CURRENT_TIMESTAMP
                   WHERE pair=? AND direction=?""",
                (new_n, new_wins, new_losses, net_pnl, fee_adjusted_net, new_avg_r, pair, direction),
            )
        self.conn.commit()

    def pair_win_rate(self, pair: str, min_n: int = 5) -> dict | None:
        """Recent per-pair win-rate for self-learning feedback.

        Returns {"n", "wins", "losses", "win_rate", "fee_adjusted_net",
        "avg_r_multiple"} or None when fewer than ``min_n`` trades recorded.
        Both directions are combined so a pair's overall edge is captured.
        """
        cur = self.conn.execute(
            "SELECT COALESCE(SUM(n),0), COALESCE(SUM(wins),0), COALESCE(SUM(losses),0), "
            "COALESCE(SUM(fee_adjusted_net),0.0), COALESCE(AVG(avg_r_multiple),0.0) "
            "FROM strategy_perf WHERE pair = ?",
            (pair,),
        ).fetchone()
        if not cur:
            return None
        n, wins, losses, net, avg_r = cur
        if n < min_n:
            return None
        return {
            "n": n, "wins": wins, "losses": losses,
            "win_rate": (wins / n) if n else 0.0,
            "fee_adjusted_net": net, "avg_r_multiple": avg_r,
        }

    def ranking(self, limit: int = 20) -> list[dict]:
        cur = self.conn.execute(
            "SELECT pair, direction, n, wins, losses, net_pnl, fee_adjusted_net, avg_r_multiple FROM strategy_perf ORDER BY fee_adjusted_net DESC LIMIT ?",
            (limit,),
        )
        return [dict(r) for r in cur.fetchall()]


class AttachmentReadRepository:
    """Vision reads of trade-signal chart attachments.

    Covers all non-bias signal shapes: formal_setup, scalp_watch, management,
    pnl_card. BTC regime posts live in btc_bias_reads, never here.
    """

    def __init__(self, conn: sqlite3.Connection | None = None):
        self.conn = conn or get_connection()

    def save(self, source_id: int, message_id: int, channel: str = "", **fields: Any) -> int:
        cols = {
            "source_id": source_id,
            "message_id": message_id,
            "channel": channel,
            "media_type": fields.get("media_type", "photo"),
            "local_path": fields.get("local_path", ""),
            "symbol_posted": fields.get("symbol_posted", ""),
            "symbol_resolved": fields.get("symbol_resolved", ""),
            "has_chart_data": 1 if fields.get("has_chart_data", True) else 0,
            "chart_entry": fields.get("chart_entry"),
            "chart_sl": fields.get("chart_sl"),
            "chart_tp": json_dumps(fields.get("chart_tp") or []),
            "chart_support": json_dumps(fields.get("chart_support") or []),
            "chart_resistance": json_dumps(fields.get("chart_resistance") or []),
            "chart_trend": fields.get("chart_trend", ""),
            "chart_setup_type": fields.get("chart_setup_type", ""),
            "levels_source": fields.get("levels_source", ""),
            "vision_struct": json_dumps(fields.get("vision_struct") or {}),
            "signal_shape": fields.get("signal_shape", "formal_setup"),
            "text_levels": json_dumps(fields.get("text_levels") or []),
        }
        placeholders = ", ".join("?" for _ in cols)
        sql = (
            f"INSERT OR REPLACE INTO attachment_reads ({', '.join(cols)}) "
            f"VALUES ({placeholders})"
        )
        cur = self.conn.execute(sql, tuple(cols.values()))
        self.conn.commit()
        return int(cur.lastrowid or 0)

    def persist_resolution(self, row_id: int, levels: Any) -> None:
        """Persist resolved_* columns for a scalp_watch row.

        Written for EVERY scalp_watch signal, including skipped ones, so the
        confidence threshold can be tuned against a full near-miss audit trail.
        """
        self.conn.execute(
            """UPDATE attachment_reads
               SET resolved_entry_price = ?, resolved_entry_source = ?,
                   resolved_target_price = ?, resolved_sl_price = ?,
                   resolution_confidence = ?
               WHERE id = ?""",
            (levels.entry, levels.entry_source, levels.target,
             levels.stop, levels.confidence, row_id),
        )
        self.conn.commit()

    def get(self, row_id: int) -> dict | None:
        row = self.conn.execute(
            "SELECT * FROM attachment_reads WHERE id = ?", (row_id,)
        ).fetchone()
        return dict(row) if row else None

    def by_source(self, source_id: int) -> list[dict]:
        cur = self.conn.execute(
            "SELECT * FROM attachment_reads WHERE source_id = ? ORDER BY id",
            (source_id,),
        )
        return [dict(r) for r in cur.fetchall()]


class BtcBiasReadRepository:
    """BTC bias / market-regime reads. Separate data class from chart signals."""

    def __init__(self, conn: sqlite3.Connection | None = None):
        self.conn = conn or get_connection()

    def save(self, message_id: int, channel: str = "", **fields: Any) -> int:
        cols = {
            "message_id": message_id,
            "channel": channel,
            "media_type": fields.get("media_type", "photo"),
            "local_path": fields.get("local_path", ""),
            "caption": fields.get("caption", ""),
            "symbol_resolved": fields.get("symbol_resolved", "BTC"),
            "has_chart_data": 1 if fields.get("has_chart_data", True) else 0,
            "chart_trend": fields.get("chart_trend", ""),
            "support": json_dumps(fields.get("support") or []),
            "resistance": json_dumps(fields.get("resistance") or []),
            "range_low": fields.get("range_low"),
            "range_high": fields.get("range_high"),
            "bias_primary": fields.get("bias_primary", ""),
            "bias_secondary": fields.get("bias_secondary", ""),
            "bias_horizon": fields.get("bias_horizon", ""),
            "btc_price_at_post": fields.get("btc_price_at_post"),
            "vision_struct": json_dumps(fields.get("vision_struct") or {}),
        }
        placeholders = ", ".join("?" for _ in cols)
        sql = (
            f"INSERT OR REPLACE INTO btc_bias_reads ({', '.join(cols)}) "
            f"VALUES ({placeholders})"
        )
        cur = self.conn.execute(sql, tuple(cols.values()))
        self.conn.commit()
        return int(cur.lastrowid or 0)

    def latest(self, max_age_hours: int = 24) -> dict | None:
        """Most recent bias read within max_age_hours, or None."""
        row = self.conn.execute(
            f"""SELECT * FROM btc_bias_reads
                WHERE created_at >= datetime('now', '-{int(max_age_hours)} hours')
                ORDER BY created_at DESC, id DESC LIMIT 1"""
        ).fetchone()
        return dict(row) if row else None

    def unscored(self, older_than_days: int = 7) -> list[dict]:
        cur = self.conn.execute(
            f"""SELECT * FROM btc_bias_reads
                WHERE accuracy IS NULL
                  AND created_at < datetime('now', '-{int(older_than_days)} days')
                ORDER BY created_at"""
        )
        return [dict(r) for r in cur.fetchall()]

    def score(self, row_id: int, price_after: float, accuracy: float,
              resolved_direction: str = "") -> None:
        self.conn.execute(
            """UPDATE btc_bias_reads
               SET btc_price_after_n_days = ?, accuracy = ?, resolved_direction = ?
               WHERE id = ?""",
            (price_after, accuracy, resolved_direction, row_id),
        )
        self.conn.commit()

    def hit_rate(self, bias: str) -> tuple[int, float]:
        """(n_scored, hit_rate) for a given bias_primary value."""
        row = self.conn.execute(
            "SELECT COUNT(*) n, AVG(CASE WHEN accuracy > 0 THEN 1.0 ELSE 0.0 END) hr "
            "FROM btc_bias_reads WHERE bias_primary = ? AND accuracy IS NOT NULL",
            (bias,),
        ).fetchone()
        return (int(row["n"] or 0), float(row["hr"] or 0.0))
