"""BTC bias accuracy scoring job (plan deliverable #6).

Runs every 24h. Scores bias reads older than 7 days against the actual BTC
mark move, with a 1.5% noise floor:

    BULLISH & price_after > price_at_post * 1.015 -> +1
    BULLISH & price_after < price_at_post * 0.985 -> -1
    (mirrored for BEARISH; RANGE/NEUTRAL score on staying inside the band)

The resulting hit rates weight the regime filter: calls the analyst actually
gets right count for more, calls he lags on get discounted. That reflexive
loop is the edge over static signal-following bots.
"""

from __future__ import annotations

import logging

log = logging.getLogger("state.bias_accuracy")

NOISE_FLOOR = 0.015
SCORE_AFTER_DAYS = 7
TRUSTED_HIT_RATE = 0.70
MIN_SAMPLES = 10


def score_bias(bias_primary: str, price_at_post: float, price_after: float) -> float:
    """Return +1 (right), -1 (wrong) or 0 (inside the noise floor)."""
    if not price_at_post or not price_after:
        return 0.0

    upper = price_at_post * (1 + NOISE_FLOOR)
    lower = price_at_post * (1 - NOISE_FLOOR)
    bias = (bias_primary or "").upper()

    if bias == "BULLISH":
        if price_after > upper:
            return 1.0
        if price_after < lower:
            return -1.0
        return 0.0

    if bias == "BEARISH":
        if price_after < lower:
            return 1.0
        if price_after > upper:
            return -1.0
        return 0.0

    if bias in ("RANGE", "NEUTRAL", "NO_CHASE"):
        # Right when price stayed inside the noise band, wrong when it broke out.
        return 1.0 if lower <= price_after <= upper else -1.0

    return 0.0


def resolved_direction(price_at_post: float, price_after: float) -> str:
    if not price_at_post or not price_after:
        return ""
    if price_after > price_at_post * (1 + NOISE_FLOOR):
        return "UP"
    if price_after < price_at_post * (1 - NOISE_FLOOR):
        return "DOWN"
    return "FLAT"


async def run_bias_accuracy_job(bias_repo, exchange) -> dict:
    """Score all unscored bias reads older than SCORE_AFTER_DAYS.

    Returns a summary dict: ``{"scored": n, "hit_rates": {bias: (n, rate)}}``.
    """
    rows = bias_repo.unscored(older_than_days=SCORE_AFTER_DAYS)
    if not rows:
        return {"scored": 0, "hit_rates": {}}

    try:
        price_after = await exchange.get_mark_price("BTCUSDT")
    except Exception as e:  # noqa: BLE001 — the job must never crash the bot
        log.warning("Bias accuracy job: could not fetch BTC mark: %s", e)
        return {"scored": 0, "hit_rates": {}, "error": str(e)}

    if not price_after:
        return {"scored": 0, "hit_rates": {}}

    scored = 0
    for row in rows:
        at_post = row.get("btc_price_at_post") or 0.0
        if not at_post:
            continue
        acc = score_bias(row.get("bias_primary", ""), at_post, price_after)
        bias_repo.score(
            row["id"], price_after, acc,
            resolved_direction(at_post, price_after),
        )
        scored += 1

    hit_rates = {}
    for bias in ("BULLISH", "BEARISH", "RANGE", "NEUTRAL", "NO_CHASE"):
        n, rate = bias_repo.hit_rate(bias)
        if n:
            hit_rates[bias] = (n, rate)

    log.info("Bias accuracy job: scored %d rows, hit rates %s", scored, hit_rates)
    return {"scored": scored, "hit_rates": hit_rates}


def bias_weight(bias_repo, bias_primary: str) -> float:
    """Weight multiplier for a bias, learned from its historical hit rate.

    Below MIN_SAMPLES the weight is a neutral 1.0 — never over-fit on a
    handful of calls.
    """
    n, rate = bias_repo.hit_rate(bias_primary)
    if n < MIN_SAMPLES:
        return 1.0
    return 1.25 if rate >= TRUSTED_HIT_RATE else 0.75
