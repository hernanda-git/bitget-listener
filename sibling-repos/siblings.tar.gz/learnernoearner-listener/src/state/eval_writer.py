"""Evaluation & monitoring writer — the learning-loop sink.

Runs periodically (called from the health reporter / orchestrator loop). It:
  - snapshots equity (balance) so drawdown + growth are measurable
  - rolls up closed positions into strategy_perf (per pair/direction, fee-adjusted)
  - writes eval_snapshots (expectancy per window/regime) so edge decay is detectable

Designed for a FRESH deploy: on an empty DB it writes a baseline snapshot and is
harmless. It only ever appends — never deletes or mutates live positions.
"""

from __future__ import annotations

import logging
from typing import Any

from src.state.database import get_connection
from src.state.repositories import (
    EquitySnapshotRepository,
    EvalSnapshotRepository,
    StrategyPerfRepository,
    PositionMetricsRepository,
    PositionRepository,
)

log = logging.getLogger("state.eval_writer")


def _safe_div(a: float, b: float) -> float:
    return a / b if b else 0.0


def snapshot_equity(conn=None, balance_usdt: float = 0.0, available_usdt: float | None = None,
                    unrealized_pnl: float = 0.0, open_positions: int = 0) -> int:
    """Write one equity point. Caller supplies live balance from the exchange."""
    repo = EquitySnapshotRepository(conn)
    return repo.save(balance_usdt, available_usdt, unrealized_pnl, open_positions,
                     source="exchange")


def compute_eval(conn=None, windows: tuple[str, ...] = ("all", "24h", "7d")) -> dict:
    """Compute fee-adjusted expectancy and write eval_snapshots + refresh
    strategy_perf from position_metrics. Returns a summary dict for logging."""
    conn = conn or get_connection()
    pm = PositionMetricsRepository(conn)
    pr = PositionRepository(conn)
    ev = EvalSnapshotRepository(conn)
    sp = StrategyPerfRepository(conn)

    # Refresh strategy_perf from position_metrics (fee-adjusted source of truth).
    rows = conn.execute(
        """SELECT p.pair, p.direction, pm.net_pnl, pm.gross_pnl, pm.r_multiple
           FROM position_metrics pm JOIN positions p ON p.id = pm.position_id
           WHERE p.status = 'CLOSED'"""
    ).fetchall()
    for r in rows:
        pair, direction, net, gross, rmult = r
        is_win = net > 0
        sp.upsert(pair, direction or "", net, net, is_win, rmult or 0.0)

    summary: dict[str, Any] = {}
    for win in windows:
        if win == "all":
            where = ""
            params: tuple = ()
        else:
            hours = 24 if win == "24h" else 168
            where = "AND p.exit_time >= datetime('now', ?)"
            params = (f"-{hours} hours",)

        q = f"""
            SELECT COUNT(*),
                   SUM(CASE WHEN pm.net_pnl > 0 THEN 1 ELSE 0 END),
                   SUM(CASE WHEN pm.net_pnl <= 0 THEN 1 ELSE 0 END),
                   COALESCE(AVG(CASE WHEN pm.net_pnl > 0 THEN pm.net_pnl END),0),
                   COALESCE(AVG(CASE WHEN pm.net_pnl <= 0 THEN pm.net_pnl END),0),
                   COALESCE(AVG(pm.net_pnl),0),
                   COALESCE(SUM(pm.net_pnl),0)
            FROM position_metrics pm JOIN positions p ON p.id = pm.position_id
            WHERE p.status = 'CLOSED' {where}
        """
        row = conn.execute(q, params).fetchone()
        n, wins, losses, avg_win, avg_loss, expectancy, total_net = row
        n = n or 0
        win_rate = _safe_div(wins or 0, n)
        # max drawdown from equity series
        eq = EquitySnapshotRepository(conn).series(2000)
        max_dd = 0.0
        peak = None
        for e in eq:
            b = e["balance_usdt"]
            if peak is None or b > peak:
                peak = b
            if peak:
                dd = (peak - b) / peak
                max_dd = max(max_dd, dd)

        ev.save(
            window=win, regime="", n_trades=n, win_rate=win_rate,
            avg_win=avg_win or 0.0, avg_loss=avg_loss or 0.0,
            expectancy_usdt=expectancy or 0.0,
            fee_adjusted_expectancy_usdt=expectancy or 0.0,
            max_drawdown=max_dd, sharpe=0.0,
            note=f"total_net={total_net:.4f}",
        )
        summary[win] = {
            "n": n, "win_rate": win_rate, "expectancy": expectancy or 0.0,
            "max_drawdown": max_dd, "total_net": total_net or 0.0,
        }
        log.info("eval[%s] n=%d wr=%.1f%% exp=%.4f dd=%.2f%%", win, n,
                 win_rate * 100, expectancy or 0.0, max_dd * 100)
    return summary


def strategy_ranking(conn=None, limit: int = 20) -> list[dict]:
    """Top pairs by fee-adjusted net PnL (for monitoring / rotation decisions)."""
    return StrategyPerfRepository(conn).ranking(limit)


if __name__ == "__main__":
    # Standalone: compute eval on the current DB (read-only-ish; appends snapshots).
    import json
    print(json.dumps(compute_eval(), indent=2, default=str))
    print("TOP PAIRS:")
    for r in strategy_ranking(10):
        print(f"  {r['pair']:12} {r['direction']:5} n={r['n']:3} "
              f"net={r['fee_adjusted_net']:+.4f} r={r['avg_r_multiple']:.2f}")
