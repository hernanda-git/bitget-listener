"""Orchestrator surface config watcher.

Watches ``/opt/bots/listener/config/surface.json`` for changes written by the
vaisravana orchestrator. When a new surface is detected, merges it into the
bot's config and signals the orchestrator to re-evaluate.

The orchestrator writes deltas to surface.json and creates a reload.flag.
This module reads both files, validates the merged config, and applies changes
without restarting the bot.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import time
from pathlib import Path
from typing import Any, Callable, Optional

logger = logging.getLogger(__name__)

# Default surface path — overridden by env SURFACE_CONFIG_PATH if set.
DEFAULT_SURFACE_PATH = "/opt/bots/listener/config/surface.json"
DEFAULT_RELOAD_FLAG_PATH = "/opt/bots/listener/config/reload.flag"


class ConfigWatcher:
    """Background watcher for orchestrator surface.json changes."""

    def __init__(
        self,
        surface_path: Optional[str] = None,
        reload_flag_path: Optional[str] = None,
        on_change: Optional[Callable[[dict[str, Any]], None]] = None,
        check_interval: float = 10.0,
    ) -> None:
        self.surface_path = Path(surface_path or DEFAULT_SURFACE_PATH)
        self.reload_flag_path = Path(reload_flag_path or DEFAULT_RELOAD_FLAG_PATH)
        self.on_change = on_change
        self.check_interval = check_interval
        self._last_mtime: float = 0.0
        self._last_flag: str = ""
        self._running = False
        self._task: Optional[asyncio.Task[None]] = None

    async def start(self) -> None:
        """Start the background watcher task."""
        if self._running:
            return
        self._running = True
        self._task = asyncio.create_task(self._watch_loop())
        logger.info(
            "ConfigWatcher started: surface=%s flag=%s interval=%.0fs",
            self.surface_path, self.reload_flag_path, self.check_interval,
        )

    async def stop(self) -> None:
        """Stop the background watcher task."""
        self._running = False
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
            self._task = None
        logger.info("ConfigWatcher stopped")

    async def _watch_loop(self) -> None:
        """Main watch loop: check surface.json and reload.flag periodically."""
        while self._running:
            try:
                await self._check()
            except Exception:
                logger.exception("ConfigWatcher check failed")
            await asyncio.sleep(self.check_interval)

    async def _check(self) -> None:
        """Check for surface.json or reload.flag changes."""
        # Check reload.flag first (orchestrator writes this after surface.json)
        try:
            if self.reload_flag_path.exists():
                new_flag = self.reload_flag_path.read_text().strip()
                if new_flag and new_flag != self._last_flag:
                    self._last_flag = new_flag
                    logger.info("ConfigWatcher: reload.flag changed — loading surface")
                    await self._load_and_apply()
                    return
        except Exception:
            logger.exception("ConfigWatcher: reload.flag check failed")

        # Check surface.json mtime
        try:
            if self.surface_path.exists():
                mtime = self.surface_path.stat().st_mtime
                if mtime > self._last_mtime:
                    self._last_mtime = mtime
                    logger.info("ConfigWatcher: surface.json changed — loading")
                    await self._load_and_apply()
        except Exception:
            logger.exception("ConfigWatcher: surface.json check failed")

    async def _load_and_apply(self) -> None:
        """Load surface.json, validate, merge into config, and signal change."""
        try:
            surface = json.loads(self.surface_path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError) as exc:
            logger.warning("ConfigWatcher: failed to read surface.json: %s", exc)
            return

        if not surface:
            logger.info("ConfigWatcher: surface.json is empty — skipping")
            return

        logger.info("ConfigWatcher: loaded surface with keys: %s", list(surface.keys()))

        # Call the on_change callback if provided
        if self.on_change:
            try:
                self.on_change(surface)
            except Exception:
                logger.exception("ConfigWatcher: on_change callback failed")