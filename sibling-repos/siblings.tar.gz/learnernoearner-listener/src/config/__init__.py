"""Configuration loading and validation."""
