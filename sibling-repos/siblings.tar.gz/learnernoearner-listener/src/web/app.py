"""FastAPI Web UI + WebSocket event stream + password-protected control panel.

Single-page dashboard: KPIs, live market tiles, positions, recent trades, an
activities timeline, a live logs tail, and a parse/attachment sandbox. A
WebSocket mirrors queued events to connected browsers.

Control panel (password-gated):
  - manual close of any open position (reduceOnly market)
  - manual entry: pair (autocomplete) + side + entry + sl + tp + margin + leverage
    -> the bot computes quantity from notional (margin x leverage), clamps
    leverage to the pair's exchange cap, bumps notional to meet MIN_NOTIONAL,
    sets leverage, rests a LIMIT entry + reduceOnly SL/TP.
  - live/paper toggle (flips exchange.active in config.yaml, restarts the bot)

Auth: a single shared password (DASHBOARD_PASSWORD env, default fallback). On
POST /login a signed HttpOnly session cookie is set; every other route requires
it. The password itself is never sent to the client and never lives in source.

Reuses ``DashboardState`` (background aggregator). ``attach_dashboard(state, bus,
exchange, order_service, registry, set_mode)`` wires the bot's pieces in;
``create_app(state)`` returns the FastAPI app.
"""

from __future__ import annotations

import asyncio
import hashlib
import hmac
import json
import logging
import os
import secrets
import time
import traceback
from collections import deque
from typing import Any

from fastapi import FastAPI, Request, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse, JSONResponse

from src.web.dashboard_state import DashboardState, LOG_CLS

log = logging.getLogger("web.app")

# Module-level handles so main.py can attach bot pieces without import cycles.
_STATE: DashboardState | None = None
_CTRL: Any = None  # ControlPanel (exchange/order_service/registry/set_mode)

# ─── Auth ──────────────────────────────────────────────────────────────────
# A single shared dashboard password. Served only from env (gitignored .env).
_PASSWORD = os.environ.get("DASHBOARD_PASSWORD", "k2kb2bdbgv")
# Server-side secret used to sign the session cookie (rotates per process boot,
# never leaves the host). A signed cookie is required for every protected route.
_AUTH_SECRET = secrets.token_hex(32)
_COOKIE = "lnr_sess"
# session token = sha256(password || secret). Cheap, stateless, no server store.
def _expected_token() -> str:
    return hashlib.sha256((_PASSWORD + _AUTH_SECRET).encode()).hexdigest()

def _valid_session(req: Request) -> bool:
    tok = req.cookies.get(_COOKIE)
    if not tok:
        return False
    # constant-time compare
    return hmac.compare_digest(tok, _expected_token())

def _auth_ok(req: Request, body: dict | None = None) -> bool:
    """Auth for control actions: valid session cookie OR password in body.

    Monitoring (snapshot/WS) is open. Trade controls require either a session
    cookie from /login or the dashboard password supplied in the JSON body.
    """
    if _valid_session(req):
        return True
    pw = ((body or {}) or {}).get("password", "")
    return hmac.compare_digest(pw, _PASSWORD) if pw else False


def _require(req: Request):
    if not _valid_session(req):
        return JSONResponse({"error": "unauthorized"}, status_code=401)
    return None


class EventBus:
    """In-process pub/sub for the WebSocket stream (drained by /ws/events)."""

    def __init__(self, maxlen: int = 2000) -> None:
        self._queue: deque = deque(maxlen=maxlen)

    def publish(self, event: dict) -> None:
        self._queue.append(event)

    def drain(self) -> list[dict]:
        out = []
        while self._queue:
            out.append(self._queue.popleft())
        return out


_BUS = EventBus()


def set_state(state: DashboardState) -> None:
    global _STATE
    _STATE = state


class ControlPanel:
    """Thin, safe wrapper exposing manual trade controls to the Web UI.

    Every method goes through the bot's own exchange adapter / order service
    (which enforce reduceOnly, precision rounding, MIN_NOTIONAL, leverage caps)
    rather than issuing raw Binance calls.
    """

    def __init__(self, exchange=None, order_service=None, registry=None,
                 set_mode=None):
        self.ex = exchange
        self.os = order_service
        self.registry = registry
        self.set_mode = set_mode  # callable(mode: str) -> None

    # ── structured logging/emit for every manual action (success + failure) ──
    def _log_action(self, etype: str, ok: bool, detail: str, **extra) -> None:
        """Log every manual control action to journald AND emit it to the WS bus
        AND the dashboard activity timeline so the UI shows successes AND
        failures (not just wins). Failures are logged at ERROR level."""
        rec = {"type": etype, "ok": ok, "detail": detail, **extra}
        # Drop 'payload' so _ingest_event stores the whole rec as `data` (which
        # carries ok/detail). Keeping payload would nest it and hide ok from the
        # timeline's failure styling.
        rec.pop("payload", None)
        if ok:
            log.info("Manual action %s: %s", etype, detail)
        else:
            log.error("Manual action FAILED %s: %s | %s", etype, detail, extra)
        try:
            _BUS.publish(rec)          # live WebSocket stream
            if _STATE is not None:
                _STATE.publish(rec)     # dashboard activity timeline (snapshot)
        except Exception:  # noqa: BLE001
            pass

    # ── symbol autocomplete ──────────────────────────────────────────────
    def symbol_hints(self, query: str = "", limit: int = 60) -> list[str]:
        q = (query or "").upper().strip()
        try:
            if self.registry is not None and getattr(self.registry, "is_ready", False):
                syms = [s.symbol for s in self.registry.get_all_symbols()]
            else:
                syms = []
        except Exception:
            syms = []
        if not syms and self.ex is not None:
            # fallback: a small curated set
            syms = ["BTCUSDT", "ETHUSDT", "SOLUSDT", "BNBUSDT", "XRPUSDT",
                    "DOGEUSDT", "ADAUSDT", "AVAXUSDT", "LINKUSDT", "PEPEUSDT",
                    "BONKUSDT", "1000PEPEUSDT", "1000BONKUSDT"]
        if q:
            syms = [s for s in syms if q in s]
        # favour *USDT pairs, then sort
        usdt = [s for s in syms if s.endswith("USDT")]
        other = [s for s in syms if not s.endswith("USDT")]
        return (usdt + other)[:limit]

    # ── manual entry: compute quantity/leverage, place LIMIT + SL/TP ───────
    async def manual_entry(self, payload: dict) -> dict:
        ex = self.ex
        if ex is None:
            self._log_action("ManualOrder", False, "no exchange connected", payload=payload)
            return {"ok": False, "error": "no exchange connected"}
        pair = (payload.get("pair") or "").upper().strip()
        side = (payload.get("side") or "").upper().strip()
        entry = float(payload.get("entry") or 0)
        sl = float(payload.get("sl") or 0)
        tp = float(payload.get("tp") or 0)
        margin = float(payload.get("margin") or 0)
        lev_in = int(payload.get("leverage") or 1)
        if not pair or side not in ("LONG", "SHORT", "BUY", "SELL"):
            self._log_action("ManualOrder", False, "pair + side(LONG/SHORT) required", payload=payload)
            return {"ok": False, "error": "pair + side(LONG/SHORT) required"}
        if entry <= 0:
            self._log_action("ManualOrder", False, "entry price must be > 0", payload=payload)
            return {"ok": False, "error": "entry price must be > 0"}
        # Resolve real symbol + load exchange filters (minNotional, maxLeverage, tick)
        from src.exchange.binance import _resolve_futures_symbol
        sym, _, _ = _resolve_futures_symbol(pair)
        loader = getattr(ex, "_load_futures_filters", None)
        rules = await loader(sym) if loader else None
        max_lev = int(rules.get("maxLeverage", 125)) if rules and rules.get("maxLeverage") else 125
        min_notional = float(rules.get("minNotional", 5.0)) if rules and rules.get("minNotional") else 5.0
        # Clamp requested leverage to the pair cap.
        lev = max(1, min(lev_in, max_lev))
        # Ensure notional (margin x lev) meets MIN_NOTIONAL; bump if needed.
        notional = margin * lev
        if notional < min_notional:
            need_lev = min(max_lev, max(1, int((min_notional / margin) + 0.999)) if margin > 0 else max_lev)
            lev = need_lev
            notional = margin * lev
        # Quantity in base asset = notional / entry price.
        qty = notional / entry if entry > 0 else 0.0
        # Round quantity to pair precision + enforce MIN_NOTIONAL via exchange helper.
        rounder = getattr(ex, "_round_quantity", None)
        if rounder:
            qty, _ = await rounder(sym, qty, price_ref=entry)
        qty = float(qty)
        if qty <= 0:
            return {"ok": False, "error": "computed quantity <= 0 (margin too small for this pair)"}
        # Set leverage on the symbol (best-effort; ignore if unsupported).
        try:
            await ex.set_symbol_leverage(sym, lev)
        except Exception as e:  # noqa: BLE001
            log.warning("set_leverage failed for %s: %s", sym, e)
        direction = "BUY" if side in ("LONG", "BUY") else "SELL"
        # Place LIMIT entry (rest on book at entry). If entry is far from market
        # this may not fill immediately — that mirrors the bot's own behaviour.
        try:
            if direction == "BUY":
                order = await ex.limit_buy(sym, qty, entry)
            else:
                order = await ex.limit_sell(sym, qty, entry)
        except Exception as e:  # noqa: BLE001
            self._log_action("ManualOrder", False, f"entry order failed: {e}",
                             symbol=sym, side=side, entry=entry, qty=qty, leverage=lev)
            return {"ok": False, "error": f"entry order failed: {e}",
                    "trace": traceback.format_exc()}
        result = {"ok": True, "symbol": sym, "side": side, "entry": entry,
                  "qty": qty, "leverage": lev, "notional": round(notional, 2),
                  "min_notional": min_notional, "order_id": getattr(order, "order_id", ""),
                  "order_status": getattr(order, "status", "")}
        # Rest reduceOnly SL + TP if provided.
        try:
            if sl > 0:
                sl_side = "SELL" if direction == "BUY" else "BUY"
                if sl_side == "SELL":
                    so = await ex.limit_sell(sym, qty, sl, reduce=True)
                else:
                    so = await ex.limit_buy(sym, qty, sl, reduce=True)
                result["sl_order"] = getattr(so, "order_id", "")
            if tp > 0:
                tp_side = "SELL" if direction == "BUY" else "BUY"
                if tp_side == "SELL":
                    to = await ex.limit_sell(sym, qty, tp, reduce=True)
                else:
                    to = await ex.limit_buy(sym, qty, tp, reduce=True)
                result["tp_order"] = getattr(to, "order_id", "")
        except Exception as e:  # noqa: BLE001
            result["sl_tp_note"] = f"entry placed; SL/TP not set: {e}"
        self._log_action("ManualOrder", True,
                         f"{side} {sym} entry={entry} qty={qty} lev={lev} notional={round(notional,2)}",
                         symbol=sym, side=side, entry=entry, qty=qty, leverage=lev,
                         order_id=result.get("order_id"), sl_order=result.get("sl_order"),
                         tp_order=result.get("tp_order"), sl_tp_note=result.get("sl_tp_note"))
        return result

    async def manual_close(self, payload: dict) -> dict:
        ex = self.ex
        if ex is None:
            self._log_action("ManualClose", False, "no exchange connected", payload=payload)
            return {"ok": False, "error": "no exchange connected"}
        sym = (payload.get("symbol") or "").upper().strip()
        if not sym:
            self._log_action("ManualClose", False, "symbol required", payload=payload)
            return {"ok": False, "error": "symbol required"}
        # authoritative size from exchange
        pos = await ex.get_open_position(sym)
        if pos is None:
            # try from dashboard snapshot positions
            if _STATE is not None:
                for p in _STATE.positions:
                    if p.get("symbol", "").upper() == sym:
                        pos = type("P", (), {"direction": p.get("direction"),
                                            "size": p.get("size")})()
            if pos is None:
                self._log_action("ManualClose", False, f"no open position for {sym}", symbol=sym)
                return {"ok": False, "error": f"no open position for {sym}"}
        size = float(getattr(pos, "size", 0) or 0)
        direction = getattr(pos, "direction", "")
        if size <= 0:
            self._log_action("ManualClose", False, f"position size for {sym} is 0", symbol=sym)
            return {"ok": False, "error": f"position size for {sym} is 0"}
        close_side = "SELL" if direction.upper() == "LONG" else "BUY"
        try:
            o = await ex.market_close(sym, size, side=close_side)
        except Exception as e:  # noqa: BLE001
            self._log_action("ManualClose", False, f"close failed: {e}", symbol=sym, size=size)
            return {"ok": False, "error": f"close failed: {e}", "trace": traceback.format_exc()}
        self._log_action("ManualClose", True, f"closed {sym} size={size} side={close_side}",
                         symbol=sym, size=size, side=close_side,
                         order_id=getattr(o, "order_id", ""), status=getattr(o, "status", ""))
        return {"ok": True, "symbol": sym, "closed": size, "side": close_side,
                "order_id": getattr(o, "order_id", ""), "status": getattr(o, "status", "")}

    def current_mode(self) -> str:
        return "paper" if (_STATE and _STATE.paper) else "binance"

    def toggle_mode(self, mode: str) -> dict:
        mode = (mode or "").lower()
        if mode not in ("paper", "binance", "binance_testnet"):
            self._log_action("ModeToggle", False, f"invalid mode requested: {mode}")
            return {"ok": False, "error": "mode must be paper|binance|binance_testnet"}
        if self.set_mode is None:
            self._log_action("ModeToggle", False, "no callback available")
            return {"ok": False, "error": "mode toggle unavailable (no callback)"}
        self._log_action("ModeToggle", True, f"switching to {mode}; bot restarting to apply", mode=mode)
        self.set_mode(mode)
        return {"ok": True, "mode": mode, "note": "config updated; bot restarting to apply"}


def attach_dashboard(state: DashboardState, bus: Any,
                     exchange=None, order_service=None, registry=None,
                     set_mode=None) -> None:
    """Subscribe ``state`` to the bot's EventBus and wire the control panel."""
    set_state(state)
    global _CTRL
    _CTRL = ControlPanel(exchange=exchange, order_service=order_service,
                         registry=registry, set_mode=set_mode)

    def _forward(event):
        try:
            etype = getattr(event, "event_type", "event")
            payload = getattr(event, "payload", {}) or {}
            payload = payload if isinstance(payload, dict) else {"detail": str(payload)}
            record = {"type": etype, "data": payload}
            state.publish(record)
            _BUS.publish(record)
        except Exception:  # noqa: BLE001
            log.exception("dashboard forward failed")

    for et in (
        "SignalReceived", "AttachmentScalp", "DecisionCreated",
        "PositionOpened", "PositionModified", "PositionClosed",
        "TP1PartialExit", "TriggerEntered", "ConditionalSignalSaved",
        "BiasRead", "VisionError",
        # control-panel + order outcomes (so manual actions AND successes/
        # failures all surface in the Activity tab, not just bot-driven events)
        "OrderFailed", "OrderError", "ValidationError",
        "ManualOrder", "ManualClose", "ModeToggle",
    ):
        try:
            bus.subscribe(et, _forward)
        except Exception:  # noqa: BLE001
            pass


def create_app(state: DashboardState | None = None) -> FastAPI:
    """Build the FastAPI app. ``state`` may be injected for tests."""
    if state is not None:
        set_state(state)

    app = FastAPI(title="learnernoearner-listener Dashboard", version="2.0")

    # ── Auth ────────────────────────────────────────────────────────────
    @app.post("/login")
    async def login(req: Request):
        body = await _safe_json(req)
        pw = (body or {}).get("password", "")
        if hmac.compare_digest(pw, _PASSWORD):
            resp = JSONResponse({"ok": True})
            resp.set_cookie(_COOKIE, _expected_token(), httponly=True,
                            samesite="lax", path="/", max_age=60 * 60 * 24 * 7,
                            secure=False)
            return resp
        return JSONResponse({"ok": False, "error": "invalid password"}, status_code=401)

    @app.get("/logout")
    async def logout():
        resp = JSONResponse({"ok": True})
        resp.delete_cookie(_COOKIE, path="/")
        return resp

    @app.get("/health")
    async def health():
        return {"status": "ok", "bot": (_STATE.bot_name if _STATE else None),
                "authed": True, "timestamp": _now()}

    @app.get("/favicon.ico")
    async def favicon():
        from fastapi.responses import Response
        return Response(status_code=204)

    @app.get("/", response_class=HTMLResponse)
    async def index():
        return HTMLResponse(_DASHBOARD_HTML)

    @app.get("/api/snapshot")
    async def snapshot(req: Request):
        if _STATE is None:
            return {"error": "dashboard not initialized"}
        return _STATE.snapshot()

    # ── Control: symbols (autocomplete) ─────────────────────────────────
    @app.get("/api/symbols")
    async def symbols(q: str = ""):
        if _CTRL is None:
            return {"symbols": []}
        return {"symbols": _CTRL.symbol_hints(q)}

    # ── Control: manual entry ───────────────────────────────────────────
    @app.post("/api/order")
    async def order(req: Request):
        body = await _safe_json(req)
        if not _auth_ok(req, body):
            return JSONResponse({"error": "password required"}, status_code=401)
        if _CTRL is None:
            return JSONResponse({"ok": False, "error": "control panel not ready"}, status_code=503)
        try:
            res = await _CTRL.manual_entry(body or {})
        except Exception as e:  # noqa: BLE001
            return JSONResponse({"ok": False, "error": str(e), "trace": traceback.format_exc()}, status_code=400)
        return JSONResponse(res, status_code=200 if res.get("ok") else 400)

    # ── Control: manual close ───────────────────────────────────────────
    @app.post("/api/close")
    async def close(req: Request):
        body = await _safe_json(req)
        if not _auth_ok(req, body):
            return JSONResponse({"error": "password required"}, status_code=401)
        if _CTRL is None:
            return JSONResponse({"ok": False, "error": "control panel not ready"}, status_code=503)
        try:
            res = await _CTRL.manual_close(body or {})
        except Exception as e:  # noqa: BLE001
            return JSONResponse({"ok": False, "error": str(e), "trace": traceback.format_exc()}, status_code=400)
        return JSONResponse(res, status_code=200 if res.get("ok") else 400)

    # ── Control: live/paper toggle ──────────────────────────────────────
    @app.post("/api/mode")
    async def mode(req: Request):
        body = await _safe_json(req)
        if not _auth_ok(req, body):
            return JSONResponse({"error": "password required"}, status_code=401)
        if _CTRL is None:
            return JSONResponse({"ok": False, "error": "control panel not ready"}, status_code=503)
        res = _CTRL.toggle_mode((body or {}).get("mode", ""))
        return JSONResponse(res, status_code=200 if res.get("ok") else 400)

    @app.get("/api/mode")
    async def mode_get():
        return {"mode": _CTRL.current_mode() if _CTRL else "paper",
                "paper": 1 if (_STATE and _STATE.paper) else 0}

    @app.websocket("/ws/events")
    async def ws_events(ws: WebSocket):
        # Monitoring stream only (events/logs) — no auth required. Control
        # actions go through the authenticated POST routes.
        await ws.accept()
        try:
            while True:
                for ev in _BUS.drain():
                    await ws.send_text(json.dumps(ev))
                await asyncio.sleep(0.5)
        except WebSocketDisconnect:
            pass
        except Exception:  # noqa: BLE001
            log.exception("ws/events error")

    @app.post("/api/parse")
    async def parse_signal(req: Request):
        from src.agent.parser import parse_signal as _parse
        body = await _safe_json(req)
        text = (body or {}).get("text", "")
        channel = (body or {}).get("channel", "sandbox")
        mid = int((body or {}).get("message_id", 1) or 1)
        has_media = bool((body or {}).get("has_media", False))
        try:
            sig = _parse(mid, channel, text, has_media=has_media)
        except Exception as e:  # noqa: BLE001
            return {"ok": False, "error": str(e), "trace": traceback.format_exc()}
        return {"ok": True, "raw": text, "parsed": {
            "pair": sig.pair, "direction": sig.direction,
            "entry_price": sig.entry_price, "sl_price": sig.sl_price,
            "tp_prices": sig.tp_prices}}

    @app.post("/api/vision")
    async def vision_sandbox(req: Request):
        if _STATE is None:
            return {"ok": False, "error": "dashboard not initialized"}
        from src.agent.vision import VisionExtractor
        body = await _safe_json(req)
        path = (body or {}).get("path", "")
        caption = (body or {}).get("caption", "")
        if not path or not os.path.exists(path):
            return {"ok": False, "error": f"image not found at {path}"}
        try:
            ex = VisionExtractor(_state_config())
            result = await ex.extract(path, caption)
        except Exception as e:  # noqa: BLE001
            return {"ok": False, "error": str(e), "trace": traceback.format_exc()}
        return {"ok": True, "path": path, "vision_struct": result}

    return app


async def _safe_json(req: Request) -> dict:
    try:
        return await req.json()
    except Exception:  # noqa: BLE001
        return {}


def _state_config() -> dict:
    try:
        from src.config.loader import load_config
        return load_config()
    except Exception:  # noqa: BLE001
        return {}


def _now() -> str:
    from datetime import datetime, timezone
    return datetime.now(timezone.utc).isoformat()


# ─── Dashboard HTML (adapted from mexc-listener, + auth + control panel) ──
_DASHBOARD_HTML = r"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="color-scheme" content="light dark">
<link rel="icon" href="data:,">
<title>learnernoearner · fattyfatclub → Binance</title>
<style>
:root{
  /* ── palette: single accent (indigo) + semantic status only ── */
  --accent:#6366f1; --accent-600:#4f46e5; --accent-700:#4338ca;
  --accent-soft:#eef2ff; --accent-ring:rgba(99,102,241,.35);
  --pos:#16a34a; --pos-bg:#ecfdf5; --pos-line:#bbf7d0;
  --neg:#dc2626; --neg-bg:#fef2f2; --neg-line:#fecaca;
  --warn:#d97706; --warn-bg:#fffbeb; --warn-line:#fde68a;
  /* light surfaces */
  --bg:#f5f7fb; --bg-2:#eef2f8; --surface:#ffffff; --surface-2:#f7f9fc;
  --ink:#0e1726; --ink-soft:#475569; --mut:#64748b; --mut-2:#94a3b8; --line:#e6ecf3;
  --shadow:0 1px 2px rgba(15,23,42,.04),0 12px 30px rgba(15,23,42,.07);
  --shadow-sm:0 1px 2px rgba(15,23,42,.05),0 4px 12px rgba(15,23,42,.05);
  --shadow-pop:0 20px 50px rgba(15,23,42,.16);
  /* ── scales ── */
  --r-xl:22px; --r-lg:18px; --r:14px; --r-sm:10px; --r-xs:7px;
  --s1:4px; --s2:8px; --s3:12px; --s4:16px; --s5:20px; --s6:24px; --s7:32px;
  --ff:'Inter',system-ui,-apple-system,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;
  --mono:ui-monospace,SFMono-Regular,'JetBrains Mono',Menlo,Consolas,monospace;
}
@media (prefers-color-scheme:dark){
  :root{
    --bg:#0b1120; --bg-2:#0e1626; --surface:#121b2e; --surface-2:#16203a;
    --ink:#e8edf6; --ink-soft:#aab6c8; --mut:#8190a6; --mut-2:#5b6b85; --line:#243149;
    --accent-soft:#1c2546; --accent-ring:rgba(129,140,248,.4);
    --pos-bg:#0f2a1e; --pos-line:#1c5238; --neg-bg:#2a1416; --neg-line:#5b2226;
    --warn-bg:#2a2010; --warn-line:#5c4318;
    --shadow:0 1px 2px rgba(0,0,0,.3),0 14px 34px rgba(0,0,0,.45);
    --shadow-sm:0 1px 2px rgba(0,0,0,.3),0 4px 12px rgba(0,0,0,.3);
    --shadow-pop:0 20px 50px rgba(0,0,0,.6);
  }
}
*{box-sizing:border-box}html,body{margin:0;padding:0}
body{font-family:var(--ff);background:var(--bg);color:var(--ink);font-size:14px;line-height:1.5;
  min-height:100vh;-webkit-font-smoothing:antialiased;text-rendering:optimizeLegibility;
  font-feature-settings:'cv11','ss01';letter-spacing:-.005em}
h1,h2,h3,p{margin:0}
a{color:var(--accent-600)}
.num{font-family:var(--mono);font-variant-numeric:tabular-nums;letter-spacing:-.02em}
.pos{color:var(--pos)!important}.neg{color:var(--neg)!important}
/* decorative bg */
.bg{position:fixed;inset:0;z-index:-1;overflow:hidden;pointer-events:none;
  background:radial-gradient(1200px 600px at 12% -8%,rgba(99,102,241,.10),transparent 60%),
            radial-gradient(900px 500px at 100% 0%,rgba(236,72,153,.06),transparent 55%),
            linear-gradient(180deg,var(--bg) 0%,var(--bg-2) 100%)}
/* ── top bar ── */
.topbar{position:sticky;top:0;z-index:30;display:flex;align-items:center;gap:var(--s4);flex-wrap:wrap;
  padding:var(--s3) var(--s5);background:color-mix(in srgb,var(--surface) 82%,transparent);
  backdrop-filter:blur(16px) saturate(140%);border-bottom:1px solid var(--line)}
.brand{display:flex;align-items:center;gap:var(--s3);min-width:0}
.brand-mark{width:40px;height:40px;border-radius:12px;flex:none;display:grid;place-items:center;
  background:linear-gradient(135deg,var(--accent) 0%,#8b5cf6 100%);color:#fff;
  box-shadow:0 6px 16px var(--accent-ring)}
.brand-mark svg{width:22px;height:22px}
.brand-text{min-width:0}.brand-text h1{font-size:1.02rem;font-weight:800;letter-spacing:-.02em;color:var(--ink);
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.brand-text p{font-size:.68rem;margin-top:2px;color:var(--mut);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.status-cluster{display:flex;align-items:center;gap:var(--s2);margin-left:auto;flex-wrap:wrap}
.pill{display:inline-flex;align-items:center;gap:6px;font-size:.7rem;font-weight:700;
  padding:5px 10px;border-radius:999px;border:1px solid var(--line);background:var(--surface);color:var(--ink-soft);letter-spacing:.02em;white-space:nowrap}
.pill .dot{width:7px;height:7px;border-radius:50%;background:var(--mut-2)}
.pill.paper{background:var(--warn-bg);border-color:var(--warn-line);color:var(--warn)}
.pill.live{background:var(--pos-bg);border-color:var(--pos-line);color:var(--pos)}
.pill.live .dot{background:var(--pos);box-shadow:0 0 0 3px var(--pos-line)}
.pill.accent{background:var(--accent-soft);border-color:var(--accent-ring);color:var(--accent-600)}
.conn{display:inline-flex;align-items:center;gap:6px;font-size:.72rem;color:var(--mut);font-weight:600}
.conn .dot{width:8px;height:8px;border-radius:50%;background:var(--warn);transition:.2s}
.conn .dot.live{background:var(--pos);box-shadow:0 0 0 4px var(--pos-line)}
/* ── tabs (segmented) ── */
.tabs{display:flex;gap:var(--s2);max-width:1180px;margin:0 auto;padding:var(--s5) var(--s5) 0}
.tab{flex:1;padding:10px var(--s3);border:1px solid var(--line);background:var(--surface);color:var(--mut);
  border-radius:var(--r);font-weight:700;font-size:.82rem;cursor:pointer;transition:.18s;letter-spacing:-.01em}
.tab:hover{color:var(--ink);border-color:var(--accent-ring);transform:translateY(-1px)}
.tab.active{background:var(--accent);color:#fff;border-color:var(--accent);box-shadow:0 8px 20px var(--accent-ring)}
.tab-pane{display:none;animation:fade .22s ease}
.tab-pane.active{display:block}
@keyframes fade{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:none}}
/* ── shell + cards ── */
.shell{max-width:1180px;margin:0 auto;padding:var(--s5) var(--s5) var(--s7)}
.card{background:var(--surface);border:1px solid var(--line);border-radius:var(--r-lg);box-shadow:var(--shadow);overflow:hidden}
.card-head{display:flex;align-items:center;gap:var(--s2);padding:var(--s4) var(--s5) var(--s2)}
.card-head h2{font-size:.72rem;font-weight:800;color:var(--mut);text-transform:uppercase;letter-spacing:.08em}
.card-head .hint{margin-left:auto;font-size:.7rem;color:var(--mut-2);font-weight:600}
.card-body{padding:var(--s4) var(--s5) var(--s5)}
.section{margin-top:var(--s4)}
/* ── KPI ── */
.kpi-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:var(--s4)}
.kpi:last-child{grid-column:span 2}
.kpi{display:flex;gap:var(--s3);align-items:flex-start;padding:var(--s4) var(--s5);position:relative;overflow:hidden;
  background:var(--surface);border:1px solid var(--line);border-radius:var(--r-lg);box-shadow:var(--shadow-sm);transition:.2s}
.kpi:hover{transform:translateY(-3px);box-shadow:var(--shadow);border-color:var(--accent-ring)}
.kpi-icon{width:42px;height:42px;border-radius:12px;flex:none;display:grid;place-items:center;
  background:var(--accent-soft);color:var(--accent-600)}
.kpi-icon svg{width:20px;height:20px}
.kpi-icon.green{background:var(--pos-bg);color:var(--pos)}
.kpi-icon.red{background:var(--neg-bg);color:var(--neg)}
.kpi-icon.amber{background:var(--warn-bg);color:var(--warn)}
.kpi-body{min-width:0;position:relative;z-index:1;display:flex;flex-direction:column;gap:3px}
.kpi-label{font-size:.66rem;font-weight:700;color:var(--mut);text-transform:uppercase;letter-spacing:.06em}
.kpi-value{font-size:1.55rem;font-weight:800;line-height:1.1;font-variant-numeric:tabular-nums;color:var(--ink);white-space:nowrap;margin:0}
.kpi-sub{font-size:.7rem;color:var(--mut-2);font-weight:500;margin:0;line-height:1.3}
.kpi-spark{margin-top:7px;height:26px}
/* ── market ── */
.market-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:var(--s4)}
.mkt{padding:var(--s4);border-radius:var(--r);background:var(--surface-2);border:1px solid var(--line);transition:.2s}
.mkt:hover{border-color:var(--accent-ring);transform:translateY(-2px)}
.mkt-top{display:flex;align-items:center;gap:var(--s2)}
.mkt-sym{font-size:.82rem;font-weight:800;color:var(--ink);letter-spacing:.01em}
.mkt-chg{margin-left:auto;font-size:.7rem;font-weight:800;padding:3px 8px;border-radius:999px;font-variant-numeric:tabular-nums}
.mkt-chg.pos{background:var(--pos-bg);color:var(--pos)}.mkt-chg.neg{background:var(--neg-bg);color:var(--neg)}
.mkt-price{font-size:1.4rem;font-weight:800;margin-top:var(--s2);font-variant-numeric:tabular-nums;color:var(--ink);transition:color .15s}
.mkt-price.flash-up{animation:mktFlashUp .7s ease-out}
.mkt-price.flash-down{animation:mktFlashDown .7s ease-out}
@keyframes mktFlashUp{0%{color:var(--pos)}100%{color:var(--ink)}}
@keyframes mktFlashDown{0%{color:var(--neg)}100%{color:var(--ink)}}
.mkt-spark{margin-top:var(--s3);height:34px}
.mkt-spark .spark{display:block}
.mkt-flat{height:34px;border-radius:var(--r-xs);background:linear-gradient(90deg,var(--line),transparent,var(--line));opacity:.4}
.kpi-spark{margin-top:6px;height:26px}
.kpi-spark .spark{display:block}
.kpi-value.muted{color:var(--mut-2);font-weight:700}
/* ── grids + tables ── */
.grid2x2{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:var(--s4);margin-top:var(--s4)}
.grid2col{display:grid;grid-template-columns:minmax(0,1.3fr) minmax(0,1fr) minmax(0,1fr) minmax(0,1fr);gap:var(--s4);margin-top:var(--s4)}
.grid2col>.card:first-child{grid-column:span 2}
.table-wrap{overflow:auto;max-height:360px;border-radius:var(--r-sm)}
table{width:100%;border-collapse:collapse;font-size:.78rem}
th,td{text-align:left;padding:9px 10px;border-bottom:1px solid var(--line);white-space:nowrap}
th{color:var(--mut);font-weight:700;font-size:.64rem;text-transform:uppercase;letter-spacing:.06em;
  background:var(--surface-2);position:sticky;top:0;z-index:1}
tbody tr:last-child td{border-bottom:0}tbody tr:hover{background:var(--surface-2)}
.sym{font-weight:700;color:var(--ink)}
.side{font-size:.64rem;font-weight:800;padding:3px 8px;border-radius:6px;text-transform:uppercase;letter-spacing:.02em}
.side.long,.side.buy{background:var(--pos-bg);color:var(--pos)}.side.short,.side.sell{background:var(--neg-bg);color:var(--neg)}
.empty{color:var(--mut-2);font-size:.8rem;padding:var(--s3) 0;display:flex;align-items:center;gap:var(--s2)}
.empty svg{width:16px;height:16px;opacity:.7;flex:none}
.empty .e-sub{color:var(--mut-2);font-size:.72rem;font-weight:500}
/* ── meta strip (inside card-body, matches other cards' head+body structure) ── */
.meta-strip{display:grid;grid-template-columns:repeat(4,auto);justify-content:start;gap:var(--s4) var(--s6);padding:0}
.ms-item{display:flex;flex-direction:column;gap:4px}
.ms-k{font-size:.6rem;font-weight:700;color:var(--mut);text-transform:uppercase;letter-spacing:.06em}
.ms-v{font-size:.9rem;font-weight:800;color:var(--ink)}
/* ── stats ── */
.stats-list{display:grid;gap:0}
.stat-row{display:flex;justify-content:space-between;align-items:center;padding:11px 4px;border-bottom:1px solid var(--line)}
.stat-row:last-child{border-bottom:0}
.stat-row .k{color:var(--mut);font-size:.78rem;font-weight:600}
.stat-row .v{font-weight:800;font-variant-numeric:tabular-nums;font-size:.88rem;color:var(--ink)}
/* ── activity timeline ── */
.timeline{height:300px;overflow:auto;padding-right:4px}
.act-row{display:flex;gap:var(--s3);padding:var(--s3) 2px;border-bottom:1px solid var(--line);align-items:flex-start;border-radius:var(--r-xs)}
.act-row:last-child{border-bottom:0}
.act-dot{width:9px;height:9px;border-radius:50%;flex:none;margin-top:5px;background:var(--mut-2)}
.act-dot.sig{background:#f59e0b}.act-dot.ord{background:var(--accent)}.act-dot.fill{background:var(--pos)}
.act-dot.pos{background:#3b82f6}.act-dot.warn{background:var(--warn)}
.act-body{min-width:0;flex:1}
.act-head{display:flex;align-items:center;gap:var(--s2);margin-bottom:2px}
.act-msg{font-size:.76rem;color:var(--ink-soft);margin-top:3px;word-break:break-word;line-height:1.4}
.tag{font-size:.58rem;font-weight:800;padding:2px 7px;border-radius:6px;background:var(--surface-2);
  border:1px solid var(--line);color:var(--mut);text-transform:uppercase;letter-spacing:.05em;white-space:nowrap}
.tag.sig{color:#b45309;background:var(--warn-bg);border-color:var(--warn-line)}
.tag.ord{color:var(--accent-600);background:var(--accent-soft);border-color:var(--accent-ring)}
.tag.fill{color:var(--pos);background:var(--pos-bg);border-color:var(--pos-line)}
.tag.pos{color:#2563eb;background:#eff6ff;border-color:#bfdbfe}
.tag.warn{color:var(--warn);background:var(--warn-bg);border-color:var(--warn-line)}
.tag.err{color:var(--neg);background:var(--neg-bg);border-color:var(--neg-line)}
.act-dot.err{background:var(--neg)}
.act-row.fail{background:var(--neg-bg)}
.act-row.fail .act-msg{color:var(--neg);font-weight:700}
/* ── logs ── */
.log{height:300px;overflow:auto;background:#0b1120;color:#cbd5e1;border-radius:var(--r-sm);padding:var(--s3) var(--s4);
  font-family:var(--mono);font-size:.72rem;line-height:1.6}
.log-line{padding:2px 0;display:flex;gap:var(--s3)}
.log-line .t{color:#64748b;flex:none}.log-line .msg{color:#cbd5e1;word-break:break-word;min-width:0}
.log-line .sig{color:#fcd34d}.log-line .ord{color:#c4b5fd}.log-line .fill{color:#6ee7b7}
.log-line .pos{color:#93c5fd}.log-line .sid{color:#93c5fd}.log-line .warn{color:#fcd34d}.log-line .mut{color:#94a3b8}
/* ── sandbox ── */
.sandbox{padding:var(--s4) var(--s5) var(--s5)}
.sandbox textarea{width:100%;min-height:64px;padding:var(--s3);border-radius:var(--r-sm);border:1px solid var(--line);
  background:var(--surface-2);color:var(--ink);font-size:.8rem;font-family:var(--mono);resize:vertical}
.sandbox .row{display:flex;gap:var(--s2);margin-top:var(--s3);flex-wrap:wrap}
.sandbox pre{background:#0b1120;color:#cbd5e1;border-radius:var(--r-sm);padding:var(--s3) var(--s4);overflow:auto;font-size:.7rem;
  font-family:var(--mono);max-height:240px;margin:0}
/* ── buttons + control form ── */
.btn{padding:9px 16px;border-radius:var(--r-sm);border:1px solid var(--line);background:var(--accent);color:#fff;
  font-weight:800;font-size:.78rem;cursor:pointer;transition:.16s;font-family:var(--ff);letter-spacing:-.01em}
.btn:hover{background:var(--accent-600);transform:translateY(-1px);box-shadow:0 8px 18px var(--accent-ring)}
.btn:active{transform:translateY(0)}.btn:focus-visible{outline:2px solid var(--accent-ring);outline-offset:2px}
.btn.ghost{background:var(--surface-2);color:var(--ink-soft);border-color:var(--line)}
.btn.ghost:hover{background:var(--surface);color:var(--ink);box-shadow:none}
.btn.danger{background:var(--neg);color:#fff;border-color:var(--neg)}
.btn.warn{background:var(--warn);color:#fff;border-color:var(--warn)}
.btn.sm{padding:6px 11px;font-size:.7rem}
.frm{display:grid;grid-template-columns:1fr 1fr;gap:var(--s3)}
.fld{display:flex;flex-direction:column;gap:5px}
.fld label{font-size:.64rem;font-weight:700;color:var(--mut);text-transform:uppercase;letter-spacing:.05em}
.fld input,.fld select{padding:9px 11px;border-radius:var(--r-sm);border:1px solid var(--line);
  background:var(--surface-2);color:var(--ink);font-size:.82rem;font-family:var(--mono);transition:.15s}
.fld input:focus,.fld select:focus{outline:none;border-color:var(--accent);box-shadow:0 0 0 3px var(--accent-ring);background:var(--surface)}
.fld.full{grid-column:1 / -1}
.calc{background:var(--accent-soft);border:1px solid var(--accent-ring);border-radius:var(--r-sm);
  padding:var(--s3);font-size:.72rem;color:var(--accent-700);grid-column:1 / -1;display:flex;gap:var(--s4);flex-wrap:wrap;line-height:1.5}
.calc b{color:var(--accent-700)}
.ctrl-actions{display:flex;gap:var(--s2);flex-wrap:wrap;margin-top:var(--s3);align-items:center}
.out{margin-top:var(--s3);font-size:.72rem;white-space:pre-wrap;font-family:var(--mono);
  background:var(--surface-2);border:1px solid var(--line);border-radius:var(--r-sm);padding:var(--s3);max-height:240px;overflow:auto}
.out.ok{color:var(--pos);border-color:var(--pos-line);background:var(--pos-bg)}
.out.err{color:var(--neg);border-color:var(--neg-line);background:var(--neg-bg)}
/* ── footer ── */
.foot{display:flex;align-items:center;gap:var(--s4);flex-wrap:wrap;margin-top:var(--s5);padding:var(--s4) var(--s5);
  color:var(--mut);font-size:.72rem;font-weight:500;border-top:1px solid var(--line)}
.foot .foot-brand{margin-left:auto;color:var(--mut-2)}
/* ── login overlay ── */
.overlay{position:fixed;inset:0;z-index:60;display:flex;align-items:center;justify-content:center;background:rgba(8,15,30,.6);backdrop-filter:blur(8px)}
.lock{width:min(340px,92vw);background:var(--surface);border:1px solid var(--line);border-radius:var(--r-lg);box-shadow:var(--shadow-pop);padding:var(--s6) var(--s5);text-align:center}
.lock h3{margin:var(--s1) 0;font-size:1.05rem;color:var(--ink)}
.lock p{margin:0 0 var(--s5);font-size:.74rem;color:var(--mut)}
.lock input{width:100%;padding:var(--s3);border-radius:var(--r-sm);border:1px solid var(--line);font-size:.9rem;text-align:center;letter-spacing:.08em}
.lock .btn{width:100%;margin-top:var(--s4)}
.lock .err{color:var(--neg);font-size:.72rem;margin-top:var(--s3);min-height:1em}
/* ── responsive ── */
@media (max-width:1100px){.grid2col{grid-template-columns:minmax(0,1fr) minmax(0,1fr)}.grid2col>.card:first-child{grid-column:span 2}}
@media (max-width:900px){.kpi-grid{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media (max-width:820px){.grid2x2{grid-template-columns:1fr}.grid2col{grid-template-columns:1fr}.grid2col>.card:first-child{grid-column:span 1}}
@media (max-width:640px){.shell{padding:var(--s4) var(--s3) var(--s6)}.tabs{padding:var(--s4) var(--s3) 0}
  .kpi{padding:var(--s3) var(--s4)}.kpi-value{font-size:1.3rem}
  .brand-text p{display:none}.topbar{padding:var(--s3)}.frm{grid-template-columns:1fr}.meta-strip{grid-template-columns:1fr 1fr;gap:var(--s5) var(--s5)}}
@media (max-width:480px){.kpi-grid{grid-template-columns:1fr}.kpi:last-child{grid-column:auto}.tab{font-size:.74rem;padding:9px 0}}
</style>
</head>
<body>
<div class="bg" aria-hidden="true"><span class="blob b1"></span><span class="blob b2"></span><span class="blob b3"></span></div>

<header class="topbar">
  <div class="brand">
    <div class="brand-mark" aria-hidden="true">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 17l6-6 4 4 6-7"/><path d="M15 8h5v5"/></svg>
    </div>
    <div class="brand-text">
      <h1>learnernoearner-listener</h1>
      <p>@fattyfatclub → Binance Futures · signal execution</p>
    </div>
  </div>
  <div class="status-cluster">
    <span id="mode" class="pill paper">PAPER</span>
    <span class="pill accent">@fattyfatclub</span>
    <span class="conn" id="conn"><span class="dot"></span><span id="connText">connecting…</span></span>
  </div>
</header>
<nav class="tabs" id="tabs">
  <button class="tab active" data-tab="overview">Overview</button>
  <button class="tab" data-tab="activity">Activity</button>
  <button class="tab" data-tab="control">Control</button>
</nav>

<main class="shell" id="shell">

  <!-- ===== OVERVIEW ===== -->
  <section class="tab-pane active" id="tab-overview">
    <section class="card">
      <div class="card-head"><h2>Account</h2><span class="hint">live state</span></div>
      <div class="card-body meta-strip">
        <div class="ms-item"><span class="ms-k">Mode</span><span class="ms-v" id="ms_mode">—</span></div>
        <div class="ms-item"><span class="ms-k">Exchange</span><span class="ms-v">Binance Futures</span></div>
        <div class="ms-item"><span class="ms-k">Watched</span><span class="ms-v" id="ms_watch">—</span></div>
        <div class="ms-item"><span class="ms-k">Last update</span><span class="ms-v" id="ms_upd">—</span></div>
      </div>
    </section>

    <section class="kpi-grid">
      <div class="card kpi"><div class="kpi-icon alt"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12V7H5a2 2 0 0 1 0-4h14v4"/><path d="M3 5v14a2 2 0 0 0 2 2h16v-5"/></svg></div><div class="kpi-body"><div class="kpi-label">Balance (USDT)</div><div class="kpi-value num" id="k_balance">—</div><div class="kpi-sub" id="k_balance_sub">available margin</div><div class="kpi-spark" id="k_balance_spark"></div></div></div>
      <div class="card kpi"><div class="kpi-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/></svg></div><div class="kpi-body"><div class="kpi-label">Net PnL</div><div class="kpi-value num" id="k_pnl">0.00</div><div class="kpi-sub" id="k_pnl_sub">—</div></div></div>
      <div class="card kpi"><div class="kpi-icon alt"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m12 2 9 5-9 5-9-5 9-5Z"/><path d="m3 12 9 5 9-5"/></svg></div><div class="kpi-body"><div class="kpi-label">Open positions</div><div class="kpi-value num" id="k_pos">0</div><div class="kpi-sub">active positions</div></div></div>
      <div class="card kpi"><div class="kpi-icon amber"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/></svg></div><div class="kpi-body"><div class="kpi-label">Win rate</div><div class="kpi-value num" id="k_wr">—</div><div class="kpi-sub" id="k_wr_sub">—</div></div></div>
      <div class="card kpi"><div class="kpi-icon alt"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="20" x2="12" y2="10"/><line x1="18" y1="20" x2="18" y2="4"/><line x1="6" y1="20" x2="6" y2="16"/></svg></div><div class="kpi-body"><div class="kpi-label">Profit factor</div><div class="kpi-value num" id="k_pf">—</div><div class="kpi-sub">gross win / loss</div></div></div>
      <div class="card kpi"><div class="kpi-icon red"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="22 17 13.5 8.5 8.5 13.5 2 7"/><polyline points="16 17 22 17 22 11"/></svg></div><div class="kpi-body"><div class="kpi-label">Max drawdown</div><div class="kpi-value num" id="k_dd">—</div><div class="kpi-sub">peak to trough</div></div></div>
      <div class="card kpi"><div class="kpi-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg></div><div class="kpi-body"><div class="kpi-label">Trades</div><div class="kpi-value num" id="k_trades">0</div><div class="kpi-sub">closed trades</div></div></div>
    </section>

    <section class="section card">
      <div class="card-head"><h2>Live market</h2><span class="hint">Binance public ticker</span></div>
      <div class="card-body market-grid" id="market"></div>
    </section>

    <div class="grid2x2">
      <section class="card">
        <div class="card-head"><h2>Open positions</h2><span class="hint" id="posCount">0</span></div>
        <div class="card-body">
          <div class="table-wrap" id="positionsTable" style="display:none">
            <table><thead><tr><th>Symbol</th><th>Side</th><th>Size</th><th>Entry</th><th>Mark</th><th>Liq</th><th>PnL</th><th>PnL%</th><th></th></tr></thead><tbody id="positionsBody"></tbody></table>
          </div>
          <div class="empty" id="posEmpty"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 3v18h18"/><path d="M7 14l3-3 3 3 4-5"/></svg><span>No open positions yet — signals that fill will appear here.<span class="e-sub"> Live.</span></span></div>
        </div>
      </section>
      <section class="card">
        <div class="card-head"><h2>Recent trades</h2><span class="hint">last 30</span></div>
        <div class="card-body"><div class="table-wrap"><table><thead><tr><th>Time</th><th>Symbol</th><th>PnL</th></tr></thead><tbody id="tradesBody"></tbody></table></div></div>
      </section>
    </div>
  </section>

  <!-- ===== ACTIVITY ===== -->
  <section class="tab-pane" id="tab-activity">
    <div class="grid2col">
      <section class="card">
        <div class="card-head"><h2>Activities</h2><span class="hint">newest first · red = failure</span></div>
        <div class="card-body"><div class="timeline" id="activities"></div></div>
      </section>
      <section class="card">
        <div class="card-head"><h2>Statistics</h2></div>
        <div class="card-body"><div class="stats-list">
          <div class="stat-row"><span class="k">Total trades</span><span class="v num" id="s_total">0</span></div>
          <div class="stat-row"><span class="k">Wins / Losses</span><span class="v num" id="s_wl">0 / 0</span></div>
          <div class="stat-row"><span class="k">Win rate</span><span class="v num" id="s_wr">—</span></div>
          <div class="stat-row"><span class="k">Profit factor</span><span class="v num" id="s_pf">—</span></div>
          <div class="stat-row"><span class="k">Expectancy</span><span class="v num" id="s_exp">—</span></div>
          <div class="stat-row"><span class="k">Max drawdown</span><span class="v num" id="s_dd">—</span></div>
          <div class="stat-row"><span class="k">Open positions</span><span class="v num" id="s_open">0</span></div>
          <div class="stat-row"><span class="k">Net PnL</span><span class="v num" id="s_net">0.00</span></div>
        </div></div>
      </section>
      <section class="card">
        <div class="card-head"><h2>Logs</h2><span class="hint">live event stream</span></div>
        <div class="card-body"><div class="log" id="logs"></div></div>
      </section>
    </div>
  </section>

  <!-- ===== CONTROL ===== -->
  <section class="tab-pane" id="tab-control">
    <section class="section card">
      <div class="card-head"><h2>Control panel</h2><span class="hint">manual entry · close · mode — password required</span></div>
      <div class="card-body">
        <div class="frm">
          <div class="fld full"><label>Pair (autocomplete)</label>
            <input id="c_pair" list="pairlist" placeholder="e.g. BTC, ETH, SOL, PEPE…" autocomplete="off">
            <datalist id="pairlist"></datalist>
          </div>
          <div class="fld"><label>Side</label>
            <select id="c_side"><option value="LONG">LONG</option><option value="SHORT">SHORT</option></select>
          </div>
          <div class="fld"><label>Entry price</label><input id="c_entry" type="number" step="any" placeholder="0.00"></div>
          <div class="fld"><label>Stop loss</label><input id="c_sl" type="number" step="any" placeholder="0.00"></div>
          <div class="fld"><label>Take profit</label><input id="c_tp" type="number" step="any" placeholder="0.00"></div>
          <div class="fld"><label>Margin (USDT)</label><input id="c_margin" type="number" step="any" value="1" placeholder="1"></div>
          <div class="fld"><label>Leverage (x)</label><input id="c_lev" type="number" step="1" value="10" placeholder="10"></div>
          <div class="calc" id="c_calc">type pair + entry + margin + leverage…</div>
        </div>
        <div class="ctrl-actions">
          <button class="btn" id="c_submit">Place order</button>
          <button class="btn ghost" id="c_clear">Clear</button>
          <span style="margin-left:auto;display:inline-flex;align-items:center;gap:.5rem">
            <span id="mode2" class="pill paper">PAPER</span>
            <button class="btn ghost sm" id="c_topaper">→ Paper</button>
            <button class="btn sm" id="c_tolive">→ Live</button>
          </span>
        </div>
        <div class="ctrl-actions">
          <button class="btn warn" id="c_flatten">Flatten all (close everything)</button>
        </div>
        <div class="out" id="c_out"></div>
      </div>
    </section>

    <section class="card">
      <div class="card-head"><h2>Parse sandbox</h2><span class="hint">live text parser</span></div>
      <div class="card-body sandbox">
        <textarea id="sandboxText" placeholder="Paste a signal, e.g. $BTC long entry 64000 sl 62000 tp1 67000 tp2 70000">$BTC long entry 64000 sl 62000 tp1 67000 tp2 70000</textarea>
        <div class="row">
          <button class="btn" id="sandboxRun">Parse</button>
          <button class="btn ghost" id="sandboxClear">Clear</button>
        </div>
        <pre id="sandboxOut">parsed output will appear here…</pre>
      </div>
    </section>
  </section>

  <footer class="foot">
    <span id="health">poll 5s · updated —</span>
    <button class="btn ghost sm" id="logoutBtn" style="margin-left:auto">Lock</button>
    <span class="foot-brand">learnernoearner-listener · real-time dashboard</span>
  </footer>
</main>

<script>
(function(){
'use strict';
const WSS = (location.protocol === 'https:' ? 'wss://' : 'ws://') + location.host + '/ws/events';
const ACTIVITY_TYPES = new Set(['SignalReceived','AttachmentScalp','DecisionCreated','PositionOpened','PositionModified','PositionClosed','TP1PartialExit','TriggerEntered','ConditionalSignalSaved','BiasRead','VisionError','OrderFailed','OrderError','ValidationError','ManualOrder','ManualClose','ModeToggle']);
const LOG_CLS = {SignalReceived:'sig',AttachmentScalp:'ord',DecisionCreated:'ord',PositionOpened:'pos',PositionModified:'pos',PositionClosed:'fill',TP1PartialExit:'fill',TriggerEntered:'ord',ConditionalSignalSaved:'warn',BiasRead:'sig',VisionError:'warn',OrderFailed:'err',OrderError:'err',ValidationError:'err',ManualOrder:'ord',ManualClose:'ord',ModeToggle:'warn'};
let ws, AUTH_TOKEN=null;
const BOOT_TS=Math.floor(Date.now()/1000); // dashboard load time → "listening since" indicator
const SPARK={}; // symbol -> [{t,p}] live price history (client-side, last 60 ticks)
const EQH=[];     // equity history [{t,p}] for the balance sparkline
const LAST_PRICE={}; // symbol -> last rendered price (for tick flash)
// Build an inline SVG sparkline from a [{t,p}] series. trend: 1 up / -1 down / 0 flat (drives color).
function sparkSVG(series,w,h,trend){
  if(!series||series.length<2)return '';
  const ps=series.map(d=>d.p);const min=Math.min(...ps),max=Math.max(...ps);
  const rng=(max-min)||1;const n=series.length;
  const col=trend>0?'var(--pos)':trend<0?'var(--neg)':'var(--mut-2)';
  const uid='sg'+(Math.random().toString(36).slice(2,8));
  const pts=series.map((d,i)=>{const x=(i/(n-1))*w;const y=h-((d.p-min)/rng)*(h-2)-1;return x.toFixed(1)+','+y.toFixed(1);}).join(' ');
  const area='0,'+h+' '+pts+' '+(w)+','+h;
  return '<svg class="spark" viewBox="0 0 '+w+' '+h+'" preserveAspectRatio="none" width="100%" height="'+h+'">'
    +'<defs><linearGradient id="'+uid+'" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="'+col+'" stop-opacity="0.28"/><stop offset="100%" stop-color="'+col+'" stop-opacity="0"/></linearGradient></defs>'
    +'<polygon points="'+area+'" fill="url(#'+uid+')"/>'
    +'<polyline points="'+pts+'" fill="none" stroke="'+col+'" stroke-width="1.8" stroke-linejoin="round" stroke-linecap="round"/></svg>';
}
const $=id=>document.getElementById(id);
function esc(s){s=String(s==null?'':s);return s.replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
function num(v){const n=Number(v);return (v===null||v===undefined||v===''||isNaN(n))?null:n;}
function fmt(n){n=num(n);if(n===null)return '—';const a=Math.abs(n);if(a>=1)return n.toLocaleString(undefined,{maximumFractionDigits:2});return n.toFixed(4);}
function fmtSigned(n){n=num(n);if(n===null)return '—';return (n>=0?'+':'')+fmt(n);}
function logTime(ts){const d=ts?new Date(ts*1000):new Date();return d.toLocaleTimeString([],{hour12:false});}
function clsOf(v){const n=num(v);if(n===null)return '';if(n>0)return 'pos';if(n<0)return 'neg';return '';}
function setConn(live){const dot=document.querySelector('#conn .dot');const txt=$('connText');if(live){dot.className='dot live';txt.textContent='live';}else{dot.className='dot';txt.textContent='reconnecting…';}}

// ── auth (control actions only; monitoring is open) ──
function setModeUI(paper){const m=$('mode');m.textContent=paper?'PAPER':'LIVE';m.className='pill '+(paper?'paper':'live');const m2=$('mode2');if(m2){m2.textContent=paper?'PAPER':'LIVE';m2.className='pill '+(paper?'paper':'live');}}
// Ask for the dashboard password only when the user actually acts on the bot.
function askPw(){return prompt('Enter dashboard password to control the bot:');}
function withPw(body){const pw=askPw();if(pw===null)return null;return Object.assign({},body,{password:pw});}
$('logoutBtn').onclick=()=>{location.reload();};

// ── tabs ──
function showTab(name){
  document.querySelectorAll('.tab-pane').forEach(p=>p.classList.toggle('active', p.id==='tab-'+name));
  document.querySelectorAll('.tab').forEach(t=>t.classList.toggle('active', t.dataset.tab===name));
  try{localStorage.setItem('dash_tab',name);}catch(e){}
}
document.querySelectorAll('.tab').forEach(t=>t.onclick=()=>showTab(t.dataset.tab));
try{const saved=localStorage.getItem('dash_tab');if(saved)showTab(saved);}catch(e){}

// ── websocket ──
function startWS(){
  try{ws=new WebSocket(WSS);}catch(e){setConn(false);return;}
  ws.onopen=()=>{setConn(true);if(AUTH_TOKEN){ws.send(JSON.stringify({auth:AUTH_TOKEN}));}};
  ws.onmessage=ev=>{try{const d=JSON.parse(ev.data);if(d.type==='auth'&&d.error){location.reload();return;}pushEvent(d);}catch(e){}};
  ws.onclose=()=>{setConn(false);setTimeout(startWS,2500);};
  ws.onerror=()=>{setConn(false);};
}

function pushEvent(ev){/* events augment logs/activities live */
  const t=ev.type||'event';const cls=LOG_CLS[t]||'mut';
  // logs
  const lg=$('logs');if(lg){const line=document.createElement('div');line.className='log-line';
    line.innerHTML='<span class="t">'+logTime(Math.floor(Date.now()/1000))+'</span><span class="tag '+cls+'">'+esc(TAG_LABEL[t]||t)+'</span><span class="msg">'+esc(actMsg(t,ev.data))+'</span>';
    lg.prepend(line);if(lg.children.length>200)lg.removeChild(lg.lastChild);}
}

// ── polling snapshot ──
async function refresh(){
  try{const r=await fetch('/api/snapshot');const s=await r.json();renderSnapshot(s);}catch(e){}
  setTimeout(refresh,5000);
}
function renderSnapshot(s){
  if(!s)return;
  // ── accumulate sparkline history from the live poll stream ──
  const now=Date.now();
  Object.keys(s.market||{}).forEach(sym=>{const p=num(s.market[sym].price);if(p==null)return;
    if(!SPARK[sym])SPARK[sym]=[];const h=SPARK[sym];h.push({t:now,p:p});if(h.length>60)h.shift();});
  const eq=(s.balance&&s.balance.equity!=null)?s.balance.equity:null;
  if(eq!=null){EQH.push({t:now,p:eq});if(EQH.length>60)EQH.shift();}
  const paper=!!s.paper;setModeUI(paper);
  if($('ms_mode'))$('ms_mode').textContent=paper?'PAPER':'LIVE';
  if($('ms_watch'))$('ms_watch').textContent=(s.market&&Object.keys(s.market).length)+' pairs';
  if($('ms_upd'))$('ms_upd').textContent=logTime(Math.floor(Date.now()/1000));
  const st=s.stats||{};
  const bal=(s.balance&&s.balance.equity!=null)?s.balance.equity:0;
  if($('k_equity'))$('k_equity').textContent=fmt(bal);
  $('k_balance').textContent=fmt((s.balance&&s.balance.available!=null)?s.balance.available:0);
  if($('k_balance_spark'))$('k_balance_spark').innerHTML=sparkSVG(EQH,120,26,EQH.length>1?(EQH[EQH.length-1].p>=EQH[0].p?1:-1):0);
  $('k_pnl').textContent=fmtSigned(st.net_pnl);$('k_pnl').className='kpi-value num '+clsOf(st.net_pnl);
  $('k_pos').textContent=st.open_positions!=null?st.open_positions:(s.positions?s.positions.length:0);
  $('k_wr').textContent=st.win_rate?st.win_rate+'%':'—';$('k_wr').classList.toggle('muted',!st.win_rate);
  $('k_pf').textContent=st.profit_factor?st.profit_factor:'—';$('k_pf').classList.toggle('muted',!st.profit_factor);
  $('k_dd').textContent=st.max_drawdown?fmt(st.max_drawdown):'—';$('k_dd').classList.toggle('muted',!st.max_drawdown);
  $('k_trades').textContent=st.total_trades||0;
  const mk=$('market');mk.innerHTML='';const m=s.market||{};
  Object.keys(m).forEach(sym=>{const d=m[sym]||{};const chg=num(d.change24h)||0;
    const tile=document.createElement('div');tile.className='mkt';
    const spark=sparkSVG(SPARK[sym],120,34,chg>=0?1:-1);
    const pr=d.price;
    let flash='';
    if(LAST_PRICE[sym]!=null && pr!=null && pr!==LAST_PRICE[sym]) flash=' flash-'+(pr>LAST_PRICE[sym]?'up':'down');
    LAST_PRICE[sym]=pr;
    tile.innerHTML='<div class="mkt-top"><span class="mkt-sym">'+esc(sym)+'</span><span class="mkt-chg '+(chg>=0?'pos':'neg')+'">'+(chg>=0?'+':'')+(chg).toFixed(2)+'%</span></div>'
      +'<div class="mkt-price num'+flash+'">'+fmt(pr)+'</div>'
      +'<div class="mkt-spark">'+(spark||'<div class="mkt-flat"></div>')+'</div>';
    mk.appendChild(tile);});
  if(!Object.keys(m).length){mk.innerHTML='<div class="empty">loading prices…</div>';}
  const pos=s.positions||[];$('posCount').textContent=pos.length;
  if(pos.length){const tb=$('positionsBody');tb.innerHTML='';pos.forEach(p=>{
      const tr=document.createElement('tr');
      tr.innerHTML='<td class="sym">'+esc(p.symbol)+'</td><td><span class="side '+(p.direction||'').toLowerCase()+'\">'+(p.direction||'')+'</span></td><td class="num">'+fmt(p.size)+'</td><td class="num">'+fmt(p.entry)+'</td><td class="num">'+fmt(p.mark)+'</td><td class="num">'+fmt(p.liq_price)+'</td><td class="num '+clsOf(p.pnl)+'">'+fmtSigned(p.pnl)+'</td>'+'<td class="num '+clsOf(p.pnl)+'">'+(p.pnl!=null&&p.entry&&p.size?((p.pnl/(p.entry*p.size)*100).toFixed(2)+'%'):'—')+'</td>'+'<td><button class="btn danger sm" data-close="'+esc(p.symbol)+'">Close</button></td>';
      tb.appendChild(tr);});
    $('positionsTable').style.display='';$('posEmpty').style.display='none';
  } else {$('positionsTable').style.display='none';$('posEmpty').style.display='';}
  // recent trades (real data from s.trades, when present)
  const tb2=$('tradesBody');const trs=(s.trades||[]).slice(0,30);
  if(trs.length){tb2.innerHTML='';trs.forEach(t=>{const tr=document.createElement('tr');
    tr.innerHTML='<td class="num">'+logTime(t.close_ts||t.ts)+'</td><td class="sym">'+esc(t.symbol)+'</td><td class="num '+(clsOf(t.pnl))+'">'+fmtSigned(t.pnl)+'</td>';
    tb2.appendChild(tr);});}else{tb2.innerHTML='<tr><td colspan="3"><div class="empty"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 1 0 18 0 9 9 0 0 0-18 0"/><path d="M12 7v5l3 2"/></svg><span>No closed trades yet.<span class="e-sub"> Fills &amp; exits show here.</span></span></div></td></tr>';}
  const acts=$('activities');acts.innerHTML='';(s.activities||[]).slice().reverse().forEach(a=>{
    const t=a.type||'event';let cls=LOG_CLS[t]||'mut';
    // failures get a red 'fail' class on the row + dot so rejections stand out
    const failed = (a.data && a.data.ok===false) || cls==='err';
    if(failed) cls='err';
    const row=document.createElement('div');row.className='act-row'+(failed?' fail':'');
    row.innerHTML='<span class="act-dot '+cls+'"></span><div class="act-body"><div class="act-head"><span class="tag '+cls+'">'+esc(TAG_LABEL[t]||t)+'</span><span class="ts">'+logTime(a.ts)+'</span></div><div class="act-msg">'+esc(actMsg(t,a.data))+'</div></div>';
    acts.appendChild(row);});
  const lg=$('logs');if(!s._booted){}
  $('s_total').textContent=st.total_trades||0;$('s_wl').textContent=(st.wins||0)+' / '+(st.losses||0);
  $('s_wr').textContent=st.win_rate?st.win_rate+'%':'—';$('s_pf').textContent=st.profit_factor?st.profit_factor:'—';
  $('s_exp').textContent=st.expectancy?fmt(st.expectancy):'—';$('s_dd').textContent=st.max_drawdown?fmt(st.max_drawdown):'—';
  $('s_open').textContent=st.open_positions!=null?st.open_positions:pos.length;$('s_net').textContent=fmtSigned(st.net_pnl);
  $('health').textContent='poll 5s · listening since '+logTime(BOOT_TS)+' · updated '+logTime(Math.floor(Date.now()/1000));
}
function shortMsg(d){if(!d)return '';if(typeof d==='string')return d;const parts=[];
  ['detail','reason','symbol','pair','side','direction','action','status','msg','message','error','order_id','notional','pnl'].forEach(k=>{if(d[k]!=null)parts.push(k+': '+d[k]);});
  return parts.slice(0,6).join(' · ')||JSON.stringify(d).slice(0,160);}
// Human-readable tag chips + activity messages (no raw JSON dumps)
const TAG_LABEL={
  SignalReceived:'SIGNAL', AttachmentScalp:'SCALP', DecisionCreated:'DECISION',
  PositionOpened:'OPEN', PositionModified:'MODIFY', PositionClosed:'CLOSE',
  TP1PartialExit:'TP1', TriggerEntered:'TRIGGER', ConditionalSignalSaved:'COND',
  BiasRead:'BIAS', VisionError:'VISION', OrderFailed:'FAIL', OrderError:'FAIL',
  ValidationError:'FAIL', ManualOrder:'MANUAL', ManualClose:'MANUAL', ModeToggle:'MODE'
};
function actMsg(type,d){d=d||{};const g=k=>d[k];
  switch(type){
    case 'SignalReceived': return 'New signal'+(g('channel')?(' from @'+g('channel')):'');
    case 'DecisionCreated': return (g('pair')?('Decision: '+g('pair')+' '+(g('direction')||g('side')||'')):'Decision created');
    case 'AttachmentScalp': {const s2=g('pair')||g('symbol');return 'Chart scalp'+(s2?(' · '+s2+' '+(g('side')||'')):'')+(g('action')?(' → '+g('action')):'');}
    case 'PositionOpened': return 'Opened '+(g('symbol')||g('pair')||'position');
    case 'PositionModified': return 'Modified '+(g('symbol')||g('pair')||'position');
    case 'PositionClosed': return 'Closed '+(g('symbol')||g('pair')||'position');
    case 'TP1PartialExit': return 'TP1 partial exit · '+(g('symbol')||g('pair')||'');
    case 'TriggerEntered': {const s2=g('symbol')||g('pair');return 'Trigger entered'+(s2?(' · '+s2):'');}
    case 'ConditionalSignalSaved': return 'Conditional signal saved';
    case 'BiasRead': return 'Bias read';
    case 'VisionError': return 'Vision error'+(g('detail')?(': '+g('detail')):'');
    case 'OrderFailed': return 'Order rejected'+(g('detail')?(': '+g('detail')):(g('reason')?(': '+g('reason')):''));
    case 'OrderError': return 'Order error'+(g('detail')?(': '+g('detail')):(g('reason')?(': '+g('reason')):''));
    case 'ValidationError': return 'Validation failed'+(g('detail')?(': '+g('detail')):(g('reason')?(': '+g('reason')):''));
    case 'ManualOrder': return (g('ok')===false?('Manual order failed'+(g('detail')?(': '+g('detail')):'')):('Manual order'+( (g('symbol')||g('pair'))?(' · '+(g('symbol')||g('pair'))+' '+(g('side')||'')):'')));
    case 'ManualClose': return 'Manual close · '+(g('symbol')||g('pair')||'');
    case 'ModeToggle': return 'Mode → '+(g('mode')||g('to')||g('target')||'changed');
    default: return shortMsg(d);
  }
}

// ── symbols autocomplete ──
let symCache=[];
async function loadSymbols(){
  try{const r=await fetch('/api/symbols?q=');const d=await r.json();symCache=d.symbols||[];
    const dl=$('pairlist');dl.innerHTML=symCache.slice(0,200).map(s=>'<option value="'+esc(s)+'">').join('');
  }catch(e){}
}
// live filter on input
$('c_pair').addEventListener('input',async function(){
  const q=this.value;const r=await fetch('/api/symbols?q='+encodeURIComponent(q));const d=await r.json();
  $('pairlist').innerHTML=(d.symbols||[]).slice(0,200).map(s=>'<option value="'+esc(s)+'">').join('');
  calcNotional();
});
['c_entry','c_margin','c_lev'].forEach(id=>$(id).addEventListener('input',calcNotional));
function calcNotional(){
  const entry=num($('c_entry').value),margin=num($('c_margin').value)||0,lev=num($('c_lev').value||1)||1;
  const notional=margin*lev;const qty=entry>0?notional/entry:0;
  $('c_calc').innerHTML='notional <b>$'+(notional?notional.toFixed(2):'0.00')+'</b> · qty <b>'+(qty?qty.toFixed(4):'0')+'</b> '+(entry>0?'@ '+entry:'')+'<br><span style="opacity:.8">leverage auto-clamped to pair cap; notional bumped to meet MIN_NOTIONAL</span>';
}

// ── place order ──
$('c_submit').onclick=async()=>{const out=$('c_out');out.className='out';out.textContent='placing…';
  const base={pair:$('c_pair').value,side:$('c_side').value,entry:num($('c_entry')),sl:num($('c_sl')),tp:num($('c_tp')),margin:num($('c_margin')),leverage:num($('c_lev'))};
  const body=withPw(base);if(!body){out.textContent='cancelled';return;}
  const r=await fetch('/api/order',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
  const d=await r.json();out.className='out '+(d.ok?'ok':'err');out.textContent=JSON.stringify(d,null,2);refresh();
};
$('c_clear').onclick=()=>{['c_pair','c_entry','c_sl','c_tp','c_margin','c_lev'].forEach(id=>$(id).value='');$('c_out').textContent='';};
// mode toggle
$('c_topaper').onclick=async()=>{const body=withPw({mode:'paper'});if(!body)return;
  const r=await fetch('/api/mode',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});const d=await r.json();$('c_out').className='out '+(d.ok?'ok':'err');$('c_out').textContent=JSON.stringify(d,null,2);};
$('c_tolive').onclick=async()=>{if(!confirm('Switch to LIVE trading? Real funds at risk.'))return;const body=withPw({mode:'binance'});if(!body)return;
  const r=await fetch('/api/mode',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});const d=await r.json();$('c_out').className='out '+(d.ok?'ok':'err');$('c_out').textContent=JSON.stringify(d,null,2);};
// close buttons (delegated)
$('positionsBody').addEventListener('click',async e=>{const b=e.target.closest('[data-close]');if(!b)return;const sym=b.getAttribute('data-close');if(!confirm('Close '+sym+'?'))return;
  const body=withPw({symbol:sym});if(!body)return;
  const r=await fetch('/api/close',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});const d=await r.json();$('c_out').className='out '+(d.ok?'ok':'err');$('c_out').textContent=JSON.stringify(d,null,2);refresh();});
// flatten all (safety): close every open position
$('c_flatten').onclick=async()=>{if(!confirm('FLATTEN ALL — close every open position now?'))return;
  const r=await fetch('/api/snapshot');const s=await r.json();const pos=(s.positions||[]);
  if(!pos.length){$('c_out').className='out';$('c_out').textContent='nothing to close (no open positions)';return;}
  const pw=askPw();if(pw===null)return;let ok=0,fail=0,msg=[];
  for(const p of pos){const body={symbol:p.symbol,password:pw};
    const rr=await fetch('/api/close',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});const d=await rr.json();
    if(d.ok)ok++;else{fail++;msg.push(p.symbol+': '+(d.error||'failed'));}}
  $('c_out').className='out '+(fail?'err':'ok');
  $('c_out').textContent='Flatten: closed '+ok+(fail?(' · failed '+fail+' ('+msg.join('; ')+')'):'');refresh();};

// ── parse sandbox ──
$('sandboxRun').onclick=async()=>{const r=await fetch('/api/parse',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({text:$('sandboxText').value})});const d=await r.json();$('sandboxOut').textContent=JSON.stringify(d,null,2);};
$('sandboxClear').onclick=()=>{$('sandboxText').value='';$('sandboxOut').textContent='';};

// ── start: open dashboard, no login gate ──
function start(){
  startWS();
  loadSymbols();
  refresh(); // first refresh() populates mode + all KPIs/market from snapshot
}
start();
})();
</script>
</body>
</html>"""
