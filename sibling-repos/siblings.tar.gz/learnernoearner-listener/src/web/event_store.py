"""Postgres-backed event persistence for the dashboard.

The dashboard's live activity/log streams live only in RAM (a deque), so every
restart wipes the signal/decision/order history. This module persists each
ingested event to the Sera Postgres instance (fatty_config.bot_events) and can
reload recent events on startup so the timeline survives restarts.

All DB work is best-effort: a failure must NEVER break the dashboard. Writes run
from the dashboard's own background thread (never the request path).
"""
from __future__ import annotations

import json
import logging
import os
import threading
from datetime import datetime, timezone

log = logging.getLogger("web.event_store")

try:
    import pg8000
except Exception as exc:  # noqa: BLE001
    pg8000 = None
    log.warning("event_store: pg8000 unavailable (%s) — events will not be persisted", exc)

_PW_FILE = os.path.expanduser("~/.pg_app_pw")
_DEFAULT_URL = "postgresql://app:***@127.0.0.1:5432/fatty_config"

_lock = threading.Lock()
_conn = None
_enabled = False


def _build_conn_kwargs() -> dict | None:
    """Resolve pg8000 connection kwargs. Prefer CONFIG_DB_URL when valid; else
    build from the app role + ~/.pg_app_pw."""
    raw = os.environ.get("CONFIG_DB_URL", "").strip()
    if raw and "***" not in raw and raw.startswith("postgresql://"):
        # parse postgresql://user:pass@host:port/db
        from urllib.parse import urlparse
        u = urlparse(raw)
        return {
            "host": u.hostname or "127.0.0.1",
            "port": u.port or 5432,
            "user": u.username or "app",
            "password": u.password or "",
            "database": u.path.lstrip("/") or "fatty_config",
        }
    try:
        pw = open(_PW_FILE).read().strip()
    except Exception:  # noqa: BLE001
        pw = None
    if not pw:
        return None
    return {"host": "127.0.0.1", "port": 5432, "user": "app", "password": pw, "database": "fatty_config"}


def init_event_store() -> bool:
    """Create the table if needed. Returns True if persistence is available."""
    global _enabled, _conn
    if pg8000 is None:
        return False
    kwargs = _build_conn_kwargs()
    if not kwargs:
        log.warning("event_store: no DSN available — persistence disabled")
        return False
    try:
        with _lock:
            c = pg8000.connect(**kwargs)
            cur = c.cursor()
            cur.execute(
                "CREATE TABLE IF NOT EXISTS bot_events ("
                " id bigserial PRIMARY KEY, ts bigint NOT NULL, iso text NOT NULL,"
                " bot text NOT NULL DEFAULT 'learnernoearner', type text NOT NULL,"
                " ok boolean NOT NULL DEFAULT true, detail text NOT NULL DEFAULT '',"
                " payload jsonb NOT NULL DEFAULT '{}'::jsonb)"
            )
            cur.execute("CREATE INDEX IF NOT EXISTS idx_bot_events_ts ON bot_events (ts DESC)")
            cur.execute("CREATE INDEX IF NOT EXISTS idx_bot_events_type ON bot_events (type)")
            c.commit()
            c.close()
        _enabled = True
        log.info("event_store: connected + table ready")
        return True
    except Exception as exc:  # noqa: BLE001
        log.error("event_store: init failed (%s) — persistence disabled", exc)
        _enabled = False
        return False


def _get_conn():
    global _conn
    if _conn is None:
        kwargs = _build_conn_kwargs()
        if not kwargs:
            return None
        _conn = pg8000.connect(**kwargs)
    return _conn


def save_event(rec: dict) -> None:
    """Persist one event record. No-op if disabled or on any error."""
    if not _enabled or pg8000 is None:
        return
    try:
        ts = int(rec.get("ts") or rec.get("data", {}).get("ts", 0) or 0)
        if not ts:
            ts = int(__import__("time").time())
        iso = datetime.fromtimestamp(ts, tz=timezone.utc).isoformat()
        etype = rec.get("type", "event")
        data = rec.get("data", {}) or {}
        ok = bool(data.get("ok", True)) if isinstance(data, dict) else True
        detail = str(data.get("detail", ""))[:2000]
        payload = json.dumps(data, default=str)
        with _lock:
            c = _get_conn()
            cur = c.cursor()
            cur.execute(
                "INSERT INTO bot_events (ts, iso, bot, type, ok, detail, payload)"
                " VALUES (%s, %s, 'learnernoearner', %s, %s, %s, %s)",
                (ts, iso, etype, ok, detail, payload),
            )
            c.commit()
    except Exception as exc:  # noqa: BLE001
        # never let a DB hiccup break the dashboard
        log.warning("event_store: save failed (%s)", exc)
        global _conn
        _conn = None  # force reconnect next time


def load_recent(limit: int = 200) -> list[dict]:
    """Return recent events (newest first) as dashboard activity records."""
    if not _enabled or pg8000 is None:
        return []
    try:
        with _lock:
            c = _get_conn()
            cur = c.cursor()
            cur.execute(
                "SELECT ts, type, ok, detail, payload FROM bot_events"
                " ORDER BY ts DESC LIMIT %s",
                (limit,),
            )
            rows = cur.fetchall()
        out = []
        for ts, etype, ok, detail, payload in rows:
            try:
                data = json.loads(payload) if payload else {}
            except Exception:  # noqa: BLE001
                data = {}
            if not isinstance(data, dict):
                data = {}
            data.setdefault("ok", ok)
            if detail and "detail" not in data:
                data["detail"] = detail
            out.append({"ts": ts, "type": etype, "data": data})
        return out
    except Exception as exc:  # noqa: BLE001
        log.warning("event_store: load failed (%s)", exc)
        global _conn
        _conn = None
        return []
