"""Dashboard state aggregator for the learnernoearner Web UI.

Folds pipeline events (signals, decisions, fills, positions, attachment/scalp
reads, BTC-bias reads) into live logs + activities streams, polls market prices
from Binance public futures ticker, and (when a live exchange is present) pulls
balance/positions so the dashboard reflects real account state even in paper mode.

Design notes:
- This module is intentionally decoupled from the bot's event bus. It exposes a
  single ``publish(event_dict)`` entry point; ``main.py`` subscribes a thin
  adapter to the bot's ``EventBus`` and forwards each ``Event`` here.
- All network/IO is defensive: a failed poll never crashes the loop.
- Market prices use Binance *public* REST (no auth, works from any region);
  failures degrade to a soft '—' rather than breaking the UI.
"""

from __future__ import annotations

import os
import time
import threading
from collections import deque
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

log = __import__("logging").getLogger("web.dashboard_state")

# Postgres-backed event persistence (so activities/signals survive restarts).
try:
    from .event_store import init_event_store, save_event, load_recent
except Exception:  # noqa: BLE001
    init_event_store = lambda: False  # type: ignore
    save_event = lambda rec: None  # type: ignore
    load_recent = lambda limit=200: []  # type: ignore

# Activity event types we surface in the timeline (everything else is logged only)
# Failures are included on purpose: the timeline must show WHY a trade didn't
# fill (e.g. "INJUSDT order failed: Margin insufficient"), not just successes.
ACTIVITY_TYPES = {
    "SignalReceived", "AttachmentScalp", "DecisionCreated",
    "PositionOpened", "PositionModified", "PositionClosed",
    "TP1PartialExit", "TriggerEntered", "ConditionalSignalSaved",
    "BiasRead", "VisionError",
    # trade execution outcomes (success + failure) — surfaced so the user sees
    # both fills AND rejections (insufficient margin, validation, API errors)
    "OrderPlaced", "OrderFilled", "OrderFailed", "OrderError",
    "ValidationError", "ManualOrder", "ManualClose", "ModeToggle",
}
# Events that should trigger a live account/stat refresh
REFRESH_TYPES = {"PositionOpened", "PositionModified", "PositionClosed",
                 "TP1PartialExit", "TriggerEntered", "ManualClose"}

# Tag classes for the activity/log rows
LOG_CLS = {
    "SignalReceived": "sig", "AttachmentScalp": "ord", "DecisionCreated": "ord",
    "PositionOpened": "pos", "PositionModified": "pos", "PositionClosed": "fill",
    "TP1PartialExit": "fill", "TriggerEntered": "ord",
    "ConditionalSignalSaved": "warn", "BiasRead": "sig", "VisionError": "warn",
    # failure / rejection surfacing (red) — so the timeline shows why trades
    # didn't fill, not just successes
    "OrderFailed": "err", "OrderError": "err", "ValidationError": "err",
    "ManualOrder": "ord", "ManualClose": "ord", "ModeToggle": "warn",
}


class DashboardState:
    """Aggregates dashboard data from events + exchange + DB."""

    def __init__(
        self,
        exchange=None,
        db_path: str | Path | None = None,
        market_symbols: tuple[str, ...] = ("BTCUSDT", "ETHUSDT", "SOLUSDT", "BNBUSDT"),
        poll_interval: float = 5.0,
        account_poll_interval: float = 15.0,
        paper: bool = True,
        bot_name: str = "learnernoearner",
    ) -> None:
        self.ex = exchange
        self.db_path = Path(db_path) if db_path else None
        self.market_symbols = list(market_symbols)
        self.poll_interval = poll_interval
        self.account_poll_interval = account_poll_interval
        self._last_account_ts = 0.0
        self.paper = paper
        self.bot_name = bot_name

        self.market: dict[str, dict] = {}
        self.spark: dict[str, deque] = {}
        self.positions: list[dict] = []
        self.open_orders: list[dict] = []
        self.balance: dict = {}
        self.activities: deque = deque(maxlen=300)
        self.logs: deque = deque(maxlen=600)
        self.stats = self._empty_stats()
        self._incoming: deque = deque(maxlen=2000)
        self._last_balance = 0.0
        self._stop = False
        self._thread: Optional[threading.Thread] = None
        self._async_loop: Any = None  # private asyncio loop for sync-thread exchange calls

        # ── Binance REST rate-limit guard ────────────────────────────────────
        # The bot's exchange adapter already protects its own traffic (WS market
        # data = zero REST weight, ban-aware batched refresh, circuit breaker).
        # The dashboard piggybacks on that adapter when present. This guard is a
        # last-resort IP-ban backoff: if ANY Binance REST call 429/418s, we stop
        # hitting public endpoints entirely for a cooling-off window so the Sera
        # IP is never pushed into a hard ban.
        self._binance_cool_until: float = 0.0  # epoch seconds; REST paused until then
        self._market_cache: dict[str, tuple[float, float, float]] = {}  # sym -> (price, chg, ts)
        self._market_cache_ttl: float = 30.0  # serve cached prices; don't re-hit Binance

    # ─── public ingest ─────────────────────────────────────────────────────
    def publish(self, event: dict) -> None:
        """Accept an event dict from the bot's event bus adapter."""
        self._incoming.append(event)

    @staticmethod
    def _empty_stats():
        return {
            "total_trades": 0, "wins": 0, "losses": 0, "win_rate": 0.0,
            "net_pnl": 0.0, "profit_factor": 0.0, "expectancy": 0.0,
            "max_drawdown": 0.0, "avg_hold": 0.0, "open_positions": 0,
            "balance": 0.0, "equity": 0.0,
        }

    # ─── lifecycle ─────────────────────────────────────────────────────────
    def start(self):
        if self._thread and self._thread.is_alive():
            return
        self._stop = False
        # Bring Postgres-backed persistence online (best-effort) and replay the
        # last N events so the activity timeline survives restarts.
        try:
            if init_event_store():
                hist = load_recent(200)
                # oldest -> newest so order matches the live stream
                for rec in reversed(hist):
                    if rec.get("type") in ACTIVITY_TYPES:
                        self.activities.append(rec)
                    self.logs.append(rec)
                if hist:
                    log.info("event_store: replayed %d historical events", len(hist))
        except Exception:  # noqa: BLE001
            pass
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()

    def stop(self):
        self._stop = True

    def _loop(self):
        while not self._stop:
            try:
                self._loop_once()
            except Exception:  # noqa: BLE001
                log.exception("dashboard loop error")
            time.sleep(self.poll_interval)

    def _loop_once(self):
        # fold queued events
        while self._incoming:
            self._ingest_event(self._incoming.popleft())
        # poll market (fast, public REST)
        self._poll_market()
        # poll account (throttled)
        self._poll_account()
        # refresh DB-backed stats
        self._refresh_stats()

    # ─── event ingestion ──────────────────────────────────────────────────
    def _ingest_event(self, ev: dict):
        now = int(time.time())
        etype = ev.get("type") or ev.get("event_type") or "event"
        payload = ev.get("payload", ev)
        if isinstance(payload, dict) is False:
            payload = {"detail": str(payload)}
        rec = {"ts": now, "type": etype, "data": payload}
        self.logs.append(rec)
        if etype in ACTIVITY_TYPES:
            self.activities.append(rec)
        # persist to Postgres so the timeline survives restarts (best-effort)
        try:
            save_event(rec)
        except Exception:  # noqa: BLE001
            pass
        # force an account refresh when something trade-related happened
        if etype in REFRESH_TYPES:
            self._last_account_ts = 0.0

    # ─── polling ───────────────────────────────────────────────────────────
    def _poll_market(self):
        now = time.time()
        # If we're in a Binance cooling-off window (a 429/418 hit us), serve the
        # cached last-known prices and skip all REST. This is the key guard that
        # keeps the Sera IP from being pushed into a hard IP ban.
        cooling = now < self._binance_cool_until
        for sym in self.market_symbols:
            try:
                px, chg = self._market_price(sym, cooling=cooling)
                if px:
                    self.market[sym] = {"price": px, "ts": int(now), "change24h": chg}
                    sp = self.spark.setdefault(sym, deque(maxlen=60))
                    sp.append({"ts": int(now), "price": px})
            except Exception:  # noqa: BLE001
                pass

    def _market_price(self, sym: str, cooling: bool = False):
        """Return (price, change24h_pct), preferring cached data.

        Priority:
        1. Fresh local cache (TTL) — avoids any network hit.
        2. Exchange adapter's get_ticker() — protected path (WS cache / ban-aware
           batched refresh). Reuses the bot's own rate-limit circuitry.
        3. Raw public REST fallback (only when no exchange), with a 30s cache so
           we never exceed ~2 requests/min/symbol, and skipped entirely while
           cooling off after a 429/418.
        """
        now = time.time()
        cached = self._market_cache.get(sym)
        if cached and (now - cached[2]) < self._market_cache_ttl:
            return cached[0], cached[1]
        if cooling:
            # serve stale cache rather than re-hitting the banned endpoint
            return (cached[0], cached[1]) if cached else (0.0, 0.0)

        # Path 2: exchange adapter (protected)
        ex = self.ex
        if ex is not None and hasattr(ex, "get_ticker"):
            try:
                t = self._run_async(ex.get_ticker(sym))
                if t is not None and getattr(t, "error", None) is None:
                    px = float(getattr(t, "last_price", 0) or 0)
                    chg = float(getattr(t, "change_pct_24h", 0) or 0)
                    if px:
                        self._market_cache[sym] = (px, chg, now)
                        return px, chg
                elif t is not None and getattr(t, "error", None):
                    self._note_binance_cool(t.error)
            except Exception:  # noqa: BLE001
                pass

        # Path 3: raw public REST fallback (no exchange). Cache + ban-aware.
        px, chg = self._fetch_public_price(sym)
        if px:
            self._market_cache[sym] = (px, chg, now)
        return px, chg

    def _note_binance_cool(self, err_text: str):
        """If a Binance rate-limit/ban signal shows up, pause REST briefly."""
        low = (err_text or "").lower()
        if any(k in low for k in ("429", "418", "banned", "too many", "rate limit", "ip")):
            self._binance_cool_until = max(self._binance_cool_until, time.time() + 60.0)

    @staticmethod
    def _fetch_public_price(sym: str):
        """Return (price, change24h_pct) from Binance public futures ticker.

        Fallback only (used when no exchange adapter is present). Callers cache
        the result for 30s via _market_price, so this fires at most ~2/min/symbol.
        """
        import httpx
        url = f"https://fapi.binance.com/fapi/v1/ticker/24hr?symbol={sym.upper()}"
        try:
            r = httpx.get(url, timeout=8)
            if r.status_code in (429, 418):
                return 0.0, 0.0  # signal caller to cool off (handled upstream)
            d = r.json() or {}
            if isinstance(d, list):
                d = d[0] if d else {}
            last = d.get("lastPrice") or d.get("closePrice")
            chg = d.get("priceChangePercent")
            return float(last), float(chg) if chg is not None else 0.0
        except Exception:  # noqa: BLE001
            return 0.0, 0.0

    def _run_async(self, coro):
        """Run an async coroutine to completion from the sync poll thread.

        Exchange adapters expose ``async def`` methods (get_balance /
        get_positions). The dashboard polls from a background thread, so we run
        those coroutines on a dedicated private loop rather than blocking the bot's
        event loop. The loop is created lazily and reused.
        """
        loop = getattr(self, "_async_loop", None)
        if loop is None or loop.is_closed():
            import asyncio
            loop = asyncio.new_event_loop()
            self._async_loop = loop
        return loop.run_until_complete(coro)

    def _poll_account(self):
        now = time.time()
        if now - self._last_account_ts < self.account_poll_interval:
            return
        self._last_account_ts = now
        # During a Binance cooling-off window, skip account REST entirely.
        if now < self._binance_cool_until:
            return
        ex = self.ex
        if ex is None:
            return
        # balance
        try:
            bal = self._run_async(ex.get_balance())
            if bal is not None:
                total = getattr(bal, "total_usdt", 0.0) or 0.0
                free = getattr(bal, "free_usdt", 0.0) or 0.0
                self.balance = {
                    "equity": float(total),
                    "available": float(free),
                    "currency": "USDT",
                }
                self._last_balance = float(total)
        except Exception:  # noqa: BLE001
            pass
        # positions
        try:
            positions = self._run_async(ex.get_positions())
            out = []
            for p in positions:
                out.append({
                    "symbol": getattr(p, "symbol", ""),
                    "direction": getattr(p, "direction", ""),
                    "size": float(getattr(p, "size", 0.0) or 0.0),
                    "entry": float(getattr(p, "entry_price", 0.0) or 0.0),
                    "mark": float(getattr(p, "mark_price", 0.0) or 0.0),
                    "liq_price": float(getattr(p, "liquidation_price", 0.0) or 0.0),
                    "pnl": float(getattr(p, "unrealized_pnl", 0.0) or 0.0),
                    "leverage": int(getattr(p, "leverage", 1) or 1),
                    "margin": float(getattr(p, "margin", 0.0) or 0.0),
                    "status": "OPEN",
                })
            self.positions = out
        except Exception:  # noqa: BLE001
            pass

    # ─── DB-backed stats ──────────────────────────────────────────────────
    def _refresh_stats(self):
        if self.db_path is None or not self.db_path.exists():
            # fall back to in-memory (positions pulled from exchange)
            self._stats_from_positions()
            self.stats["open_positions"] = len(self.positions)
            self.stats["balance"] = self._last_balance
            self.stats["equity"] = self._last_balance
            return
        try:
            import sqlite3
            conn = sqlite3.connect(str(self.db_path))
            conn.row_factory = sqlite3.Row
            try:
                rows = conn.execute(
                    "SELECT pnl, status FROM positions WHERE pnl IS NOT NULL"
                ).fetchall()
            finally:
                conn.close()
            trades = [float(r["pnl"]) for r in rows]
            total = len(trades)
            wins = sum(1 for t in trades if t > 0)
            losses = sum(1 for t in trades if t < 0)
            gross_win = sum(t for t in trades if t > 0)
            gross_loss = abs(sum(t for t in trades if t < 0))
            net = gross_win - gross_loss
            wr = (wins / total * 100.0) if total else 0.0
            pf = (gross_win / gross_loss) if gross_loss else (gross_win if gross_win else 0.0)
            exp = (net / total) if total else 0.0
            self.stats = {
                "total_trades": total, "wins": wins, "losses": losses,
                "win_rate": round(wr, 2), "net_pnl": round(net, 2),
                "profit_factor": round(pf, 2), "expectancy": round(exp, 2),
                "max_drawdown": self.stats.get("max_drawdown", 0.0),
                "avg_hold": 0.0,
                "open_positions": len(self.positions),
                "balance": self._last_balance,
                "equity": self._last_balance,
            }
        except Exception:  # noqa: BLE001
            self._stats_from_positions()

    def _stats_from_positions(self):
        trades = [p["pnl"] for p in self.positions if p.get("pnl")]
        total = len(trades)
        wins = sum(1 for t in trades if t > 0)
        losses = sum(1 for t in trades if t < 0)
        net = sum(trades)
        wr = (wins / total * 100.0) if total else 0.0
        self.stats = {
            "total_trades": total, "wins": wins, "losses": losses,
            "win_rate": round(wr, 2), "net_pnl": round(net, 2),
            "profit_factor": 0.0, "expectancy": 0.0, "max_drawdown": 0.0,
            "avg_hold": 0.0, "open_positions": len(self.positions),
            "balance": self._last_balance, "equity": self._last_balance,
        }

    # ─── snapshot for the UI ───────────────────────────────────────────────
    def snapshot(self) -> dict:
        return {
            "paper": 1 if self.paper else 0,
            "bot": self.bot_name,
            "market": dict(self.market),
            "spark": {k: list(v) for k, v in self.spark.items()},
            "positions": self.positions,
            "balance": self.balance,
            "open_orders": self.open_orders,
            "stats": self.stats,
            "logs": list(self.logs)[-120:],
            "activities": list(self.activities)[-50:],
            "health": {"ts": int(time.time()), "poll_interval": self.poll_interval},
        }
