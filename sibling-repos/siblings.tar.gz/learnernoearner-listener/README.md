# 🤖 Learnernoearner Signal Listener — Auto-Trade Pipeline

> **Telegram → LLM → Binance Futures.**  
> Real-time signal monitoring, AI-powered analysis, automated execution.

[![Version](https://img.shields.io/badge/version-v115-blue)]()
[![Python](https://img.shields.io/badge/python-3.11%2B-green)]()
[![Docker](https://img.shields.io/badge/deployed-Docker_(VPS)-2496ED)]()
[![Binance](https://img.shields.io/badge/exchange-Binance_Futures-yellow)]()
[![LLM](https://img.shields.io/badge/LLM-mimo--v2.5-orange)]()

---

## 🚀 At a Glance

```mermaid
graph LR
    A[📡 fattyfatclub] --> B[Regex Parse<br/>1ms]
    B --> C[Gate 1<br/>Pre-LLM]
    C --> D[🧠 LLM<br/>mimo-v2.5]
    D --> E[Gate 2<br/>Hard Clamps]
    E --> F[⚡ Order Exec]
    F --> G[📈 Binance Futures]
    F --> H[📱 Telegram Notif]
    G --> I[🛡 Position Monitor<br/>10s loop]
```

| Metric | Value |
|--------|-------|
| **Signal Source** | `@fattyfatclub` (UNKNOWN TRADERS ACADEMY) |
| **Exchange** | Binance USDⓈ-M Futures (isolated margin) |
| **LLM** | OpenCode Go · `mimo-v2.5` |
| **Deploy** | Tencent VPS (sera) · Docker container |
| **Version** | `v116` |
| **Risk** | $5 max pos · 10% risk · 30% daily loss limit |

---

## 🧠 How It Works

### The Pipeline

Every Telegram message flows through **6 stages** in ~2 seconds:

| Stage | What Happens | Cost |
|-------|-------------|------|
| **① Regex Parse** | Extracts pair, direction, SL/TP in ~1ms | Free |
| **② Gate 1** | Idempotency check, cooldown, whitelist | Free |
| **③ LLM Brain** | Analyzes signal, decides ENTER/CLOSE/SKIP | ~1 API call |
| **④ Gate 2** | Clamps position size, leverage, daily loss | Free |
| **⑤ Execution** | LIMIT entry + SL/TP placement | Binance API |
| **⑥ Notification** | Telegram card with full trade details | Free |

> ⚡ **Management commands** (`sl to entry`, `tp1 booked`, `full`, etc.) **skip the LLM entirely** and execute directly in ~200ms.

### Architecture

```
src/
├── main.py                  # Entry point — wires everything
├── orchestrator.py          # Pipeline coordinator
├── listener.py              # Telethon Telegram listener + bot commands
├── agent/
│   ├── parser.py            # Regex signal parser (~1ms)
│   ├── agent.py             # LLM brain (OpenCode Go)
│   └── gate.py              # Safety Gates 1 & 2
├── exchange/
│   ├── base.py              # Abstract exchange interface
│   ├── binance.py           # Binance Futures REST API
│   ├── paper.py             # Paper trading simulator
│   ├── validation.py        # Pre-submission order validation
│   └── symbol_registry.py   # Dynamic symbol cache
├── execution/
│   ├── order_service.py     # Decision → orders + SL/TP
│   └── position_manager.py  # Background 10s monitor loop
├── state/
│   ├── database.py          # SQLite (WAL, auto-migration)
│   └── repositories.py      # Repository pattern (11 repos)
├── api/
│   ├── server.py            # FastAPI (15+ endpoints)
│   ├── auth.py              # API key + HMAC + rate limiter
│   └── webhook.py           # Trade event webhook
├── domain/models.py         # Typed dataclasses
├── events/bus.py            # In-process pub/sub
├── health/reporter.py       # Periodic health checks
└── notifier/telegram.py     # Bot API notifications
```

---

## 📊 Live Stats

| Metric | Value |
|--------|-------|
| **Signals Processed** | 160+ |
| **Trades Executed** | 21 |
| **Currently Open** | PUMPUSDT LONG · AAVEUSDT LONG |
| **Most Traded** | KAITOUSDT (5×) · 1000BONKUSDT (3×) · PUMPUSDT (2×) |
| **Management Commands** | 50+ |
| **Database** | SQLite · 14 tables · `/data/trades.db` |

---

## 🛡️ Safety Architecture

Three independent layers — **no single component can override the hard limits**:

### Gate 1 (Pre-LLM)
- ✅ Idempotency — same `message_id` never processed twice
- ✅ Cooldown — 5min minimum gap per pair
- ✅ Whitelist — restrict to approved pairs

### Gate 2 (Post-LLM)
- 🛑 Max position: **$5** hard cap
- 🛑 Max concurrent: **10** positions
- 🛑 Daily loss limit: **30%**
- 🛑 Leverage ceiling: **20×**
- 🛑 SL direction validation
- 🛑 Portfolio leverage cap: **10×**

### Position Manager (10s loop)
- 🔄 Price-based SL monitoring (for -4120 pairs)
- 🔄 Self-heal — re-attaches missing SL/TP
- 🔄 Orphan detection — verifies against exchange
- 🔄 Time-based exit — auto-closes after 48h
- 📱 Telegram notification on every close

---

## 💬 Bot Commands

Send these as private messages to your bot:

| Command | Description |
|---------|-------------|
| `/check <pair>` | Price + 24h stats |
| `/balance` | Futures account balance |
| `/positions` | Open positions + PnL |
| `/positions add ...` | Manual entry (LONG/SHORT, qty, lev, price) |
| `/close <pair>` | Market-close position |
| `/pending` | Pending conditional signals |
| `/cancel <id>` | Cancel pending signal |
| `/health` | Full system health check |
| `/setport N` | Margin budget per trade |
| `/setleverage N` | Default leverage ceiling |
| `/version` | Bot version |
| `/help` | All commands |

---

## 🔌 API Bridge

Secure HTTP API on port `9090` for Hermes or external tools:

```bash
# Stats dashboard
curl -s -H "X-API-Key: $KEY" http://localhost:9090/api/v1/stats

# Pipeline trace by correlation ID
curl -s -H "X-API-Key: $KEY" http://localhost:9090/api/v1/logs/{correlation_id}

# Full trade trace with LLM interaction
curl -s -H "X-API-Key: $KEY" http://localhost:9090/api/v1/trades/{id}
```

> Auth: API key + HMAC-SHA256 for writes · Rate limited: 30 req/min/IP

---

## 🚀 Quick Start

```bash
# Clone
git clone https://github.com/hernanda-git/learnernoearner-listener.git
cd learnernoearner-listener

# Install
pip install -r requirements.txt

# Configure
cp .env.example .env
# Edit .env with your Telegram API credentials, Binance API key, etc.

# Dry-run first (analyzes without trading)
# config.yaml → agent.auto_trade: false
python src/main.py
```

> 📖 Full docs: [SETUP.md](docs/SETUP.md) · [CONFIGURATION.md](docs/CONFIGURATION.md) · [DEPLOYMENT.md](docs/DEPLOYMENT.md)

---

## 📚 Documentation

| Doc | What | 
|-----|------|
| [🏗 Architecture](docs/ARCHITECTURE.md) | Full system architecture + DB schema |
| [📦 Setup](docs/SETUP.md) | Step-by-step local + Fly.io setup |
| [⚙️ Configuration](docs/CONFIGURATION.md) | All config keys |
| [🛡 Risk Management](docs/RISK_MANAGEMENT.md) | Safety gates + risk controls |
| [🚀 Deployment](docs/DEPLOYMENT.md) | Fly.io + Docker deployment |
| [📡 Signal Parsing](docs/SIGNAL_PARSING.md) | Regex + LLM signal patterns |
| [🔌 API Reference](docs/API.md) | Exchange + HTTP API |
| [🛩 Fly Operations](docs/FLY_OPERATIONS.md) | Logs, SSH, health checks |
| [🤖 Agent Guide](AGENTS.md) | AI agent maintenance runbook |

---

## 🤝 Contributing (for AI Agents)

Read [`AGENTS.md`](AGENTS.md) first — it's the AI agent's guide to this project with code conventions, known pitfalls, agentic workflows, and deployment procedures.

---

## 📜 License

Built with Hermes Agent · OpenCode Go (mimo-v2.5) · Binance USDⓈ-M Futures

*"The market is a signal. The bot is the trigger. You are the edge."*
