# Changelog

All notable changes to the learnernoearner-listener auto-trade pipeline.

---

## [v116] — 2026-08-01

### Added
- **Auto-cancel stale LIMIT orders on management commands** — when a management command (`sl to entry`, `tpN`, `tp1 booked`, `cutting`, `full close`) arrives for a pair whose LIMIT entry is still resting on the book, the bot now cancels the stale order before proceeding instead of parking or silently skipping.
  - New `_cancel_pending_limit_orders()` helper: queries exchange for pending LIMIT orders, cancels each via `cancel_order()`, cleans up DB order rows (`UPDATE orders SET status = 'CANCELED'`)
  - Injected into `_handle_management()`, `_handle_tp1_booked()`, and `_handle_full_close()` — all three management handlers
  - After cancelling, parks the intent for replay once a new position opens (via existing `pending_mgmt_repo`)
  - Sends clear notification: "🗑️ **Stale LIMIT orders cancelled — `{pair}`**"
- **Fix**: management commands no longer lost when entry LIMIT hasn't filled yet but a new signal (tp1, cutting, sl to entry) arrives for the pair

### Changed
- Management command flow now checks for pending LIMIT orders before parking/skipping
- Notification messages updated to mention stale order cancellation status

---

## [v115] — 2026-07-31

### Changed
- **LLM provider switched back to OpenCode Go**: from OpenGateway (opengateway.gitlawb.com) → OpenCode Go (opencode.ai/zen/go/v1)
- **Model changed**: mindai/macaron-v1-tall → mimo-v2.5
- **New API key**: Updated OPENCODE_GO_API_KEY (previous key was expired/403)
- deepseek-v4-flash was region-locked to China, mimo-v2.5 selected as replacement

## [v113] — 2026-07-28

### Fixed
- **/health (and all slash commands) with @botusername suffix**: after the VPS migration two bots share the owner's chat, so Telegram autocomplete sends `/health@xvalarion_bot`. The Telethon `on_command` handler compared the RAW text (`cmd == "/health"`), so any suffixed command was silently dropped. Now the `@suffix` is stripped before matching; commands addressed to a DIFFERENT bot (e.g. `/status@vaisravana_bot`) are ignored (no cross-talk). Username configurable via `XVALARION_BOT_USERNAME` (default `xvalarion_bot`).
- Added `tests/test_cmd_username_routing.py` regression tests.

## [v110] — 2026-07-27

### Fixed
- **Quantity rounding fix**: `_enter_position()` now uses `exchange._round_quantity()` as the PRIMARY rounding path, which handles lazy filter loading + integer fallback for low-price coins. Manual stepSize rounding is kept as fallback only when `_round_quantity` fails.
- **`validate_order()` threshold relaxed**: Changed from 50% → 3× comparison. Small quantities near the step grid (e.g. 0.0555 → 0.1 for AAVEUSDT stepSize=0.1) legitimately round up by >50%; this is expected, not a bug.
- **AAVEUSDT LIVE triggered**: Manual LONG entered @ 100.75 with SL=98.50 (price-monitored) and TP=106.0 (LIMIT resting).

## [v109] — 2026-07-27

### Added
- `BINANCE_ALGO_ORDERS=1` Fly secret enabled (Algo Order API for -4120 pairs)

### Fixed
- **`_modify_position()` orphan protection**: Now saves old SL/TP orders before cancelling them. If new placement fails, attempts to restore old orders. Position is never left without protection.
- **Position manager self-heal now works**: Previously only logged "self-heal will re-attach protection" but never did. Fix: resets `_protection_placed`/+`_sl_monitored` when orphaned live position detected, uses 60s cooldown instead of permanent guard, so protection is actually re-attached on next tick.
- **KAITOUSDT**: Zero orders on exchange for 30+ hours despite SL=entry in DB. Fixed by self-heal reactivation.

## [v108] — 2026-07-26

### Fixed
- Config: raised `max_concurrent_positions` 2 → 10
- Min notional re-check after step rounding for PUMPUSDT -4164 drop

## [v107] — 2026-07-26

### Added
- Truncate long Telegram messages (>4096 chars)
- Reuse httpx client in webhook for connection reuse

## [v106] — 2026-07-25

### Added
- `handle_edit()` separate path for edited message management commands
- `.env` consolidation

## [v105] — 2026-07-25

### Added
- Cooldown for closed pairs
- Step rounding after min-notional scale
- Idle backoff in position monitor loop
- Version cleanup

## [v104] — 2026-07-23

### Docs
- Comprehensive documentation overhaul: ARCHITECTURE, SETUP, CONFIGURATION, RISK_MANAGEMENT, SIGNAL_PARSING, API, FLY_OPERATIONS

## [v103] — 2026-07-22

### Fixed
- SL/TP close notifications now sent to Telegram with PnL, direction, exit price, reason
- Health report markdown escaping

## [v102] — 2026-07-21

### Fixed
- Management commands reject when specified pair has no open position (fix v101)
- LLM CLOSE now actually executes via `order_service` (was no-op)
- Added `closed at entry` / `full` management command patterns

## [v101] — 2026-07-21

### Added
- TP1 partial close: 1/2 instead of 1/3
- Divide TP quantity across multiple levels

## [v100] — 2026-07-21

### Added
- tpN + full text management commands (no LLM, deterministic execution)
- Regression tests for sl-to-entry

## [v92] — 2026-07-14

### Fixed
- CLOSE action in orchestrator now actually calls `order_service.execute()` (was returning without closing)
- Added `/close <symbol>` Telegram command
- SL-to-entry misroute + zero-qty rejection fix

## [v91] — 2026-07-14

### Fixed
- Manual `/close` FK-safe position_events insert
- Live monitor hardening: verify exit via `get_positions()`, guaranteed market fills, tz-aware entry_time

## [v81] — 2026-07-13

### Fixed
- Reduce-Only flag is now an explicit `reduce=` parameter per call (not inferred from order type)
- Exit LIMIT orders no longer lose reduceOnly flag
- 95 tests passing

## [v57] — 2026-07-09

### Fixed
- Version tracking: `src/version.py` now auto-bumped on deploy
- Deploy process passes `RELEASE_VERSION` env var

## [v56] — 2026-07-09

### Fixed
- Self-heal idempotency: mark SL unplaceable (XPLUSDT/1000x) so it stops re-attempting every tick
- Algo Order API gating: feature detected from testnet URL; never call on testnet (404)

## [v55] — 2026-07-09

### Added
- Reconcilation of late-fill resting LIMIT orders (XPLUSDT root cause)
- STOP -4120 fallback: SL → price-monitored, TP → LIMIT fallback
- `/check` price command
- `/positions add` manual entry with side inference
- API bridge with HMAC signing + rate limiter
- `/db` slash command for DB browsing
- Symbol registry with dynamic exchangeInfo caching
- Dual-constraint position sizing (risk-based + port cap)
- Health reporter with 6h periodic checks
- Full test suite

## [v1] — Initial release

Basic Telegram → LLM → Binance Futures pipeline with regex parsing and safety gates.
