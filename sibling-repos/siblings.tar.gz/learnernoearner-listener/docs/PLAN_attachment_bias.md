# Plan: Attachment Ingestion + BTC Bias Tracking

Status: IMPLEMENTED on branch dev (schema → fetcher → vision → parser → consumers → bias job).
Delta spec: see docs/PLAN_attachment_bias_ADDENDUM_scalp_levels.md (scalp-watch level resolver).
Branch: dev. Production bot on Sera untouched.

Goal: make the bot read the channel's chart attachments (not just text) and track
the analyst's BTC/market bias separately, so entries can be filtered by trade-setup
quality AND market regime — the missing edge for profitable scalping vs millions of
dumb signal-following bots.

## Why

The signal channel `fattyfatclub` posts:
1. Trade setups: `#PAIR $PAIR LONG/SHORT TRADE / ENTRY / TARGET / STOPLOSS` + a TradingView chart.
2. Management calls: `sl to entry $PAIR`, `move sl to breakeven`, `$PAIR X% up, book profits`
   (often a BloFin PnL card image, not a TradeView chart).
3. BTC bias / market-movement: `$BTC going good`, `$BTC range identified`, `$BTC bottom not in`,
   `$BTC 5% down when everyone bullish` + chart. NO entry/sl/tp.

The bot currently stores only `raw_text` of signals — it discards the attachment entirely.
But the attachment carries the trade-quality signal the text lacks. Real evidence pulled
(read-only, 25 recent messages, 16 with media):
- KAITO long got liquidated (-19.96). The chart showed the entry was a BULL TRAP / dead-cat
  bounce in a breakdown — low-probability setup the text (clean 1:5.6 R/R) hid.
- INJ/ZAMA wins were clean pullback-longs at support / bottom-fish with good R/R.
=> Reading the chart would have flagged KAITO as `fakeout` and skipped/downsized it.

The BTC bias posts are a separate regime signal. When BTC bias = RANGE / NO_CHASE / BEARISH,
new long setups should be downsized or skipped — the KAITO guard at the regime level.

## Scheme (validated against all 12 BTC attachments pulled)

### Table 1 — attachment_reads (trade-signal charts only)
```sql
CREATE TABLE attachment_reads (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  source_id INTEGER NOT NULL,            -- FK signals.id
  message_id INTEGER NOT NULL,
  channel TEXT DEFAULT '',
  media_type TEXT DEFAULT 'photo',
  local_path TEXT DEFAULT '',
  symbol_posted TEXT DEFAULT '',
  symbol_resolved TEXT DEFAULT '',
  has_chart_data INTEGER DEFAULT 1,      -- 0 = meme / no levels
  chart_entry REAL, chart_sl REAL,
  chart_tp TEXT DEFAULT '',              -- JSON[]
  chart_support TEXT DEFAULT '', chart_resistance TEXT DEFAULT '',  -- JSON[]
  chart_trend TEXT DEFAULT '',           -- uptrend/downtrend/range/chop
  chart_setup_type TEXT DEFAULT '',      -- pullback/breakout/reversal/fakeout/pnl_card
  levels_source TEXT DEFAULT '',         -- text|chart|both
  signal_shape TEXT DEFAULT 'formal_setup',  -- formal_setup|scalp_watch|management|pnl_card
  text_levels TEXT DEFAULT '',           -- JSON[] numeric levels regexed from raw_text
  resolved_entry_price REAL, resolved_entry_source TEXT DEFAULT '',
  resolved_target_price REAL, resolved_sl_price REAL,
  resolution_confidence REAL,            -- 0..1, see addendum §3
  vision_struct TEXT DEFAULT '',         -- RAW JSON (audit only, never queried)
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(channel, message_id)
);
CREATE INDEX idx_ar_src ON attachment_reads(source_id);
```

### Table 2 — btc_bias_reads (BTC bias / market-movement only)
```sql
CREATE TABLE btc_bias_reads (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  message_id INTEGER NOT NULL,
  channel TEXT DEFAULT '',
  media_type TEXT DEFAULT 'photo',
  local_path TEXT DEFAULT '',
  caption TEXT DEFAULT '',
  symbol_resolved TEXT DEFAULT 'BTC',
  has_chart_data INTEGER DEFAULT 1,
  chart_trend TEXT DEFAULT '',
  support TEXT DEFAULT '', resistance TEXT DEFAULT '',   -- JSON[]
  range_low REAL, range_high REAL,        -- populated ONLY when bias=RANGE
  bias_primary TEXT DEFAULT '',           -- BULLISH/BEARISH/NEUTRAL/RANGE/NO_CHASE
  bias_secondary TEXT DEFAULT '',         -- st-bearish / mt-bullish etc
  bias_horizon TEXT DEFAULT '',           -- short/medium/long
  btc_price_at_post REAL,                 -- BTC/USDT mark (basis for scoring)
  vision_struct TEXT DEFAULT '',          -- RAW JSON (audit only)
  resolved_direction TEXT DEFAULT '',
  btc_price_after_n_days REAL,
  accuracy REAL DEFAULT NULL,             -- +1 / -1 / 0
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(channel, message_id)
);
CREATE INDEX idx_btc_created ON btc_bias_reads(created_at);
```

### vision_struct JSON shape (raw audit; scalars above are canonical/queried)
```json
{
  "levels": {"entry":null,"sl":null,"tp":[],
             "support":[63153.9,63426.6,63930.5],
             "resistance":[64706.5,67442.3,68206.4]},
  "trend":"uptrend",
  "setup_type":"pullback",
  "wave":[{"idx":0,"price":63153.9,"label":"swing_low"},
          {"idx":1,"price":64600,"label":"current"},
          {"idx":2,"price":68206.4,"label":"projected_target"}],
  "arrows":[{"at":{"idx":1,"price":64600},"dir":"right","meaning":"continuation"}],
  "bias":{"primary":"BULLISH","secondary":"","horizon":""},
  "has_chart_data":true
}
```
- wave = the drawn trajectory as an ordered polyline. Compare actual price path vs projected
  wave later: divergence = setup failing in real time = early-exit learning signal.
- arrows[].meaning ∈ {entry_trigger, target, continuation, reversal_pending}.

### Extraction method
At fetch time, vision prompt asks specifically (not vague "describe"):
list every horizontal line w/ exact price + label; state trend; classify setup_type;
transcribe the drawn wave as ordered waypoints [idx,price,label]; list every arrow w/
direction + meaning; for bias posts state directional bias (primary/secondary/horizon).
Returns the JSON above. (Download+vision pipeline already proven working via read-only
StringSession fetch — 16 charts + 12 BTC charts retrieved without disrupting the bot.)

### Schema deviation from the original spec
The `signal_shape` / `text_levels` / `resolved_*` / `resolution_confidence` columns above
are added by the scalp-watch addendum (docs/PLAN_attachment_bias_ADDENDUM_scalp_levels.md §1).
They are applied as migrations, not in the base CREATE TABLE, so existing DBs upgrade in place.

## Parser routing (exact)
- text matches `#PAIR $PAIR (LONG|SHORT) TRADE` + has ENTRY/TARGET/STOPLOSS -> attachment_reads
- `$BTC` + bias keyword + NO entry/sl/tp -> btc_bias_reads (capture btc_price_at_post = live BTC mark)
- `$BTC` + IS a trade setup -> attachment_reads only (bias table stays BTC-regime-only)
- management post w/ BloFin card -> attachment_reads with chart_setup_type='pnl_card'
- loose scalp call (no TRADE/ENTRY/SL, matches SCALP_WORDS) -> attachment_reads with
  signal_shape='scalp_watch'; entry/target/stop come from src/agent/level_resolver.py

## Consumer mapping (the edge)
- attachment_reads.chart_setup_type='fakeout' -> KAITO GUARD: skip or size x0.3 (don't buy
  breakdown bounces). Highest-value filter.
- levels_source='both' mismatch >1% -> use chart value, flag.
- btc_bias_reads latest (<=24h old):
    BEARISH     -> long size x0.5 or skip
    RANGE       -> skip breakout-longs, allow pullback-longs
    NO_CHASE    -> stand aside
    BULLISH     -> normal
- bias accuracy scoring (24h job): rows where accuracy IS NULL and created_at < now-7d
    pull BTC mark; bias_primary=BULLISH & price_after > price_at_post*1.015 -> +1
                          & price_after < price_at_post*0.985 -> -1 ; else 0
    (1.5% noise floor). If his RANGE/NO_CHASE calls hit >=70% -> weight them heavier;
    if lagging -> discount. That is the reflexivity/learning loop vs static bots.

## Implementation steps (when exiting plan mode)
1. attachment_reads + btc_bias_reads schema (database.py migration + repositories).
2. Attachment fetcher reuse: download media at signal time (copy session / StringSession,
   read-only, disconnect fast) -> local_path. Vision extraction -> structured fields.
3. Parser: route trade vs bias vs pnl_card; populate both tables; record btc_price_at_post.
4. Setup-quality gate (fakeout -> skip/downsize) in order_service entry path.
5. Regime filter in entry gate consuming btc_bias_reads latest row.
6. Bias accuracy job (src/state/bias_accuracy.py) scoring + weighting.
7. Scalp-watch delta: classify_signal_shape (parser), src/agent/level_resolver.py,
   LIMIT-at-resolved-level wiring in order_service.place_entry. Sizing untouched:
   compute_notional_qty is the single sizing path for every shape.
   Full spec: docs/PLAN_attachment_bias_ADDENDUM_scalp_levels.md

## Notes / risks
- Reusing the bot's StringSession for a second connection causes a brief monitoring blip on
  the live bot. Only do this read-only and disconnect immediately, OR run after a clean
  restart via the reset script. Never call getUpdates on the bot token (steals its updates).
- Charts are sometimes mislabeled ($BTC caption but an alt chart) -> symbol_resolved +
  always score bias against BTC/USDT mark regardless.
- vision_struct is audit-only; scalar columns are canonical to avoid drift.
