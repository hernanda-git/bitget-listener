# Frontrun-Split Entry (draft-and-cancel hedge)

config: `risk.frontrun_split` in config.yaml.

## Why
When a signal is frontrunned (price already moved adversely past the signal
entry), a pure LIMIT at the signal entry may never fill. We still want in, but
we also still want the better price if it pulls back. Solution: enter a small
market portion now, rest a limit for the rest at the original signal entry.

## Behavior
1. On ENTER, if `frontrun_split.enabled` and the live mark price is adversely
   past `entry_price` by more than `frontrun_threshold_pct` (adverse only — a
   favorable dip does NOT trigger a split), branch to the split path:
   - **market_pct** (25%) enters at market immediately (guaranteed fill).
   - **limit_pct** (75%) rests as a LIMIT at the original signal `entry_price`.
2. The open Position reflects ONLY the market portion (`quantity` = market leg).
   The resting limit is tracked via `positions.pending_limit_order_id/qty` so
   management commands can find and cancel it.
3. SL/TP are placed for the open (market) portion immediately.

## Management (breakeven / tp1) — "stop chasing, run the open portion"
- **sl to entry / sl be (breakeven):** the resting limit leg is cancelled first
  (`_cancel_pending_limit_orders` + `clear_pending_limit_leg`). SL is moved to
  **slightly profitable** = `entry × (1 ± breakeven_fee_buffer_pct)` (not flat
  zero) so a stop there closes net positive after fees. Only the open 25% runs.
- **tp1 / tp here / partial:** the resting limit leg is cancelled first, then
  `tp1_close_pct` (default 0.5) of the OPEN size is market-closed for profit,
  SL moved to slightly-profitable breakeven, and the remainder runs to TP.
- If the 75% limit already filled before the command, there is no pending leg —
  the command applies to the full position normally (cancel step is a no-op).

## Late fill of the resting leg
If price pulls back to the signal entry and the 75% limit fills while the
position is still open, `_reconcile_one` detects it (pending_limit_order_id
matches the filled order) and **merges** it into the existing position:
weighted entry recomputed, qty added, pending leg cleared, SL/TP refreshed for
the combined size. No second position is created.

## Config knobs
| key | default | meaning |
|---|---|---|
| enabled | true | master switch |
| market_pct | 0.25 | immediate market portion |
| limit_pct | 0.75 | resting limit portion |
| frontrun_threshold_pct | 0.5 | adverse move % that triggers a split |
| breakeven_fee_buffer_pct | 0.07 | SL above entry on breakeven (covers RT fees) |
| tp1_close_pct | 0.5 | fraction of open size closed on tp1 |

## Verified
- `_enter_split` creates position with qty=market leg, pending=qty limit leg,
  entry=market fill. (mock test, no live exchange.)
- `clear_pending_limit_leg` zeroes tracking fields.
- breakeven SL = entry × (1+0.0007) > entry.
- Fixed bug: `stamp_order_position` must be called on `position_repo`, not
  `order_repo` (caught by test).
