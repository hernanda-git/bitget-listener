# Comprehensive Bot Review — learnernoearner-listener (fatty bot)

> Expert-trader + engineer review. Honest, no bias. Based on actual running container (v115) and workspace `dev` branch.

---

## 1. Current State

**Running container:** v115 (Sera, `/opt/bots/listener`)
**Workspace copy:** v115 on `dev` branch (`/root/workspace/repos/learnernoearner-listener`)
**LLM:** mindai/macaron-v1-tall via opengateway.gitlawb.com
**Exchange:** Binance USDⓈ-M Futures (mainnet), ISOLATED margin
**Risk:** port_usdt=$1, max_leverage=20, max_port_pct=10%, max_concurrent=10

**Critical finding:** running container is **behind** the `dev` branch. Many fixes documented in EVALUATION.md as "shipped on dev" are NOT yet deployed. The running container is the pre-dev state.

---

## 2. What's Actually Implemented (verified on running container)

### ✓ Gate 2 dual-constraint sizing (`gate.py`)
Position sized by **risk-based** (`max_loss / sl_distance`) AND **port cap** (`balance × max_port_pct`), whichever is smaller. Leverage computed from `pos_value / port_usdt`, snapped to valid Binance levels. Portfolio notional cap (`existing + new ≤ balance × max_portfolio_leverage`). Margin sanity check. This is solid.

### ✓ Algo Order API for -4120 pairs (`binance.py`)
When conditional STOP/TP is rejected on the standard endpoint (-4120), retries via the Algo Order API to place a **real conditional STOP-LIMIT** (visible in Binance Conditional tab, fills as LIMIT at stop_price). This is the correct fix for -4120 pairs (PUMPUSDT, KAITOUSDT, AAVEUSDT).

### ✓ reduceOnly on exits
Exit orders carry `reduceOnly=true`. Entry orders do NOT (correct — Binance rejects entry with reduceOnly).

### ✓ stop_loss() uses conditional STOP-LIMIT (not market)
Places `STOP` (conditional STOP-LIMIT) which fills as a LIMIT at the stop_price — no slippage. Mapped to futures `STOP` type.

### ✓ markPrice polling in position_manager
`_check_position` calls `get_mark_price()` and closes if mark crosses SL.

### ✓ liquidation_price references in binance.py
`get_positions()` reads `markPrice` from Binance response.

### ✓ Self-heal logic in position_manager
If SL/TP orders are missing on the exchange (e.g. cancelled externally), the position manager re-attaches protection with a 60s cooldown. Also verifies against the exchange positions feed before auto-closing to avoid dropping a live position.

---

## 3. What's NOT Implemented (verified on running container)

### ✗ BUG A — Fees never recorded (still present)
No source references `commission`, `open_fee`, `close_fee`, `net_usd`, `gross_usd`. Every trade closes with fee=0. The `fee_model` table (maker 2bps / taker 5bps = 7bps RT) exists but is never read. **You cannot tell if any strategy is +EV after fees.**

### ✗ BUG B — Exit at 0.00 on liquidation (still present)
`_finalize_close` does `exit_value = (order.avg_price or 0) * position.quantity`. On a liquidation where `avg_price` is None, exit is booked at **0.00** = entire notional lost. The KAITOUSDT -19.96 wipe pattern is still possible.

### ✗ BUG C — No reduce-only LIMIT fallback for STOP rejection
The `dev` branch has `reduce_only_limit_stop` (commit 160db49) which places a reduce-only LIMIT at the SL price when conditional STOP is rejected — but this is **NOT in the running container**. Currently, when STOP is rejected, the position relies solely on software price monitoring (the 10s poll).

### ✗ No real-time liquidation capture
No `forceOrder` websocket subscription. Liquidations are only discovered when the poll next runs (up to 10s gap).

### ✗ No eval/monitoring layer wired
`eval_writer` module exists in workspace but is **NOT wired** into the running container. No `equity_snapshots`, `position_metrics`, `signal_popularity`, `param_log`, `eval_snapshots`, `strategy_perf` writes. The learning loop is empty.

### ✗ No reflexivity guard
No `signal_popularity` tracking, no `crowd_density_score`, no counter-trade tilt, no shadow ledger, no drift detection, no strategy rotation.

### ✗ No pre-LLM fast path
Every signal goes through the full LLM round-trip (30s timeout). The parser (~1ms) is fast but the LLM is the bottleneck — slow bots get front-run.

### ✗ markPrice is polling only, not WS
Position manager polls `get_mark_price()` (REST). No `!markPrice@arr` websocket subscription.

---

## 4. The Reflexivity Problem — "Think Different"

You're right: if millions of bots do the same thing, the price behaves differently. Here's the honest analysis.

### The core flaw
The bot trades **signals from one Telegram channel** (@fattyfatclub). Every subscriber runs a similar bot. When the signal fires:
- A wave of correlated orders hits the same pair → **entry slippage** (you buy after the crowd lifted price)
- The common SL band becomes a **liquidity magnet** → crowd's stops + your stop fill each other, accelerating the move that liquidates you (the KAITOUSDT pattern)
- The channel's "win rate" is measured on **their** fill, not yours. By the time your bot acts, the edge is arbitraged away.

**This is why the measured win rate is 3.2%, not the channel's advertised number.** You are the retail trader arriving late to a crowded trade.

### What "think different" actually means

#### 1. Don't be the last one in — pre-LLM fast path
The `parser.py` is ~1ms. The LLM round-trip (30s timeout) is the bottleneck. Cache a **fast pre-LLM decision** for known signal shapes (e.g. "X% up from entry" → enter; "SL at X" → enter with SL). Only escalate to LLM when ambiguous. This front-runs slow bots.

#### 2. Counter-trade the crowd (reflexivity edge)
When a signal is **very popular** (many eyeballs, many bots), the fade (mean-reversion against the initial spike) often has +EV because the spike is liquidity-driven, not information-driven. Track signal popularity (how fast others react) and tilt size/direction accordingly. The shadow ledger records signal→price-impact over N rows and rotates when the counter-trade edge decays.

#### 3. Trade where the crowd isn't
The bot allows `*` (all pairs). Most channels only cover liquid majors. Scan the **long tail of low-volume pairs** where bot density is low and the signal-to-noise from your data is higher.

#### 4. Use your own data, not the channel's narrative
The `binance-crypto-realtime` pipeline (separate repo) already scores strength/va/squeeze across all symbols every tick. Feed **that** into the decision instead of (or to confirm) the Telegram signal. Independent signal = independent edge.

---

## 5. Real-Time Data Pipeline — What's Missing for High Win Rates

### Current data sources
- Telegram channel signals (crowd sentiment, lagged)
- Binance REST polling (markPrice, klines) — 10s gap

### What you need for a top-1% bot

#### A. Real-time market microstructure (the `binance-crypto-realtime` pipeline)
Already exists as a separate repo. Should feed into the bot's decision:
- **Strength/va/squeeze scores** across all symbols every tick
- **Orderbook imbalance** (bid/ask depth ratio) — detects liquidity walls
- **CVD (cumulative volume delta)** — aggressive buyer vs seller pressure
- **Funding rate** — crowded positioning signal
- **Liquidation heatmap** — where the crowd's stops cluster (reflexivity)

#### B. Real-time signal detection (not just Telegram)
- **Binance aggTrade stream** — detect unusual volume spikes on pairs before the channel posts
- **Orderbook delta** — detect accumulation/distribution before price moves
- **Funding rate shifts** — detect crowded positioning before the move

#### C. The missing piece: a decision layer that combines independent signals
The bot currently has ONE signal (Telegram) + ONE decision (LLM). A top-1% bot needs:
- **Independent signal** (market microstructure scores) + **crowd signal** (Telegram)
- **Fast path** (rule-based, sub-second) for clear signals → front-run slow bots
- **LLM** for ambiguous cases where both signals disagree
- **Reflexivity guard** — when crowd signal is very popular, tilt toward counter-trade

---

## 6. Architecture Recommendation

```
┌─────────────────────────────────────────────────────────────┐
│  DATA LAYER (always-on)                                       │
│  binance-crypto-realtime  → strength/va/squeeze scores, all   │
│  symbols, every tick (TimescaleDB)        ← independent edge  │
│  Telegram channel feed      → raw signals (crowd sentiment)    │
│  Binance aggTrade/orderbook   → microstructure signals         │
└───────────────┬───────────────────────────┬───────────────────┘
                │                            │
┌───────────────▼──────────────┐  ┌─────────▼──────────────────┐
│  DECISION AGENT (LLM + rules) │  │  REFLEXIVITY GUARD          │
│  - fast pre-LLM rule path     │  │  - signal popularity tracker│
│  - LLM for ambiguous cases    │  │  - counter-trade tilt       │
│  - fee-aware +EV check        │  │  - shadow ledger (44M rows) │
└───────────────┬──────────────┘  └─────────┬──────────────────┘
                │                            │
┌───────────────▼────────────────────────────▼──────────────────┐
│  RISK GATE (hard clamps, size-from-SL, notional cap, fee adj)  │
└───────────────┬─────────────────────────────────────────────────┘
                │
┌───────────────▼─────────────────────────────────────────────────┐
│  EXECUTION + real-time stops (markPrice WS, forceOrder WS)       │
└───────────────┬─────────────────────────────────────────────────┘
                │
┌───────────────▼─────────────────────────────────────────────────┐
│  LEARNING LOOP (the missing piece)                               │
│  - every close → fee-adjusted outcome → param_log               │
│  - drift detection: is edge decaying? rotate strategy           │
│  - periodic self-eval vs baseline, promote winning params        │
└─────────────────────────────────────────────────────────────────┘
```

The **learning loop** is what's absent. Today params are static. A top-1% bot must (a) measure true fee-adjusted expectancy per regime, (b) detect when the crowd has arbitraged the signal, and (c) rotate.

---

## 7. Prioritized Fix List

| # | Fix | Type | Why |
|---|-----|------|-----|
| 1 | Size from SL distance + hard notional cap (no liquidation) | P0 | stops account death |
| 2 | Real-time stops: markPrice WS + forceOrder WS, 1–2s | P0 | stops the wipe |
| 3 | Never record exit at `or 0`; use liquidation price | P0 | honest PnL |
| 4 | Record real fees; net_usd = gross − fees | P1 | measures true edge |
| 5 | Pre-LLM fast path for known signals (sub-second) | P1 | beats slow bots |
| 6 | Reflexivity guard + counter-trade tilt + shadow ledger | P1 | the actual edge |
| 7 | Feed binance-crypto-realtime scores into decision | P2 | independent signal |
| 8 | Learning loop: drift detect + param rotation | P2 | self-improving |

**Do not deploy until #1–#3 are in.** They are the difference between a bot that bleeds and a bot that survives long enough to learn.

---

## 8. Bottom Line

The bot is well-engineered (async, gates, idempotency, self-heal) but it is **trading a crowded, lagged signal with no hard risk floor and no fee truth**. Fix the risk floor and the stop latency first; then attack the reflexivity edge. The balance will not grow until #1–#3 ship — no strategy survives liquidations.

The running container (v115) is behind the `dev` branch. Many fixes documented in EVALUATION.md as "shipped on dev" are NOT yet deployed. The `dev` branch contains the `reduce_only_limit_stop` fix and the eval/monitoring layer, but neither is in the running container.

---

## 9. Verification Checklist

Before claiming any fix ships:
1. `python3 scripts/pnl_snapshot.py` — confirm edge metrics (don't deploy a negative-expectancy config without P0 fixes)
2. Confirm no open positions before any restart (see Pre-Restart Safety Check in listener-bot-ops skill)
3. After fixes: assert `open_fee/close_fee` non-zero on mainnet and that liquidations record a real price (not 0.00)
4. `python3 -m py_compile src/**/*.py` — compile-check everything
5. `python3 -m pytest tests/ -p no:cacheprovider` — run pure-logic tests