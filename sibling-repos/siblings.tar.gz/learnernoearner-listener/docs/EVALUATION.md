# Evaluation — learnernoearner-listener (fatty bot)

> Expert-trader post-mortem. Read after the PnL numbers. Goal: turn a
> negative-expectancy bot into a top-1% autonomous agent. **Honest, no bias.**

---

## 1. The actual PnL (real numbers, 31 closed trades)

| Metric | Value | Verdict |
|---|---|---|
| Win rate | **3.2%** (1 / 31) | fatal |
| Avg win | +0.133 USDT | tiny |
| Avg loss | −0.725 USDT | 5.5× the win |
| Win:Loss size ratio | **0.18** | should be >1 to survive low WR |
| Expectancy / trade | **−0.70 USDT** | bleeds every trade |
| Displayed net | −21.62 USDT | understated (see §2) |
| True fee-adj net | ~−21.72 USDT | fees small in abs but hidden |
| **Single worst trade** | **KAITOUSDT −19.96 (92% of all loss)** | one liquidation |

This is **not variance**. A 3.2% win rate with a 0.18 reward:risk ratio is a
structurally negative-expectancy system. Running it longer just compounds the
bleed. The +EV-after-fees mandate in the brief is not met.

---

## 2. Bug A — Fees are never recorded (fake PnL)

**Finding:** no source file references `open_fee`, `close_fee`, `net_usd`, or
`gross_usd`. Every row in `trades` has `open_fee=0, close_fee=0`. The
`fee_model` table exists (maker 2bps / taker 5bps = 7bps RT) but is never used
to adjust recorded PnL.

**Impact:** the dashboard's "net" is a fantasy. At 7bps RT on ~$5 notional that
is ~$0.0035/trade — small today, but (a) it hides strategy edge and (b) at scale
or higher notional it becomes the dominant cost. More importantly, **you cannot
tell if any strategy is +EV after fees**, which is the entire point of the brief.

**Fix:** capture `fills[].commission` from Binance on every order, persist to
`open_fee`/`close_fee`, and compute `net_usd = gross_usd - open_fee - close_fee`.
Add an assertion in the close path so a trade never closes with fee=0 on mainnet.

---

## 3. Bug B — The liquidation wipe (the real killer)

**Finding (root cause of the −19.96):** KAITOUSDT closed at `exit_price=0.00`.
Trace the code:

1. `position_manager` polls `get_mark_price()` every 10s and closes if
   `mark <= sl_price` (LONG). This is the **only** protection for pairs where
   Binance rejects STOP orders (−4120: PUMPUSDT, KAITOUSDT, AAVEUSDT).
2. A fast gap-down (or a 1m-kline fallback that lags up to 60s) can blow past
   the SL between polls. Binance liquidates the position.
3. When the bot later "discovers" the position is gone, `_finalize_close` does
   `exit_value = (order.avg_price or 0) * qty` → **avg_price is None → 0.00** →
   records exit at 0 = the entire notional as loss. The wipe is booked as a
   "close" at price 0.

**Why it matters:** a single missed SL = account-destroying for a $1–$5 account.
The 10s poll + kline fallback is too slow for the very pairs it's meant to
protect (the −4120 list). The bot has **no hard exchange-side stop** for those
pairs and no margin-level guard.

- **Fixes (priority order):**
- **Hard cap notional per position** from leverage: `notional ≤ balance × risk% /
  (sl_distance%)`. Never let one position risk >X% of equity. Today `port_usdt`
  is fixed at $1 but `size` is computed from leverage up to `max_leverage=20` ×
  `max_position_hold` — a 20× position on a 5% move = liquidation. Gate 2 must
  clamp `size` so liquidation distance > SL distance with buffer.
- **Reduce poll interval** for −4120 pairs to 1–2s, or subscribe to the
  `!markPrice` websocket stream instead of polling (real-time, no 10s gap).
- **On close, never use `or 0` for price.** If `avg_price` is missing, read the
  position's real exit from `get_positions()` unrealized PnL / `income` endpoint,
  or mark the trade as `LIQUIDATED` with the liquidation price from the
  forceOrder stream — not 0.00.

> **PROGRESS (dev):** the "real-time SL" gap is partially addressed —
> `stop_loss()` now places a **reduce-only LIMIT at the SL price** as a genuine
> exchange order when conditional STOP is rejected (covers INJUSDT/ZAMAUSDT-style
> non--4120 rejections, not only -4120). The monitor also polls `_sl_monitored`
> pairs at ~1s. Remaining: hard notional cap (size-from-SL) and forceOrder WS
> for true real-time liquidation capture. See commit on `dev`.
>
> **DESIGN NOTE — notional / leverage is intentional by design (NOT a bug):**
> position notional is sized from `port_usdt × max_leverage` (e.g. $1 × 20 =
> $20 notional at 20×). liquidation sits at ~`1/leverage` from entry (≈5% at
> 20×). this is a deliberate risk posture chosen by the owner, not an oversight.
> the trade-off: when a signal's SL distance exceeds the liquidation distance
> (wide SL / tight liquidation), the position can be liquidated before the SL
> fires. this was reviewed and accepted as the intended behavior. the reduce-only
> LIMIT stop (above) + 1s monitor poll are the mitigations in place. do NOT
> "fix" sizing by clamping notional from SL distance unless the owner explicitly
> asks — it would change the chosen risk profile.
- **Subscribe to `forceOrder` websocket** so a liquidation is caught the instant
  it happens and recorded correctly.

---

## 4. Bug C — SL/TP "protection" is soft and can silently disappear

The `_protection_placed` / `_sl_monitored` idempotency set, plus the 30-min
"no orders → maybe auto-close" heuristic, means a position can be monitored by
price only (no exchange order). If the poll misses the SL hit (gap, or the
kline fallback lags), there is **no second line of defense**. For a $1 account,
one miss = death.

**Fix:** treat price-monitoring as a *backup*, not primary. For −4120 pairs,
use a **trailing reduce-only LIMIT** or a **position-side hedge** as the real
stop, and always keep the 1–2s poll as backstop.

---

## 5. The reflexivity problem (think different)

> "If millions of users run bots and those millions of bots do the same thing,
> the price will behave differently." — correct, and this is the core flaw.

The bot trades **signals from one Telegram channel (@fattyfatclub)**, parsed and
acted on by an LLM. Every other subscriber to that channel runs a *similar* bot.
When the signal fires, a wave of correlated orders hits the same pair at the same
time:

- The entry gets **slipped** (you buy after the crowd lifted the price).
- The SL cluster becomes a **liquidity magnet** — when price approaches the
  common SL band, the crowd's stops + your stop all fill each other, accelerating
  the move that liquidates you (exactly the KAITOUSDT pattern).
- The channel's "win rate" is measured on *their* fill, not *yours*. By the time
  your bot acts, the edge is arbitraged away.

**This is why win rate is 3.2%, not the channel's advertised number.** You are
the proverbial retail trader arriving late to a crowded trade.

### What "think different" actually means here

1. **Don't be the last one in.** Parse the signal the *instant* it posts and
   front-run the slow bots (sub-second). Your `parser.py` is ~1ms — keep it, but
   the LLM round-trip (30s timeout) is the bottleneck. Cache a fast pre-LLM
   decision for known signal shapes; only escalate to LLM when ambiguous.
2. **Counter-trade the crowd (reflexivity edge).** When a signal is *very*
   popular (many eyeballs, many bots), the fade (mean-reversion against the
   initial spike) often has +EV because the spike is liquidity-driven, not
   information-driven. Track signal popularity (how fast others react) and tilt
   size/direction accordingly. The brief already calls for monitoring this via a
   shadow ledger — implement it: record signal→price-impact over N rows and
   rotate when the counter-trade edge decays.
3. **Trade where the crowd isn't.** The bot allows `* ` (all pairs). Most
   channels only cover liquid majors. Scan the long tail of low-volume pairs
   where bot density is low and the signal-to-noise from *your* data is higher.
4. **Use your own data, not the channel's narrative.** The `binance-crypto-
   realtime` pipeline (separate repo) already scores strength/va/squeeze across
   all symbols every tick. Feed *that* into the decision instead of (or to
   confirm) the Telegram signal. Independent signal = independent edge.

---

## 6. Architecture recommendation (autonomous agentic)

Current: single container, linear pipeline (signal → parse → LLM → gate →
execute → poll). Works, but every decision is one LLM call with no learning
loop. To reach top 1%:

```
┌─────────────────────────────────────────────────────────────┐
│  DATA LAYER (always-on)                                       │
│  binance-crypto-realtime  → strength/va/squeeze scores, all   │
│  symbols, every tick (TimescaleDB)        ← independent edge  │
│  Telegram channel feed      → raw signals (crowd sentiment)    │
└───────────────┬───────────────────────────┬───────────────────┘
                │                            │
┌───────────────▼──────────────┐  ┌─────────▼──────────────────┐
│  DECISION AGENT (LLM + rules) │  │  REFLEXIVITY GUARD          │
│  - fast pre-LLM rule path     │  │  - signal popularity tracker│
│  - LLM for ambiguous cases    │  │  - counter-trade tilt       │
│  - fee-aware +EV check        │  │  - shadow ledger (44M rows) │
└───────────────┬──────────────┘  └─────────┬──────────────────┘
                │                            │
┌───────────────▼────────────────────────────▼──────────────────┐
│  RISK GATE (hard clamps, size-from-SL, notional cap, fee adj)  │
└───────────────┬─────────────────────────────────────────────────┘
                │
┌───────────────▼─────────────────────────────────────────────────┐
│  EXECUTION + real-time stops (markPrice WS, forceOrder WS)       │
└───────────────┬─────────────────────────────────────────────────┘
                │
┌───────────────▼─────────────────────────────────────────────────┐
│  LEARNING LOOP (the missing piece)                               │
│  - every close → fee-adjusted outcome → param_log               │
│  - drift detection: is edge decaying? rotate strategy           │
│  - periodic self-eval vs baseline, promote winning params        │
└─────────────────────────────────────────────────────────────────┘
```

The **learning loop** is what's absent. Today params are static. A top-1% bot
must (a) measure true fee-adjusted expectancy per regime, (b) detect when the
crowd has arbitraged the signal, and (c) rotate. Store outcomes in
`eval_snapshots` + `param_log` (tables exist but are empty — 0 rows).

---

## 7. Prioritized fix list (for the next deploy)

| # | Fix | Type | Why |
|---|-----|------|-----|
| 1 | Size from SL distance + hard notional cap (no liquidation) | P0 | stops account death |
| 2 | Real-time stops: markPrice WS + forceOrder WS, 1–2s | P0 | stops the wipe |
| 3 | Never record exit at `or 0`; use liquidation price | P0 | honest PnL |
| 4 | Record real fees; net_usd = gross − fees | P1 | measures true edge |
| 5 | Pre-LLM fast path for known signals (sub-second) | P1 | beats slow bots |
| 6 | Reflexivity guard + counter-trade tilt + shadow ledger | P1 | the actual edge |
| 7 | Feed binance-crypto-realtime scores into decision | P2 | independent signal |
| 8 | Learning loop: drift detect + param rotation | P2 | self-improving |

**Do not redeploy until #1–#3 are in.** They are the difference between a bot
that bleeds and a bot that survives long enough to learn.

---

## 8. Bottom line

The bot is well-engineered (async, gates, idempotency, self-heal) but it is
**trading a crowded, lagged signal with no hard risk floor and no fee truth**.
Fix the risk floor and the stop latency first; then attack the reflexivity edge.
The balance will not grow until #1–#3 ship — no strategy survives liquidations.
