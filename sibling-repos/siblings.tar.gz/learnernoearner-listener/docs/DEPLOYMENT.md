# Deployment Guide

## Docker Compose (Tencent Lighthouse VPS "sera")

The system runs on Tencent Lighthouse VPS "sera" (43.157.208.115, ap-jakarta) via a 4-container docker-compose stack.

### Prerequisites

- Docker + Docker Compose installed on sera
- Git identity: `valarion <42990222+hernanda-git@users.noreply.github.com>`

### Application Structure

```
/opt/bots/
├── docker-compose.yml   # Stack definition (listener, gateway, wsproxy, caddy)
├── Caddyfile            # Reverse proxy config
├── listener/            # bots-listener container
│   ├── main.py
│   ├── Dockerfile
│   └── src/             # Application code
├── gateway/             # bots-gateway container
├── wsproxy/             # bots-wsproxy container
└── .env                 # Local secrets (NOT in image)
```

### Deploy Steps

#### 1. Set Secrets

Secrets are managed via docker-compose environment variables (see `docker-compose.yml` and `.env`).

| Secret | Required | Description |
|--------|----------|-------------|
| `TELEGRAM_BOT_TOKEN` | ✅ | Bot token from @BotFather |
| `NOTIFY_CHAT_ID` | ✅ | Telegram chat for notifications |
| `BINANCE_API_KEY` | ✅ | Binance futures API key |
| `BINANCE_API_SECRET` | ✅ | Binance futures API secret |
| `GITLAWB_API_KEY` | ✅ | API key for opengateway.gitlawb.com |
| `TG_API_ID` | ✅ | Telegram API ID |
| `TG_API_HASH` | ✅ | Telegram API hash |
| `SESSION_STRING` | ✅ | Telethon string session |
| `CHANNEL_USERNAME` | ✅ | Channel to monitor |
| `API_KEY` | ⚠️ | Required for HTTP API bridge |
| `API_HMAC_SECRET` | ⚠️ | HMAC signing for API bridge |

#### 2. Deploy

```bash
cd /opt/bots

# Start/restart the stack
docker compose up -d

# Rebuild after code changes
docker compose up -d --build bots-listener
```

#### 3. Verify

```bash
docker compose ps
# Should show: bots-listener (running), bots-gateway (healthy), bots-wsproxy (running), bots-caddy (running)

docker logs bots-listener -n 20
# Should show startup messages, no errors

curl -s -o /dev/null -w "HTTP %{http_code}\n" http://localhost:9090/health
# Should return HTTP 200
```

### Container Details

| Container | Port | Role |
|-----------|------|------|
| `bots-listener` | 9090 | Telegram listener + FastAPI bridge |
| `bots-gateway` | 8000 | LLM gateway |
| `bots-wsproxy` | 8888 | WebSocket proxy |
| `bots-caddy` | 80 | Reverse proxy |

### Persistent Data

The app uses a bind-mounted volume at `/data/` for persistent state:

```bash
ls -la /data/
# /data/trades.db    — SQLite database (all trade history)
# /data/sessions/    — Telethon session
# /data/logs/        — Application logs
```

The volume survives container restarts and redeployments.

### Updating Config

Config is in `config.yaml` (mounted into the listener container). To change:

```bash
# Edit config.yaml
vim /opt/bots/listener/src/config.yaml

# Restart the listener to pick up changes
docker compose restart bots-listener
```

---

## Local Development

### Prerequisites

```bash
cd /opt/bots/listener/src
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# Edit .env with your keys
```

### Running Locally

```bash
# Dry-run (no real trades)
# Edit config.yaml: agent.auto_trade: false
python src/main.py

# Paper trading
# Edit config.yaml: exchange.active: paper
python src/main.py

# Real trading (testnet)
# Edit config.yaml: exchange.active: binance_testnet
python src/main.py

# Real trading (mainnet)
# Edit config.yaml: exchange.active: binance
python src/main.py
```

### Run Tests

```bash
python -m pytest tests/ -v
```

---

## Git Workflow

```bash
# Branch for features
git checkout -b feature/my-change

# Make changes, then:
git add src/ docs/
git commit -m "description: what changed"
git push origin listener-local

# Merge to main
git checkout main
git merge feature/my-change
git push origin main
```

---

## Environment Matrix

| Mode | `exchange.active` | `agent.auto_trade` | API Calls | Risk |
|------|-------------------|-------------------|-----------|------|
| Dry-run | any | `false` | Read-only | None |
| Paper trading | `paper` | `true` | None | None |
| Testnet | `binance_testnet` | `true` | Binance testnet | Fake money |
| Production | `binance` | `true` | Real Binance | Real money |
| Gateway proxy | `binance` + proxy | `true` | Via gateway | Real money |