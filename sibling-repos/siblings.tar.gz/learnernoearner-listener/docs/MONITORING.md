# Monitoring & Evaluation Schema

what the bot now logs for proper evaluation + monitoring, and how to read it.
All additive — safe on a fresh (empty) DB. Never mutates live positions.

## New tables (src/state/database.py)

| Table | Captures | Why |
|---|---|---|
| `equity_snapshots` | balance / available / unrealized / open count, periodic | equity curve → drawdown + growth |
| `position_metrics` | per-close fee rollup, gross/net pnl, notional, sl_distance, r_multiple, risk_usdt, **exit_type** (SL/TP/MANUAL/LIQUIDATION/TIME/SYSTEM), liquidation_price, latencies | true fee-adjusted expectancy + HOW each position died |
| `signal_popularity` | crowd_density_score, reaction_lag, concurrent_mentions, pre/post signal price impact | reflexivity / edge-decay signal |
| `param_log` | every param change (manual/auto/drift) | traceability of tuning |
| `eval_snapshots` | per-window (all/24h/7d) win_rate, expectancy, fee-adj expectancy, max_drawdown, sharpe | learning-loop sink, detects decay |
| `strategy_perf` | per pair/direction: n, wins, losses, net, fee-adj net, avg r_multiple | which pairs/regimes are actually +EV |

## Wiring (where writes happen)

- **fee rollup + exit_type + r_multiple** — `position_manager._finalize_close` calls
  `PositionRepository.finalize_position_metrics()` on every close.
- **equity snapshot + eval recompute** — `health/reporter.build_health_report` calls
  `eval_writer.snapshot_equity()` + `compute_eval()` every 6h health cycle.
- **signal popularity** — `orchestrator.handle_signal` calls `SignalPopularityRepository.save()`
  on every signal (crowd density estimated from pair repeat rate).

## How to read it

```bash
# fee-adjusted expectancy + drawdown per window
python3 -m src.state.eval_writer

# top pairs by fee-adjusted net pnl
python3 -c "from src.state.eval_writer import strategy_ranking; [print(r) for r in strategy_ranking(10)]"

# how did each position die?
sqlite3 /data/trades.db "SELECT p.pair, pm.exit_type, round(pm.net_pnl,4), round(pm.r_multiple,2) FROM position_metrics pm JOIN positions p ON p.id=pm.position_id ORDER BY pm.net_pnl"
```

## What this fixes vs the old deploy

- PnL was **fee-blind** (executions.fee existed but was never rolled up). Now net_pnl
  = gross − open_fee − close_fee, computed at close.
- A liquidation was booked as a silent close at exit=0.00. Now exit_type='LIQUIDATION'
  and liquidation_price is recorded.
- r_multiple was always 0.000. Now computed from sl_distance × notional.
- No equity curve, no per-pair perf, no signal-crowding data. All present now.

## Still manual (future)

- `post_signal_impact_pct` / `pre_signal_vol_z` are placeholders — wire to the
  binance-crypto-realtime pipeline (klines) for real reflexivity measurement.
- `sharpe` / regime tags are 0/'' — fill from eval_snapshots once enough data exists.
- counter-trade tilt logic consumes `signal_popularity.crowd_density_score` (not yet
  wired into the decision; that is the next phase per EVALUATION.md).
