# Addendum to docs/PLAN_attachment_bias.md
## Level-based "scalp watch" signals — concrete design

Apply this as a delta on top of the already-committed plan. It does **not** touch
notional sizing (`qty = port_usdt × max_leverage` stays exactly as-is everywhere).
It only adds a fourth signal shape, a level resolver, and wires resolved levels into
order placement as a `LIMIT` price instead of `MARKET`.

---

### 0. Why this needs its own path

Your existing parser routes on `#PAIR $PAIR (LONG|SHORT) TRADE` + explicit
`ENTRY/TARGET/STOPLOSS`. A post like:

> "$PUMP watching for a possible short scalp from the current levels all the way
> down to 0.0023"

matches none of that:
- no `TRADE` keyword, no `ENTRY:`/`SL:`
- `$PUMP` isn't `$BTC`, so it doesn't hit the bias path either
- "current levels" is not a number — it only becomes one once you look at the chart
- "0.0023" is a **target**, not an entry — the phrase is "from [entry zone] ... down
  to [target]", the classic shape of a scalp call

Today this either gets silently dropped or misfiled as a malformed trade setup. It
needs to be its own classification: **SCALP_WATCH**.

---

### 1. Schema delta (extends deliverable #1)

Add to `attachment_reads` (same table, not a new one — a scalp watch is still a
trade-signal chart, just a looser one):

```sql
ALTER TABLE attachment_reads ADD COLUMN signal_shape TEXT
  -- 'formal_setup' | 'scalp_watch' | 'management' | 'pnl_card'
  DEFAULT 'formal_setup';

ALTER TABLE attachment_reads ADD COLUMN text_levels JSON;
  -- raw numeric levels regex-extracted from raw_text, e.g. [{"value":0.0023,"role":"target_hint"}]

ALTER TABLE attachment_reads ADD COLUMN resolved_entry_price REAL;
ALTER TABLE attachment_reads ADD COLUMN resolved_entry_source TEXT;
  -- 'text_explicit' | 'chart_level' | 'text_chart_merged' | 'current_mark_fallback'

ALTER TABLE attachment_reads ADD COLUMN resolved_target_price REAL;
ALTER TABLE attachment_reads ADD COLUMN resolved_sl_price REAL;
  -- NULL is allowed here, but see §4 — no SL means order_service must refuse the trade,
  -- it does not mean "skip stop loss".

ALTER TABLE attachment_reads ADD COLUMN resolution_confidence REAL;
  -- 0..1, heuristic score, see §3
```

`vision_struct` stays the untouched audit JSON per your original spec — the new
scalar columns above are the canonical/queried fields, same pattern you already used
for `chart_entry`/`chart_sl`/etc.

---

### 2. Parser routing delta (extends deliverable #4)

```python
# src/agent/parser.py

SCALP_WORDS = {"scalp", "watching for", "possible short", "possible long",
               "current levels", "from current", "down to", "up to"}

def classify_signal_shape(raw_text: str) -> str:
    t = raw_text.lower()
    has_formal_trade = bool(re.search(r"\btrade\b", t)) and \
                        bool(re.search(r"entry|target|stop", t))
    if has_formal_trade:
        return "formal_setup"

    if "$btc" in t and not has_formal_trade:
        return None  # falls through to existing bias routing, unchanged

    if any(w in t for w in SCALP_WORDS):
        return "scalp_watch"

    if is_blofin_pnl_card(media):  # your existing detector
        return "management"

    return "formal_setup"  # unchanged default, existing behavior preserved
```

`scalp_watch` posts go into `attachment_reads` exactly like formal setups (same
table, same FK to `signals.id`), just with `signal_shape='scalp_watch'` and
`chart_entry`/`chart_sl`/`chart_tp` populated by the resolver in §3 instead of by
direct text parsing.

---

### 3. The level resolver (new module)

This is the actual "cross attachment + text" logic you asked for.

```python
# src/agent/level_resolver.py
"""
Resolves an actionable (entry, target, stop) triple for scalp_watch signals by
merging: (a) explicit numbers found in raw_text, (b) support/resistance/trend from
the vision-extracted chart, (c) current mark price as a last-resort anchor.

Never invents a stop-loss. If no stop can be derived, resolution_confidence is
capped low enough that order_service (see §4) will refuse to trade it.
"""
import re
from dataclasses import dataclass

NUM_RE = re.compile(r"(?<![\w.])(\d{1,6}(?:\.\d{1,8})?)(?![\w])")

@dataclass
class ResolvedLevels:
    entry: float | None
    entry_source: str
    target: float | None
    stop: float | None
    confidence: float

def extract_text_numbers(raw_text: str) -> list[float]:
    return [float(n) for n in NUM_RE.findall(raw_text)]

def resolve_scalp_levels(
    raw_text: str,
    vision_struct: dict,
    side: str,               # "LONG" | "SHORT", from existing LONG/SHORT keyword match
    current_mark_price: float,
) -> ResolvedLevels:
    text_nums = extract_text_numbers(raw_text)
    support = vision_struct.get("levels", {}).get("support") or []
    resistance = vision_struct.get("levels", {}).get("resistance") or []
    trend = vision_struct.get("trend")

    # --- target: the extreme text number in the direction of the trade ---
    target = None
    if text_nums:
        target = min(text_nums) if side == "SHORT" else max(text_nums)

    # --- entry: "current levels" phrasing -> anchor to chart, not to text ---
    entry = None
    entry_source = "current_mark_fallback"

    chart_levels = resistance if side == "SHORT" else support
    if chart_levels:
        # nearest chart level to current mark, on the correct side of price
        candidates = [
            lvl for lvl in chart_levels
            if (lvl >= current_mark_price if side == "SHORT" else lvl <= current_mark_price)
        ] or chart_levels
        entry = min(candidates, key=lambda lvl: abs(lvl - current_mark_price))
        entry_source = "chart_level"
    else:
        entry = current_mark_price
        entry_source = "current_mark_fallback"

    # --- stop: only from the chart, never fabricated from text ---
    stop = None
    opposite_levels = support if side == "SHORT" else resistance
    if opposite_levels:
        stop = max(opposite_levels) if side == "SHORT" else min(opposite_levels)
        # sanity: stop must sit beyond entry in the adverse direction
        if side == "SHORT" and stop <= entry:
            stop = None
        if side == "LONG" and stop >= entry:
            stop = None

    # --- confidence scoring ---
    confidence = 0.0
    if entry_source == "chart_level":
        confidence += 0.4
    if target is not None:
        confidence += 0.3
    if stop is not None:
        confidence += 0.3
    if trend and ((side == "SHORT" and trend == "down") or (side == "LONG" and trend == "up")):
        confidence = min(1.0, confidence + 0.1)

    return ResolvedLevels(entry, entry_source, target, stop, confidence)
```

**Worked example**, `$PUMP ... short scalp ... down to 0.0023`, chart shows
resistance at 0.00251, support at 0.00219, trend=down, mark price 0.00246:

```
text_nums        = [0.0023]
side              = SHORT
target            = 0.0023          # the extreme text number, matches "down to"
entry candidates  = [0.00251]  (resistance >= mark)
entry             = 0.00251, source="chart_level"
stop candidates   = [0.00219]  (support, must be > entry for a short stop -> fails)
stop              = None   # 0.00219 < entry, so it can't be the SHORT's stop -> None
confidence        = 0.4 (chart_level) + 0.3 (target) + 0 (no stop) + 0.1 (trend) = 0.8
```

Note the stop came back `None` here — the support level is below entry, which is
where you'd expect a *target* on a bigger move, not a stop for this scalp. That's
correct behavior, not a bug: this resolver refuses to fabricate a stop out of the
wrong side of the chart. See §4 for what happens next.

---

### 4. order_service wiring (extends deliverable #5, sizing untouched)

```python
# src/execution/order_service.py

def place_entry(signal_row, vision_struct, current_mark_price):
    qty = compute_notional_qty(port_usdt, max_leverage)  # UNCHANGED — do not touch

    if signal_row.signal_shape == "scalp_watch":
        levels = resolve_scalp_levels(
            signal_row.raw_text, vision_struct, signal_row.side, current_mark_price
        )
        persist_resolution(signal_row.id, levels)  # writes resolved_* columns

        if levels.stop is None:
            log.info("scalp_watch %s: no derivable stop, refusing entry", signal_row.id)
            return None  # no trade — never enter a scalp with no stop, regardless of confidence

        if levels.confidence < 0.6:
            log.info("scalp_watch %s: confidence %.2f below threshold, skipping",
                      signal_row.id, levels.confidence)
            return None

        # KAITO GUARD and REGIME FILTER still run exactly as in the original plan,
        # unchanged, downstream of this block — they gate go/no-go, never touch qty.
        if not passes_kaito_guard(signal_row, vision_struct):
            return None
        if not passes_regime_filter(signal_row):
            return None

        return exchange.place_limit_order(
            symbol=signal_row.symbol_resolved,
            side=signal_row.side,
            price=levels.entry,       # LIMIT at resolved chart level, not MARKET
            qty=qty,                  # UNCHANGED sizing
            reduce_only=False,
        )

    # ... existing formal_setup path unchanged ...
```

Key guarantees this preserves:
- `qty` is computed identically to every other path — sizing logic is never touched.
- A scalp watch with no derivable stop **never** places an order. It does not fall
  back to "trade without a stop" under any confidence level.
- KAITO guard and regime filter apply to `scalp_watch` exactly as to formal setups —
  same gate, same order, no bypass.
- `resolved_entry_price` / `resolved_target_price` / `resolved_sl_price` /
  `resolution_confidence` are persisted for every scalp_watch signal even when the
  trade is skipped, so you get a full audit trail of near-misses to tune the
  confidence threshold later.

---

### 5. Test additions (extends your mock-test requirement)

Add to the temp-sqlite mock test suite:
1. `test_classify_scalp_watch` — the exact `$PUMP` example text classifies as
   `scalp_watch`, not `formal_setup` or dropped.
2. `test_resolve_scalp_levels_worked_example` — asserts the exact numbers in §3's
   worked example (entry=0.00251, target=0.0023, stop=None, confidence≈0.8).
3. `test_no_stop_no_trade` — resolver returns `stop=None` → `place_entry` returns
   `None` and no `exchange.place_limit_order` call is made (mock the exchange, assert
   `call_count == 0`).
4. `test_sizing_unchanged` — run `place_entry` on both a `formal_setup` and a
   `scalp_watch` signal with identical `port_usdt`/`max_leverage`, assert the `qty`
   passed to `exchange.place_limit_order` is byte-identical in both.

---

### 6. What to update in the original PLAN_attachment_bias.md

- Add `signal_shape` enum value `scalp_watch` next to `formal_setup`/`management`.
- Note the new `text_levels`/`resolved_*`/`resolution_confidence` columns on
  `attachment_reads` (§1 above) as a schema deviation from the original spec.
- Cross-reference this addendum file from the main plan doc.

---

### Next step

If you're running this through Claude Code (or another agent) with real filesystem
access to `/root/workspace/repos/learnernoearner-listener`, hand it both this
addendum and the original `docs/PLAN_attachment_bias.md` — it has everything needed
to implement deliverables 1–7 plus this scalp-watch delta in one pass, in the order
your original doc specifies (schema → fetcher → vision → parser → consumers → bias
job), verifying each on a temp sqlite before moving to the next, exactly as your
constraints require.
