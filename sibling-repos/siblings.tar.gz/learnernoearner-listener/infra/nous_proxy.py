#!/usr/bin/env python3
"""tiny local broker: forwards openai-style chat completions to nous inference api
using the live bearer token from hermes ~/.hermes/auth.json (refreshed by hermes).
listens on the docker bridge so only local containers can reach it."""
import json
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

AUTH_PATH = "/root/.hermes/auth.json"
UPSTREAM = "https://inference-api.nousresearch.com/v1/chat/completions"
BIND = ("172.18.0.1", 9099)


def get_token():
    with open(AUTH_PATH) as f:
        d = json.load(f)
    p = d.get("providers", {}).get("nous", {})
    return p.get("agent_key") or p.get("access_token") or ""


class Handler(BaseHTTPRequestHandler):
    def do_POST(self):
        if not self.path.endswith("/chat/completions"):
            self.send_error(404)
            return
        length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(length)
        req = urllib.request.Request(
            UPSTREAM,
            data=body,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {get_token()}",
                "User-Agent": "hermes-agent/1.0",
            },
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=120) as resp:
                data = resp.read()
                self.send_response(resp.status)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)
        except urllib.error.HTTPError as e:
            data = e.read()
            self.send_response(e.code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
        except Exception as e:
            msg = json.dumps({"error": str(e)}).encode()
            self.send_response(502)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(msg)))
            self.end_headers()
            self.wfile.write(msg)

    def log_message(self, fmt, *args):
        pass


if __name__ == "__main__":
    ThreadingHTTPServer(BIND, Handler).serve_forever()
