@echo off
echo ========================================
echo   Learnernoearner Listener - Auth
echo ========================================
echo.
set /p PHONE="Enter your phone number (e.g. +6281234567890): "
echo.
echo Sending code to %PHONE%...
"C:\Users\it26\AppData\Local\hermes\hermes-agent\venv\Scripts\python.exe" "%~dp0auth.py" %PHONE%
echo.
pause
