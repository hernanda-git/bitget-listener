# mexc-listener — Continuation Handoff (Sera VPS)

> Self-contained prompt + status for a FRESH session. Paste the block in
> "## COPY-PASTE PROMPT" into a new chat to continue.

## Current state (verified this session)
- Repo cloned to `/opt/bots/mexc-listener`, branch `mexc-listener-design` (default).
- `gh` authed as `hernanda-git` with `repo` scope → clone/push works.
- **Suite: 85 passed, GREEN** (`uv run pytest tests/ -q`). No code written yet.
- P0–P3 logic done. Paper-by-default. NOT wired to live MEXC/Telegram/OpenCode. NOT go-live.
- Working tree clean except untracked `uv.lock` (from `uv pip install`, do NOT commit).

## Two Sera-specific facts (cost debugging time — do NOT rediscover)
- **TERMINAL CRASH**: any command containing a `.venv/bin/python*` path dies with
  `ValueError: embedded null byte` (lifecycle_guard reads the ELF as a script, even
  inside `bash -c`). **USE `uv` INSTEAD**: `uv pip install -e ".[test]"` and
  `uv run pytest tests/ -q` (uv auto-detects `.venv` in cwd, never embeds the venv path).
  Also: the `patch` tool refuses `/etc/systemd` writes.
- **POSTGRES**: role `app`, db `fatty_config`, password in `~/.pg_app_pw` (NOT the one
  in `~/.pg_setup_role.sql` — that is a different setup-role pw and fails). Unix-socket
  peer auth FAILS for root; use host:
  `PGPASSWORD=*** ~/.pg_app_pw) psql -h 127.0.0.1 -U app -d fatty_config`.
  Shared tables already exist: `bots`(paper,channel,tg_bot_token_env[name only — secrets
  rule OK), `trades_log` (NO fee/liq columns yet — you must ALTER them in),
  `signals_log`, `risk`, `bias_log`.

## Design decisions already made (don't re-derive)
- `GoLiveStore` → `bots` table (`paper` bool) + new `mexc_golive` table (one-time
  `go_live_token`). Do NOT alter shared `bots` columns; keep `tg_bot_token_env` as env-name.
- `DecisionStore` → new `mexc_decisions(decision_id PK, side)`.
- `PositionStore` → new `mexc_positions(symbol PK, …)` + `mexc_orders(order_id PK, …)`.
- `EvalStore` → new `mexc_eval(pair PK, wins, losses)`.
- `ledger.py` → fee-aware `trades_log` writer; `init_schema()` ALTERs nullable
  `fee`, `close_fee`, `liq_price` onto `trades_log` (idempotent).
- TDD: unit-test Postgres stores with an INJECTED fake `conn` (records executed
  SQL+params, simulates fetch) — zero network, consistent with the 85 fakes-only tests.
  Add a real-DB integration test gated behind `@pytest.mark.integration` + availability
  check so the default suite stays hermetic at 85+.
- Wire into `main.build_container`: use real PG stores when `CONFIG_DB_URL` set AND
  `MEXC_FAKE` unset; else keep the existing `_Mem*` fakes. Commit-per-item, push to
  `origin/mexc-listener-design`.

## COPY-PASTE PROMPT

```
Continue building `mexc-listener` on this machine (Sera VPS).

REPO: /opt/bots/mexc-listener  (branch mexc-listener-design, already cloned + checked out)
PRIVATE GITHUB: github.com/hernanda-git/mexc-listener
STATUS: P0-P3 logic DONE + 85 fakes-only unit tests GREEN. NOT wired to live MEXC/Telegram/OpenCode, NOT go-live. Paper-by-default.

FIRST, READ IN ORDER (source of truth):
1. DOCUMENTATION.md   2. docs/DESIGN.md   3. docs/CONCRETE-SPEC.md   4. .hermes/plans/mexc-listener-plan.md

TWO SERA-SPECIFIC FACTS (already cost debugging time — do not rediscover):
- TERMINAL CRASH: any command containing a `.venv/bin/python*` path dies with
  "embedded null byte" (lifecycle_guard reads the ELF as a script, even inside
  `bash -c`). USE `uv` INSTEAD: `uv pip install -e ".[test]"` and `uv run pytest
  tests/ -q` (uv auto-detects .venv in cwd, never embeds the venv path).
- POSTGRES: role `app`, db `fatty_config`, password in `~/.pg_app_pw` (NOT the one
  in `~/.pg_setup_role.sql`). Unix-socket peer auth FAILS for root; use host:
  `PGPASSWORD=*** ~/.pg_app_pw) psql -h 127.0.0.1 -U app -d fatty_config`.
  Shared tables already exist: bots(paper,channel,tg_bot_token_env[name only]),
  trades_log (NO fee/liq columns yet — you must ALTER them in), signals_log,
  risk, bias_log.

VERIFY BEFORE BUILDING (stop if red):
  cd /opt/bots/mexc-listener
  uv run pytest tests/ -q   # expect 85 passed, green
If not green, report and stop.

MANDATORY RULES:
- TDD only: write failing test FIRST, implement, green, then commit.
- Run FULL suite (85+ green) before every commit. No commit on red.
- Code > git history > docs. If doc contradicts code, fix the doc.
- No LLM fallback for trades. Repair is deterministic (src/exchanges/repair.py).
  LLM only DECIDES (src/llm/brain.py), never fixes an order.
- Never auto-cancel reduce_only protective SL/TP.
- Paper by default. Real orders only after GoLiveGate (src/notifier/bot.py) AND
  scripts/mexc_api_probe.py prints ALL GREEN against the real MEXC key.
- Commit small per logical unit; push to origin/mexc-listener-design after each green step.
- Secrets live in .env (gitignored). Config DB stores env-var NAMES only, never secrets.

NEXT ITEMS (from DOCUMENTATION.md §2, in order):
1. src/config/db.py — Postgres ConfigStore implementing the abstract bases
   GoLiveStore(bots+mexc_golive token), DecisionStore(mexc_decisions),
   PositionStore(mexc_positions+mexc_orders), EvalStore(mexc_eval).
   src/store/ledger.py — fee-aware trades_log writer; init_schema() ALTERs
   trades_log to add fee/close_fee/liq_price (idempotent).
   TDD: test Postgres stores with an injected fake `conn` (records SQL+params,
   simulates fetch) — zero network. Gate a real-DB test behind
   pytest.mark.integration + availability check so default suite stays hermetic.
   Wire into main.build_container: use PG stores when CONFIG_DB_URL set AND
   MEXC_FAKE unset, else keep existing _Mem* fakes.
2. src/sources/telegram.py — live Telethon listener: events.NewMessage on
   @fattyfatclub, extract image bytes, call LLMBrain.decide, route
   ENTER->Gate1->Gate2->OrderService, MANAGEMENT->OrderService transform.
3. src/llm/client.py — real OpenAI-compat client for OpenCode
   (LLM_BASE_URL/LLM_API_KEY/LLM_MODEL=deepseek-v4-flash-free); wire into
   main.build_container when MEXC_FAKE unset.
4. src/exchanges/mexc.py — real _signed_request + place_order/close/stop/position/
   mark against MEXC Futures REST; validate vs mexc_api_probe.py output.
5. src/streaming/mexc_ws.py — live connect() loop + jittered reconnect + heartbeat,
   dispatch to PositionManager/OrderService callbacks.
6. src/notifier/bot.py — Telegram bot commands (/status /balance /positions /live /paper).
7. /etc/caddy/Caddyfile — reverse_proxy :8080 + /ws/events (see scripts/deploy.sh [4/5]).

DO NOT go live. After wiring, run scripts/mexc_api_probe.py and report its result.
Report a short status after each item: what changed, test count, commit hash.
```

## File map for pending items
| Item | File(s) |
|---|---|
| Postgres ConfigStore + ledger | `src/config/db.py`, `src/store/ledger.py` |
| Live Telethon listener | `src/sources/telegram.py` |
| OpenCode LLM client | `src/llm/client.py` (wire in `main.build_container`) |
| MEXC order REST endpoints | `src/exchanges/mexc.py` (`_signed_request` + `place_order`/`close`/`stop`) |
| MEXC WS live loop | `src/streaming/mexc_ws.py` (`connect`) |
| Telegram bot commands | `src/notifier/bot.py` |
| Caddy | `/etc/caddy/Caddyfile` (see `deploy.sh`) |
