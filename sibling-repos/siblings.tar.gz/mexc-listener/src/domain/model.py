"""Frozen domain dataclasses for mexc-listener.

Model-level correctness rules (DESIGN §3 / CONCRETE-SPEC §4):
- Fill.fee is ALWAYS recorded (non-zero when a real fill occurs).
- Position.liq_price holds the REAL liquidation price (never 0.00).
- Protective orders carry reduce_only; entry orders do NOT.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


class Side(str, Enum):
    BUY = "BUY"
    SELL = "SELL"


class Direction(str, Enum):
    LONG = "LONG"
    SHORT = "SHORT"


class SignalType(str, Enum):
    ENTRY = "ENTRY"
    CONDITIONAL = "CONDITIONAL"
    MANAGEMENT = "MANAGEMENT"


class Action(str, Enum):
    ENTER = "ENTER"
    CONDITIONAL = "CONDITIONAL"
    SKIP = "SKIP"
    MANAGEMENT = "MANAGEMENT"


@dataclass(frozen=True)
class Instrument:
    """Canonical MEXC futures symbol (REST style, e.g. BTCUSDT)."""
    symbol: str
    base: str
    quote: str = "USDT"
    tick_size: float = 0.0
    lot_size: float = 0.0
    min_qty: float = 0.0
    max_qty: float = 0.0
    min_price: float = 0.0
    max_price: float = 0.0
    min_notional: float = 0.0
    max_leverage: int = 125
    contract_size: float = 1.0  # for 1000x / multiplier quirks (F11)

    def to_ws_symbol(self) -> str:
        """REST BTCUSDT -> WS BTC_USDT (underscore)."""
        return self.symbol.replace("USDT", "_USDT") if self.symbol.endswith("USDT") else self.symbol


@dataclass(frozen=True)
class RawSignal:
    """Raw Telegram message from @fattyfatclub, text + optional image attachments."""
    message_id: int
    channel: str
    text: str
    images: tuple[bytes, ...] = ()
    ts: int = 0


@dataclass(frozen=True)
class Signal:
    """Normalized trade call (USDT-quoted, peg=1.0 like bybit)."""
    pair: str
    direction: Direction
    entry: Optional[float]
    sl: Optional[float]
    tps: tuple[float, ...] = ()
    leverage: Optional[int] = None
    raw_text: str = ""
    signal_type: SignalType = SignalType.ENTRY
    confidence_pct: float = 0.0
    bias: str = ""


@dataclass(frozen=True)
class OrderRequest:
    """MEXC-specific order body."""
    symbol: str
    side: Side
    price: float
    qty: float
    order_type: str = "LIMIT"   # LIMIT | STOP | TAKE_PROFIT
    reduce_only: bool = False
    client_order_id: str = ""
    stop_price: Optional[float] = None
    time_in_force: str = "GTC"
    leverage: Optional[int] = None      # applied for opening orders (None -> exchange default)
    margin_type: str = "isolated"       # "isolated" (openType 2) | "cross" (openType 1)


@dataclass
class Position:
    symbol: str
    direction: Direction
    size: float
    entry: float
    leverage: int
    liq_price: float          # REAL liquidation price (never 0.00)
    mark: float = 0.0
    pnl: float = 0.0
    fee: float = 0.0
    margin: float = 0.0
    status: str = "OPEN"


@dataclass
class Fill:
    symbol: str
    side: Side
    fill_price: float
    qty: float
    fee: float                # non-zero real fee (USDT)
    fee_asset: str = "USDT"
    ts: int = 0
    client_order_id: str = ""
    pnl: float = 0.0          # realized PnL on a closing fill (0.0 if opening)


@dataclass
class TradeDecision:
    """LLM brain output (structured)."""
    action: Action
    pair: str
    direction: Optional[Direction] = None
    entry: Optional[float] = None
    sl: Optional[float] = None
    tps: tuple[float, ...] = ()
    leverage: Optional[int] = None
    confidence_pct: float = 0.0
    bias: str = ""
    reason: str = ""
