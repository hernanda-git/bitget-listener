"""Manual trading controller + risk calculator for the dashboard.

- calc(): given a pair, margin, leverage and entry, computes the exact qty
  (lot-rounded), notional, margin actually required, whether it clears MEXC's
  $5 min-notional, the max leverage the pair/balance allows, and the isolated
  liquidation buffer (≈ 1/leverage).
- manual_enter(): place a manual opening order with optional SL/TP (live or paper).
- manual_close(): close an open position by symbol (live or paper).
- set_mode(): toggle paper/live by flipping the order service's hard gate and
  persisting the flag to .env.

All helpers are thin wrappers over the already-verified exchange + OrderService;
no new network code. Manual orders use a distinct client_order_id prefix so they
never collide with signal-driven orders (idempotency guard stays intact).
"""
from __future__ import annotations

import math
import time

from domain.model import Side


def calc(exchange, symbol: str, margin: float, leverage: int, entry: float,
         balance_available: float = 0.0) -> dict:
    """Compute a valid order plan for a manual entry.

    Returns a dict with: qty, notional, margin_required, min_notional_ok,
    max_leverage (pair cap), max_leverage_balance (balance-constrained),
    liq_buffer_pct, last_price, tick, lot, note.
    """
    inst = exchange.get_instrument(symbol)
    last = entry or 0.0
    if last <= 0:
        # best-effort last price from ticker cache
        try:
            for s in exchange.get_all_symbols():
                if s["symbol"] == symbol:
                    last = s["lastPrice"] or 0.0
                    break
        except Exception:  # noqa: BLE001
            pass
    if last <= 0:
        last = inst.min_price or 0.0

    lev = max(1, int(leverage))
    # notional target from margin x leverage
    target_notional = margin * lev
    # raw qty then floor to lot
    qty = target_notional / last if last > 0 else 0.0
    step = inst.lot_size or 1.0
    if step > 0:
        qty = math.floor(qty / step) * step
    # enforce MEXC min notional by bumping qty up to the lot step
    min_notional = inst.min_notional or 5.0
    if last > 0:
        while qty * last < min_notional and qty < (inst.max_qty or 1e12):
            qty += step
    # recompute actual notional + margin required at the chosen leverage
    notional = qty * last
    margin_required = notional / lev if lev else notional
    min_notional_ok = notional >= min_notional - 1e-6

    # available leverage: pair cap, and balance-constrained (balance * lev >= notional)
    max_lev_pair = int(inst.max_leverage or 125)
    max_lev_balance = 1
    if balance_available > 0 and notional > 0:
        max_lev_balance = max(1, int(math.floor((balance_available) / (notional / lev)) if lev else 1))
    # simpler balance constraint: max lev so that margin_required <= balance
    max_lev_balance = max(1, int(math.floor(balance_available / margin_required))) if margin_required > 0 else max_lev_pair
    max_lev_balance = min(max_lev_balance, max_lev_pair)

    # isolated liquidation buffer ≈ 1/leverage (price move to liquidation)
    liq_buffer_pct = 100.0 / lev if lev else 0.0

    note = ""
    if not min_notional_ok:
        note = f"below MEXC min notional ${min_notional:.0f} — bumped qty"
    if margin_required > balance_available > 0:
        note = (note + "; " if note else "") + "margin exceeds available balance"

    return {
        "symbol": symbol,
        "last_price": last,
        "tick": inst.tick_size,
        "lot": step,
        "leverage": lev,
        "qty": qty,
        "notional": notional,
        "margin_required": margin_required,
        "min_notional": min_notional,
        "min_notional_ok": min_notional_ok,
        "max_leverage": max_lev_pair,
        "max_leverage_balance": max_lev_balance,
        "liq_buffer_pct": liq_buffer_pct,
        "note": note,
    }


def manual_enter(order_service, exchange, symbol: str, side: str, entry: float,
                 margin: float, leverage: int, sl=None, tp=None,
                 client_prefix: str = "MAN") -> dict:
    """Place a manual opening order (marketable limit at `entry`).

    side: 'BUY' (long) or 'SELL' (short). margin x leverage => notional; qty is
    computed + lot-rounded + min-notional-floored via the exchange helpers.
    SL/TP are optional protective orders.
    """
    inst = exchange.get_instrument(symbol)
    lev = max(1, int(leverage))
    last = entry or 0.0
    if last <= 0:
        try:
            for s in exchange.get_all_symbols():
                if s["symbol"] == symbol:
                    last = s["lastPrice"] or 0.0
                    break
        except Exception:  # noqa: BLE001
            pass
    if last <= 0:
        return {"ok": False, "error": "entry price is 0 and no market price available"}
    notional = margin * lev
    qty = notional / last
    qty = exchange.round_qty(symbol, qty, last)  # floor to lot + min-notional bump
    entry_px = exchange.round_price(symbol, last)
    if qty <= 0:
        return {"ok": False, "error": "computed qty <= 0 (check margin/leverage)"}
    decision_id = f"{client_prefix}-{int(time.time()*1000)}"
    side_norm = "BUY" if str(side).upper().startswith("B") else "SELL"
    tps = (float(tp),) if tp not in (None, 0, "") else ()
    res = order_service.enter(
        decision_id, symbol, side_norm, entry_px, qty, lev,
        float(sl) if sl not in (None, 0, "") else None, tps)
    return {
        "ok": res.ok,
        "status": res.status,
        "order_ids": list(res.order_ids),
        "symbol": symbol, "side": side_norm, "qty": qty,
        "notional": qty * entry_px, "leverage": lev,
        "paper": order_service.paper,
    }


def manual_close(order_service, exchange, symbol: str, side: str = None) -> dict:
    """Close an open position for `symbol` (reduce_only market). Live or paper."""
    # Determine close side from current position if not supplied
    if side is None:
        try:
            pos = exchange.get_position(symbol)
            if pos:
                side = "SELL" if str(pos.direction).upper() == "LONG" else "BUY"
        except Exception:  # noqa: BLE001
            pass
    if side is None:
        side = "SELL"  # default attempt (will be validated by exchange)
    # Use exchange.close directly so it works in live mode (OrderService.enter is
    # for entries; close uses reduce_only market order on the open position).
    if order_service.paper:
        # paper close via dashboard state? simplest: emit a paper close event
        if order_service.bus is not None:
            order_service.bus.publish({"type": "paper_close", "data": {"symbol": symbol}})
        return {"ok": True, "status": "PAPER_CLOSED", "symbol": symbol, "paper": True}
    last = 0.0
    try:
        for s in exchange.get_all_symbols():
            if s["symbol"] == symbol:
                last = s["lastPrice"] or 0.0
                break
    except Exception:  # noqa: BLE001
        pass
    qty = 0.0
    try:
        pos = exchange.get_position(symbol)
        if pos:
            qty = pos.size
    except Exception:  # noqa: BLE001
        pass
    res = exchange.close(symbol, Side.SELL if side.upper() == "SELL" else Side.BUY, qty, price=last or None)
    return {"ok": True, "status": res.get("status") or "CLOSED",
            "raw": res, "symbol": symbol, "paper": False}


def set_mode(order_service, mode: str, persist_config=None) -> dict:
    """Toggle paper/live. mode: 'live' | 'paper'.

    Flips the OrderService hard gate (paper flag). Persists MEXC_FAKE to .env so a
    restart keeps the mode. Returns the resulting paper boolean.
    """
    paper = (mode or "paper").lower() != "live"
    order_service.paper = paper
    # keep exchange margin_type in sync (isolated default enforced)
    if persist_config is not None:
        try:
            persist_config("MEXC_FAKE", "1" if paper else "0")
            persist_config("MEXC_GO_LIVE", "0" if paper else "1")
        except Exception:  # noqa: BLE001
            pass
    return {"ok": True, "mode": "paper" if paper else "live", "paper": paper}
