"""FastAPI Web UI + WebSocket event stream.

Real-time single-page dashboard: overview KPIs, live market prices, positions,
balance/equity, trades + pnl chart, per-pair statistics, a live logs tail and an
activities timeline. A WebSocket mirrors queued events to connected clients; the
dashboard also polls REST snapshots so data is always fresh.

EventBus: synchronous publish (append to deque); the WS endpoint drains it
asynchronously. DashboardState aggregates equity history, stats and folds bus
events into logs/activities.
"""
from __future__ import annotations

# BTC dominance fetcher lives in dashboard_state (it publishes ticks via PriceBus).
from web.dashboard_state import _fetch_btcd  # noqa: F401  (used by /api/btcd route)

import asyncio
import base64
import hashlib
import hmac
import json
import os
import secrets
import time
import urllib.request
from collections import deque
from typing import Callable, Optional

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException, Depends, status
from fastapi.responses import HTMLResponse
from fastapi.security import HTTPBasic, HTTPBasicCredentials


# ----------------------------------------------------------------------------
# Dashboard password auth (HTTP Basic over HTTPS/Cloudflare TLS).
# Password (user-provided) is NOT stored; only a PBKDF2 hash in .env as
# DASH_PASSWORD_HASH = "<salt_hex>:<derived_hex>". Constant-time compare.
# ----------------------------------------------------------------------------
_AUTH = HTTPBasic(auto_error=False)


def _load_hash() -> Optional[str]:
    h = os.getenv("DASH_PASSWORD_HASH", "")
    return h.strip() or None


def _verify_pw(password: str) -> bool:
    stored = _load_hash()
    if not stored:
        return False  # no hash configured -> deny (fail closed)
    try:
        salt_hex, dk_hex = stored.split(":", 1)
        salt = bytes.fromhex(salt_hex)
        expected = bytes.fromhex(dk_hex)
    except Exception:  # noqa: BLE001
        return False
    dk = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 200000)
    return hmac.compare_digest(dk, expected)


def require_auth(creds: Optional[HTTPBasicCredentials] = Depends(_AUTH)) -> None:
    if creds is None or not _verify_pw(creds.password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Not authenticated",
            headers={"WWW-Authenticate": "Basic"},
        )


# Lighter gate for the three mutating trading actions (manual enter / close / mode).
# Monitoring + read-only calc are open; only actions require the password.
def require_trade_auth(creds: Optional[HTTPBasicCredentials] = Depends(_AUTH)) -> None:
    if creds is None or not _verify_pw(creds.password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Password required to trade",
            headers={"WWW-Authenticate": "Basic"},
        )


def _ws_authorized(headers) -> bool:
    """Check Basic auth on a WebSocket upgrade (Authorization: Basic ...)."""
    auth = None
    if isinstance(headers, dict):
        auth = headers.get("authorization") or headers.get("Authorization")
    if not auth:
        return False
    try:
        scheme, b64 = auth.split(" ", 1)
        if scheme.lower() != "basic":
            return False
        user_pass = base64.b64decode(b64).decode()
        _, pw = user_pass.split(":", 1)
        return _verify_pw(pw)
    except Exception:  # noqa: BLE001
        return False



class EventBus:
    """In-process pub/sub. publish() is synchronous; WS endpoint drains the queue."""
    def __init__(self, maxlen: int = 2000) -> None:
        self._queue: deque = deque(maxlen=maxlen)

    def publish(self, event: dict) -> None:
        self._queue.append(event)

    def drain(self) -> list[dict]:
        out = []
        while self._queue:
            out.append(self._queue.popleft())
        return out


_DASHBOARD_HTML = r"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="color-scheme" content="light">
<title>mexc-listener · fattyfatclub → MEXC</title>
<style>
:root{
  --bg:#f4f7fb;
  --bg-2:#eef3f9;
  --surface:#ffffff;
  --surface-2:#f8fafc;
  --ink:#0f1d2e;
  --ink-soft:#2b3d52;
  --mut:#64748b;
  --mut-2:#94a3b8;
  --line:#e5edf5;
  --brand:#14b8a6;
  --brand-2:#0d9488;
  --accent:#6366f1;
  --ok:#059669;
  --bad:#e11d48;
  --warn:#d97706;
  --pp:#7c3aed;
  --amber-bg:#fff7ed;
  --green-bg:#ecfdf5;
  --radius:18px;
  --radius-sm:12px;
  --shadow:0 12px 32px rgba(15,42,78,.08),0 2px 6px rgba(15,42,78,.05);
  --shadow-sm:0 2px 8px rgba(15,42,78,.06);
  --grad:linear-gradient(135deg,#14b8a6 0%,#6366f1 100%);
  --grad-soft:linear-gradient(135deg,rgba(20,184,166,.12),rgba(99,102,241,.12));
}
*{box-sizing:border-box}
html,body{margin:0;padding:0}
body{
  font-family:'Inter',system-ui,-apple-system,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;
  background:var(--bg);
  color:var(--ink);
  font-size:14px;
  line-height:1.45;
  min-height:100vh;
  -webkit-font-smoothing:antialiased;
  text-rendering:optimizeLegibility;
}
.bg{position:fixed;inset:0;z-index:-1;overflow:hidden;pointer-events:none;
  background:linear-gradient(180deg,#f8fbfe 0%,var(--bg) 55%,var(--bg-2) 100%);}
.blob{position:absolute;border-radius:50%;filter:blur(70px);opacity:.5;mix-blend-mode:multiply;}
.b1{width:420px;height:420px;left:-90px;top:-110px;background:#b7f3e9;}
.b2{width:380px;height:380px;right:-70px;top:60px;background:#dcd9ff;}
.b3{width:340px;height:340px;left:38%;bottom:-160px;background:#fde7d1;}
@media (prefers-reduced-motion:reduce){.blob{opacity:.38}}

.topbar{
  position:sticky;top:0;z-index:20;
  display:flex;align-items:center;gap:1rem;flex-wrap:wrap;
  padding:.8rem 1.25rem;
  background:rgba(255,255,255,.82);
  backdrop-filter:blur(14px);
  border-bottom:1px solid var(--line);
}
.brand{display:flex;align-items:center;gap:.7rem;min-width:0;}
.brand-mark{
  width:38px;height:38px;border-radius:11px;flex:none;
  background:var(--grad);
  display:grid;place-items:center;
  box-shadow:0 6px 14px rgba(20,184,166,.28);
  color:#fff;
}
.brand-mark svg{width:21px;height:21px}
.brand-text{min-width:0}
.brand-text h1{font-size:1.02rem;font-weight:800;margin:0;letter-spacing:-.01em;color:var(--ink);
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.brand-text p{font-size:.68rem;margin:.1rem 0 0;color:var(--mut);white-space:nowrap;
  overflow:hidden;text-overflow:ellipsis}
.status-cluster{display:flex;align-items:center;gap:.5rem;margin-left:auto;flex-wrap:wrap}
.pill{display:inline-flex;align-items:center;gap:.35rem;font-size:.7rem;font-weight:700;
  padding:.28rem .62rem;border-radius:999px;border:1px solid var(--line);
  background:var(--surface);color:var(--ink-soft);letter-spacing:.02em;white-space:nowrap}
.pill .dot{width:6px;height:6px;border-radius:50%;background:var(--mut-2)}
.pill.paper{background:var(--amber-bg);border-color:#fde4c4;color:#b45309}
.pill.live{background:var(--green-bg);border-color:#b8eed8;color:var(--ok)}
.pill.live .dot{background:var(--ok);box-shadow:0 0 0 3px rgba(5,150,105,.15)}
.pill.accent{background:var(--grad-soft);border-color:#d6d3fb;color:#4f46e5}
.conn{display:inline-flex;align-items:center;gap:.4rem;font-size:.72rem;color:var(--mut);
  font-weight:600;padding-left:.2rem}
.conn .dot{width:8px;height:8px;border-radius:50%;background:var(--warn)}
.conn .dot.live{background:var(--ok);box-shadow:0 0 0 4px rgba(5,150,105,.12)}

.shell{max-width:1440px;margin:0 auto;padding:1.2rem 1.25rem 2rem}
.card{background:var(--surface);border:1px solid var(--line);border-radius:var(--radius);
  box-shadow:var(--shadow);}
.card-head{display:flex;align-items:center;gap:.6rem;padding:1rem 1.15rem .2rem}
.card-head h2{font-size:.72rem;font-weight:800;margin:0;color:var(--mut);
  text-transform:uppercase;letter-spacing:.08em}
.card-head .hint{margin-left:auto;font-size:.7rem;color:var(--mut-2);font-weight:600}
.card-body{padding:1rem 1.15rem 1.15rem}

.kpi-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:.9rem}
.kpi{display:flex;gap:.85rem;align-items:flex-start;padding:1.05rem 1.1rem;position:relative;
  overflow:hidden;transition:transform .18s ease,box-shadow .18s ease}
.kpi:hover{transform:translateY(-2px);box-shadow:0 16px 38px rgba(15,42,78,.12),0 2px 6px rgba(15,42,78,.05)}
.kpi::after{content:'';position:absolute;right:-30px;top:-30px;width:90px;height:90px;border-radius:50%;
  background:var(--grad-soft);opacity:.5;filter:blur(6px)}
.kpi-icon{width:38px;height:38px;border-radius:11px;flex:none;display:grid;place-items:center;
  background:var(--grad-soft);color:var(--brand-2)}
.kpi-icon svg{width:19px;height:19px}
.kpi-icon.alt{background:#eef2ff;color:#4f46e5}
.kpi-icon.green{background:var(--green-bg);color:var(--ok)}
.kpi-icon.amber{background:var(--amber-bg);color:var(--warn)}
.kpi-icon.red{background:#fff1f2;color:var(--bad)}
.kpi-body{min-width:0;position:relative;z-index:1}
.kpi-label{font-size:.68rem;font-weight:700;color:var(--mut);text-transform:uppercase;
  letter-spacing:.05em}
.kpi-value{font-size:1.5rem;font-weight:800;margin-top:.28rem;line-height:1.1;
  font-variant-numeric:tabular-nums;color:var(--ink);white-space:nowrap}
.kpi-sub{font-size:.7rem;color:var(--mut-2);margin-top:.3rem;font-weight:500}
.pos{color:var(--ok) !important}
.neg{color:var(--bad) !important}
.mutc{color:var(--mut)}

.section{margin-top:1rem}
.market-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:.9rem}
.mkt{padding:1rem;border-radius:var(--radius-sm);background:var(--surface-2);
  border:1px solid var(--line)}
.mkt-top{display:flex;align-items:center;gap:.5rem}
.mkt-sym{font-size:.78rem;font-weight:800;color:var(--ink-soft);letter-spacing:.02em}
.mkt-chg{margin-left:auto;font-size:.72rem;font-weight:700;padding:.16rem .5rem;border-radius:999px}
.mkt-chg.pos{background:var(--green-bg);color:var(--ok)}
.mkt-chg.neg{background:#fff1f2;color:var(--bad)}
.mkt-price{font-size:1.35rem;font-weight:800;margin-top:.45rem;font-variant-numeric:tabular-nums;
  color:var(--ink)}
.mkt-chart{position:relative;margin-top:.6rem;height:130px}
.mkt.btcd-tile{grid-column:span 2}
.mkt.btcd-tile .mkt-chart{height:150px}
@media (max-width:520px){ .mkt.btcd-tile{grid-column:span 1} }

.grid2x2{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:1rem;margin-top:1rem}
.grid2col{display:grid;grid-template-columns:minmax(0,1.3fr) minmax(0,1fr) minmax(0,1fr) minmax(0,1fr);gap:1rem;margin-top:1rem}
.grid2col > .card:first-child{grid-column:span 2}
.chart-wrap{position:relative;height:360px}
.table-wrap{overflow:auto;max-height:340px}
table{width:100%;border-collapse:collapse;font-size:.78rem}
th,td{text-align:left;padding:.55rem .6rem;border-bottom:1px solid var(--line);white-space:nowrap}
th{color:var(--mut);font-weight:700;font-size:.66rem;text-transform:uppercase;letter-spacing:.05em;
  background:var(--surface-2);position:sticky;top:0;z-index:1}
tbody tr:last-child td{border-bottom:0}
tbody tr:hover{background:#fbfdff}
.num{font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;font-variant-numeric:tabular-nums}
.sym{font-weight:700;color:var(--ink)}
.side{font-size:.66rem;font-weight:800;padding:.14rem .42rem;border-radius:6px;text-transform:uppercase}
.side.long,.side.buy{background:var(--green-bg);color:var(--ok)}
.side.short,.side.sell{background:#fff1f2;color:var(--bad)}
.empty{color:var(--mut-2);font-size:.8rem;padding:.4rem 0}

.stats-list{display:grid;grid-template-columns:1fr;gap:0}
.stat-row{display:flex;justify-content:space-between;align-items:center;padding:.6rem .15rem;
  border-bottom:1px solid var(--line)}
.stat-row:last-child{border-bottom:0}
.stat-row .k{color:var(--mut);font-size:.78rem;font-weight:600}
.stat-row .v{font-weight:800;font-variant-numeric:tabular-nums;font-size:.85rem;color:var(--ink)}

.timeline{height:280px;overflow:auto}
.act-row{display:flex;gap:.6rem;padding:.6rem .1rem;border-bottom:1px solid var(--line);align-items:flex-start}
.act-row:last-child{border-bottom:0}
.act-dot{width:8px;height:8px;border-radius:50%;flex:none;margin-top:.4rem;background:var(--mut-2)}
.act-dot.sig{background:var(--brand)}
.act-dot.ord{background:var(--pp)}
.act-dot.fill{background:var(--ok)}
.act-dot.pos{background:#2563eb}
.act-dot.wal{background:var(--warn)}
.act-dot.warn{background:var(--warn)}
.act-body{min-width:0;flex:1}
.act-head{display:flex;align-items:center;gap:.5rem}
.act-msg{font-size:.76rem;color:var(--ink-soft);margin-top:.18rem;word-break:break-word}
.tag{font-size:.6rem;font-weight:800;padding:.12rem .42rem;border-radius:6px;
  background:var(--surface-2);border:1px solid var(--line);color:var(--mut);
  text-transform:uppercase;letter-spacing:.04em;white-space:nowrap}
.tag.sig{color:var(--brand-2);background:#ecfdfb;border-color:#c2f2e9}
.tag.ord{color:var(--pp);background:#f3efff;border-color:#e2d9fb}
.tag.fill{color:var(--ok);background:var(--green-bg);border-color:#b8eed8}
.tag.pos{color:#2563eb;background:#eff4ff;border-color:#d4e1fb}
.tag.wal,.tag.warn{color:var(--warn);background:var(--amber-bg);border-color:#fde4c4}
.tag.ok{color:var(--ok);background:var(--green-bg);border-color:#b8eed8}
.tag.bad{color:var(--bad);background:var(--red-bg);border-color:#f7c9c9}
.gate-banner{font-size:.78rem;font-weight:700;padding:.55rem .7rem;border-radius:10px;margin-bottom:.7rem;border:1px solid var(--line)}
.gate-banner.warn{color:var(--warn);background:var(--amber-bg);border-color:#fde4c4}
.gate-banner.ok{color:var(--ok);background:var(--green-bg);border-color:#b8eed8}
.gate-banner:empty{display:none}
.risk-row{display:flex;align-items:center;justify-content:space-between;gap:.6rem;padding:.45rem 0}
.risk-row label{font-size:.74rem;font-weight:700;color:var(--mut)}
.risk-input{display:flex;align-items:center;gap:.3rem}
.risk-input input{width:74px;padding:.42rem .5rem;border-radius:9px;border:1px solid var(--line);
  background:var(--surface-2);color:var(--ink);font-size:.95rem;font-weight:800;text-align:right;
  font-variant-numeric:tabular-nums}
.risk-x{font-size:.8rem;font-weight:800;color:var(--mut-2)}
.seg{display:inline-flex;border:1px solid var(--line);border-radius:9px;overflow:hidden}
.seg button{background:var(--surface-2);border:0;color:var(--mut);font-weight:800;font-size:.66rem;
  letter-spacing:.04em;padding:.4rem .6rem;cursor:pointer}
.seg button.on{background:var(--brand-2);color:#04201c}
.btn{margin-top:.6rem;width:100%;padding:.55rem;border-radius:10px;border:1px solid var(--line);
  background:var(--brand-2);color:#04201c;font-weight:800;font-size:.8rem;cursor:pointer}
.btn:active{transform:translateY(1px)}
.risk-msg{font-size:.72rem;font-weight:700;margin-top:.5rem;min-height:.9rem;color:var(--mut)}
.risk-msg.ok{color:var(--ok)}
.risk-msg.bad{color:var(--bad)}
.risk-note{font-size:.64rem;color:var(--mut-2);margin-top:.4rem}
.ts{font-family:ui-monospace,Menlo,Consolas,monospace;font-size:.68rem;color:var(--mut-2)}

.log{height:280px;overflow:auto;background:#0f1d2e;color:#dbe7f3;border-radius:var(--radius-sm);
  padding:.7rem .8rem;font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;font-size:.72rem}
.log-line{padding:.16rem 0;display:flex;gap:.55rem;line-height:1.5}
.log-line .t{color:#7c8ea3;flex:none}
.log-line .msg{color:#c6d4e2;word-break:break-word;min-width:0}
.log-line .tag{flex:none;margin-top:.1rem}
.log-line .sig{color:#5eead4}.log-line .ord{color:#c4b5fd}.log-line .fill{color:#6ee7b7}
.log-line .pos{color:#93c5fd}.log-line .wal,.log-line .warn{color:#fcd34d}
.log-line .mut{color:#94a3b8}

.foot{display:flex;align-items:center;gap:1rem;flex-wrap:wrap;margin-top:1.1rem;
  padding:.75rem 1rem;color:var(--mut);font-size:.72rem;font-weight:500}
.foot .foot-brand{margin-left:auto;color:var(--mut-2)}

@media (max-width:1100px){
  .grid2col{grid-template-columns:minmax(0,1fr) minmax(0,1fr)}
  .grid2col > .card:first-child{grid-column:span 2}
}
@media (max-width:820px){
  .grid2x2{grid-template-columns:1fr}
  .grid2col{grid-template-columns:1fr}
  .grid2col > .card:first-child{grid-column:span 1}
}
@media (max-width:640px){
  .shell{padding:.9rem .8rem 1.5rem}
  .kpi-grid{grid-template-columns:1fr 1fr;gap:.7rem}
  .kpi{padding:.85rem .9rem}
  .kpi-value{font-size:1.25rem}
  .brand-text p{display:none}
  .topbar{padding:.7rem .8rem}
  .chart-wrap{height:280px}
}
@media (max-width:420px){
  .kpi-grid{grid-template-columns:1fr}
}

/* ---- login gate ---- */
#login{position:fixed;inset:0;z-index:100;display:flex;align-items:center;justify-content:center;
  background:linear-gradient(135deg,#0f1d2e 0%,#1e293b 100%);}
#login .box{background:var(--surface);border:1px solid var(--line);border-radius:var(--radius);
  box-shadow:var(--shadow);padding:2rem 2.2rem;width:min(360px,90vw);text-align:center}
#login h1{font-size:1.1rem;margin:0 0 .3rem;font-weight:800}
#login p{color:var(--mut);font-size:.78rem;margin:.2rem 0 1.1rem}
#login input{width:100%;padding:.7rem .8rem;border-radius:11px;border:1px solid var(--line);
  background:var(--surface-2);color:var(--ink);font-size:.95rem;margin-bottom:.6rem}
#login button{width:100%;padding:.7rem;border-radius:11px;border:1px solid var(--line);
  background:var(--brand-2);color:#04201c;font-weight:800;font-size:.85rem;cursor:pointer}
#login .err{color:var(--bad);font-size:.72rem;min-height:1rem;margin-top:.4rem;font-weight:700}
#login.locked{opacity:.6;pointer-events:none}

/* ---- manual trade ---- */
.manual-row{display:flex;gap:.5rem;flex-wrap:wrap;align-items:flex-end;margin-bottom:.5rem}
.manual-row .fld{flex:1 1 110px;min-width:0}
.manual-row label{font-size:.66rem;font-weight:700;color:var(--mut);text-transform:uppercase;letter-spacing:.04em;display:block;margin-bottom:.25rem}
.manual-row input,.manual-row select{padding:.5rem .55rem;border-radius:9px;border:1px solid var(--line);
  background:var(--surface-2);color:var(--ink);font-size:.9rem;font-weight:700;width:100%;text-align:right;font-variant-numeric:tabular-nums}
.autowrap{position:relative;flex:1 1 160px;min-width:0}
.autowrap input{text-align:left}
.ac-list{position:absolute;top:100%;left:0;right:0;z-index:30;background:var(--surface);
  border:1px solid var(--line);border-radius:0 0 9px 9px;box-shadow:var(--shadow-sm);max-height:200px;overflow:auto;display:none}
.ac-list.show{display:block}
.ac-item{padding:.42rem .6rem;font-size:.78rem;cursor:pointer;border-bottom:1px solid var(--line)}
.ac-item:last-child{border-bottom:0}
.ac-item:hover,.ac-item.hl{background:var(--grad-soft)}
.ac-item small{color:var(--mut-2);margin-left:.4rem;font-variant-numeric:tabular-nums}
.calc-out{font-size:.72rem;color:var(--mut-2);margin-top:.5rem;line-height:1.5}
.calc-out b{color:var(--ink-soft)}
.calc-out .ok{color:var(--ok);font-weight:800}
.calc-out .bad{color:var(--bad);font-weight:800}
.manual-btn{margin-top:.6rem;width:100%;padding:.65rem;border-radius:11px;border:1px solid var(--line);
  background:var(--brand-2);color:#04201c;font-weight:800;font-size:.85rem;cursor:pointer}
.manual-btn.sell{background:var(--bad);color:#fff}
.manual-btn.ghost{background:var(--surface-2);color:var(--ink-soft)}
.mode-toggle{display:inline-flex;gap:.3rem;margin-left:.5rem}
.mode-toggle button{padding:.28rem .6rem;border-radius:999px;border:1px solid var(--line);
  background:var(--surface);font-weight:800;font-size:.68rem;cursor:pointer;color:var(--mut)}
.mode-toggle button.on{background:var(--brand-2);color:#04201c;border-color:transparent}
.pos-close{margin-left:.4rem;padding:.18rem .5rem;border-radius:7px;border:1px solid var(--line);
  background:var(--surface-2);color:var(--bad);font-weight:800;font-size:.62rem;cursor:pointer}

</style>
</head>
<body>
<div class="bg" aria-hidden="true"><span class="blob b1"></span><span class="blob b2"></span><span class="blob b3"></span></div>

<header class="topbar">
  <div class="brand">
    <div class="brand-mark" aria-hidden="true">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 17l6-6 4 4 6-7"/><path d="M15 8h5v5"/></svg>
    </div>
    <div class="brand-text">
      <h1>mexc-listener</h1>
      <p>@fattyfatclub → MEXC · USDⓈ-M Futures signal execution</p>
    </div>
  </div>
  <div class="status-cluster">
  <span id="mode" class="pill paper">PAPER</span>
  <span class="mode-toggle" id="modeToggle">
    <button data-mode="paper" class="on">PAPER</button>
    <button data-mode="live">LIVE</button>
  </span>
  <span id="golive" class="pill"><span class="dot"></span>ws feed: waiting</span>
    <span class="pill accent">@fattyfatclub</span>
    <span class="conn" id="conn"><span class="dot"></span><span id="connText">connecting…</span></span>
  </div>
</header>

<main class="shell">
  <section class="kpi-grid">
    <div class="card kpi"><div class="kpi-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="6" width="20" height="12" rx="2"/><circle cx="12" cy="12" r="2.5"/></svg></div><div class="kpi-body"><div class="kpi-label">Equity (USDT)</div><div class="kpi-value num" id="k_equity">—</div><div class="kpi-sub" id="k_equity_sub">account equity</div></div></div>
    <div class="card kpi"><div class="kpi-icon alt"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12V7H5a2 2 0 0 1 0-4h14v4"/><path d="M3 5v14a2 2 0 0 0 2 2h16v-5"/><path d="M18 12a2 2 0 0 0 0 4h4v-4Z"/></svg></div><div class="kpi-body"><div class="kpi-label">Balance (USDT)</div><div class="kpi-value num" id="k_balance">—</div><div class="kpi-sub" id="k_balance_sub">available margin</div></div></div>
    <div class="card kpi"><div class="kpi-icon green"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/></svg></div><div class="kpi-body"><div class="kpi-label">Net PnL</div><div class="kpi-value num" id="k_pnl">0.00</div><div class="kpi-sub" id="k_pnl_sub">—</div></div></div>
    <div class="card kpi"><div class="kpi-icon alt"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m12 2 9 5-9 5-9-5 9-5Z"/><path d="m3 12 9 5 9-5"/></svg></div><div class="kpi-body"><div class="kpi-label">Open positions</div><div class="kpi-value num" id="k_pos">0</div><div class="kpi-sub">active positions</div></div></div>
    <div class="card kpi"><div class="kpi-icon amber"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/></svg></div><div class="kpi-body"><div class="kpi-label">Win rate</div><div class="kpi-value num" id="k_wr">—</div><div class="kpi-sub" id="k_wr_sub">—</div></div></div>
    <div class="card kpi"><div class="kpi-icon alt"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="20" x2="12" y2="10"/><line x1="18" y1="20" x2="18" y2="4"/><line x1="6" y1="20" x2="6" y2="16"/></svg></div><div class="kpi-body"><div class="kpi-label">Profit factor</div><div class="kpi-value num" id="k_pf">—</div><div class="kpi-sub">gross win / loss</div></div></div>
    <div class="card kpi"><div class="kpi-icon red"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="22 17 13.5 8.5 8.5 13.5 2 7"/><polyline points="16 17 22 17 22 11"/></svg></div><div class="kpi-body"><div class="kpi-label">Max drawdown</div><div class="kpi-value num" id="k_dd">—</div><div class="kpi-sub">peak to trough</div></div></div>
    <div class="card kpi"><div class="kpi-icon green"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg></div><div class="kpi-body"><div class="kpi-label">Trades</div><div class="kpi-value num" id="k_trades">0</div><div class="kpi-sub">closed trades</div></div></div>
  </section>

  <section class="section card">
    <div class="card-head"><h2>Live market</h2><span class="hint" id="market_hint">public MEXC ticker</span></div>
    <div class="card-body market-grid" id="market"></div>
  </section>

  <div class="grid2x2">
    <section class="card">
      <div class="card-head"><h2>Equity &amp; PnL</h2><span class="hint" id="chart_hint">—</span></div>
      <div class="card-body"><div class="chart-wrap"><canvas id="eq"></canvas></div></div>
    </section>

    <section class="card">
      <div class="card-head"><h2>Open positions</h2><span class="hint" id="posCount">0</span></div>
      <div class="card-body">
        <div class="table-wrap" id="positionsTable" style="display:none">
          <table><thead><tr><th>Symbol</th><th>Side</th><th>Size</th><th>Entry</th><th>Mark</th><th>Liq</th><th>PnL</th></tr></thead><tbody id="positionsBody"></tbody></table>
        </div>
        <div class="empty" id="posEmpty">No open positions.</div>
      </div>
    </section>

    <section class="card">
      <div class="card-head"><h2>Open orders</h2><span class="hint" id="ordCount">0</span></div>
      <div class="card-body">
        <div class="table-wrap" id="ordersTable" style="display:none">
          <table><thead><tr><th>Symbol</th><th>Side</th><th>Type</th><th>Qty</th><th>Price</th><th>Status</th></tr></thead><tbody id="ordersBody"></tbody></table>
        </div>
        <div class="empty" id="ordEmpty">No open orders.</div>
      </div>
    </section>
  </div>

  <div class="grid2col">
    <section class="card">
      <div class="card-head"><h2>Recent trades</h2><span class="hint">last 40</span></div>
      <div class="card-body">
        <div class="table-wrap"><table><thead><tr><th>Time</th><th>Symbol</th><th>PnL</th></tr></thead><tbody id="tradesBody"></tbody></table></div>
      </div>
    </section>

    <section class="card">
      <div class="card-head"><h2>Statistics</h2></div>
      <div class="card-body">
        <div class="stats-list">
          <div class="stat-row"><span class="k">Total trades</span><span class="v num" id="s_total">0</span></div>
          <div class="stat-row"><span class="k">Wins / Losses</span><span class="v num" id="s_wl">0 / 0</span></div>
          <div class="stat-row"><span class="k">Win rate</span><span class="v num" id="s_wr">—</span></div>
          <div class="stat-row"><span class="k">Profit factor</span><span class="v num" id="s_pf">—</span></div>
          <div class="stat-row"><span class="k">Expectancy</span><span class="v num" id="s_exp">—</span></div>
          <div class="stat-row"><span class="k">Avg hold</span><span class="v num" id="s_hold">—</span></div>
          <div class="stat-row"><span class="k">Max drawdown</span><span class="v num" id="s_dd">—</span></div>
          <div class="stat-row"><span class="k">Open positions</span><span class="v num" id="s_open">0</span></div>
          <div class="stat-row"><span class="k">Net PnL</span><span class="v num" id="s_net">0.00</span></div>
        </div>
      </div>
    </section>

    <section class="card">
      <div class="card-head"><h2>Go-Live Gate</h2><span class="hint" id="gate_hint">shadow expectancy</span></div>
      <div class="card-body">
        <div class="gate-banner" id="gate_banner">collecting shadow trades…</div>
        <div class="stats-list" id="gate_pairs"></div>
      </div>
    </section>

    <section class="card">
      <div class="card-head"><h2>Risk controls</h2><span class="hint">live-adjustable</span></div>
      <div class="card-body">
        <div class="risk-row">
          <label>Leverage</label>
          <div class="risk-input">
            <input id="risk_lev" type="number" min="1" max="125" step="1" inputmode="numeric" />
            <span class="risk-x">x</span>
          </div>
        </div>
        <div class="risk-row">
          <label>Margin</label>
          <div class="seg" id="risk_mt">
            <button data-mt="isolated" class="on">ISOLATED</button>
            <button data-mt="cross">CROSS</button>
          </div>
        </div>
        <button id="risk_save" class="btn">Apply</button>
        <div id="risk_msg" class="risk-msg"></div>
        <div class="risk-note">Applied to new opening orders · saved to .env</div>
      </div>
    </section>

    <section class="card">
      <div class="card-head"><h2>Manual trade</h2><span class="hint">auth required</span></div>
      <div class="card-body">
        <div class="manual-row">
          <div class="autowrap">
            <label>Pair</label>
            <input id="m_symbol" placeholder="type to search (e.g. BTC)" autocomplete="off" />
            <div class="ac-list" id="m_ac"></div>
          </div>
          <div class="fld">
            <label>Side</label>
            <select id="m_side">
              <option value="BUY">LONG</option>
              <option value="SELL">SHORT</option>
            </select>
          </div>
        </div>
        <div class="manual-row">
          <div class="fld"><label>Entry</label><input id="m_entry" type="number" step="any" placeholder="price" /></div>
          <div class="fld"><label>Margin USDT</label><input id="m_margin" type="number" step="any" value="1" /></div>
          <div class="fld"><label>Leverage</label><input id="m_lev" type="number" step="1" value="5" /></div>
        </div>
        <div class="manual-row">
          <div class="fld"><label>SL</label><input id="m_sl" type="number" step="any" placeholder="optional" /></div>
          <div class="fld"><label>TP</label><input id="m_tp" type="number" step="any" placeholder="optional" /></div>
        </div>
        <div class="calc-out" id="m_calc">enter a pair + margin + leverage to preview…</div>
        <button class="manual-btn" id="m_buy">OPEN LONG</button>
        <button class="manual-btn sell" id="m_sell">OPEN SHORT</button>
        <div class="risk-msg" id="m_msg"></div>
        <div class="risk-note">Auto-floors qty to MEXC min notional ($5) + lot step. Margin × leverage = notional. Leverage adapts to pair cap + balance.</div>
        <div class="manual-row" style="margin-top:.7rem;align-items:center">
          <div class="autowrap" style="flex:1 1 160px">
            <label>Trading password</label>
            <input id="m_pw" type="password" placeholder="password to enable actions" autocomplete="off" />
          </div>
          <span id="m_lock" class="pill paper" style="margin:0">LOCKED</span>
        </div>
      </div>
    </section>

    <section class="card">
      <div class="card-head"><h2>Activities</h2><span class="hint">newest first</span></div>
      <div class="card-body"><div class="timeline" id="activities"></div></div>
    </section>

    <section class="card">
      <div class="card-head"><h2>Logs</h2></div>
      <div class="card-body"><div class="log" id="logs"></div></div>
    </section>
  </div>

  <footer class="foot">
    <span id="health">poll 5s · updated —</span>
    <span class="foot-brand">mexc-listener · real-time WebSocket dashboard</span>
  </footer>
</main>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<script>
(function(){
'use strict';
const HAS_CHART = (typeof Chart !== 'undefined');
const $ = (id) => document.getElementById(id);
const WSS = (location.protocol === 'https:' ? 'wss://' : 'ws://') + location.host + '/ws/events';
const ACTIVITY_TYPES = new Set(['signal','order','fill','position','management','gate1_blocked','gate2_blocked','skipped','entered','wallet']);
const REFRESH_TYPES = new Set(['position','fill','wallet']);
const LOG_CLS = {signal:'sig',order:'ord',entered:'ord',fill:'fill',position:'pos',wallet:'wal',management:'warn',gate1_blocked:'warn',gate2_blocked:'warn'};

let ws;
let equityChart = null;
let refreshTimer = null;
const sparkCharts = {};
const marketTiles = {};
const mktHistory = {};   // symbol -> [{x,y}] client-side rolling price history

function esc(s){
  return String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}
function num(v){
  if (v === null || v === undefined || v === '') return null;
  const n = Number(v);
  return isNaN(n) ? null : n;
}
function hexA(hex, a){
  const h = hex.replace('#', '');
  const full = h.length === 3 ? h.split('').map((x) => x + x).join('') : h;
  const n = parseInt(full, 16);
  return 'rgba(' + ((n >> 16) & 255) + ',' + ((n >> 8) & 255) + ',' + (n & 255) + ',' + a + ')';
}
function fmt(n){
  n = num(n);
  if (n === null) return '—';
  const a = Math.abs(n);
  if (a >= 1) return n.toLocaleString(undefined, {maximumFractionDigits:2});
  return n.toFixed(4);
}
function fmtSigned(n){
  n = num(n);
  if (n === null) return '—';
  return (n >= 0 ? '+' : '') + fmt(n);
}
function logTime(ts){
  const d = ts ? new Date(ts * 1000) : new Date();
  return d.toLocaleTimeString([], {hour12:false});
}
function short(d){
  if (d == null) return '';
  if (typeof d === 'string') return d.slice(0, 120);
  try { return JSON.stringify(d).slice(0, 120); } catch (_) { return ''; }
}
function setText(id, text, cls){
  const el = $(id);
  if (!el) return;
  el.textContent = text;
  if (cls) el.className = cls;
}
function clsOf(v){
  return (typeof v === 'number' ? v : 0) >= 0 ? 'pos' : 'neg';
}

function setConn(live){
  const dot = document.querySelector('#conn .dot');
  const txt = $('connText');
  if (live){
    dot.className = 'dot live';
    txt.textContent = 'live';
  } else {
    dot.className = 'dot';
    txt.textContent = 'reconnecting…';
  }
}

function connect(){
  const w = new WebSocket(WSS, AUTH ? {headers:{'Authorization':'Basic '+AUTH}} : undefined);
  w.onopen = () => setConn(true);
  w.onclose = () => { setConn(false); setTimeout(connect, 2000); };
  w.onerror = () => w.close();
  w.onmessage = (ev) => { try { onEvent(JSON.parse(ev.data)); } catch (_) {} };
  ws = w;
}

function onEvent(e){
  const t = e.type || 'event';
  const d = e.data || {};
  if (t === 'market_tick'){ onMarketTick(d); return; }   // live price push, no log/activity
  if (t === 'btcd_tick'){ onBtcdTick(d && d.btc_dominance, d && d.ts); return; }
  addLogLine(t, d, null);
  if (ACTIVITY_TYPES.has(t)) addActivityRow(t, d, null);
  if (REFRESH_TYPES.has(t)) scheduleRefresh();
}

function onMarketTick(d){
  const sym = d && d.symbol;
  if (!sym) return;
  const tile = marketTiles[sym];
  if (!tile) return;                       // not a tracked symbol (e.g. pruned)
  const c = num(d.change24h) || 0;
  const chg = tile.querySelector('.mkt-chg');
  if (chg){ chg.textContent = (c >= 0 ? '+' : '') + c.toFixed(2) + '%'; chg.className = 'mkt-chg ' + (c >= 0 ? 'pos' : 'neg'); }
  const pe = tile.querySelector('.mkt-price');
  if (pe) pe.textContent = fmt(num(d.price));
  const ch = tile._chart;
  if (ch){
    const t = Math.floor(num(d.ts) || Date.now()/1000);
    const px = num(d.price) || 0;
    const hist = mktHistory[sym];
    if (!hist){ return; }
    const last = hist.length ? hist[hist.length-1].y : null;
    if (last === null || Math.abs(px - last) > Math.max(1e-6, Math.abs(last)*1e-6)){
      hist.push({x:t, y:px});
      if (hist.length > 120) hist.shift();   // ~6min at 3s ticks
      ch.data.datasets[0].data = hist.slice();
      ch.update('none');
    }
  }
}

function scheduleRefresh(){
  if (refreshTimer) clearTimeout(refreshTimer);
  refreshTimer = setTimeout(() => { refreshTimer = null; load(); }, 800);
}

function addLogLine(type, data, ts){
  const lg = $('logs');
  const cls = LOG_CLS[type] || 'mut';
  const line = document.createElement('div');
  line.className = 'log-line';
  line.innerHTML = '<span class="t">' + logTime(ts) + '</span><span class="tag ' + cls + '">' + esc(type) + '</span><span class="msg">' + esc(short(data)) + '</span>';
  lg.appendChild(line);
  lg.scrollTop = lg.scrollHeight;
  if (lg.childElementCount > 200) lg.removeChild(lg.firstChild);
}

function addActivityRow(type, data, ts){
  const tl = $('activities');
  const cls = LOG_CLS[type] || 'mut';
  const row = document.createElement('div');
  row.className = 'act-row';
  row.innerHTML = '<span class="act-dot ' + cls + '"></span><div class="act-body"><div class="act-head"><span class="tag ' + cls + '">' + esc(type) + '</span><span class="ts">' + logTime(ts) + '</span></div><div class="act-msg">' + esc(short(data)) + '</div></div>';
  tl.prepend(row);
  if (tl.childElementCount > 60) tl.removeChild(tl.lastChild);
}

function initEquityChart(){
  if (!HAS_CHART) return;
  const ctx = $('eq').getContext('2d');
  const g = ctx.createLinearGradient(0, 0, 0, 300);
  g.addColorStop(0, 'rgba(20,184,166,.22)');
  g.addColorStop(1, 'rgba(20,184,166,0)');
  equityChart = new Chart(ctx, {
    type: 'line',
    data: {
      datasets: [
        {label:'Equity', data:[], borderColor:'#14b8a6', backgroundColor:g, fill:true,
         tension:.32, pointRadius:0, borderWidth:2, yAxisID:'y'},
        {label:'Cumulative PnL', data:[], borderColor:'#6366f1', backgroundColor:'transparent',
         fill:false, tension:.32, pointRadius:0, borderWidth:2, borderDash:[5,4], yAxisID:'y1'}
      ]
    },
    options: {
      responsive:true,
      maintainAspectRatio:false,
      animation:false,
      interaction:{mode:'index', intersect:false},
      plugins:{
        legend:{display:true, position:'top', align:'end', labels:{usePointStyle:true, boxWidth:7, boxHeight:7, color:'#64748b', font:{size:11, weight:600}, padding:14}},
        tooltip:{
          backgroundColor:'#0f1d2e', titleColor:'#e2e8f0', bodyColor:'#cbd5e1',
          padding:10, cornerRadius:10, titleFont:{size:11, weight:600}, bodyFont:{size:11},
          callbacks:{
            title:(items) => items.length ? logTime(items[0].parsed.x) : '',
            label:(ctx) => ' ' + ctx.dataset.label + ': ' + fmt(ctx.parsed.y)
          }
        }
      },
      scales:{
        x:{type:'linear', grid:{display:false}, border:{display:false},
           title:{display:true, text:'Time', color:'#94a3b8', font:{size:10, weight:600}},
           ticks:{color:'#94a3b8', font:{size:10}, maxTicksLimit:8,
                  callback:(v) => logTime(v).slice(0,5)}},
        y:{position:'left', grid:{color:'#eef2f7'}, border:{display:false},
           title:{display:true, text:'Equity (USDT)', color:'#94a3b8', font:{size:10, weight:600}},
           ticks:{color:'#94a3b8', font:{size:10}, maxTicksLimit:6, callback:(v) => fmt(v)}},
        y1:{position:'right', grid:{display:false}, border:{display:false},
            title:{display:true, text:'Cum. PnL', color:'#94a3b8', font:{size:10, weight:600}},
            ticks:{color:'#94a3b8', font:{size:10}, maxTicksLimit:6, callback:(v) => fmtSigned(v)}}
      }
    }
  });
}

function drawEquity(s){
  if (!equityChart) return;
  const eq = (s.equity_history || []).map((e) => ({x: num(e.ts) ?? 0, y: num(e.equity) ?? 0}));
  let cum = 0;
  const pnl = (s.pnl_history || []).map((p) => { cum += num(p.pnl) || 0; return {x: num(p.ts) ?? 0, y: cum}; });
  equityChart.data.datasets[0].data = eq;
  equityChart.data.datasets[1].data = pnl;
  equityChart.update('none');
  const last = eq.length ? eq[eq.length - 1].y : null;
  $('chart_hint').textContent = last !== null ? 'equity ' + fmt(last) + ' USDT' : '—';
}

let btcdHistory = [];   // [{x,y}] client-side rolling BTC dominance history
function onBtcdTick(v, t){
  const tile = marketTiles['__btcd__'];
  const ch = tile && tile._chart;
  if (!ch) return;
  v = num(v); if (v === null) return;
  t = Math.floor(num(t) || Date.now()/1000);
  btcdHistory.push({x:t, y:v});
  if (btcdHistory.length > 180) btcdHistory.shift();   // ~60min at 20s
  ch.data.datasets[0].data = btcdHistory.slice();
  ch.update('none');
  const hint = document.getElementById('btcd_hint');
  if (hint) hint.textContent = 'BTC.D ' + fmt(v) + '% · CoinGecko';
}
// One-time REST seed so the dominance chart has a frame before the first WS tick
// (CoinGecko is cached 90s server-side, so this is cheap and rare).
function seedBtcd(){
  const tile = marketTiles['__btcd__'];
  if (!tile || !tile._chart || btcdHistory.length) return;
  fetch('/api/btcd', {cache:'no-store'}).then((r)=>r.json()).then((j)=>{
    onBtcdTick(j && j.btc_dominance);
  }).catch(()=>{});
}

function makeSparkChart(canvas){
  return new Chart(canvas, {
    type:'line',
    data:{labels:[], datasets:[{data:[], borderColor:'#14b8a6', backgroundColor:'rgba(20,184,166,.08)', fill:true, tension:.35, pointRadius:0, borderWidth:1.6}]},
    options:{responsive:false, animation:false, plugins:{legend:{display:false}, tooltip:{enabled:false}},
      scales:{x:{display:false}, y:{display:false}}, layout:{padding:1}}
  });
}

function ensureMarketTile(sym, opts){
  opts = opts || {};
  const key = opts.btcd ? '__btcd__' : sym;
  let tile = marketTiles[key];
  if (tile) return tile;
  tile = document.createElement('div');
  tile.className = 'mkt' + (opts.btcd ? ' btcd-tile' : '');
  const accent = opts.btcd ? '#f59e0b' : '#14b8a6';
  const title = opts.btcd ? 'BTC dominance' : sym;
  const hintId = opts.btcd ? 'btcd_hint' : '';
  const hintHtml = opts.btcd ? '<span class="hint" id="btcd_hint">loading…</span>' : '';
  tile.innerHTML =
    '<div class="card-head" style="padding:.2rem 0 .1rem"><h2>' + esc(title) + '</h2>' + hintHtml + '</div>' +
    (opts.btcd ? '' : '<div class="mkt-top"><span class="mkt-chg"></span></div><div class="mkt-price">—</div>') +
    '<div class="mkt-chart"><canvas></canvas></div>';
  $('market').appendChild(tile);
  marketTiles[key] = tile;
  const canvas = tile.querySelector('canvas');
  const ctx = canvas.getContext('2d');
  const g = ctx.createLinearGradient(0, 0, 0, 150);
  g.addColorStop(0, hexA(accent, .20));
  g.addColorStop(1, hexA(accent, 0));
  tile._chart = new Chart(ctx, {
    type:'line',
    data:{datasets:[{label:title, data:[], borderColor:accent, backgroundColor:g, fill:true,
                    tension:.3, pointRadius:0, borderWidth:2}]},
    options:{
      responsive:true, maintainAspectRatio:false, animation:false,
      plugins:{legend:{display:false},
        tooltip:{backgroundColor:'#0f1d2e', titleColor:'#e2e8f0', bodyColor:'#cbd5e1', padding:10, cornerRadius:10,
          callbacks:{title:(items)=>items.length?logTime(items[0].parsed.x):'', label:(ctx)=>' '+(opts.btcd?'BTC.D ':'')+fmt(ctx.parsed.y)+(opts.btcd?'%':'')+(opts.btcd?'':' '+sym)}}},
      scales:{
        x:{type:'linear', grid:{display:false}, border:{display:false},
           ticks:{color:'#94a3b8', font:{size:9}, maxTicksLimit:5, callback:(v)=>logTime(v).slice(0,5)}},
        y:{position:'left', grid:{color:'#eef2f7'}, border:{display:false},
           ticks:{color:'#94a3b8', font:{size:9}, maxTicksLimit:4, callback:(v)=> opts.btcd ? fmt(v)+'%' : fmt(v)}}
      }
    }
  });
  return tile;
}

function renderMarket(s){
  const mkt = s.market || {};
  for (const [sym, m] of Object.entries(mkt)){
    const tile = ensureMarketTile(sym);
    const c = num(m.change24h) || 0;
    const chg = tile.querySelector('.mkt-chg');
    if (chg){ chg.textContent = (c >= 0 ? '+' : '') + c.toFixed(2) + '%'; chg.className = 'mkt-chg ' + (c >= 0 ? 'pos' : 'neg'); }
    const priceEl = tile.querySelector('.mkt-price');
    if (priceEl) priceEl.textContent = fmt(m.price);
    const ch = tile._chart;
    if (ch){
      const now = Math.floor(Date.now()/1000);
      const px = num(m.price) ?? 0;
      // client-side rolling history keyed by symbol
      mktHistory[sym] = mktHistory[sym] || [];
      const hist = mktHistory[sym];
      const last = hist.length ? hist[hist.length-1].y : null;
      if (last === null || Math.abs(px - last) > Math.max(1e-6, Math.abs(last)*1e-6) || hist.length === 0){
        hist.push({x:now, y:px});
        if (hist.length > 90) hist.shift();   // ~6min at 4s polls
      }
      ch.data.datasets[0].data = hist.slice();
      ch.update('none');
    }
  }
  // BTC dominance tile (always present)
  ensureMarketTile('__btcd__', {btcd:true});
  // prune tiles whose symbol disappeared
  for (const key of Object.keys(marketTiles)){
    if (key === '__btcd__') continue;
    if (!(key in mkt)){ const t = marketTiles[key]; if (t._chart) t._chart.destroy(); t.remove(); delete marketTiles[key]; delete mktHistory[key]; }
  }
}

function renderPositions(s){
  const body = $('positionsBody');
  body.innerHTML = '';
  const ps = s.positions || [];
  $('posCount').textContent = ps.length;
  $('positionsTable').style.display = ps.length ? '' : 'none';
  $('posEmpty').style.display = ps.length ? 'none' : 'block';
  for (const p of ps){
    const pnl = num(p.pnl) ?? num(p.unrealizedPNL) ?? 0;
    const side = String(p.direction || p.side || '').toUpperCase();
    const sideCls = /LONG|BUY/.test(side) ? 'long' : /SHORT|SELL/.test(side) ? 'short' : '';
    const tr = document.createElement('tr');
    tr.innerHTML = '<td><span class="sym">' + esc(p.symbol) + '</span></td><td><span class="side ' + sideCls + '">' + esc(side || '—') + '</span></td><td class="num">' + fmt(p.size) + '</td><td class="num">' + fmt(p.entry ?? p.openPrice) + '</td><td class="num">' + fmt(p.mark ?? p.markPrice) + '</td><td class="num">' + fmt(p.liq_price ?? p.liquidatePrice) + '</td><td class="num ' + clsOf(pnl) + '">' + fmtSigned(pnl) + '</td>';
    body.appendChild(tr);
  }
}

function renderOrders(s){
  const body = $('ordersBody');
  body.innerHTML = '';
  const os = s.open_orders || [];
  $('ordCount').textContent = os.length;
  $('ordersTable').style.display = os.length ? '' : 'none';
  $('ordEmpty').style.display = os.length ? 'none' : 'block';
  for (const o of os){
    const side = String(o.direction || o.side || '').toUpperCase();
    const sideCls = /LONG|BUY/.test(side) ? 'long' : /SHORT|SELL/.test(side) ? 'short' : '';
    const tr = document.createElement('tr');
    tr.innerHTML = '<td><span class="sym">' + esc(o.symbol) + '</span></td><td><span class="side ' + sideCls + '">' + esc(side || '—') + '</span></td><td>' + esc(o.type || o.orderType || '—') + '</td><td class="num">' + fmt(o.qty ?? o.quantity ?? o.size) + '</td><td class="num">' + fmt(o.price ?? o.limitPrice) + '</td><td>' + esc(o.status || 'OPEN') + '</td>';
    body.appendChild(tr);
  }
}

function renderTrades(s){
  const body = $('tradesBody');
  body.innerHTML = '';
  const list = (s.pnl_history || []).slice(-40).reverse();
  for (const t of list){
    const pnl = num(t.pnl) || 0;
    const tr = document.createElement('tr');
    tr.innerHTML = '<td>' + logTime(t.ts) + '</td><td>' + esc(t.symbol || '—') + '</td><td class="num ' + clsOf(pnl) + '">' + fmtSigned(pnl) + '</td>';
    body.appendChild(tr);
  }
}

function renderGate(s){
  const g = s.shadow || {};
  const banner = $('gate_banner');
  const wrap = $('gate_pairs');
  if (!g.available){
    banner.textContent = 'shadow ledger offline';
    banner.className = 'gate-banner warn';
    wrap.innerHTML = '';
    return;
  }
  const min = g.min_trades || 30;
  if (g.gate_ready){
    banner.textContent = 'GATE READY — expectancy positive (' + min + '+ trades/pair)';
    banner.className = 'gate-banner ok';
  } else {
    const done = (g.pairs || []).reduce((a,p)=>a + Math.min(p.trades, min), 0);
    const total = (g.pairs || []).length * min;
    banner.textContent = 'collecting shadow trades ' + done + '/' + total + ' (need ' + min + '/pair)';
    banner.className = 'gate-banner warn';
  }
  wrap.innerHTML = '';
  for (const p of (g.pairs || [])){
    const row = document.createElement('div');
    row.className = 'stat-row';
    const wr = (p.winrate * 100).toFixed(1) + '%';
    const tag = p.trusted
      ? (p.flag ? '<span class="tag bad">weak</span>' : '<span class="tag ok">trusted</span>')
      : '<span class="tag">cold</span>';
    row.innerHTML = '<span class="k">' + p.pair + ' ' + tag + '</span>' +
                    '<span class="v num">' + p.trades + ' trades · ' + wr + '</span>';
    wrap.appendChild(row);
  }
}
function renderRisk(s){
  const r = s.risk || {};
  const lev = $('risk_lev');
  if (lev && lev.value === '') lev.value = r.leverage != null ? r.leverage : 3;
  const mt = r.margin_type || 'isolated';
  if (window.__riskMt !== mt){
    window.__riskMt = mt;
    document.querySelectorAll('#risk_mt button').forEach(b=>{
      b.classList.toggle('on', b.dataset.mt === mt);
    });
  }
}
function bindRisk(){
  const seg = document.getElementById('risk_mt');
  if (seg && !seg.dataset.bound){
    seg.dataset.bound = '1';
    seg.querySelectorAll('button').forEach(b=>{
      b.addEventListener('click', ()=>{
        seg.querySelectorAll('button').forEach(x=>x.classList.remove('on'));
        b.classList.add('on');
      });
    });
  }
  const save = document.getElementById('risk_save');
  if (save && !save.dataset.bound){
    save.dataset.bound = '1';
    save.addEventListener('click', ()=>{
      const lev = document.getElementById('risk_lev').value;
      const mt = (document.querySelector('#risk_mt button.on')||{}).dataset?.mt || 'isolated';
      const msg = document.getElementById('risk_msg');
      msg.textContent = 'saving…';
      fetch('/api/risk', {method:'POST', headers:{'Content-Type':'application/json'},
            body: JSON.stringify({leverage: lev ? Number(lev) : undefined, margin_type: mt})})
        .then(r=>r.json()).then(j=>{
          if (j.ok){
            msg.textContent = 'applied: ' + (j.effective_leverage||'?') + 'x · ' + (j.effective_margin_type||'?').toUpperCase();
            msg.className = 'risk-msg ok';
          } else {
            msg.textContent = 'error: ' + (j.error || 'unknown');
            msg.className = 'risk-msg bad';
          }
        }).catch(e=>{ msg.textContent = 'request failed'; msg.className = 'risk-msg bad'; });
    });
  }
}
function renderStats(s){
  const st = s.stats || {};
  setText('s_total', st.total_trades || 0);
  setText('s_wl', (st.wins || 0) + ' / ' + (st.losses || 0));
  setText('s_wr', st.win_rate ? st.win_rate + '%' : '—');
  setText('s_pf', st.profit_factor ? fmt(st.profit_factor) : '—');
  setText('s_exp', st.expectancy != null ? fmtSigned(st.expectancy) : '—');
  setText('s_hold', st.avg_hold ? st.avg_hold + 'm' : '—');
  setText('s_dd', '-' + fmt(st.max_drawdown || 0));
  setText('s_open', st.open_positions || 0);
  setText('s_net', fmtSigned(st.net_pnl || 0));
}

function renderAll(s){
  const paper = s.paper ? true : false;
  const mode = $('mode');
  mode.textContent = paper ? 'PAPER' : 'LIVE';
  mode.className = 'pill ' + (paper ? 'paper' : 'live');
  // sync mode toggle buttons
  document.querySelectorAll('#modeToggle button').forEach(b=>{
    b.classList.toggle('on', (b.dataset.mode === 'paper') === paper);
  });

  const go = $('golive');
  if (s.ws_feed_live){
    go.innerHTML = '<span class="dot"></span>ws feed live';
    go.className = 'pill live';
  } else {
    go.innerHTML = '<span class="dot"></span>ws feed: waiting';
    go.className = 'pill';
  }

  const st = s.stats || {};
  const bal = s.balance || {};
  const equity = num(st.equity) ?? num(bal.equity) ?? 0;
  const available = num(bal.available) ?? num(st.balance) ?? 0;
  setText('k_equity', fmt(equity));
  $('k_equity_sub').textContent = (bal.currency || 'USDT') + ' · total';
  setText('k_balance', fmt(available));
  $('k_balance_sub').textContent = bal.available != null ? 'available margin' : 'ledger balance';
  setText('k_pos', st.open_positions || 0);

  const pnl = num(st.net_pnl) || 0;
  setText('k_pnl', fmtSigned(pnl), 'kpi-value num ' + clsOf(pnl));
  $('k_pnl_sub').textContent = (st.wins || 0) + 'W · ' + (st.losses || 0) + 'L';
  setText('k_wr', st.win_rate ? st.win_rate + '%' : '—');
  $('k_wr_sub').textContent = (st.wins || 0) + 'W · ' + (st.losses || 0) + 'L';
  setText('k_pf', st.profit_factor ? fmt(st.profit_factor) : '—');
  setText('k_dd', '-' + fmt(st.max_drawdown || 0));
  setText('k_trades', st.total_trades || 0);

  // Seed Live-market tiles from the snapshot only when the WS isn't driving them
  // (first load before connect, or after a reconnect). Live ticks own the tiles
  // once the socket is open, so the 4s REST poll won't fight the stream.
  if (!(ws && ws.readyState === WebSocket.OPEN)) renderMarket(s);
  renderPositions(s);
  renderOrders(s);
  renderTrades(s);
  renderStats(s);
  renderGate(s);
  renderRisk(s);
  drawEquity(s);

  const h = s.health || {};
  $('health').textContent = 'poll ' + (h.poll_interval || 5) + 's · updated ' + (h.ts ? logTime(h.ts) : '—') + ' · bot ' + (s.bot || 'mexc-fatty');
}

function load(){
  apiFetch('/api/state').then((r) => r.json()).then((s) => renderAll(s)).catch(() => {});
}

// ---- auth + manual trading + close + mode toggle ----
let AUTH = '';   // base64 "user:pass" (user is ignored; only password matters)

function apiFetch(url, opts){
  opts = opts || {};
  opts.headers = Object.assign({}, opts.headers, AUTH ? {'Authorization':'Basic ' + AUTH} : {});
  return fetch(url, opts);
}
function apiJson(url, body){
  return apiFetch(url, {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(body||{})});
}
function b64encode(s){ return btoa(unescape(encodeURIComponent(s))); }

// Action password: monitoring is open; only trade actions (enter/close/mode) need it.
// Stored in AUTH (base64 ":pw") and attached to action requests. Verified lazily
// against a protected endpoint (401 => wrong password).
function setAuth(pw){
  const h = b64encode(':' + pw);
  AUTH = h;
  return true;
}
function authOk(resp){ return resp.status !== 401; }
function requireActionAuth(){
  const pw = (document.getElementById('m_pw') || {}).value || '';
  if (!pw){ flashTrade('enter trading password first', false); return null; }
  setAuth(pw);
  return AUTH;
}
function flashTrade(msg, ok){
  const el = document.getElementById('m_msg');
  if (!el) return;
  el.textContent = msg;
  el.className = 'risk-msg ' + (ok ? 'ok' : 'bad');
}

// symbol autocomplete
let SYMBOLS = [];
function loadSymbols(){
  apiFetch('/api/symbols').then(r=>r.json()).then(j=>{ SYMBOLS = j || []; }).catch(()=>{});
}
function renderAc(q){
  const box = document.getElementById('m_ac');
  if (!q){ box.classList.remove('show'); return; }
  q = q.toUpperCase();
  const matches = SYMBOLS.filter(s => s.symbol.indexOf(q) >= 0).slice(0, 12);
  box.innerHTML = matches.map(m =>
    '<div class="ac-item" data-sym="'+esc(m.symbol)+'">'+esc(m.symbol)+
    (m.lastPrice ? '<small>'+fmt(m.lastPrice)+'</small>' : '')+'</div>').join('');
  box.classList.add('show');
  box.querySelectorAll('.ac-item').forEach(it=>{
    it.addEventListener('click', ()=>{ document.getElementById('m_symbol').value = it.dataset.sym; box.classList.remove('show'); runCalc(); });
  });
}

function runCalc(){
  const sym = document.getElementById('m_symbol').value.trim();
  const margin = parseFloat(document.getElementById('m_margin').value) || 0;
  const lev = parseInt(document.getElementById('m_lev').value) || 1;
  const entry = parseFloat(document.getElementById('m_entry').value) || 0;
  const out = document.getElementById('m_calc');
  if (!sym){ out.textContent = 'enter a pair + margin + leverage to preview…'; return; }
  apiJson('/api/calc', {symbol:sym, margin:margin, leverage:lev, entry:entry}).then(r=>r.json()).then(j=>{
    if (!j.ok){ out.innerHTML = '<span class="bad">'+(j.error||'calc failed')+'</span>'; return; }
    const ok = j.min_notional_ok ? '<span class="ok">OK</span>' : '<span class="bad">below $'+j.min_notional+' min</span>';
    out.innerHTML =
      'last <b>'+fmt(j.last_price)+'</b> · tick '+j.tick+' · lot '+j.lot+'<br>'+
      'qty <b>'+j.qty+'</b> · notional <b>$'+fmt(j.notional)+'</b> · margin <b>$'+fmt(j.margin_required)+'</b> '+ok+'<br>'+
      'max lev <b>'+j.max_leverage+'x</b> (balance '+j.max_leverage_balance+'x) · liq buffer <b>'+j.liq_buffer_pct.toFixed(1)+'%</b>'+
      (j.note ? '<br><span class="bad">'+esc(j.note)+'</span>' : '');
  }).catch(e=>{ out.innerHTML = '<span class="bad">'+esc(e)+'</span>'; });
}

function submitManual(side){
  const auth = requireActionAuth();
  if (!auth) return;
  const sym = document.getElementById('m_symbol').value.trim();
  const margin = parseFloat(document.getElementById('m_margin').value) || 0;
  const lev = parseInt(document.getElementById('m_lev').value) || 1;
  const entry = parseFloat(document.getElementById('m_entry').value) || 0;
  const sl = parseFloat(document.getElementById('m_sl').value) || '';
  const tp = parseFloat(document.getElementById('m_tp').value) || '';
  const msg = document.getElementById('m_msg');
  if (!sym){ msg.textContent = 'pick a pair first'; msg.className='risk-msg bad'; return; }
  msg.textContent = 'submitting…'; msg.className='risk-msg';
  apiJson('/api/manual/enter', {symbol:sym, side:side, entry:entry, margin:margin, leverage:lev, sl:sl, tp:tp})
    .then(r=>r.json()).then(j=>{
      if (j.ok){ msg.textContent = 'submitted: '+side+' '+sym+' qty '+j.qty+' @ '+j.leverage+'x ('+(j.paper?'PAPER':'LIVE')+')'; msg.className='risk-msg ok'; scheduleRefresh(); }
      else if (j.detail === 'Password required to trade'){ AUTH=''; flashTrade('wrong trading password', false); }
      else { msg.textContent = 'error: '+(j.error||j.detail||'unknown'); msg.className='risk-msg bad'; }
    }).catch(e=>{ msg.textContent='request failed'; msg.className='risk-msg bad'; });
}

function closePosition(sym){
  if (!confirm('Close '+sym+' now?')) return;
  const auth = requireActionAuth();
  if (!auth) return;
  apiJson('/api/position/close', {symbol:sym}).then(r=>r.json()).then(j=>{
    const msg = document.getElementById('m_msg');
    if (j.ok){ msg.textContent = 'closed '+sym+' ('+(j.paper?'PAPER':'LIVE')+')'; msg.className='risk-msg ok'; scheduleRefresh(); }
    else if (j.detail === 'Password required to trade'){ AUTH=''; flashTrade('wrong trading password', false); }
    else { msg.textContent = 'close error: '+(j.error||j.detail||''); msg.className='risk-msg bad'; }
    scheduleRefresh();
  }).catch(()=>{});
}

function bindManual(){
  loadSymbols();
  const symInput = document.getElementById('m_symbol');
  symInput.addEventListener('input', ()=>renderAc(symInput.value.trim()));
  symInput.addEventListener('blur', ()=>setTimeout(()=>document.getElementById('m_ac').classList.remove('show'), 150));
  ['m_entry','m_margin','m_lev'].forEach(id=>document.getElementById(id).addEventListener('input', runCalc));
  document.getElementById('m_buy').addEventListener('click', ()=>submitManual('BUY'));
  document.getElementById('m_sell').addEventListener('click', ()=>submitManual('SELL'));
  // mode toggle (requires trading password)
  document.querySelectorAll('#modeToggle button').forEach(b=>{
    b.addEventListener('click', ()=>{
      const auth = requireActionAuth();
      if (!auth) return;
      const mode = b.dataset.mode;
      apiJson('/api/mode', {mode:mode}).then(r=>r.json()).then(j=>{
        if (j.ok){ document.querySelectorAll('#modeToggle button').forEach(x=>x.classList.toggle('on', x.dataset.mode===mode)); scheduleRefresh(); }
        else if (j.detail === 'Password required to trade'){ AUTH=''; flashTrade('wrong trading password', false); }
        else { flashTrade('mode error: '+(j.error||j.detail||''), false); }
      }).catch(()=>{ flashTrade('request failed', false); });
    });
  });
}

// close button injected into positions table
const _origRenderPositions = renderPositions;
renderPositions = function(s){
  _origRenderPositions(s);
  const body = document.getElementById('positionsBody');
  if (!body) return;
  body.querySelectorAll('tr').forEach(tr=>{
    const sym = tr.querySelector('.sym') && tr.querySelector('.sym').textContent;
    if (sym && !tr.querySelector('.pos-close')){
      const td = document.createElement('td');
      const btn = document.createElement('button');
      btn.className='pos-close'; btn.textContent='CLOSE'; btn.dataset.sym=sym;
      btn.addEventListener('click', ()=>closePosition(sym));
      td.appendChild(btn); tr.appendChild(td);
    }
  });
};

// boot: open monitoring (no login). Trade actions prompt for password inline.
initEquityChart();
renderAll({paper:true, stats:{}, balance:{}, market:{}, spark:{}, positions:[], open_orders:[], pnl_history:[], equity_history:[], health:{}});
load();
seedBtcd();          // one-time REST frame so BTC.D shows before first WS tick
bindRisk();          // wire Risk controls card (leverage / margin toggle)
setInterval(load, 4000);
connect();
})();
</script>
</body>
</html>"""

# keep a reference to deque for type checkers
_DEQUE = deque


def create_app(bus: EventBus, get_state: Callable[[], dict],
               dashboard_state=None, price_bus=None, exchange=None,
               order_service=None, persist_config=None, manual=None) -> FastAPI:
    app = FastAPI(title="mexc-listener")

    @app.get("/api/state")
    def state():
        return get_state()

    @app.get("/api/status")
    def status():
        s = get_state()
        return {"paper": s.get("paper", 1), "bot": s.get("bot", ""),
                "stats": s.get("stats", {})}

    @app.get("/api/positions")
    def positions():
        return get_state().get("positions", [])

    @app.get("/api/trades")
    def trades():
        return get_state().get("pnl_history", [])

    @app.get("/api/shadow")
    def shadow():
        return get_state().get("stats", {})

    @app.get("/api/balance")
    def balance():
        return get_state().get("balance", {})

    @app.get("/api/market")
    def market():
        return get_state().get("market", {})

    @app.post("/api/risk")
    def set_risk(payload: dict):
        """Live-adjust default leverage + margin mode (mirrors learner bot).

        Body: {"leverage": <int>, "margin_type": "isolated"|"cross"}
        Updates the live exchange + order service, persists to .env. Returns the
        effective values actually applied.
        """
        lev = payload.get("leverage")
        mtype = (payload.get("margin_type") or "").strip().lower()
        applied_lev = None
        applied_mt = None
        if lev is not None and exchange is not None:
            try:
                n = int(float(lev))
            except (TypeError, ValueError):
                return {"ok": False, "error": "leverage must be an integer >= 1"}
            if n < 1:
                return {"ok": False, "error": "leverage must be >= 1"}
            if n > 125:
                n = 125
            exchange.default_leverage = n
            applied_lev = n
            if persist_config is not None:
                persist_config("MEXC_DEFAULT_LEVERAGE", str(n))
        if mtype in ("isolated", "cross") and exchange is not None:
            exchange.margin_type = mtype
            if order_service is not None:
                order_service.margin_type = mtype
            applied_mt = mtype
            if persist_config is not None:
                persist_config("MEXC_MARGIN_TYPE", mtype)
        return {"ok": True,
                "leverage": getattr(exchange, "default_leverage", None) if applied_lev is not None else None,
                "margin_type": getattr(exchange, "margin_type", None) if applied_mt is not None else None,
                "effective_leverage": getattr(exchange, "default_leverage", None),
                "effective_margin_type": getattr(exchange, "margin_type", None)}

    @app.get("/api/logs")
    def logs():
        return get_state().get("logs", [])

    @app.get("/api/activities")
    def activities():
        return get_state().get("activities", [])

    @app.get("/api/btcd")
    def btcd():
        v = _fetch_btcd()
        return {"btc_dominance": v}

    @app.get("/api/health")
    def health():
        return get_state().get("health", {})

    # ---- manual trading surface (password-gated) ----
    @app.get("/api/symbols")
    def symbols():
        if exchange is None or manual is None:
            return []
        try:
            return exchange.get_all_symbols()
        except Exception:  # noqa: BLE001
            return []

    @app.get("/api/instrument")
    def instrument(symbol: str = ""):
        if exchange is None or not symbol:
            return {"ok": False, "error": "symbol required"}
        inst = exchange.get_instrument(symbol)
        last = 0.0
        try:
            for s in exchange.get_all_symbols():
                if s["symbol"] == symbol:
                    last = s["lastPrice"] or 0.0
                    break
        except Exception:  # noqa: BLE001
            pass
        return {"symbol": symbol, "last_price": last, "tick": inst.tick_size,
                "lot": inst.lot_size, "min_notional": inst.min_notional,
                "max_leverage": int(inst.max_leverage), "min_qty": inst.min_qty}

    @app.post("/api/calc")
    def calc(payload: dict):
        if exchange is None or manual is None:
            return {"ok": False, "error": "manual trading unavailable"}
        bal = 0.0
        try:
            b = get_state().get("balance", {})
            bal = float(b.get("available") or b.get("equity") or 0.0)
        except Exception:  # noqa: BLE001
            pass
        try:
            res = manual["calc"](exchange, payload.get("symbol", ""),
                                 float(payload.get("margin") or 0.0),
                                 int(payload.get("leverage") or 1),
                                 float(payload.get("entry") or 0.0), bal)
            res["ok"] = True
            return res
        except Exception as e:  # noqa: BLE001
            return {"ok": False, "error": str(e)}

    @app.post("/api/manual/enter", dependencies=[Depends(require_trade_auth)])
    def manual_enter(payload: dict):
        if order_service is None or exchange is None or manual is None:
            return {"ok": False, "error": "manual trading unavailable"}
        try:
            return manual["enter"](order_service, exchange,
                                   payload.get("symbol", ""),
                                   payload.get("side", "BUY"),
                                   float(payload.get("entry") or 0.0),
                                   float(payload.get("margin") or 0.0),
                                   int(payload.get("leverage") or 1),
                                   payload.get("sl"), payload.get("tp"))
        except Exception as e:  # noqa: BLE001
            return {"ok": False, "error": str(e)}

    @app.post("/api/position/close", dependencies=[Depends(require_trade_auth)])
    def position_close(payload: dict):
        if order_service is None or exchange is None or manual is None:
            return {"ok": False, "error": "manual trading unavailable"}
        try:
            return manual["close"](order_service, exchange,
                                   payload.get("symbol", ""), payload.get("side"))
        except Exception as e:  # noqa: BLE001
            return {"ok": False, "error": str(e)}

    @app.post("/api/mode", dependencies=[Depends(require_trade_auth)])
    def set_mode(payload: dict):
        if order_service is None or manual is None:
            return {"ok": False, "error": "mode toggle unavailable"}
        mode = (payload.get("mode") or "paper")
        try:
            return manual["set_mode"](order_service, mode, persist_config)
        except Exception as e:  # noqa: BLE001
            return {"ok": False, "error": str(e)}

    @app.get("/", response_class=HTMLResponse)
    def dashboard():
        return HTMLResponse(_DASHBOARD_HTML)

    @app.websocket("/ws/events")
    async def ws_events(ws: WebSocket):
        await ws.accept()
        try:
            while True:
                for ev in bus.drain():
                    await ws.send_json(ev)
                # Live price ticks: push to clients as they arrive (snappier than
                # the 4s REST snapshot the tiles used before).
                if price_bus is not None:
                    for tick in price_bus.drain():
                        await ws.send_json(tick)
                await asyncio.sleep(0.05)
        except WebSocketDisconnect:
            pass

    return app
