"""Dashboard state aggregator: equity history, per-pair stats, live market poll.

Feeds the Web UI. Pulls real MEXC REST data (balance/positions/open-orders) when a
live exchange is present, and runs a lightweight market-price poller so charts move in
real-time even before go-live. Also folds EventBus events into logs/activities streams.

Item 4 (2026-08-14): MexcWS position/fill/wallet callbacks now drive live state —
positions are upserted/removed by symbol, fills update stats+equity, wallet updates
balance+equity history. The WS feed is the source of truth for account data.
Item 5b: per-symbol sparkline price history.
Item 5c: efficient polling — market poll every cycle, REST account poll throttled
and skipped entirely while the WS feed is live (slow backstop only).
"""
from __future__ import annotations

import os
import time
import threading
import urllib.request
import json
from collections import deque, defaultdict
from typing import Optional


# --- BTC dominance (keyless CoinGecko /global, proxied same-origin so the
#     browser avoids CORS; cached 90s to respect CoinGecko rate limits) ---
_BTCD_CACHE: dict = {"ts": 0.0, "v": None}


def _fetch_btcd() -> float | None:
    """Return current BTC market-cap dominance % via CoinGecko /global (keyless).

    Cached 90s; returns None on any failure so the UI shows a soft 'waiting'.
    Owned here because DashboardState publishes dominance ticks over PriceBus.
    """
    now = time.time()
    if _BTCD_CACHE["v"] is not None and now - _BTCD_CACHE["ts"] < 90:
        return _BTCD_CACHE["v"]
    try:
        req = urllib.request.Request(
            "https://api.coingecko.com/api/v3/global",
            headers={"User-Agent": "mexc-listener-dashboard/1.0"},
            method="GET",
        )
        with urllib.request.urlopen(req, timeout=10) as r:
            payload = json.loads(r.read().decode("utf-8"))
        d = payload.get("data", {}).get("market_cap_percentage", {}).get("btc")
        if d is None:
            return _BTCD_CACHE["v"]
        v = float(d)
        _BTCD_CACHE.update(ts=now, v=v)
        return v
    except Exception:
        return _BTCD_CACHE["v"]


class PriceBus:
    """Thread-safe pub/sub for live price ticks pushed to WebSocket clients.

    Kept separate from EventBus because that queue is destructively drained by
    both DashboardState (for logs/activities) and the WS endpoint; sending market
    ticks through it would make them a race between the two consumers. PriceBus is
    drained only by the WS endpoint, so every tick reaches connected browsers.
    """

    def __init__(self, maxlen: int = 1000) -> None:
        self._q: deque = deque(maxlen=maxlen)
        self._lock = threading.Lock()

    def publish(self, tick: dict) -> None:
        with self._lock:
            self._q.append(tick)

    def drain(self):
        with self._lock:
            items = list(self._q)
            self._q.clear()
            return items


class DashboardState:
    def __init__(self, bus, exchange=None, poll_interval: float = 5.0,
                 market_symbols=("BTC_USDT", "ETH_USDT", "SOL_USDT"),
                 account_poll_interval: float = 15.0,
                 account_backstop_interval: float = 60.0,
                 paper: bool = True, price_bus: "PriceBus | None" = None,
                 ledger=None, order_service=None):
        self.bus = bus
        self.ex = exchange
        self.poll_interval = poll_interval
        self.market_symbols = list(market_symbols)
        self.price_bus = price_bus
        self._last_btcd = None  # last BTC dominance % pushed via PriceBus
        # account REST poll throttling (Item 5c)
        self.account_poll_interval = account_poll_interval
        self.account_backstop_interval = account_backstop_interval
        self._last_account_ts = 0.0
        # equity / pnl history (timestamped)
        self.equity_history: deque = deque(maxlen=600)
        self.pnl_history: deque = deque(maxlen=600)
        self.market: dict[str, dict] = {}  # symbol -> {price, ts, change24h}
        self.spark: dict[str, deque] = {}  # symbol -> [{ts, price}] (Item 5b)
        self.positions: list[dict] = []
        self.balance: dict = {}
        self.open_orders: list[dict] = []
        self.activities: deque = deque(maxlen=300)
        self.logs: deque = deque(maxlen=500)
        self.stats = self._empty_stats()
        self._last_balance = 0.0
        self._stop = False
        self._thread: Optional[threading.Thread] = None
        # per-pair trade ledger for stats
        self._trades: list[dict] = []
        # True once any WS position/fill/wallet push arrives (Item 4/5c)
        self.ws_feed_live = False
        # paper flag mirrored into the snapshot so the UI can show LIVE
        self.paper = paper
        # ShadowLedger (persisted EvalStore) — used to surface the go-live
        # expectancy gate on the dashboard. May be None (then gate shows cold).
        self.ledger = ledger
        # Live-adjustable risk refs (leverage/margin_type) for the dashboard
        # Risk controls card + /api/risk endpoint.
        self.order_service = order_service

    @staticmethod
    def _empty_stats():
        return {
            "total_trades": 0, "wins": 0, "losses": 0, "win_rate": 0.0,
            "net_pnl": 0.0, "profit_factor": 0.0, "expectancy": 0.0,
            "max_drawdown": 0.0, "avg_hold": 0.0, "open_positions": 0,
            "balance": 0.0, "equity": 0.0,
        }

    def start(self):
        if self._thread and self._thread.is_alive():
            return
        self._stop = False
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()

    def stop(self):
        self._stop = True

    def _loop(self):
        while not self._stop:
            try:
                self._loop_once()
            except Exception:  # noqa: BLE001
                pass
            time.sleep(self.poll_interval)

    def _loop_once(self):
        """Fold queued bus events, then run one poll cycle.

        Exposed so tests can drive ingestion + polling deterministically without
        sleeping the background thread.
        """
        for ev in self.bus.drain():
            self._ingest_event(ev)
        self._poll_once()

    # ------------------------------------------------------------------
    # Polling (Item 5c): split market (fast) from account (throttled)
    # ------------------------------------------------------------------
    def _poll_once(self):
        # 1) market prices via PUBLIC MEXC ticker REST (no auth -> works from Jakarta)
        self._poll_market()
        # 1b) BTC dominance via keyless CoinGecko; published on change (90s cache)
        self._poll_btcd()
        # 2) account state via REST only when needed (see _poll_account)
        self._poll_account()

    def _poll_market(self):
        now = int(time.time())
        for sym in self.market_symbols:
            try:
                px, chg = self._fetch_public_price(sym)
                if px:
                    self.market[sym] = {"price": px, "ts": now,
                                        "change24h": chg}
                    sp = self.spark.setdefault(sym, deque(maxlen=60))
                    sp.append({"ts": now, "price": px})
                    if self.price_bus is not None:
                        self.price_bus.publish({
                            "type": "market_tick",
                            "data": {"symbol": sym, "price": px,
                                     "change24h": chg, "ts": now},
                        })
            except Exception:  # noqa: BLE001
                pass

    def _poll_btcd(self):
        """Publish BTC market-cap dominance as a btcd_tick when it changes.

        CoinGecko /global is cached 90s, so this only emits a frame roughly once
        a minute — enough for a slow-moving metric and far cheaper than polling it
        from the browser every 20s.
        """
        v = _fetch_btcd()
        if v is None or v == self._last_btcd:
            return
        self._last_btcd = v
        if self.price_bus is not None:
            self.price_bus.publish({
                "type": "btcd_tick",
                "data": {"btc_dominance": v, "ts": int(time.time())},
            })

    def _poll_account(self):
        """REST account backfill. Skipped entirely while the WS feed is live
        (the socket is the authoritative source); a slow backstop still runs so
        a missed push can't silently desync the UI (Item 5c)."""
        now = time.time()
        if self.ex is None or getattr(self.ex, "_is_fake", False):
            return
        if self.ws_feed_live:
            if now - self._last_account_ts < self.account_backstop_interval:
                return
        else:
            if now - self._last_account_ts < self.account_poll_interval:
                return
        self._last_account_ts = now
        try:
            self.positions = self._safe_positions()
            bal = self._safe_balance()
            if bal is not None:
                self.balance = bal
                eq = float(bal.get("equity", bal.get("total", 0.0)) or 0.0)
                self.equity_history.append({"ts": int(now), "equity": eq})
                self._last_balance = eq
        except Exception:  # noqa: BLE001
            pass

    @staticmethod
    def _fetch_public_price(sym: str):
        """Return (price, change24h_pct) from MEXC public contract ticker."""
        import httpx
        # MEXC contract ticker uses underscore symbol shape (BTC_USDT); normalize
        # a no-separator input (BTCUSDT) just in case.
        sym_u = sym.replace("/", "_")
        if "_" not in sym_u:
            # insert _ before the last 4 chars (USDT/USDC) if that pattern fits
            if sym_u.endswith("USDT") and len(sym_u) > 4:
                sym_u = sym_u[:-4] + "_" + sym_u[-4:]
        url = f"https://api.mexc.com/api/v1/contract/ticker?symbol={sym_u}"
        try:
            r = httpx.get(url, timeout=8)
            d = (r.json() or {}).get("data", {})
            if isinstance(d, list):
                d = d[0] if d else {}
            last = d.get("lastPrice") or d.get("last") or d.get("close")
            chg = d.get("riseFallRate") or d.get("changeRate") or 0.0
            try:
                return float(last), float(chg) * 100.0
            except (TypeError, ValueError):
                return 0.0, 0.0
        except Exception:  # noqa: BLE001
            return 0.0, 0.0

    def _safe_balance(self):
        # MexcExchange has get_balance (real REST); fall back to position-derived
        # equity when absent.
        if hasattr(self.ex, "get_balance"):
            try:
                return self.ex.get_balance()
            except Exception:  # noqa: BLE001
                return None
        return {"equity": sum(float(p.get("pnl", 0.0)) for p in self.positions) or 0.0}

    def _safe_positions(self):
        if hasattr(self.ex, "get_open_positions"):
            try:
                return [p.__dict__ if hasattr(p, "__dict__") else p
                        for p in self.ex.get_open_positions()]
            except Exception:  # noqa: BLE001
                return []
        return self.positions

    # ------------------------------------------------------------------
    # Event ingestion (Item 4): WS position/fill/wallet -> live state
    # ------------------------------------------------------------------
    def _ingest_event(self, ev: dict):
        now = int(time.time())
        etype = ev.get("type", "event")
        # record into logs (everything) and activities (signal/order lifecycle)
        rec = {"ts": now, "type": etype, "data": ev.get("data", ev)}
        self.logs.append(rec)
        if etype in ("signal", "order", "fill", "position", "management",
                     "gate1_blocked", "gate2_blocked", "skipped", "entered",
                     "wallet"):
            self.activities.append(rec)
        # WS position push -> upsert/remove live position (Item 4)
        if etype == "position":
            self._ingest_position(ev.get("data", {}))
            self.ws_feed_live = True
        # WS wallet push -> balance + equity history (Item 4)
        elif etype == "wallet":
            self._ingest_wallet(ev.get("data", {}))
            self.ws_feed_live = True
        # fold fills into stats + pnl history
        elif etype == "fill":
            d = ev.get("data", {})
            pnl = float(d.get("pnl", 0.0) if isinstance(d, dict) else 0.0)
            self._trades.append({"ts": now, "pnl": pnl,
                                 "symbol": d.get("symbol") if isinstance(d, dict) else None})
            self.pnl_history.append({"ts": now, "pnl": pnl})
            self._recompute_stats()
            self.ws_feed_live = True

    def _ingest_position(self, d: dict):
        """Upsert or remove a position from a WS push (Position.__dict__ shape)."""
        if not isinstance(d, dict):
            return
        symbol = d.get("symbol")
        if not symbol:
            return
        try:
            size = float(d.get("size", 0.0) or 0.0)
        except (TypeError, ValueError):
            size = 0.0
        # MEXC sends size 0 / empty when a position is closed -> remove it
        if size <= 0:
            self.positions = [p for p in self.positions
                              if p.get("symbol") != symbol]
            return
        pos = {
            "symbol": symbol,
            "direction": d.get("direction", ""),
            "size": size,
            "entry": float(d.get("entry", 0.0) or 0.0),
            "leverage": d.get("leverage", 1),
            "liq_price": float(d.get("liq_price", 0.0) or 0.0),
            "mark": float(d.get("mark", 0.0) or 0.0),
            "pnl": float(d.get("pnl", 0.0) or 0.0),
            "margin": float(d.get("margin", 0.0) or 0.0),
            "fee": float(d.get("fee", 0.0) or 0.0),
            "status": d.get("status", "OPEN"),
        }
        for i, p in enumerate(self.positions):
            if p.get("symbol") == symbol:
                self.positions[i] = pos
                return
        self.positions.append(pos)

    def _ingest_wallet(self, d: dict):
        """Update balance + equity history from a WS asset push."""
        if not isinstance(d, dict):
            return
        eq = d.get("equity")
        if eq is None:
            eq = d.get("totalAsset") or d.get("total") or d.get("balance")
        try:
            eq = float(eq)
        except (TypeError, ValueError):
            eq = None
        avail = d.get("available")
        try:
            avail = float(avail)
        except (TypeError, ValueError):
            avail = 0.0
        self.balance = {
            "equity": eq if eq is not None else 0.0,
            "available": avail,
            "currency": d.get("currency", "USDT"),
        }
        if eq is not None:
            now = int(time.time())
            self.equity_history.append({"ts": now, "equity": eq})
            self._last_balance = eq

    def _recompute_stats(self):
        trades = self._trades
        total = len(trades)
        wins = sum(1 for t in trades if t["pnl"] > 0)
        losses = sum(1 for t in trades if t["pnl"] < 0)
        gross_win = sum(t["pnl"] for t in trades if t["pnl"] > 0)
        gross_loss = abs(sum(t["pnl"] for t in trades if t["pnl"] < 0))
        net = gross_win - gross_loss
        wr = (wins / total * 100.0) if total else 0.0
        pf = (gross_win / gross_loss) if gross_loss else (gross_win if gross_win else 0.0)
        exp = (net / total) if total else 0.0
        # running equity drawdown from equity_history
        eqs = [e["equity"] for e in self.equity_history]
        peak = max(eqs) if eqs else 0.0
        dd = 0.0
        for e in eqs:
            dd = max(dd, peak - e)
            peak = max(peak, e)
        self.stats = {
            "total_trades": total, "wins": wins, "losses": losses,
            "win_rate": round(wr, 2), "net_pnl": round(net, 2),
            "profit_factor": round(pf, 2), "expectancy": round(exp, 2),
            "max_drawdown": round(dd, 2), "avg_hold": 0.0,
            "open_positions": len(self.positions),
            "balance": self._last_balance,
            "equity": self._last_balance,
        }

    def shadow_expectancy(self) -> dict:
        """Go-live gate readout from the persisted ShadowLedger.

        Returns per-pair ratings + an aggregate. ``min_trades`` (30) is the
        threshold ShadowLedger requires before a pair is 'trusted'; the gate is
        green only when every actively-traded pair is trusted AND winrate >= 50%.
        """
        if self.ledger is None:
            return {"available": False, "pairs": [], "gate_ready": False,
                    "min_trades": 30}
        pairs = []
        ready = True
        for sym in self.market_symbols:
            # dashboard uses BTC_USDT; ledger stores BTCUSDT
            p = sym.replace("_", "")
            r = self.ledger.rating(p)
            pairs.append({
                "pair": sym, "trades": r.trades, "wins": r.wins,
                "losses": r.losses, "winrate": round(r.winrate, 3),
                "trusted": r.trades >= self.ledger.min_trades,
                "flag": r.flag,
            })
            if r.trades < self.ledger.min_trades:
                ready = False
        return {
            "available": True,
            "min_trades": self.ledger.min_trades,
            "pairs": pairs,
            "gate_ready": ready,
        }

    def snapshot(self) -> dict:
        return {
            "paper": 1 if self.paper else 0,
            "bot": "mexc-fatty",
            "ws_feed_live": self.ws_feed_live,
            "market": dict(self.market),
            "spark": {k: list(v) for k, v in self.spark.items()},
            "positions": self.positions,
            "balance": self.balance,
            "open_orders": self.open_orders,
            "equity_history": list(self.equity_history),
            "pnl_history": list(self.pnl_history),
            "stats": self.stats,
            "logs": list(self.logs)[-100:],
            "activities": list(self.activities)[-50:],
            "health": {"ts": int(time.time()), "poll_interval": self.poll_interval},
            "shadow": self.shadow_expectancy(),
            "risk": {
                "leverage": getattr(self.ex, "default_leverage", None),
                "margin_type": getattr(self.ex, "margin_type", None),
            },
        }
