"""mexc-listener composition root.

Run modes (CONCRETE-SPEC §10): --check-tg, --live-dry (forced paper), --dashboard
(paper unless go-live), --go-live (mint token), --bot NAME, --all-bots,
--status/--balance/--positions. Degrades to safe paper/testnet if Config DB
unreachable. Wires: parser -> Gate1 -> LLMBrain -> Gate2 -> OrderService -> MEXC,
plus MexcWS feed, PositionManager, ShadowLedger, Web UI + WS, GoLiveGate.

This module is the integration seam; unit behavior is covered by the per-module
tests. A small smoke test asserts paper mode + wiring without network.
"""
from __future__ import annotations

import argparse
import sys
import os
import time
import threading

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from exchanges.repair import DecisionStore
from services.position import PositionStore
from eval.shadow_ledger import EvalStore
from notifier.bot import GoLiveGate


def _pg_conn():
    """Return a psycopg connection if CONFIG_DB_URL is set and reachable,
    else None (caller falls back to in-memory fakes). Never raises."""
    url = os.getenv("CONFIG_DB_URL")
    if not url:
        return None
    try:
        import psycopg
        return psycopg.connect(url, connect_timeout=3)
    except Exception:  # noqa: BLE001
        return None


def build_container(paper: bool = True, live_feeds: bool = False):
    """Wire adapters (fakes in tests; real in prod). Returns a dict of components.

    ``live_feeds`` forces construction of the live MEXC WS + Telegram listeners
    even when MEXC_FAKE is set (paper mode). Use it to run a paper dashboard that
    still ingests REAL market/position/signal data — orders stay paper.
    """
    # Load .env (gitignored) here, lazily at runtime — NOT at module import, so
    # importing main in tests does not leak live secrets into the shared process
    # environment. No-ops if python-dotenv is missing or file absent.
    try:
        from dotenv import load_dotenv
        load_dotenv()
    except Exception:  # noqa: BLE001
        pass

    # Paper/simulated exchange is enabled ONLY when MEXC_FAKE is set to a truthy
    # value. In .env, MEXC_FAKE=0 MUST mean "real exchange" (the string "0" is
    # truthy in Python, so never test it with a bare bool()). Treat empty/0/false
    # as live; only 1/true/yes enables the simulator.
    def is_fake():
        v = (os.getenv("MEXC_FAKE") or "").strip().lower()
        return v in ("1", "true", "yes", "y", "on")

    from domain.model import Side
    from exchanges.mexc import MexcExchange, FakeMexcExchange
    from exchanges.repair import IdempotencyGuard, DecisionStore
    from services.validator import Gate1, Gate2, RiskConfig
    from services.risk import FixedRiskSizer, FeeModel
    from services.order import OrderService
    from services.position import PositionManager, PositionStore
    from llm.brain import LLMBrain, FakeLLM
    from eval.shadow_ledger import ShadowLedger, EvalStore
    from web.app import EventBus, create_app
    from web.dashboard_state import DashboardState, PriceBus

    cfg = RiskConfig()
    # MEXC REST can be routed through a proxy (Cloudflare Worker / fixed egress)
    # to bypass a region/IP restriction. Default: direct. Set MEXC_REST_PROXY_URL
    # to the proxy base (e.g. https://mexc-proxy.<sub>.workers.dev). NOTE: MEXC
    # enforces an API IP whitelist, so the proxy's egress IP must be whitelisted
    # on the key, otherwise MEXC returns 406 "Accessing IP is not in the whitelist".
    rest_proxy = os.getenv("MEXC_REST_PROXY_URL", "").strip()
    ex = FakeMexcExchange() if is_fake() else MexcExchange(
        os.getenv("MEXC_API_KEY", ""), os.getenv("MEXC_SECRET", ""),
        default_leverage=cfg.default_leverage, margin_type=cfg.margin_type,
        rest_proxy=rest_proxy)

    # Postgres-backed stores when configured (real I/O). Degrade to in-memory
    # Postgres connection. Order/position/golive stores stay in-memory while
    # MEXC_FAKE is set (paper-safety: never persist real order state in fake mode).
    # BUT the ShadowLedger EvalStore is ALWAYS persisted when PG is available,
    # even in fake/paper mode — that's how the bot earns its go-live expectancy
    # gate (>=30 shadow trades/pair) across restarts without ever placing a
    # real order. Recommendation A: build a real track record risk-free.
    pg = _pg_conn()
    use_pg = pg is not None
    use_pg_for_orders = use_pg and not is_fake()
    if use_pg:
        from config.db import (PgGoLiveStore, PgDecisionStore, PgPositionStore,
                               PgEvalStore, init_config_schema)
        from store.ledger import Ledger, init_ledger_schema
        init_config_schema(pg)
        init_ledger_schema(pg)
        eval_store = PgEvalStore(pg)  # persisted regardless of fake mode
        if use_pg_for_orders:
            golive_store = PgGoLiveStore(pg)
            store = PgDecisionStore(pg)
            pos_store = PgPositionStore(pg)
            trade_ledger = Ledger(pg)
        else:
            golive_store = None
            store = _MemDecisionStore()
            pos_store = _MemPositionStore()
            trade_ledger = None
    else:
        eval_store = _MemEvalStore()
        golive_store = None
        store = _MemDecisionStore()
        pos_store = _MemPositionStore()
        trade_ledger = None

    guard = IdempotencyGuard(store)
    gate1 = Gate1(cfg)
    gate2 = Gate2(cfg)
    sizer = FixedRiskSizer(cfg.risk_per_trade_usd, FeeModel(), cfg.max_position_usd, cfg.min_notional_usd)
    bus = EventBus()
    price_bus = PriceBus()
    # paper is the HARD safety gate: when True, OrderService/PositionManager never
    # touch the real exchange (simulated fills only). This is enforced in code,
    # independent of the MEXC_FAKE env flag.
    order = OrderService(ex, guard, paper=paper, bus=bus, margin_type=cfg.margin_type)
    pm = PositionManager(ex, pos_store, paper=paper)
    brain = LLMBrain(FakeLLM('{"action":"SKIP","pair":"","direction":null}'),
                    os.getenv("LLM_MODEL", "deepseek-v4-flash-free"))
    # Real LLM client only when configured AND not in fake mode (paper-safety:
    # MEXC_FAKE keeps the deterministic FakeLLM so tests never hit the network).
    if not is_fake() and os.getenv("LLM_BASE_URL"):
        from llm.client import build_llm_client
        brain = LLMBrain(build_llm_client(),
                         os.getenv("LLM_MODEL", "deepseek-v4-flash-free"))
    ledger = ShadowLedger(eval_store)
    # Telegram bot command surface imports (used by both dashboard + control bot)
    import os as _os
    from notifier.bot import persist_config_key as _persist_cfg_raw
    _ENV_PATH = _os.path.join(_os.path.dirname(_os.path.dirname(__file__)), ".env")
    def _persist_cfg(key: str, value: str) -> bool:
        return _persist_cfg_raw(key, value, path=_ENV_PATH)
    # Live dashboard aggregator: equity history, stats, market poll, logs/activities.
    dashboard_state = DashboardState(bus, exchange=ex, poll_interval=2.0, paper=paper, price_bus=price_bus, ledger=ledger, order_service=order)
    get_state = dashboard_state.snapshot
    # Manual trading controller (dashboard password-gated): calc + enter + close + mode.
    from web.manual import calc as _m_calc, manual_enter as _m_enter, manual_close as _m_close, set_mode as _m_set_mode
    app = create_app(bus, get_state, dashboard_state=dashboard_state, price_bus=price_bus,
                     exchange=ex, order_service=order, persist_config=_persist_cfg,
                     manual={
                         "calc": _m_calc,
                         "enter": _m_enter,
                         "close": _m_close,
                         "set_mode": _m_set_mode,
                     })
    # Telegram bot command surface (/status /balance /positions /live /paper)
    from notifier.bot import CommandHandler
    bot_handler = CommandHandler(
        get_state, golive_store=golive_store,
        gate=(GoLiveGate(golive_store) if golive_store else None),
        shadow_expectancy=0.0, tests_green=True, probe_green=False,
        exchange=ex, order_service=order, persist_config=_persist_cfg)

    # Live MEXC futures WS feed (Item 9c). Constructed only when real keys are
    # present and not in fake mode. The socket is NOT opened here; call
    # container["mexc_ws"].connect() to start the loop. MEXC_WS_URL env lets a
    # Cloudflare Worker sit in front of contract.mexc.com/edge to bypass the
    # Jakarta geo-block (verified: rs.login success via mexc-proxy Worker).
    mexc_ws = None
    if (not is_fake() or live_feeds) and os.getenv("MEXC_API_KEY"):
        from streaming.mexc_ws import MexcWS
        mexc_ws = MexcWS.from_env()
        # Feed pushes into the dashboard event bus (real store/pm writes happen
        # via the OrderService path, not the raw WS callback, to keep one writer).
        def _on_position(pos):
            bus.publish({"type": "position", "data": pos.__dict__ if hasattr(pos, "__dict__") else pos})
        def _on_fill(f):
            bus.publish({"type": "fill", "data": f.__dict__ if hasattr(f, "__dict__") else f})
            if trade_ledger is not None:
                try:
                    trade_ledger.write(f.__dict__ if hasattr(f, "__dict__") else {})
                except Exception:  # noqa: BLE001
                    pass
        def _on_order(o):
            bus.publish({"type": "order", "data": o})
        def _on_wallet(w):
            bus.publish({"type": "wallet", "data": w})
        def _on_heartbeat():
            bus.publish({"type": "heartbeat", "data": {"ts": int(time.time())}})
        def _on_ready():
            # Feed is authenticated + subscribed. True LIVE status even on a
            # flat account (MEXC pushes no position/wallet frames when 0 pos).
            dashboard_state.ws_feed_live = True
            print("[mexc-listener] MEXC WS feed is LIVE", flush=True)
        def _on_lost():
            dashboard_state.ws_feed_live = False
            print("[mexc-listener] MEXC WS feed LOST (reconnects exhausted)",
                  flush=True)
        mexc_ws.on_position = _on_position
        mexc_ws.on_fill = _on_fill
        mexc_ws.on_order = _on_order
        mexc_ws.on_wallet = _on_wallet
        mexc_ws.on_heartbeat = _on_heartbeat
        mexc_ws.on_ready = _on_ready
        mexc_ws.on_lost = _on_lost

    # Live Telegram signal listener (Item 2/9c). Constructed when TG creds are
    # present and not in fake mode; .start() blocks serving @fattyfatclub. The
    # SignalRouter wires parser -> Gate1 -> LLMBrain -> Gate2 -> OrderService, or
    # the MANAGEMENT fast-path (no LLM).
    telegram_listener = None
    if ((not is_fake()) or live_feeds) and os.getenv("TG_API_ID") and os.getenv("TG_API_HASH"):
        from sources.telegram import TelethonListener, SignalRouter
        router = SignalRouter(
            exchange=ex, gate1=gate1, gate2=gate2, order_service=order,
            brain=brain, risk_config=cfg,
            on_event=lambda ev: bus.publish({"type": "signal", "data": ev}),
        )
        telegram_listener = TelethonListener(
            router,
            api_id=os.getenv("TG_API_ID", ""),
            api_hash=os.getenv("TG_API_HASH", ""),
            phone=os.getenv("TG_PHONE", ""),
            session_dir=os.getenv("TG_SESSION_DIR", ".hermes/cron/output/mexc-listener"),
            channel=os.getenv("FATTY_CHANNEL", "fattyfatclub"),
        )

    return dict(ex=ex, guard=guard, gate1=gate1, gate2=gate2, sizer=sizer,
                order=order, pm=pm, brain=brain, ledger=ledger, bus=bus, app=app,
                golive_store=golive_store, trade_ledger=trade_ledger,
                bot_handler=bot_handler, paper=paper, mexc_ws=mexc_ws,
                telegram_listener=telegram_listener, dashboard_state=dashboard_state)


class _MemDecisionStore(DecisionStore):
    def __init__(self): self._ids=set(); self._active={}
    def get_active_for_decision(self, d, s): return self._active.get(d)
    def mark_client_order_id(self, c):
        if c in self._ids: return False
        self._ids.add(c); return True
    def mark_active(self, d): self._active[d] = ["FILLED"]


class _MemPositionStore(PositionStore):
    def __init__(self): self.rows={}; self.orders={}
    def create(self, r): self.rows[r.symbol]=r
    def get_open_by_pair(self, s):
        r=self.rows.get(s); return r if r and r.status=="OPEN" else None
    def update_status(self, s, st):
        if s in self.rows: self.rows[s].status=st
    def create_order(self, oid, sym, side, status="PENDING"): self.orders[oid]={"status":status,"symbol":sym,"side":side}
    def get_order(self, oid): return self.orders.get(oid)


class _MemEvalStore(EvalStore):
    def __init__(self): self.rows={}
    def record(self, p, w): self.rows.setdefault(p, []).append(w)
    def get(self, p): return self.rows.get(p, [])


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="mexc-listener")
    ap.add_argument("--live-feeds", action="store_true",
                    help="start real MEXC WS + Telegram listener while keeping orders paper")
    ap.add_argument("--live-dry", action="store_true")
    ap.add_argument("--dashboard", action="store_true")
    ap.add_argument("--go-live", action="store_true")
    ap.add_argument("--bot")
    ap.add_argument("--all-bots", action="store_true")
    ap.add_argument("--status", action="store_true")
    ap.add_argument("--balance", action="store_true")
    ap.add_argument("--positions", action="store_true")
    args = ap.parse_args(argv)

    paper = not args.go_live
    if args.live_dry:
        paper = True  # forced paper, never real
    c = build_container(paper=paper, live_feeds=args.live_feeds)
    # Start the dashboard aggregator (market poll + event folding) alongside the UI.
    ds = c.get("dashboard_state")
    if ds is not None:
        try:
            ds.start()
        except Exception:  # noqa: BLE001
            pass

    # Live feeds (MEXC WS + Telegram listener). Only when requested via
    # --live-feeds; each runs in its own daemon thread and is NON-trading: the
    # dashboard/event bus consumes the pushes, orders stay paper.
    _feed_threads = []
    if args.live_feeds:
        mexc_ws = c.get("mexc_ws")
        if mexc_ws is not None:
            t = threading.Thread(target=mexc_ws.connect, daemon=True,
                                 name="mexc-ws")
            t.start()
            _feed_threads.append(t)
            print("[mexc-listener] live MEXC WS feed starting (paper-safe)")
        tg = c.get("telegram_listener")
        if tg is not None:
            t = threading.Thread(target=tg.start, daemon=True,
                                 name="telegram-listener")
            t.start()
            _feed_threads.append(t)
            print(f"[mexc-listener] Telegram listener starting on "
                  f"@{os.getenv('FATTY_CHANNEL', 'fattyfatclub')} (paper-safe)")

    if args.dashboard or not any([args.check_tg, args.go_live, args.status,
                                  args.balance, args.positions]):
        import uvicorn
        port = int(os.getenv("WEB_PORT", "8080"))
        print(f"[mexc-listener] starting dashboard (paper={paper}) on :{port}")
        uvicorn.run(c["app"], host="0.0.0.0", port=port)
    else:
        print(f"[mexc-listener] mode=check-tg paper={paper}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
