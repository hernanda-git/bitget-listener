"""GoLiveGate (two-step) + Markdown-safe Telegram cards + bot command handlers.

CONCRETE-SPEC §11 / §3. No real order is placed until paper flips to 0 via the gate,
and only when shadow expectancy > 0 AND all tests green AND probe GREEN.

Item 6: ``CommandHandler`` builds the text for ``/status /balance /positions
/live /paper`` (pure, no socket) and ``register_bot`` wires them to
``python-telegram-bot`` (v22 Application API) at runtime.
"""
from __future__ import annotations

import os
import secrets
from typing import Callable, Optional


class GoLiveStore:
    def get(self, bot): raise NotImplementedError
    def set_paper(self, bot, val): raise NotImplementedError
    def set_token(self, bot, tok): raise NotImplementedError


def _md_escape(text: str) -> str:
    """Escape Telegram MarkdownV2 special chars to avoid parse crashes."""
    special = r"_*[]()~`>#+-=|{}.!"
    out = []
    for c in text:
        out.append("\\" + c if c in special else c)
    return "".join(out)


def persist_config_key(key: str, value: str, path: str = None) -> bool:
    """Update or append a single non-secret key in the bot .env (atomic-ish).

    Only the caller-chosen keys (MEXC_DEFAULT_LEVERAGE / MEXC_MARGIN_TYPE) are
    ever written here, so no secrets can leak. Returns True on success.
    """
    if path is None:
        path = os.getenv("MEXC_ENV", os.path.join(
            os.path.dirname(os.path.dirname(os.path.dirname(__file__))), ".env"))
    try:
        lines = []
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as fh:
                lines = fh.readlines()
        found = False
        new_lines = []
        for line in lines:
            stripped = line.strip()
            if stripped.startswith(f"{key}=") or stripped.startswith(f"# {key}="):
                new_lines.append(f"{key}={value}\n")
                found = True
            else:
                new_lines.append(line)
        if not found:
            new_lines.append(f"{key}={value}\n")
        with open(path, "w", encoding="utf-8") as fh:
            fh.writelines(new_lines)
        return True
    except Exception:  # noqa: BLE001
        return False


class GoLiveGate:
    def __init__(self, store: GoLiveStore) -> None:
        self.store = store

    def mint(self, bot: str) -> str:
        tok = secrets.token_hex(8)
        self.store.set_token(bot, tok)
        return tok

    def activate(self, bot: str, token: str, shadow_expectancy: float = 0.0,
                 tests_green: bool = False, probe_green: bool = False) -> bool:
        row = self.store.get(bot) or {}
        if row.get("go_live_token") != token:
            return False
        # hard gates: never bypass
        if not (shadow_expectancy > 0 and tests_green and probe_green):
            return False
        self.store.set_paper(bot, 0)
        self.store.set_token(bot, None)  # one-time token
        return True


class CommandHandler:
    """Pure command logic. Builds MarkdownV2-safe cards from a get_state()
    callable and drives the GoLiveGate for /live and /paper.

    The hard go-live gates (shadow_expectancy>0, tests_green, probe_green)
    are supplied at construction time by the composition root (main.build_container),
    since the gate itself is stateless per CONCRETE-SPEC §11.
    """

    def __init__(self, get_state: Callable[[], dict], golive_store: GoLiveStore = None,
                 gate: GoLiveGate = None, bot_name: str = "mexc-fatty",
                 shadow_expectancy: float = 0.0, tests_green: bool = False,
                 probe_green: bool = False, exchange=None, order_service=None,
                 persist_config: Callable[[str, str], bool] = None) -> None:
        self._get_state = get_state
        self._store = golive_store
        self._gate = gate
        self._bot = bot_name
        self._shadow_expectancy = shadow_expectancy
        self._tests_green = tests_green
        self._probe_green = probe_green
        self._exchange = exchange
        self._order_service = order_service
        self._persist = persist_config

    def cmd_status(self) -> str:
        st = self._get_state()
        mode = "LIVE" if not st.get("paper", 1) else "PAPER"
        lines = [f"*mexc-listener*  `{_md_escape(mode)}`",
                 f"bot: {_md_escape(st.get('bot', self._bot))}"]
        pos = st.get("positions", []) or []
        lines.append(f"open positions: {len(pos)}")
        for p in pos[:10]:
            sym = _md_escape(str(p.get("symbol", "?")))
            lines.append(f"  • {sym} {p.get('direction','')} @ {p.get('entry','')} "
                         f"pnl {p.get('pnl', 0)}")
        return "\n".join(lines)

    def cmd_positions(self) -> str:
        st = self._get_state()
        pos = st.get("positions", []) or []
        if not pos:
            return "*positions*  _none open_"
        lines = ["*positions*"]
        for p in pos:
            sym = _md_escape(str(p.get("symbol", "?")))
            lines.append(f"  • {sym} {p.get('direction','')} @ {p.get('entry','')} "
                         f"pnl {p.get('pnl', 0)}")
        return "\n".join(lines)

    def cmd_balance(self) -> str:
        st = self._get_state()
        mode = "LIVE" if not st.get("paper", 1) else "PAPER"
        trades = st.get("trades", []) or []
        pnl = sum(float(t.get("pnl", 0) or 0) for t in trades)
        return (f"*balance*  `{_md_escape(mode)}`\n"
                f"trades: {len(trades)}\nequity(pnl): {pnl:.2f}")

    def cmd_paper(self) -> str:
        """Force paper (always safe; never triggers a real order)."""
        if self._store is not None:
            self._store.set_paper(self._bot, 1)
        return "*mode* set to `PAPER` \\(safe\\)"

    # ---- live-adjustable risk: leverage + margin mode (mirrors learner bot) ----
    def cmd_setleverage(self, arg: str) -> str:
        if self._exchange is None:
            return "*setleverage* not configured \\(no exchange handle\\)"
        try:
            n = int(float(arg))
        except (TypeError, ValueError):
            return "*usage* `/setleverage <N>` \\(1..max_leverage\\)"
        if n < 1:
            return "*leverage* must be >= 1"
        cap = 125
        if n > cap:
            return f"*leverage* capped at {cap} \\(pair max\\)"
        self._exchange.default_leverage = n
        ok = self._persist("MEXC_DEFAULT_LEVERAGE", str(n)) if self._persist else False
        tag = " · saved" if ok else ""
        return f"*default leverage* set to `{n}x`{tag} \\(applied to new opening orders\\)"

    def cmd_setmargintype(self, arg: str) -> str:
        if self._exchange is None:
            return "*setmargintype* not configured \\(no exchange handle\\)"
        a = (arg or "").strip().lower()
        if a in ("isolated", "iso", "i"):
            mode = "isolated"
        elif a in ("cross", "c"):
            mode = "cross"
        else:
            return "*usage* `/setmargintype <isolated|cross>`"
        self._exchange.margin_type = mode
        if self._order_service is not None:
            self._order_service.margin_type = mode
        ok = self._persist("MEXC_MARGIN_TYPE", mode) if self._persist else False
        tag = " · saved" if ok else ""
        return f"*margin mode* set to `{mode.upper()}`{tag} \\(applied to new opening orders\\)"

    def cmd_leverage(self) -> str:
        lev = getattr(self._exchange, "default_leverage", None)
        return f"*default leverage*: `{lev}x`" if lev is not None else "*leverage* n/a"

    def cmd_margintype(self) -> str:
        mt = getattr(self._exchange, "margin_type", None)
        return f"*margin mode*: `{mt.upper() if mt else mt}`" if mt else "*margin mode* n/a"

    def cmd_live(self, token: str) -> str:
        if not token:
            return ("*live* requires the one-time token:\n"
                    "`/live <token>` \\(minted by --go-live, gated on shadow "
                    "expectancy>0 + tests green + probe GREEN\\)")
        if self._store is None or self._gate is None:
            return "*live* not configured \\(no GoLiveGate\\)"
        ok = self._gate.activate(
            bot=self._bot, token=token,
            shadow_expectancy=self._shadow_expectancy,
            tests_green=self._tests_green, probe_green=self._probe_green)
        if ok:
            return "*mode* set to `LIVE` — real orders enabled"
        return ("*live* blocked: token mismatch or hard gates not met "
                "\\(shadow expectancy>0 + tests green + probe GREEN\\)")


def register_bot(token: str, get_state: Callable[[], dict], golive_store=None,
                 gate=None, bot_name: str = "mexc-fatty", exchange=None,
                 order_service=None, persist_config=None):
    """Wire CommandHandler to python-telegram-bot (v22 Application API).

    Returns the Application; caller calls ``app.run_polling()``. Lazy import so
    the module imports without the PTB dependency in tests.
    """
    from telegram import Update
    from telegram.ext import Application, CommandHandler as PTBCommand, ContextTypes

    handler = CommandHandler(get_state, golive_store=golive_store, gate=gate,
                             bot_name=bot_name, exchange=exchange,
                             order_service=order_service, persist_config=persist_config)
    app = Application.builder().token(token).build()

    async def _status(u: Update, c: ContextTypes.DEFAULT_TYPE):
        await u.message.reply_text(handler.cmd_status(), parse_mode="MarkdownV2")
    async def _positions(u, c):
        await u.message.reply_text(handler.cmd_positions(), parse_mode="MarkdownV2")
    async def _balance(u, c):
        await u.message.reply_text(handler.cmd_balance(), parse_mode="MarkdownV2")
    async def _paper(u, c):
        await u.message.reply_text(handler.cmd_paper(), parse_mode="MarkdownV2")
    async def _live(u, c):
        tok = (c.args[0] if c.args else "")
        await u.message.reply_text(handler.cmd_live(tok), parse_mode="MarkdownV2")
    async def _setleverage(u, c):
        arg = (c.args[0] if c.args else "")
        await u.message.reply_text(handler.cmd_setleverage(arg), parse_mode="MarkdownV2")
    async def _setmargintype(u, c):
        arg = (c.args[0] if c.args else "")
        await u.message.reply_text(handler.cmd_setmargintype(arg), parse_mode="MarkdownV2")
    async def _leverage(u, c):
        await u.message.reply_text(handler.cmd_leverage(), parse_mode="MarkdownV2")
    async def _margintype(u, c):
        await u.message.reply_text(handler.cmd_margintype(), parse_mode="MarkdownV2")

    app.add_handler(PTBCommand("status", _status))
    app.add_handler(PTBCommand("positions", _positions))
    app.add_handler(PTBCommand("balance", _balance))
    app.add_handler(PTBCommand("paper", _paper))
    app.add_handler(PTBCommand("live", _live))
    app.add_handler(PTBCommand("setleverage", _setleverage))
    app.add_handler(PTBCommand("setmargintype", _setmargintype))
    app.add_handler(PTBCommand("leverage", _leverage))
    app.add_handler(PTBCommand("margintype", _margintype))
    return app
