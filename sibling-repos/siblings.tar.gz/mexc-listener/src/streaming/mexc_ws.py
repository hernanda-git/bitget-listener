"""MEXC Futures WebSocket: login + personal.filter, push parsing (F6/F7).

CONCRETE-SPEC §6: MEXC has no listenKey; login then personal.filter. WS symbols
use '_' separator. Callbacks: on_fill (fee-aware), on_position (real liq price),
on_order, on_wallet, on_heartbeat (dead-man watchdog reset).

The live loop (`connect`) does jittered reconnect + ping/pong heartbeat and
dispatches parsed messages to the registered callbacks (Item 5).
"""
from __future__ import annotations

import json
import os
import random
import sys
import time
from typing import Optional

from domain.model import Fill, Position, Direction, Side


def build_login(api_key: str, signature: str, req_time: str) -> dict:
    return {"method": "login", "param": {
        "apiKey": api_key, "signature": signature, "reqTime": req_time}}


def build_filter(symbols: list[str]) -> dict:
    rules = [f"{s}_USDT" if not s.endswith("_USDT") else s for s in symbols]
    return {"method": "personal.filter", "param": {"filters": [
        {"filter": "order"},
        {"filter": "order.deal"},
        {"filter": "position", "rules": rules},
        {"filter": "asset"},
    ]}}


def _num(v) -> float:
    try:
        return float(v)
    except (TypeError, ValueError):
        return 0.0


def _jittered_backoff(attempt: int, base: float = 1.0, cap: float = 30.0) -> float:
    """Exponential backoff with jitter, capped. attempt is 0-based."""
    import math
    expo = min(cap, base * (2 ** attempt))
    return max(0.0, min(cap, expo * random.uniform(0.5, 1.5)))


def parse_fill(data: dict) -> Fill:
    side = Side.BUY if str(data.get("side", "")).upper() == "BUY" else Side.SELL
    pnl = data.get("pnl") or data.get("profit") or data.get("realisedAmount") or 0.0
    try:
        pnl = float(pnl)
    except (TypeError, ValueError):
        pnl = 0.0
    return Fill(
        symbol=(data.get("symbol", "") or "").replace("_", ""),
        side=side,
        fill_price=_num(data.get("price")),
        qty=_num(data.get("vol")),
        fee=_num(data.get("fee")),
        fee_asset=(data.get("feeCoin") or "USDT"),
        ts=int(_num(data.get("ts"))),
        client_order_id=str(data.get("orderId", "")),
        pnl=pnl,
    )


def parse_position(data: dict) -> Position:
    ptype = str(data.get("positionType", "")).upper()
    direction = Direction.LONG if ptype == "LONG" else Direction.SHORT
    return Position(
        symbol=(data.get("symbol", "") or "").replace("_", ""),
        direction=direction,
        size=_num(data.get("holdVol")),
        entry=_num(data.get("holdAvgPrice")),
        leverage=int(_num(data.get("leverage")) or 1),
        liq_price=_num(data.get("liquidatePrice")),
        pnl=_num(data.get("pnl")),
        margin=_num(data.get("margin")),
        mark=_num(data.get("markPrice")),
    )


class MexcWS:
    def __init__(self, api_key: str, secret: str, ws_url: str = None,
                 on_fill=None, on_position=None, on_order=None, on_wallet=None,
                 on_heartbeat=None, proxy: str = None,
                 on_ready=None, on_lost=None) -> None:
        self.api_key = api_key
        self.secret = secret
        # Env override MEXC_WS_URL lets a Cloudflare Worker / proxy sit in front of
        # contract.mexc.com/edge to bypass region geo-blocks (e.g. Jakarta -> 301 /404).
        self.ws_url = ws_url or os.getenv("MEXC_WS_URL", "wss://contract.mexc.com/edge")
        # proxy follows websockets' `proxy=` arg (http/https/socks). Falls back to
        # HTTPS_PROXY / WSS_PROXY env when not set explicitly.
        self.proxy = proxy or os.getenv("MEXC_WS_PROXY") or os.getenv("HTTPS_PROXY") \
            or os.getenv("WSS_PROXY")
        self.on_fill = on_fill
        self.on_position = on_position
        self.on_order = on_order
        self.on_wallet = on_wallet
        self.on_heartbeat = on_heartbeat
        # on_ready fires once login + personal.filter both succeed (feed is LIVE),
        # on_lost fires when the socket exhausts reconnects (feed is DOWN).
        self.on_ready = on_ready
        self.on_lost = on_lost
        self._connected = False
        self._sleep = time.sleep  # injectable for tests

    @classmethod
    def from_env(cls, **kwargs) -> "MexcWS":
        """Build from MEXC_API_KEY / MEXC_SECRET / MEXC_WS_URL / MEXC_WS_PROXY."""
        return cls(
            os.getenv("MEXC_API_KEY", ""),
            os.getenv("MEXC_SECRET", ""),
            ws_url=os.getenv("MEXC_WS_URL"),
            proxy=os.getenv("MEXC_WS_PROXY"),
            **kwargs,
        )

    def sign_login(self, req_time: str, auth) -> dict:
        """MEXC contract WS login signature.

        MEXC docs: signature = HMAC-SHA256(secret, apiKey + reqTime + paramString),
        where paramString is empty for login (no query params). Reuses MexcAuth.
        """
        sig = auth.sign("", req_time)
        return build_login(self.api_key, sig, req_time)

    def _dispatch(self, msg: dict) -> None:
        ch = msg.get("channel", "")
        # (server ping/pong keep-alive is answered in the session loop, which
        #  holds the async socket handle — see _run_session.)
        data = msg.get("data", {})
        if ch == "push.personal.order.deal" and self.on_fill:
            self.on_fill(parse_fill(data))
        elif ch == "push.personal.position" and self.on_position:
            self.on_position(parse_position(data))
        elif ch == "push.personal.order" and self.on_order:
            self.on_order(data)
        elif ch in ("push.personal.asset",) and self.on_wallet:
            self.on_wallet(data)
        elif ch in ("ping", "pong"):
            # heartbeat resets the dead-man watchdog TTL (CONCRETE-SPEC §8)
            if self.on_heartbeat:
                self.on_heartbeat()

    def connect(self, websocket_class=None, max_retries: int = 10,
                heartbeat_interval: float = 20.0, login_builder=None) -> int:
        """Live socket loop: login -> filter -> dispatch; jittered reconnect on
        close/error, capped at ``max_retries``. Returns the number of reconnect
        attempts made (for tests/observability)."""
        import websockets  # available at runtime (dep)
        ws_class = websocket_class or websockets.connect
        from exchanges.mexc_auth import MexcAuth
        auth = MexcAuth(self.api_key, self.secret)
        attempt = 0
        while attempt <= max_retries:
            try:
                print(f"[mexc-ws] connecting (attempt {attempt + 1}) -> "
                      f"{self.ws_url}", file=sys.stderr, flush=True)
                self._run_session(ws_class, auth, login_builder, heartbeat_interval)
                self._connected = True
                return attempt
            except Exception as e:  # noqa: BLE001  (socket drop / refused)
                print(f"[mexc-ws] session error: {type(e).__name__}: {e}",
                      file=sys.stderr, flush=True)
                attempt += 1
                if attempt > max_retries:
                    self._connected = False
                    print(f"[mexc-ws] giving up after {max_retries} retries "
                          f"(feed DOWN)", file=sys.stderr, flush=True)
                    if self.on_lost:
                        try:
                            self.on_lost()
                        except Exception:  # noqa: BLE001
                            pass
                    return attempt
                backoff = _jittered_backoff(attempt - 1)
                print(f"[mexc-ws] reconnecting in {backoff:.1f}s",
                      file=sys.stderr, flush=True)
                self._sleep(backoff)
        return attempt

    def _run_session(self, ws_class, auth, login_builder, heartbeat_interval, proxy=None):
        """Open one WS session, login, subscribe, and loop on messages."""
        import asyncio
        import json as _json

        async def _session():
            connect_kwargs = {}
            if proxy:
                connect_kwargs["proxy"] = proxy
            async with ws_class(self.ws_url, **connect_kwargs) as sock:
                req_time = str(int(time.time() * 1000))
                login = (login_builder() if login_builder else
                         self.sign_login(req_time, auth))
                await sock.send(_json.dumps(login))
                # subscribe to personal filters
                await sock.send(_json.dumps(build_filter([])))
                ready_flags = {"login": False, "filter": False}

                def _maybe_ready():
                    if ready_flags["login"] and ready_flags["filter"]:
                        self._connected = True
                        print("[mexc-ws] login + filter OK — feed LIVE",
                              file=sys.stderr, flush=True)
                        if self.on_ready:
                            try:
                                self.on_ready()
                            except Exception:  # noqa: BLE001
                                pass

                last_heartbeat = time.time()
                while True:
                    msg = await sock.recv()
                    if isinstance(msg, bytes):
                        msg = msg.decode("utf-8")
                    data = _json.loads(msg)
                    # Capture login / filter confirmation for readiness.
                    ch = data.get("channel", "")
                    if ch == "rs.login" and str(data.get("data", "")).lower() == "success":
                        ready_flags["login"] = True
                        _maybe_ready()
                    elif ch == "rs.personal.filter" and \
                            str(data.get("data", "")).lower() == "success":
                        ready_flags["filter"] = True
                        _maybe_ready()
                    elif ch in ("rs.error",):
                        print(f"[mexc-ws] rs.error: {data.get('data')}",
                              file=sys.stderr, flush=True)
                    # Server-initiated keep-alive: MEXC sends {"method":"ping"}
                    # and expects a {"method":"pong"} back or it drops the link.
                    elif ch == "ping":
                        try:
                            await sock.send(_json.dumps({"method": "pong"}))
                        except Exception:  # noqa: BLE001
                            pass
                        if self.on_heartbeat:
                            self.on_heartbeat()
                        continue
                    # dispatch app messages
                    self._dispatch(data)
                    # periodic ping to keep the link alive (client side)
                    if time.time() - last_heartbeat >= heartbeat_interval:
                        try:
                            await sock.send(_json.dumps({"method": "ping"}))
                        except Exception:  # noqa: BLE001
                            pass
                        last_heartbeat = time.time()

        loop = asyncio.new_event_loop()
        try:
            loop.run_until_complete(_session())
        finally:
            loop.close()

class FakeMarketStream:
    """No-socket twin: feed dict messages via dispatch for tests."""
    def __init__(self) -> None:
        self.received: list[dict] = []

    def send(self, msg: dict) -> None:
        self.received.append(msg)
