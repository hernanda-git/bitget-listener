"""1000x / contract-multiplier symbol map (F11). Low-price MEXC tokens may trade as
1000XXXUSDT or with a contract multiplier; qty math must scale by contract_size.

CONCRETE-SPEC §1.
"""
from __future__ import annotations

from typing import Dict


class ContractMultiplierMap:
    def __init__(self, multipliers: Dict[str, float]) -> None:
        self._m = multipliers

    def multiplier(self, symbol: str) -> float:
        return self._m.get(symbol, 1.0)

    def scale_qty(self, symbol: str, qty: float) -> float:
        return qty * self.multiplier(symbol)
