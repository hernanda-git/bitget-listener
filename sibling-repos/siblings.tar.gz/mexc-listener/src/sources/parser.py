"""@fattyfatclub signal parser + SymbolMap (fork of bybit-listener parser).

CONCRETE-SPEC §1: REST symbol BTCUSDT; WS symbol BTC_USDT.
Management commands skip the LLM (fast path). Conditional signals captured with
a trigger entry level (mirrors learner's CONDITIONAL handling).
"""
from __future__ import annotations

import re
from enum import Enum
from typing import Optional

from domain.model import Signal, Direction, SignalType


class SymbolMap:
    @staticmethod
    def to_rest(token: str) -> str:
        t = token.replace("$", "").replace("#", "").strip().upper()
        return f"{t}USDT" if not t.endswith("USDT") else t

    @staticmethod
    def to_ws(symbol: str) -> str:
        return symbol.replace("USDT", "_USDT") if symbol.endswith("USDT") else symbol


# --- entry / conditional signal parsing ---
_TOKEN_RE = re.compile(r"\$([A-Za-z0-9]+)|#([A-Za-z0-9]+)")
_DIR_RE = re.compile(r"\b(LONG|SHORT)\b", re.I)
_ENTRY_RE = re.compile(r"entry\s*[:=]?\s*\$?\s*([\d.]+)", re.I)
_SL_RE = re.compile(r"\b(?:sl|stop)\s*[:=]?\s*\$?\s*([\d.]+)", re.I)
_TP_LINE_RE = re.compile(r"\btp\s*[:=]?\s*\$?\s*([\d./,\s]+)", re.I)
_LEV_RE = re.compile(r"\blev(?:erage)?\s*[:=]?\s*(\d+)x?", re.I)
_COND_RE = re.compile(r"(long|short).*?(above|below).*?([\d.]+)", re.I)


def _extract_tps(text: str) -> tuple[float, ...]:
    m = _TP_LINE_RE.search(text)
    if not m:
        return ()
    nums = re.findall(r"[\d.]+", m.group(1))
    return tuple(float(n) for n in nums)


def _first_group(m) -> Optional[str]:
    return m.group(1) or m.group(2) if m else None


# --- compact @fattyfatclub format (e.g. "🔴 TRADE — INJUSDT / 📊 SHORT | MARKET /
# 💰 Qty: 0.019066 / ⚙️ 10x / 🛑 SL=4.305 / 🎯 TP1=3.978, TP2=3.9") ---
_COMPACT_RE = re.compile(r"trade\s*[—-]\s*([A-Za-z0-9]+)", re.I)
_DIR2_RE = re.compile(r"\b(LONG|SHORT)\b\s*\|?\s*(MARKET|LIMIT)", re.I)
_QTY_RE = re.compile(r"qty\s*[:=]?\s*([\d.]+)", re.I)
_LEV2_RE = re.compile(r"(\d+)\s*x\b", re.I)
_SL2_RE = re.compile(r"\bsl\s*[:=]?\s*([\d.]+)", re.I)
_TP2_RE = re.compile(r"\btp1?\s*[:=]?\s*([\d.]+)(?:\s*,?\s*tp2?\s*[:=]?\s*([\d.]+))?", re.I)


def _parse_compact(text: str) -> Optional[Signal]:
    """Parse the compact fatty Telegram card. Returns Signal or None."""
    m = _COMPACT_RE.search(text)
    if not m:
        return None
    pair = SymbolMap.to_rest(m.group(1))
    d = _DIR2_RE.search(text)
    if not d:
        return None
    direction = Direction.LONG if d.group(1).upper() == "LONG" else Direction.SHORT
    order_kind = (d.group(2) or "LIMIT").upper()
    entry = None if order_kind == "MARKET" else None
    qty_m = _QTY_RE.search(text)
    qty = float(qty_m.group(1)) if qty_m else None
    lev_m = _LEV2_RE.search(text)
    leverage = int(lev_m.group(1)) if lev_m else None
    sl_m = _SL2_RE.search(text)
    sl = float(sl_m.group(1)) if sl_m else None
    tp_m = _TP2_RE.search(text)
    tps = ()
    if tp_m:
        vals = [x for x in (tp_m.group(1), tp_m.group(2)) if x]
        tps = tuple(float(v) for v in vals)
    return Signal(
        pair=pair,
        direction=direction,
        entry=entry,  # MARKET -> resolved at execution time from live mark price
        sl=sl,
        tps=tps,
        leverage=leverage,
        raw_text=text,
        signal_type=SignalType.ENTRY,
        confidence_pct=95.0,
    )


def parse_signal(text: str) -> Optional[Signal]:
    # 1) try compact fatty card first (no $/# tokens)
    compact = _parse_compact(text)
    if compact:
        return compact
    tok = _first_group(_TOKEN_RE.search(text))
    if not tok:
        # conditional without $token still possible
        cond = _COND_RE.search(text)
        if not cond:
            return None
    raw_dir = _DIR_RE.search(text)
    entry_m = _ENTRY_RE.search(text)
    sl_m = _SL_RE.search(text)
    tps = _extract_tps(text)
    lev_m = _LEV_RE.search(text)

    # conditional (no explicit entry, but has above/below trigger)
    cond = _COND_RE.search(text)
    if cond and not entry_m:
        direction = Direction.LONG if cond.group(1).lower() == "long" else Direction.SHORT
        return Signal(
            pair=SymbolMap.to_rest(tok) if tok else "",
            direction=direction,
            entry=float(cond.group(3)),
            sl=float(sl_m.group(1)) if sl_m else None,
            tps=tps,
            leverage=int(lev_m.group(1)) if lev_m else None,
            raw_text=text,
            signal_type=SignalType.CONDITIONAL,
        )

    if not raw_dir and not entry_m:
        # noise / no actionable signal
        if not cond:
            return None

    pair = SymbolMap.to_rest(tok) if tok else ""
    direction = Direction.LONG if (raw_dir and raw_dir.group(1).upper() == "LONG") else Direction.SHORT
    return Signal(
        pair=pair,
        direction=direction,
        entry=float(entry_m.group(1)) if entry_m else None,
        sl=float(sl_m.group(1)) if sl_m else None,
        tps=tps,
        leverage=int(lev_m.group(1)) if lev_m else None,
        raw_text=text,
        signal_type=SignalType.ENTRY,
    )


# --- management command parsing (no LLM) ---
_MGMT_PATTERNS = [
    (re.compile(r"sl\s*to\s*entry", re.I), "SL_TO_ENTRY"),
    (re.compile(r"\b(?:book|take|grab|secure|lock)\s+(?:in\s+)?(?:profit\s+)?tp1?\b", re.I),
     "TP1_PARTIAL"),
    (re.compile(r"\btp1\s+booked\b", re.I), "TP1_PARTIAL"),
    (re.compile(r"\bfull\b", re.I), "FULL_CLOSE"),
    (re.compile(r"\bclose\b", re.I), "FULL_CLOSE"),
]


def parse_management(text: str) -> Optional[dict]:
    tok = _first_group(_TOKEN_RE.search(text))
    if not tok:
        return None
    for pat, cmd in _MGMT_PATTERNS:
        if pat.search(text):
            return {"command": cmd, "pair": SymbolMap.to_rest(tok), "raw": text}
    return None


def normalize_pair(token: str) -> str:
    return SymbolMap.to_rest(token)
