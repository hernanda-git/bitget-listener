"""Live Telegram listener for @fattyfatclub (Item 2, TDD).

Two layers:

1. ``SignalRouter`` — PURE orchestration, no network. Given a ``RawSignal``
   (text + optional image bytes) it routes:
     ENTER/CONDITIONAL -> Gate1 (pre-LLM, idemp/cooldown/whitelist)
                       -> LLMBrain.decide (vision on chart + text parser)
                       -> Gate2 (fee-aware clamps)
                       -> OrderService.enter
     MANAGEMENT        -> parse_management (no LLM, ~200ms fast path)
                       -> OrderService transform (modify_sl_to_entry / close)
   SKIP / blocked -> no order. Deterministic; the LLM only *decides*, never
   *fixes* an order (DESIGN §7 / CONCRETE-SPEC §6).

2. ``TelethonListener`` — thin network adapter: subscribes to
   ``events.NewMessage`` on @fattyfatclub, extracts image bytes, builds a
   ``RawSignal``, and delegates to ``SignalRouter``. First-run auth uses a PTY
   (phone code) — see README; this class only handles the live event loop.

HANDOFF-CONTINUE "Next items" #2; DOCUMENTATION.md §2 item 2.
"""
from __future__ import annotations

import os
from typing import Optional

from domain.model import RawSignal, TradeDecision, Action, Direction, SignalType
from sources.parser import parse_management


class SignalRouter:
    """Pure signal -> order routing. Unit-testable without Telegram/MEXC/LLM."""

    def __init__(self, exchange, gate1, gate2, order_service, brain, risk_config,
                 on_event=None):
        self.ex = exchange
        self.gate1 = gate1
        self.gate2 = gate2
        self.order = order_service
        self.brain = brain
        self.cfg = risk_config
        self.on_event = on_event  # optional callback(dict) for observability

    def _emit(self, kind: str, **kw):
        if self.on_event is not None:
            self.on_event({"kind": kind, **kw})

    def handle(self, raw: RawSignal) -> dict:
        # 1) MANAGEMENT fast path (no LLM)
        mgmt = parse_management(raw.text)
        if mgmt is not None:
            return self._handle_management(mgmt, raw)

        # 2) Trade/conditional -> Gate1 (pre-LLM) -> LLM -> Gate2 -> order
        # Gate1 needs a pair; try a quick parse to seed it (whitelist/cooldown).
        pair_guess = self._pair_from_text(raw.text)
        g1 = self.gate1.check(raw.message_id, pair_guess, ts=raw.ts or None)
        if not g1.ok:
            self._emit("gate1_blocked", reason=g1.reason, message_id=raw.message_id)
            return {"placed": False, "stage": "gate1", "reason": g1.reason}

        # 2a) Deterministic parser-first path: if the text parses cleanly into an
        # ENTRY signal (compact fatty card or classic $TOKEN format), use it
        # directly. The LLM only decides on ambiguous/conditional text — it never
        # authors or repairs an order (reliability rule).
        from sources.parser import parse_signal as _parse_signal
        parsed = _parse_signal(raw.text)
        if parsed is not None and parsed.pair and parsed.direction is not None:
            decision = TradeDecision(
                action=Action.ENTER,
                pair=parsed.pair,
                direction=parsed.direction,
                entry=parsed.entry,
                sl=parsed.sl,
                tps=parsed.tps,
                leverage=parsed.leverage,
                bias=parsed.bias,
                reason="parser-direct",
            )
        else:
            decision = self.brain.decide(raw)
        if decision.action in (Action.SKIP,):
            self._emit("skipped", message_id=raw.message_id)
            return {"placed": False, "stage": "llm", "reason": "SKIP"}
        if decision.action == Action.MANAGEMENT:
            return self._handle_management(
                {"command": "FULL_CLOSE", "pair": decision.pair, "raw": raw.text},
                raw, decision=decision)

        # Build a normalized decision dict for Gate2
        dec = self._decision_to_dict(decision)
        open_pos = self._open_position_count()
        g2 = self.gate2.check(dec, open_pos, self._daily_loss_pct())
        if not g2.ok:
            self._emit("gate2_blocked", reason=g2.reason, message_id=raw.message_id)
            return {"placed": False, "stage": "gate2", "reason": g2.reason}

        # Resolve entry price. MARKET signals (entry is None) use the live mark
        # price so sizing + the order can proceed (MEXC fills at market).
        order_type = "MARKET"
        entry_price = dec["entry"]
        if entry_price is None:
            mark = self._mark_price(dec["pair"])
            if mark and mark > 0:
                entry_price = mark
            else:
                self._emit("no_mark", message_id=raw.message_id,
                           reason="MARKET signal but no mark price available")
                return {"placed": False, "stage": "price", "reason": "no_mark_price"}
            order_type = "MARKET"
        else:
            order_type = "LIMIT"

        side = "BUY" if dec["direction"].upper() == "LONG" else "SELL"
        qty = g2.size_usd / max(entry_price, 1e-9)
        res = self.order.enter(
            decision_id=f"msg{raw.message_id}",
            pair=dec["pair"], side=side,
            price=entry_price, qty=qty,
            leverage=g2.leverage, sl=dec["sl"], tps=dec["tps"],
            order_type=order_type,
        )
        self._emit("entered", message_id=raw.message_id, pair=dec["pair"],
                   order_type=order_type)
        return {"placed": True, "stage": "order", "decision": dec,
                "order_result": res}

    def _mark_price(self, pair: str) -> float:
        try:
            return float(self.ex.get_mark(pair))
        except Exception:  # noqa: BLE001
            return 0.0

    # --- internals -------------------------------------------------------
    def _pair_from_text(self, text: str) -> str:
        # Prefer the compact fatty card parser; fall back to $/# token scan.
        from sources.parser import _parse_compact, normalize_pair
        compact = _parse_compact(text)
        if compact and compact.pair:
            return compact.pair
        import re
        m = re.search(r"\$([A-Za-z0-9]+)|#([A-Za-z0-9]+)", text)
        if not m:
            return ""
        return normalize_pair(m.group(1) or m.group(2))

    def _decision_to_dict(self, d: TradeDecision) -> dict:
        return {
            "pair": d.pair,
            "direction": d.direction.value if d.direction else "LONG",
            "entry": d.entry,
            "sl": d.sl,
            "tps": tuple(d.tps or ()),
            "leverage": d.leverage,
            "price": d.entry,
        }

    def _handle_management(self, mgmt: dict, raw: RawSignal,
                           decision: Optional[TradeDecision] = None) -> dict:
        cmd = mgmt["command"]
        pair = mgmt["pair"]
        if cmd == "SL_TO_ENTRY":
            self.order.modify_sl_to_entry(pair, new_sl=0.0)
            self._emit("management", command=cmd, pair=pair)
            return {"placed": False, "management": "SL_TO_ENTRY", "pair": pair}
        if cmd in ("FULL_CLOSE", "TP1_PARTIAL"):
            # OrderService transform: caller closes/partials via exchange; here we
            # surface the command for the live loop to act on.
            self._emit("management", command=cmd, pair=pair)
            return {"placed": False, "management": cmd, "pair": pair}
        return {"placed": False, "management": "UNKNOWN", "pair": pair}

    def _open_position_count(self) -> int:
        # best-effort; if exchange exposes positions, count OPEN
        positions = getattr(self.ex, "positions", None)
        if isinstance(positions, dict):
            return sum(1 for p in positions.values()
                       if getattr(p, "status", "OPEN") == "OPEN")
        return 0

    def _daily_loss_pct(self) -> float:
        # The watchdog/risk layer feeds this; default 0 in router scope.
        return getattr(self.cfg, "daily_loss_pct", 0.0)


class TelethonListener:
    """Live network adapter: reads @fattyfatclub via Telethon user client.

    Thin wrapper — all real logic lives in ``SignalRouter``. The constructor
    is lazy (does not connect) so it can be constructed in tests without a
    network. ``start`` connects and registers the NewMessage handler.
    """

    def __init__(self, router: SignalRouter, api_id: str = "", api_hash: str = "",
                 phone: str = "", session_dir: str = "", channel: str = "fattyfatclub",
                 client=None) -> None:
        self.router = router
        self.api_id = api_id or os.getenv("TG_API_ID", "")
        self.api_hash = api_hash or os.getenv("TG_API_HASH", "")
        self.phone = phone or os.getenv("TG_PHONE", "")
        self.session_dir = session_dir or os.getenv("TG_SESSION_DIR", ".")
        self.channel = channel or os.getenv("FATTY_CHANNEL", "fattyfatclub")
        self._client = client  # injectable for tests; None -> real Telethon

    def _build_client(self):
        if self._client is not None:
            return self._client
        from telethon import TelegramClient
        session = os.path.join(self.session_dir, "mexc_listener")
        return TelegramClient(session, int(self.api_id), self.api_hash)

    async def _on_new_message(self, event):
        msg = event.message
        if msg is None:
            return
        text = msg.message or ""
        # Extract image bytes from attached media (photo/doc)
        images = ()
        if getattr(msg, "media", None) is not None:
            try:
                data = await msg.download_media(file=bytes)
                if isinstance(data, bytes):
                    images = (data,)
            except Exception:  # noqa: BLE001
                images = ()
        raw = RawSignal(message_id=msg.id, channel=self.channel, text=text,
                        images=images, ts=int(msg.date.timestamp()) if msg.date else 0)
        # Router is sync; run in executor to avoid blocking the event loop.
        import asyncio
        await asyncio.get_event_loop().run_in_executor(None, self.router.handle, raw)

    def start(self):
        """Connect and serve. Blocks until disconnected (live mode)."""
        client = self._build_client()
        from telethon import events

        @client.on(events.NewMessage(chats=self.channel))
        async def _h(event):
            await self._on_new_message(event)

        client.start(phone=self.phone)
        client.run_until_disconnected()
