"""Edge C execution rigor: idempotent dedup + deterministic repair (no LLM).

CONCRETE-SPEC §5. Mirrors crypto-auto-trader-reliability root causes #1/#2/#3/#4.
No LLM is ever called to "fix" a trade (anti-pattern removed).
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from domain.model import OrderRequest, Side


class DecisionStore:
    def get_active_for_decision(self, decision_id: str, side: str):
        raise NotImplementedError

    def mark_client_order_id(self, client_order_id: str) -> bool:
        raise NotImplementedError


@dataclass
class DedupResult:
    skipped: bool
    status: str = ""


class IdempotencyGuard:
    def __init__(self, store: DecisionStore) -> None:
        self.store = store

    def check(self, decision_id: str, side: Side) -> DedupResult:
        active = self.store.get_active_for_decision(decision_id, side.value)
        if active is not None:
            return DedupResult(skipped=True, status="DUPLICATE_SKIPPED")
        # record intent so a re-sent/retried decision is blocked (Edge C #4)
        if hasattr(self.store, "mark_active"):
            self.store.mark_active(decision_id)
        return DedupResult(skipped=False)


class RepairOrder:
    """Deterministic repair of a rejected order: round up qty to meet minNotional,
    keep reduce_only semantics. Resubmit ONCE; never calls an LLM."""
    def repair(self, symbol: str, side: str, price: float, qty: float,
               min_notional: float, lot_size: float,
               reduce_only: bool = False) -> OrderRequest:
        import math
        step = lot_size or 1.0
        q = math.floor(qty / step) * step
        if q <= 0:
            q = step
        while q * price < min_notional and q < 1e12:
            q += step
        return OrderRequest(
            symbol=symbol,
            side=Side.BUY if side.upper() == "BUY" else Side.SELL,
            price=price,
            qty=q,
            order_type="LIMIT",
            reduce_only=reduce_only,
        )
