"""MEXC HMAC auth — fresh implementation (do NOT reuse Bybit/Binance auth).

Signing model (MEXC_FEATURE_MINING §1.1):
  sign = HMAC-SHA256(secret, accessKey + Request-Time + paramString)
  headers: ApiKey, Request-Time (ms string), Signature
  GET: paramString = sorted(query_params, "&")
  POST: paramString = json body string (no sorting)
"""
from __future__ import annotations

import hmac
import hashlib
import time
from typing import Union, Dict


class MexcAuth:
    def __init__(self, api_key: str, secret: str) -> None:
        self.api_key = api_key
        self.secret = secret

    def sign(self, param_string: str, timestamp_ms: str) -> str:
        payload = f"{self.api_key}{timestamp_ms}{param_string}"
        return hmac.new(
            self.secret.encode("utf-8"), payload.encode("utf-8"), hashlib.sha256
        ).hexdigest()

    def build_param_string(self, params: Union[str, Dict[str, str]]) -> str:
        if isinstance(params, str):
            return params  # POST: raw JSON body
        # GET: sort lexicographically, join with &
        return "&".join(f"{k}={params[k]}" for k in sorted(params))

    def get_headers(self, timestamp_ms: str | None = None,
                    param_string: str = "") -> Dict[str, str]:
        ts = timestamp_ms or str(int(time.time() * 1000))
        return {
            "ApiKey": self.api_key,
            "Request-Time": ts,
            "Signature": self.sign(param_string, ts),
        }
