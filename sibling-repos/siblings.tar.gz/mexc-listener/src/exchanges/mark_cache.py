"""Mark-price cache: single batched refresh, stale-served while banned.

CONCRETE-SPEC §2 (F13). Avoids per-tick REST; serves last known mark if fetch fails.
"""
from __future__ import annotations

from typing import Callable, Dict


class MarkCache:
    def __init__(self, fetcher: Callable[[str], float], ttl_s: int = 30) -> None:
        self._fetcher = fetcher
        self.ttl_s = ttl_s
        self._marks: Dict[str, float] = {}
        self._ts: Dict[str, float] = {}

    def get(self, symbol: str, now: float = 0.0) -> float:
        import time as _t
        now = now or _t.time()
        if symbol in self._marks and (now - self._ts.get(symbol, 0)) < self.ttl_s:
            return self._marks[symbol]
        # refresh (or serve stale if fetch raises)
        try:
            price = self._fetcher(symbol)
            self._marks[symbol] = price
            self._ts[symbol] = now
            return price
        except Exception:
            return self._marks.get(symbol, 0.0)
