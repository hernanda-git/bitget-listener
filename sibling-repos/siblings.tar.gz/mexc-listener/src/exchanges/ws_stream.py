"""Ban-aware backoff (jittered exponential, capped). MEXC CEX bans are milder than
Binance but real; copy learner's proven pattern as insurance.

CONCRETE-SPEC §2. On rate-limit -> back off (extend, don't hammer). Reset on success.
"""
from __future__ import annotations

import random


class BanBackoff:
    def __init__(self, base_s: float = 5.0, max_s: float = 60.0,
                 factor: float = 2.0) -> None:
        self.base_s = base_s
        self.max_s = max_s
        self.factor = factor
        self._level = 0

    def next_wait(self) -> float:
        return min(self.base_s * (self.factor ** self._level), self.max_s)

    def wait(self) -> float:
        """Jittered wait duration to apply at the sleep site."""
        return self.next_wait() * (0.5 + random.random() * 0.5)

    def note_ban(self) -> None:
        self._level += 1

    def note_success(self) -> None:
        self._level = 0
