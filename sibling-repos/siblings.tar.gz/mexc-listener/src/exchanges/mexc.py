"""MEXC Futures REST V1 adapter (skeleton + instruments cache + rounding).

CONCRETE-SPEC §5 rounding/validation guards are implemented here (Edge C).
Network calls are isolated behind `_signed_request` so FakeMexcExchange can stub them.
"""
from __future__ import annotations

import httpx
import math
import time
from typing import Optional

from exchanges.mexc_auth import MexcAuth
from domain.model import Instrument, Side, Position


# Representative instrument presets (stand-ins for /api/v1/contract/detail).
_PRESETS: dict[str, dict] = {
    "BTCUSDT": dict(base="BTC", tick_size=0.1, lot_size=0.0001, min_qty=0.0001,
                    max_qty=100.0, min_price=0.1, max_price=999999.0,
                    min_notional=5.0, max_leverage=125, contract_size=0.0001),
    "ETHUSDT": dict(base="ETH", tick_size=0.01, lot_size=0.001, min_qty=0.001,
                    max_qty=1000.0, min_price=0.01, max_price=999999.0,
                    min_notional=5.0, max_leverage=100, contract_size=1.0),
    "APEUSDT": dict(base="APE", tick_size=0.001, lot_size=0.1, min_qty=0.1,
                    max_qty=100000.0, min_price=0.1, max_price=99.0,
                    min_notional=5.0, max_leverage=50, contract_size=1.0),
    "DOGEUSDT": dict(base="DOGE", tick_size=0.00001, lot_size=1.0, min_qty=1.0,
                     max_qty=10000000.0, min_price=0.00001, max_price=9.0,
                     min_notional=5.0, max_leverage=75, contract_size=1.0),
    "1000PEPEUSDT": dict(base="1000PEPE", tick_size=0.00001, lot_size=1.0, min_qty=1.0,
                         max_qty=100000000.0, min_price=0.00001, max_price=99.0,
                         min_notional=5.0, max_leverage=50, contract_size=1.0),
}


class _ValidationResult:
    def __init__(self, ok: bool, reason: str = "") -> None:
        self.ok = ok
        self.reason = reason


class MexcExchange:
    def __init__(self, api_key: str, secret: str, base_url: str = "https://api.mexc.com",
                 rest_proxy: str = "", timeout: float = 10.0, default_leverage: int = 3,
                 margin_type: str = "isolated") -> None:
        self._auth = MexcAuth(api_key, secret)
        # REST base used for direct calls (fallback). In production we route ALL
        # signed REST through rest_proxy (the Cloudflare Worker) so Jakarta's
        # geo-block on contract.mexc.com is bypassed (mirrors the live WS feed).
        self.base_url = base_url
        self.rest_proxy = rest_proxy.rstrip("/") if rest_proxy else ""
        self._timeout = timeout
        self._cache: dict[str, Instrument] = {}
        self._client = httpx.Client(timeout=timeout)
        # Live-adjustable defaults (mirrored from RiskConfig; updated via /setleverage,
        # /setmargintype). Applied to every opening order.
        self.default_leverage = int(default_leverage)
        self.margin_type = margin_type  # "isolated" | "cross"

    # ---- instruments cache (F10) ----
    # Real specs are fetched from the public /api/v1/contract/detail endpoint
    # (no auth needed); unknown symbols fall back to a preset. The liquidation
    # buffer + min-notional rounding used by the manual calculator are derived
    # from these specs.
    _DETAIL_CACHE_TTL = 600  # seconds

    def _fetch_detail(self, symbol: str) -> Optional[dict]:
        """Public contract detail (no auth). Returns normalized spec dict or None."""
        try:
            r = self._client.get(
                f"{self.base_url}/api/v1/contract/detail",
                params={"symbol": symbol}, timeout=self._timeout)
            if r.status_code == 200:
                j = r.json()
                return j.get("data") if isinstance(j, dict) else None
        except Exception:  # noqa: BLE001
            return None
        return None

    def get_instrument(self, symbol: str) -> Instrument:
        if symbol not in self._cache:
            # normalize key: presets use e.g. BTCUSDT (no underscore)
            norm = symbol.replace("_", "")
            p = _PRESETS.get(norm, _PRESETS.get(symbol, _PRESETS["BTCUSDT"]))
            inst = Instrument(symbol=symbol, **p)
            # try to enrich with real specs (public endpoint)
            d = self._fetch_detail(symbol)
            if d:
                def _num(x, default):
                    try:
                        return float(x)
                    except (TypeError, ValueError):
                        return default
                # MEXC contract detail fields:
                #   priceScale/volScale -> decimals; priceUnit/volUnit -> step.
                #   contractSize = notional per 1 contract (BTC=0.0001, INJ=1).
                #   minVol = minimum contracts (NOT base qty).
                #   vol is in CONTRACTS, not base asset.
                tick = _num(d.get("priceUnit"), p["tick_size"])
                if not tick or tick <= 0:
                    # fall back to 10**(-priceScale)
                    ps = _num(d.get("priceScale"), 0)
                    tick = 10 ** (-ps) if ps else p["tick_size"]
                lot = _num(d.get("volUnit"), p["lot_size"])
                if not lot or lot <= 0:
                    vs = _num(d.get("volScale"), 0)
                    lot = 10 ** (-vs) if vs else p["lot_size"]
                csize = _num(d.get("contractSize"), p["contract_size"])
                if tick and tick > 0:
                    inst = Instrument(
                        symbol=symbol, base=p["base"], quote="USDT",
                        tick_size=tick,
                        lot_size=lot,
                        min_qty=_num(d.get("minVol"), p["min_qty"]),
                        max_qty=_num(d.get("maxVol"), p["max_qty"]),
                        min_price=_num(d.get("minPrice"), p["min_price"]),
                        max_price=_num(d.get("maxPrice"), p["max_price"]),
                        min_notional=p["min_notional"],
                        max_leverage=int(_num(d.get("maxLeverage"), p["max_leverage"])),
                        contract_size=csize,
                    )
            self._cache[symbol] = inst
        return self._cache[symbol]

    def get_all_symbols(self) -> list[dict]:
        """All tradable USDT perpetuals from the public ticker (symbol + lastPrice).

        Cached for 60s. Used by the dashboard pair autocomplete.
        """
        now = time.time()
        if getattr(self, "_sym_cache", None) and now - getattr(self, "_sym_ts", 0) < 60:
            return self._sym_cache
        out = []
        try:
            r = self._client.get(f"{self.base_url}/api/v1/contract/ticker", timeout=self._timeout)
            if r.status_code == 200:
                j = r.json()
                data = j.get("data") or []
                for row in data:
                    sym = row.get("symbol")
                    if not sym:
                        continue
                    out.append({"symbol": sym, "lastPrice": float(row.get("lastPrice") or 0.0)})
        except Exception:  # noqa: BLE001
            pass
        self._sym_cache = out
        self._sym_ts = now
        return out

    # ---- rounding (Edge C, CONCRETE-SPEC §5) ----
    def round_price(self, symbol: str, price: float) -> float:
        inst = self.get_instrument(symbol)
        if inst.tick_size and inst.tick_size > 0:
            import math
            decimals = max(0, int(round(-math.log10(inst.tick_size))))
            rounded = math.floor(price / inst.tick_size) * inst.tick_size
            rounded = round(rounded, decimals)  # kill float residue
            # clamp UP to minPrice only if within 10x (never inflate a $0.16 coin to $100)
            if inst.min_price and rounded < inst.min_price and inst.min_price <= rounded * 10:
                rounded = inst.min_price
            return rounded
        return price

    def round_qty(self, symbol: str, qty: float, price_ref: float) -> float:
        inst = self.get_instrument(symbol)
        if inst.lot_size and inst.lot_size > 0:
            import math
            qty = math.floor(qty / inst.lot_size) * inst.lot_size
        # loop up until notional >= min_notional (skip when price unknown/zero)
        step = inst.lot_size or 1.0
        if price_ref and price_ref > 0:
            while qty * price_ref < inst.min_notional and qty < inst.max_qty:
                qty += step
        return qty

    def validate_order(self, symbol: str, side: str, price: float, qty: float,
                       inst: Optional[Instrument] = None) -> _ValidationResult:
        inst = inst or self.get_instrument(symbol)
        if qty <= 0 or qty < inst.min_qty or qty > inst.max_qty:
            return _ValidationResult(False, "qty out of bounds")
        if price < inst.min_price or price > inst.max_price:
            return _ValidationResult(False, "price out of bounds")
        if qty * price < inst.min_notional:
            return _ValidationResult(False, "below minNotional")
        return _ValidationResult(True)

    # ---- network (stubbable) ----
    def _signed_request(self, method: str, path: str, params: dict | None = None,
                        body: "str | dict | None" = None) -> dict:
        ts = str(__import__("time").time_ns() // 1_000_000)
        import urllib.parse as _up
        # Route through the Cloudflare Worker proxy when configured (bypasses the
        # Jakarta geo-block on contract.mexc.com). The proxy mirrors the request
        # path onto the correct upstream host by prefix, so we keep the real
        # MEXC path here (e.g. /api/v1/contract/order/open).
        base = self.rest_proxy or self.base_url
        if isinstance(body, dict):
            # MEXC POST signing: paramString = the raw JSON body string (no sorting).
            # Sign the compact JSON and send that EXACT string as the body so the
            # server-side signature check matches what was transmitted.
            import json as _json
            body_str = _json.dumps(body, separators=(",", ":"))
            param_string = body_str
            headers = self._auth.get_headers(ts, self._auth.build_param_string(param_string))
            headers = {**headers, "Content-Type": "application/json"}
            r = self._client.request(method, f"{base}{path}", params=params,
                                     content=body_str, headers=headers)
        else:
            # MEXC GET signing: the paramString is EMPTY for authenticated GETs.
            # Query params are sent normally but are NOT part of the signature
            # (verified: balance /api/v1/private/account/assets works with an empty
            # paramString; including params in the signature yields 404/602). This
            # matches MEXC's contract client, which signs GET requests with {}.
            param_string = ""
            headers = self._auth.get_headers(ts, self._auth.build_param_string(param_string))
            url = f"{base}{path}" + (f"?{_up.urlencode(params)}" if params else "")
            r = self._client.request(method, url, headers=headers)
        return r.json()

    # ---- order endpoints (MEXC Futures V1) ----
    def set_leverage(self, symbol: str, leverage: int, margin_type: str = "isolated") -> dict:
        """Set position leverage + margin mode for a symbol (MEXC V1).

        ``openType``: 1 = cross, 2 = isolated. Endpoint is
        ``/api/v1/private/position/change_leverage`` (confirmed working via ccxt;
        the singular ``/position/leverage`` path returns 600 Parameter error).
        """
        open_type = 2 if str(margin_type).lower() == "isolated" else 1
        lev = int(leverage)
        body = {"symbol": symbol, "leverage": lev, "openType": open_type,
                "positionType": 2}
        try:
            return self._signed_request(
                "POST", "/api/v1/private/position/change_leverage", body=body)
        except Exception:  # noqa: BLE001
            return {"success": False, "code": -1, "message": "leverage endpoint unavailable"}

    def qty_to_contracts(self, symbol: str, base_qty: float) -> float:
        """Convert a base-asset quantity to MEXC contract count (vol).

        MEXC order `vol` is expressed in CONTRACTS, where 1 contract = contractSize
        base units (BTC contractSize=0.0001, INJ contractSize=1)."""
        inst = self.get_instrument(symbol)
        csize = inst.contract_size or 1.0
        return base_qty / csize

    def _vol_contracts(self, symbol: str, qty: float) -> float:
        """Round a base-asset qty to a valid integer contract count (MEXC vol).

        MEXC requires `vol` to be an integer number of contracts >= minVol
        (e.g. 1 for INJ/BTC). Round UP so a fractional base qty still maps to a
        valid >=1 contract count; clamp into [minVol, maxVol]."""
        inst = self.get_instrument(symbol)
        contracts = self.qty_to_contracts(symbol, qty)
        step = inst.lot_size or 1.0
        if step and step > 0:
            # round up to the nearest step (never 0)
            import math
            contracts = math.ceil(contracts / step) * step
        contracts = int(contracts)
        min_v = int(inst.min_qty or 1)
        max_v = int(inst.max_qty or 1_000_000_000)
        contracts = max(min_v, min(contracts, max_v))
        return contracts

    def place_order(self, req) -> dict:
        """Submit an order. Opening LIMIT/MARKET -> /api/v1/private/order/create;
        protective STOP/TAKE_PROFIT -> /api/v1/private/order/submit (reduce_only).

        MEXC contract API shape (verified working):
          - side: 1 = open BUY / long, 2 = open SELL / short (INTEGER, not string)
          - positionType: 1 = long position, 2 = short position
          - openType: 2 = isolated, 1 = cross
          - type: 1 = limit, 2 = market (market takes no price)
          - vol: number of CONTRACTS (not base qty)
          - leverage: int (per-order)
        """
        if req.order_type in ("STOP", "TAKE_PROFIT"):
            # protective order: same direction side, reduce_only
            side_int = 1 if req.side == Side.BUY else 2
            pos_type = 1 if req.side == Side.BUY else 2
            body = {
                "symbol": req.symbol,
                "price": self.round_price(req.symbol, req.price),
                "vol": self._vol_contracts(req.symbol, req.qty),
                "leverage": int(req.leverage if req.leverage else self.default_leverage),
                "side": side_int,
                "type": 1,                               # limit trigger
                "openType": 2,
                "positionType": pos_type,
                "reduceOnly": True,
                "stopPrice": self.round_price(req.symbol, req.stop_price or req.price),
                "timeInForce": req.time_in_force or "GTC",
            }
            resp = self._signed_request("POST", "/api/v1/private/order/submit", body=body)
            return {"order_id": self._order_id(resp), "raw": resp}

        # OPENING order
        lev = int(req.leverage if req.leverage else self.default_leverage)
        mtype = req.margin_type or self.margin_type
        open_type = 2 if str(mtype).lower() == "isolated" else 1
        # MEXC side semantics (confirmed via ccxt source):
        #   1 = open long, 2 = close short, 3 = open short, 4 = close long
        side_int = 1 if req.side == Side.BUY else 3   # BUY -> open long; SELL -> open short
        pos_type = 1 if req.side == Side.BUY else 2
        is_market = (req.order_type == "MARKET")
        body = {
            "symbol": req.symbol,
            "vol": self._vol_contracts(req.symbol, req.qty),
            "leverage": lev,
            "side": side_int,
            "openType": open_type,
            "positionType": pos_type,
            "type": 2 if is_market else 1,
            "timeInForce": req.time_in_force or "GTC",
        }
        # MEXC market orders still require a price reference (else 2007);
        # send the live mark so the market order is accepted.
        if is_market:
            body["price"] = self.round_price(req.symbol, self.get_mark(req.symbol))
        else:
            body["price"] = self.round_price(req.symbol, req.price)
        resp = self._signed_request("POST", "/api/v1/private/order/create", body=body)
        return {"order_id": self._order_id(resp), "raw": resp}

    def close(self, symbol: str, side: Side, qty: float,
              price: float | None = None) -> dict:
        """Close an open position. MEXC closes via /order/submit with reduceOnly=True
        using the opposite side, priced at market (type 2) or a limit (type 1)."""
        # MEXC side semantics (confirmed via ccxt source):
        #   1 = open long, 2 = close short, 3 = open short, 4 = close long
        # `side` here is the position being closed: SELL = closing a LONG
        # (sell to close -> side 4, close long), BUY = closing a SHORT
        # (buy to close -> side 2, close short).
        side_int = 4 if side == Side.SELL else 2
        pos_type = 1 if side == Side.SELL else 2
        body = {
            "symbol": symbol,
            "vol": self._vol_contracts(symbol, qty),
            "leverage": int(self.default_leverage),
            "side": side_int,
            "type": 2,                               # market close
            "openType": 2,
            "positionType": pos_type,
            "reduceOnly": True,
        }
        if price is not None:
            body["price"] = self.round_price(symbol, price)
            body["type"] = 1
        resp = self._signed_request("POST", "/api/v1/private/order/submit", body=body)
        return {"order_id": self._order_id(resp), "raw": resp}

    def get_position(self, symbol: str):
        """Read open position(s); returns a domain Position or None."""
        resp = self._signed_request(
            "GET", "/api/v1/private/position/open_positions", params={"symbol": symbol})
        data = resp.get("data") or []
        if isinstance(data, dict):
            data = data.get("data") or []
        for p in data:
            if p.get("symbol") == symbol:
                return self._position_from_row(p)
        return None

    def get_open_positions(self) -> list:
        """All open positions across symbols (used by the dashboard account poll).

        MEXC ``/api/v1/private/position/open_positions`` returns a list of position
        rows; convert each into a domain ``Position``.
        """
        resp = self._signed_request("GET", "/api/v1/private/position/open_positions")
        data = resp.get("data") or []
        if isinstance(data, dict):
            data = data.get("data") or []
        out = []
        for p in data:
            if not isinstance(p, dict):
                continue
            sym = p.get("symbol", "")
            if not sym:
                continue
            out.append(self._position_from_row(p))
        return out

    def get_balance(self) -> dict:
        """Account equity/available across assets (used by the dashboard poll).

        Uses the unified ``/api/v1/private/account/assets`` endpoint (verified
        working; returns per-currency rows with equity/available). Sums to a single
        USDT-denominated figure for the UI.
        """
        resp = self._signed_request("GET", "/api/v1/private/account/assets")
        data = resp.get("data") or []
        if isinstance(data, dict):
            data = data.get("data") or []
        equity = 0.0
        available = 0.0
        for a in data:
            if not isinstance(a, dict):
                continue
            try:
                # MEXC futures account rows use `equity` and `availableBalance`
                # (also `availableOpen` = margin free to open new positions).
                equity += float(a.get("equity") or 0.0)
                available += float(a.get("availableBalance") or a.get("available") or 0.0)
            except (TypeError, ValueError):
                continue
        return {"equity": equity, "available": available, "currency": "USDT"}

    def get_mark(self, symbol: str) -> float:
        """Latest mark/last price for a symbol (used for sizing + time-exit).

        MEXC's ``/contract/detail`` does NOT include a live price; the tradable
        last price lives in ``/contract/ticker`` (public, no auth)."""
        try:
            resp = self._client.get(
                f"{self.base_url}/api/v1/contract/ticker",
                params={"symbol": symbol}, timeout=self._timeout)
            if resp.status_code == 200:
                j = resp.json()
                data = j.get("data") or {}
                last = data.get("lastPrice") or data.get("markPrice") or data.get("last")
                if last is not None:
                    return float(last)
        except Exception:  # noqa: BLE001
            return 0.0
        return 0.0

    # ---- helpers ----
    @staticmethod
    def _order_id(resp: dict) -> str:
        data = resp.get("data") or {}
        return str(data.get("orderId") or data.get("order_id") or "")

    @staticmethod
    def _position_from_row(p: dict) -> "Position":
        from domain.model import Direction
        ptype = int(p.get("positionType", 1))     # 1=long, 2=short (MEXC)
        direction = Direction.LONG if ptype == 1 else Direction.SHORT
        return Position(
            symbol=p.get("symbol", ""),
            direction=direction,
            size=float(p.get("holdVol", 0.0)),
            entry=float(p.get("openPrice", 0.0)),
            leverage=int(float(p.get("leverage", 1))),
            liq_price=float(p.get("liquidatePrice", 0.0)),
            mark=float(p.get("markPrice", 0.0) or 0.0),
            pnl=float(p.get("unrealizedPNL", 0.0)),
            fee=0.0,
            margin=float(p.get("margin", 0.0)),
            status="OPEN",
        )


class FakeMexcExchange(MexcExchange):
    """No-network twin. Overrides the network boundary; cache works off presets."""
    def __init__(self, api_key: str = "k", secret: str = "s") -> None:
        super().__init__(api_key, secret)
        self._client = None  # type: ignore

    def _signed_request(self, method: str, path: str, params=None, body=None) -> dict:
        # Fake always returns a success envelope; tests assert on rounding/validation
        return {"success": True, "code": 0, "data": {}}

    def get_open_positions(self) -> list:
        # No open positions in fake mode (dashboard REST backfill returns empty).
        return []

    def get_balance(self) -> dict:
        return {"equity": 1000.0, "available": 995.0, "currency": "USDT"}
