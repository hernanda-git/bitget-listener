"""LLM brain: OpenAI-compatible client (deepseek-v4-flash-free via OpenCode).

Vision: chart image attachments from @fattyfatclub are sent as image_url content
parts. Text parser resolves ambiguous/conditional signals into a structured
TradeDecision (JSON). Deterministic JSON parse; no LLM fallback for trades (the
reliability rule: never let the LLM silently author/repair orders).

CONCRETE-SPEC: LLM brain ON, vision + text, collect ALL data.
"""
from __future__ import annotations

import json
from typing import Optional, Protocol


class LLMClient(Protocol):
    def chat(self, messages: list, model: str, max_tokens: int,
             temperature: float) -> str: ...


_SYSTEM = (
    "You are a crypto futures signal interpreter for @fattyfatclub. Given the "
    "channel text (and any chart image), output STRICT JSON: "
    '{"action":"ENTER|CONDITIONAL|SKIP|MANAGEMENT","pair":"TOKENUSDT",'
    '"direction":"LONG|SHORT","entry":float|null,"sl":float|null,'
    '"tps":[float],"leverage":int|null,"confidence_pct":0-100,"bias":"...",'
    '"reason":"..."}. Resolve ambiguous/conditional calls. Never invent pairs not '
    "mentioned. If no actionable trade, action=SKIP."
)


def build_messages(raw) -> list:
    content = [{"type": "text", "text": raw.text}]
    for img in raw.images:
        content.append({"type": "image_url",
                        "image_url": {"url": f"data:image/png;base64,{img!r}"}})
    return [
        {"role": "system", "content": _SYSTEM},
        {"role": "user", "content": content},
    ]


class LLMBrain:
    def __init__(self, client: LLMClient, model: str = "deepseek-v4-flash-free",
                 max_tokens: int = 1024, temperature: float = 0.0) -> None:
        self.client = client
        self.model = model
        self.max_tokens = max_tokens
        self.temperature = temperature

    def decide(self, raw) -> "object":
        from domain.model import TradeDecision, Action, Direction
        msgs = build_messages(raw)
        reply = self.client.chat(msgs, self.model, self.max_tokens, self.temperature)
        data = json.loads(reply)
        return TradeDecision(
            action=Action(data.get("action", "SKIP")),
            pair=data.get("pair", ""),
            direction=(Direction(data["direction"]) if data.get("direction") else None),
            entry=data.get("entry"),
            sl=data.get("sl"),
            tps=tuple(data.get("tps", []) or []),
            leverage=data.get("leverage"),
            confidence_pct=float(data.get("confidence_pct", 0.0)),
            bias=data.get("bias", ""),
            reason=data.get("reason", ""),
        )


class FakeLLM:
    def __init__(self, json_reply: str) -> None:
        self.json_reply = json_reply
        self.calls = 0
    def chat(self, messages, model, max_tokens, temperature) -> str:
        self.calls += 1
        return self.json_reply
