"""Item 3 — Live OpenCode LLM client (OpenAI-compatible, TDD).

Implements the ``LLMClient`` Protocol used by ``LLMBrain`` (src/llm/brain.py):
    chat(messages, model, max_tokens, temperature) -> str
against an OpenAI-compatible endpoint (LLM_BASE_URL / LLM_API_KEY /
LLM_MODEL=deepseek-v4-flash-free) via plain ``httpx`` (already a dependency,
no heavy openai SDK needed).

The LLM only *decides* (returns JSON); it never fixes an order (DESIGN §7).

HANDOFF-CONTINUE "Next items" #3; DOCUMENTATION.md §2 item 3.
"""
from __future__ import annotations

import json
import os
from typing import Optional

import httpx


class OpenCodeLLM:
    """OpenAI-compatible chat client for OpenCode (deepseek-v4-flash-free)."""

    def __init__(self, base_url: Optional[str] = None, api_key: Optional[str] = None,
                 model: Optional[str] = None, timeout: float = 30.0,
                 client: Optional[httpx.Client] = None) -> None:
        self.base_url = (base_url or os.getenv("LLM_BASE_URL", "")).rstrip("/")
        self.api_key = api_key if api_key is not None else os.getenv("LLM_API_KEY", "")
        self.model = model or os.getenv("LLM_MODEL", "deepseek-v4-flash-free")
        self.timeout = timeout
        self._client = client

    def _http(self) -> httpx.Client:
        if self._client is not None:
            return self._client
        return httpx.Client(timeout=self.timeout)

    def chat(self, messages: list, model: str, max_tokens: int,
             temperature: float) -> str:
        if not self.base_url:
            raise RuntimeError("LLM_BASE_URL not configured")
        url = f"{self.base_url}/chat/completions"
        headers = {"Authorization": f"Bearer {self.api_key}",
                   "Content-Type": "application/json"}
        payload = {
            "model": model or self.model,
            "messages": messages,
            "max_tokens": max_tokens,
            "temperature": temperature,
        }
        client = self._http()
        try:
            resp = client.post(url, headers=headers, json=payload)
            resp.raise_for_status()
            data = resp.json()
            return data["choices"][0]["message"]["content"]
        finally:
            if self._client is None:
                client.close()


def build_llm_client() -> OpenCodeLLM:
    """Construct from env (LLM_BASE_URL/LLM_API_KEY/LLM_MODEL)."""
    return OpenCodeLLM()
