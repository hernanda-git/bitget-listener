"""ShadowLedger (Edge B): per-pair signal win-rate. Reports + flags weak pairs;
auto-downsizes only when auto_downsize=True (behind config flag, user-confirmed).

CONCRETE-SPEC §9.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


class EvalStore:
    def record(self, pair: str, win: bool): raise NotImplementedError
    def get(self, pair: str): raise NotImplementedError


@dataclass
class Rating:
    pair: str
    trades: int
    wins: int
    losses: int
    winrate: float
    flag: bool


class ShadowLedger:
    def __init__(self, store: EvalStore, min_trades: int = 30,
                 poor_winrate: float = 0.50, auto_downsize: bool = False,
                 downsize_factor: float = 0.5) -> None:
        self.store = store
        self.min_trades = min_trades
        self.poor_winrate = poor_winrate
        self.auto_downsize = auto_downsize
        self.downsize_factor = downsize_factor

    def record(self, pair: str, win: bool) -> None:
        self.store.record(pair, win)

    def rating(self, pair: str) -> Rating:
        outcomes = self.store.get(pair)
        trades = len(outcomes)
        wins = sum(1 for o in outcomes if o)
        losses = trades - wins
        winrate = (wins / trades) if trades else 0.0
        trusted = trades >= self.min_trades
        flag = trusted and winrate < self.poor_winrate
        return Rating(pair, trades, wins, losses, winrate, flag)

    def size_multiplier(self, pair: str) -> float:
        if not self.auto_downsize:
            return 1.0
        r = self.rating(pair)
        return self.downsize_factor if r.flag else 1.0
