"""Safety gates (Gate1 pre-LLM, Gate2 post-LLM). Deterministic, no LLM.

CONCRETE-SPEC §3. See crypto-auto-trader-reliability for the gate philosophy.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional


@dataclass
class RiskConfig:
    risk_per_trade_usd: float = 1.0      # SL-distance risk budget (margin ~ notional/leverage)
    max_position_usd: float = 6.0        # keep notional small (~$1.2 margin @5x) to fit balance
    max_concurrent: int = 1
    max_daily_loss_pct: float = 30.0
    max_leverage: int = 20
    default_leverage: int = 5          # user default: $1 margin x 5x = $5 notional (MEXC floor)
    margin_type: str = "isolated"      # "isolated" (openType 2) | "cross" (openType 1)
    min_notional_usd: float = 5.0
    cooldown_s: int = 30
    whitelist_only: bool = True
    whitelist: set = field(default_factory=set)


@dataclass
class GateResult:
    ok: bool
    reason: str = ""
    leverage: Optional[int] = None
    size_usd: Optional[float] = None


# leverage snap ladder (MEXC)
_LEV_LADDER = [1, 2, 3, 5, 7, 10, 15, 20, 25, 30, 50, 75, 100, 125]


def _snap_leverage(needed: int) -> int:
    for v in _LEV_LADDER:
        if v >= needed:
            return v
    return _LEV_LADDER[-1]


class Gate1:
    """Pre-LLM: idempotency (message_id), per-pair cooldown, whitelist."""
    def __init__(self, cfg: RiskConfig, now: callable = None) -> None:
        self.cfg = cfg
        self._now = now or __import__("time").time
        self._seen: set[int] = set()
        self._last_pair_ts: dict[str, float] = {}

    def check(self, message_id: int, pair: str, ts: Optional[int] = None) -> GateResult:
        if message_id in self._seen:
            return GateResult(False, "duplicate message_id")
        self._seen.add(message_id)
        if self.cfg.whitelist_only and pair not in self.cfg.whitelist:
            return GateResult(False, f"pair {pair} not whitelisted")
        now = (ts if ts is not None else self._now())
        last = self._last_pair_ts.get(pair)
        if last is not None and (now - last) < self.cfg.cooldown_s:
            return GateResult(False, f"cooldown active for {pair}")
        self._last_pair_ts[pair] = now
        return GateResult(True)


class Gate2:
    """Post-LLM: fee-aware size, leverage snap+clamp, SL direction, min-notional,
    concurrent, daily-loss kill switch."""
    def __init__(self, cfg: RiskConfig) -> None:
        self.cfg = cfg

    def check(self, decision: dict, open_positions: int,
              daily_loss_pct: float) -> GateResult:
        pair = decision["pair"]
        direction = decision.get("direction", "LONG").upper()
        entry = float(decision.get("entry") or 0.0)
        sl = decision.get("sl")
        lev_req = int(decision.get("leverage") or self.cfg.max_leverage)
        price = float(decision.get("price") or entry)
        pair_max = int(decision.get("pair_max_leverage") or self.cfg.max_leverage)

        if daily_loss_pct >= self.cfg.max_daily_loss_pct:
            return GateResult(False, f"daily loss {daily_loss_pct:.1f}% >= kill switch")
        if open_positions >= self.cfg.max_concurrent:
            return GateResult(False, f"concurrent {open_positions} >= {self.cfg.max_concurrent}")
        if sl is not None:
            sl = float(sl)
            if direction == "LONG" and sl >= entry:
                return GateResult(False, "SL above entry for LONG")
            if direction == "SHORT" and sl <= entry:
                return GateResult(False, "SL below entry for SHORT")

        # leverage: snap up, clamp to config + pair max
        needed = _snap_leverage(lev_req)
        eff = min(needed, self.cfg.max_leverage, pair_max)

        # fixed-risk size: distance entry->SL defines risk per unit
        if sl is not None and entry > 0 and sl != entry:
            risk_per_unit = abs(entry - sl)
            size_units = self.cfg.risk_per_trade_usd / risk_per_unit
            size_usd = size_units * price
        else:
            size_usd = self.cfg.risk_per_trade_usd  # fallback floor
        if size_usd > self.cfg.max_position_usd:
            size_usd = self.cfg.max_position_usd
        if size_usd < self.cfg.min_notional_usd:
            return GateResult(False, f"size {size_usd:.2f} < min_notional")
        return GateResult(True, "", leverage=eff, size_usd=size_usd)
