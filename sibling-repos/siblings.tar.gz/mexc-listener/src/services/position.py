"""PositionManager: WS-synced lifecycle, self-heal SL/TP, orphan detect, 48h exit,
reconcile resting LIMIT that fills late. No LLM.

CONCRETE-SPEC §7. Mirrors learnernoearner fixes: resting-limit-reconcile (XPLUSDT),
48h time-exit, self-heal missing protective orders.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Optional

from domain.model import OrderRequest, Side


@dataclass
class PositionRow:
    symbol: str
    direction: str
    size: float
    entry: float
    leverage: int
    liq_price: float
    status: str = "OPEN"
    opened_at: int = 0
    has_sl: bool = False
    has_tp: bool = False


class PositionStore:
    def create(self, row: PositionRow): raise NotImplementedError
    def get_open_by_pair(self, symbol): raise NotImplementedError
    def update_status(self, symbol, status): raise NotImplementedError
    def create_order(self, order_id, symbol, side, status="PENDING"): raise NotImplementedError
    def get_order(self, order_id): raise NotImplementedError


class PositionManager:
    """WS-synced lifecycle. Paper-safe: when ``paper`` is True, no real orders
    are placed (protection/SL/TP self-heal becomes a no-op) — mirrors the
    OrderService hard gate so PAPER is enforced in code, not just a UI label.
    """

    def __init__(self, exchange, store: PositionStore,
                 time_exit_hours: int = 48, paper: bool = True) -> None:
        self.ex = exchange
        self.store = store
        self.time_exit_hours = time_exit_hours
        self.paper = paper
        self._protection_placed: set[str] = set()

    def _place(self, req: "OrderRequest") -> None:
        if self.paper:
            return  # simulate: never touch the real exchange
        self.ex.place_order(req)

    def reconcile_pending_orders(self) -> list[str]:
        """Top of monitor loop: any PENDING entry order that FILLED late builds a
        Position + attaches SL/TP. Idempotent."""
        created = []
        for oid, o in list(self.ex.orders.items()) if hasattr(self.ex, "orders") else []:
            if o.get("status") != "FILLED":
                continue
            sym = o["symbol"]
            if self.store.get_open_by_pair(sym) is not None:
                continue  # idempotent: already have a position
            # build position from the late fill
            row = PositionRow(symbol=sym, direction=o.get("direction", "LONG"),
                              size=o.get("size", 0.001), entry=o.get("entry", 0.0),
                              leverage=o.get("leverage", 10), liq_price=o.get("liq_price", 0.0),
                              status="OPEN", opened_at=int(time.time()))
            self.store.create(row)
            # attach SL/TP (self-heal) — same as enter()
            self._place_protection(sym, sl_price=o.get("sl", 0.0), tps=o.get("tps", ()))
            created.append(sym)
        return created

    def _place_protection(self, symbol: str, sl_price: float, tps: tuple):
        if symbol in self._protection_placed:
            return
        if sl_price:
            self._place(OrderRequest(symbol=symbol, side=Side.SELL, price=sl_price,
                qty=0.001, order_type="STOP", reduce_only=True, stop_price=sl_price,
                time_in_force="GTC"))
        for tp in tps:
            self._place(OrderRequest(symbol=symbol, side=Side.SELL, price=tp,
                qty=0.001, order_type="TAKE_PROFIT", reduce_only=True, stop_price=tp,
                time_in_force="GTC"))
        self._protection_placed.add(symbol)

    def time_exit_check(self, now: Optional[int] = None) -> list[str]:
        now = now or int(time.time())
        closed = []
        for sym, row in self.store.rows.items():
            if row.status != "OPEN":
                continue
            if now - row.opened_at >= self.time_exit_hours * 3600:
                self.store.update_status(sym, "CLOSED")
                closed.append(sym)
        return closed

    def self_heal_protection(self, symbol: str, sl_price: float, tps: tuple = ()):
        row = self.store.get_open_by_pair(symbol)
        if row is None:
            return
        if not row.has_sl and sl_price:
            self._place(OrderRequest(symbol=symbol, side=Side.SELL, price=sl_price,
                qty=row.size, order_type="STOP", reduce_only=True, stop_price=sl_price,
                time_in_force="GTC"))
            row.has_sl = True
        if tps and not row.has_tp:
            for tp in tps:
                self._place(OrderRequest(symbol=symbol, side=Side.SELL, price=tp,
                    qty=row.size, order_type="TAKE_PROFIT", reduce_only=True, stop_price=tp,
                    time_in_force="GTC"))
            row.has_tp = True
