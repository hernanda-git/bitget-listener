"""Fixed-risk position sizer, fee-aware (single-source fee model).

CONCRETE-SPEC §4. net = gross - (open_fee + close_fee).
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass
class FeeModel:
    maker: float = 0.0002
    taker: float = 0.0005

    def open_fee(self, qty: float, price: float) -> float:
        return qty * price * self.taker

    def close_fee(self, qty: float, price: float) -> float:
        return qty * price * self.taker

    def net(self, gross_usd: float, qty: float, price: float) -> float:
        return gross_usd - self.open_fee(qty, price) - self.close_fee(qty, price)


class FixedRiskSizer:
    def __init__(self, risk_per_trade_usd: float, fees: FeeModel,
                 max_position_usd: float = 100.0, min_notional_usd: float = 5.0) -> None:
        self.risk_per_trade_usd = risk_per_trade_usd
        self.fees = fees
        self.max_position_usd = max_position_usd
        self.min_notional_usd = min_notional_usd

    def size(self, pair: str, entry: float, sl: float, price: float,
             leverage: int) -> float:
        if entry <= 0 or price <= 0:
            raise ValueError("entry/price must be > 0")
        distance = abs(entry - sl)
        if distance <= 0:
            raise ValueError("SL distance must be > 0")
        raw_units = self.risk_per_trade_usd / distance
        notional = raw_units * price
        if notional > self.max_position_usd:
            raw_units = self.max_position_usd / price
        # Enforce MEXC minimum order notional so the order is always valid/tradable.
        if raw_units * price < self.min_notional_usd:
            raw_units = self.min_notional_usd / price
        return raw_units
