"""OrderService: entry + protective SL/TP with reduce_only, idempotent dedup,
never auto-cancel protective. Deterministic repair on reject (no LLM).

CONCRETE-SPEC §6, crypto-auto-trader-reliability #4/#8/#11.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Optional

from domain.model import OrderRequest, Side
from exchanges.repair import IdempotencyGuard


@dataclass
class OrderResult:
    ok: bool
    status: str = ""
    order_ids: tuple = ()


class OrderService:
    """Entry + protective SL/TP. Paper-safe by construction: when ``paper`` is
    True, no real order is ever placed — ``enter``/``modify_sl_to_entry`` return
    simulated results. This is the hard safety gate: the dashboard's "PAPER"
    badge alone must never be trusted to prevent live fills.
    """

    def __init__(self, exchange, guard: IdempotencyGuard, paper: bool = True,
                 bus=None, margin_type: str = "isolated") -> None:
        self.ex = exchange
        self.guard = guard
        self.paper = paper
        self.bus = bus
        self.margin_type = margin_type  # "isolated" | "cross" (live-adjustable)

    def _emit(self, payload: dict) -> None:
        if self.bus is not None:
            try:
                self.bus.publish({"type": "paper_order", "data": payload})
            except Exception:  # noqa: BLE001
                pass

    def enter(self, decision_id: str, pair: str, side: str, price: float,
              qty: float, leverage: int, sl: Optional[float],
              tps: tuple[float, ...] = (), order_type: str = "LIMIT") -> OrderResult:
        dedupe = self.guard.check(decision_id, Side.BUY if side == "BUY" else Side.SELL)
        if dedupe.skipped:
            return OrderResult(False, dedupe.status)
        if self.paper:
            # Simulated fill — no network, no real order. Deterministic fake IDs.
            ids = [f"PAPER-{decision_id}-E"]
            if sl is not None:
                ids.append(f"PAPER-{decision_id}-SL")
            for i in range(len(tps)):
                ids.append(f"PAPER-{decision_id}-TP{i+1}")
            self._emit({"decision_id": decision_id, "pair": pair, "side": side,
                        "price": price, "qty": qty, "leverage": leverage,
                        "sl": sl, "tps": list(tps), "status": "PAPER_ENTERED"})
            return OrderResult(True, "PAPER_ENTERED", tuple(ids))
        placed = []
        # entry (opening) — LIMIT or MARKET (MARKET needs no price)
        entry = OrderRequest(symbol=pair, side=Side.BUY if side.upper() == "BUY" else Side.SELL,
                             price=price or 0.0, qty=qty,
                             order_type="MARKET" if order_type == "MARKET" else "LIMIT",
                             reduce_only=False,
                             client_order_id=f"{decision_id}-E",
                             leverage=leverage, margin_type=self.margin_type)
        placed.append(self.ex.place_order(entry))
        # protective SL/TP as conditional reduce_only (STOP / TAKE_PROFIT)
        if sl is not None:
            sl_req = OrderRequest(symbol=pair, side=Side.SELL if side.upper() == "BUY" else Side.BUY,
                                  price=sl, qty=qty, order_type="STOP", reduce_only=True,
                                  stop_price=sl, time_in_force="GTC",
                                  client_order_id=f"{decision_id}-SL")
            placed.append(self.ex.place_order(sl_req))
        for i, tp in enumerate(tps, 1):
            tp_req = OrderRequest(symbol=pair, side=Side.SELL if side.upper() == "BUY" else Side.BUY,
                                  price=tp, qty=qty, order_type="TAKE_PROFIT", reduce_only=True,
                                  stop_price=tp, time_in_force="GTC",
                                  client_order_id=f"{decision_id}-TP{i}")
            placed.append(self.ex.place_order(tp_req))
        return OrderResult(True, "ENTERED", tuple(p.get("order_id") for p in placed))

    def modify_sl_to_entry(self, pair: str, new_sl: float) -> OrderResult:
        if self.paper:
            self._emit({"pair": pair, "new_sl": new_sl, "status": "PAPER_SL_MOVED"})
            return OrderResult(True, "PAPER_SL_MOVED")
        # Move SL to entry: place a NEW protective SL at new_sl. The OLD protective
        # SL is intentionally NOT canceled (never auto-cancel reduce_only protective).
        req = OrderRequest(symbol=pair, side=Side.SELL, price=new_sl, qty=0.0,
                          order_type="STOP", reduce_only=True, stop_price=new_sl,
                          time_in_force="GTC", client_order_id=f"{pair}-SL-MOVE")
        self.ex.place_order(req)
        return OrderResult(True, "SL_MOVED")
