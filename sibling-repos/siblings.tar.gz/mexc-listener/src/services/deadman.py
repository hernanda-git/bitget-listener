"""Dead-man's-switch watchdog (MEXC has no native scheduleCancel).

Fires on_stale() only in LIVE mode after heartbeat TTL lapses. Paper mode never
fires (no real orders to cancel).
"""
from __future__ import annotations

from typing import Callable, Optional


class DeadManWatchdog:
    def __init__(self, ttl_s: int = 60, on_stale: Optional[Callable[[], None]] = None,
                 live: bool = False) -> None:
        self.ttl_s = ttl_s
        self.on_stale = on_stale
        self.live = live
        self._last_beat = 0.0

    def beat(self, now: Optional[float] = None) -> None:
        import time as _t
        self._last_beat = now if now is not None else _t.time()

    def check(self, now: Optional[float] = None) -> bool:
        import time as _t
        now = now if now is not None else _t.time()
        if self._last_beat == 0.0:
            return False
        if now - self._last_beat >= self.ttl_s:
            if self.live and self.on_stale:
                self.on_stale()
            return self.live  # only report "stale fired" in live mode
        return False
