"""Fee-aware trades_log writer for mexc-listener (Item 1, TDD).

``Ledger.write`` inserts a trade into the shared ``trades_log`` table, including
the REAL fill fee, close fee, and liquidation price (DESIGN §3 rule "record real
fee + real liquidation price on every fill/position"; CONCRETE-SPEC §4).

``init_ledger_schema`` idempotently ALTERs the shared ``trades_log`` to add the
nullable ``fee``, ``close_fee`` and ``liq_price`` columns (they don't exist on
the sibling-shared table yet). Runs only when a real DB connection is present.

All methods take an injected ``conn`` (psycopg connection or a fake that records
SQL+params) so the unit suite stays network-free.

HANDOFF-CONTINUE "Next items" #1 / #7; DOCUMENTATION.md §2 item 1.
"""
from __future__ import annotations


class Ledger:
    """Writes completed trades into ``trades_log`` with fee/liq columns."""

    def __init__(self, conn) -> None:
        self.conn = conn

    def write(self, row: dict) -> None:
        """Insert one trade row. ``row`` keys map 1:1 to trades_log columns;
        the three fee/liq keys (fee, close_fee, liq_price) are required by the
        new schema but tolerated as missing (default 0.0 / None)."""
        sql = """INSERT INTO trades_log
                 (ts_open, iso_open, ts_close, iso_close, bot, symbol, side,
                  entry, exit_px, size, lev, sl, tp, margin, pnl,
                  close_reason, dry, source_msg_id, fee, close_fee, liq_price)
                 VALUES
                 (%(ts_open)s, %(iso_open)s, %(ts_close)s, %(iso_close)s,
                  %(bot)s, %(symbol)s, %(side)s, %(entry)s, %(exit_px)s,
                  %(size)s, %(lev)s, %(sl)s, %(tp)s, %(margin)s, %(pnl)s,
                  %(close_reason)s, %(dry)s, %(source_msg_id)s,
                  %(fee)s, %(close_fee)s, %(liq_price)s)"""
        params = {
            "ts_open": row.get("ts_open"),
            "iso_open": row.get("iso_open", ""),
            "ts_close": row.get("ts_close"),
            "iso_close": row.get("iso_close", ""),
            "bot": row.get("bot", ""),
            "symbol": row.get("symbol", ""),
            "side": row.get("side", ""),
            "entry": row.get("entry"),
            "exit_px": row.get("exit_px"),
            "size": row.get("size"),
            "lev": row.get("lev"),
            "sl": row.get("sl"),
            "tp": row.get("tp"),
            "margin": row.get("margin"),
            "pnl": row.get("pnl"),
            "close_reason": row.get("close_reason", ""),
            "dry": bool(row.get("dry", False)),
            "source_msg_id": row.get("source_msg_id"),
            "fee": row.get("fee", 0.0),
            "close_fee": row.get("close_fee", 0.0),
            "liq_price": row.get("liq_price"),
        }
        self.conn.execute(sql, params)
        self.conn.commit()


def init_ledger_schema(conn) -> None:
    """Idempotently add fee/liq columns to the shared trades_log table."""
    alters = [
        "ALTER TABLE trades_log ADD COLUMN IF NOT EXISTS fee double precision",
        "ALTER TABLE trades_log ADD COLUMN IF NOT EXISTS close_fee double precision",
        "ALTER TABLE trades_log ADD COLUMN IF NOT EXISTS liq_price double precision",
    ]
    for sql in alters:
        conn.execute(sql)
    conn.commit()
