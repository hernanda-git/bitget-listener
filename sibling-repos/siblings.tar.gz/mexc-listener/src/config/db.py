"""Postgres-backed ConfigStore family for mexc-listener (Item 1, TDD).

Implements the four abstract stores against the shared ``fatty_config`` DB used
by the bybit/hyperliquid siblings:

- GoLiveStore   -> ``bots`` (paper bool) + new ``mexc_golive`` (one-time token)
- DecisionStore -> new ``mexc_decisions`` (decision_id PK, client_order_id, side)
- PositionStore -> new ``mexc_positions`` (symbol PK) + ``mexc_orders``
- EvalStore     -> new ``mexc_eval`` (pair PK, wins/losses)

Stores ENV-VAR NAMES only, never secrets (DOCUMENTATION §5 / DESIGN §8).

Design note: ``GoLiveStore.get(bot)`` and ``EvalStore.get(pair)`` both declare a
``get`` with different signatures, so a single 4-in-1 object cannot satisfy both
without ambiguity. We therefore expose one adapter class per abstract base, all
sharing the ``ConfigStore`` connection base (SOLID: each adapter implements
exactly one contract, matching the existing in-memory fakes which are also
separate instances in ``main.build_container``).

All methods take an injected ``conn`` (a psycopg connection or a fake that
records SQL+params and simulates fetch) so the unit suite stays network-free.

CONCRETE-SPEC §2/§4/§5; HANDOFF-CONTINUE "Next items" #1.
"""
from __future__ import annotations

from typing import Optional

from notifier.bot import GoLiveStore
from exchanges.repair import DecisionStore
from services.position import PositionStore, PositionRow
from eval.shadow_ledger import EvalStore


class ConfigStore:
    """Shared Postgres connection base for the store adapters."""

    def __init__(self, conn) -> None:
        self.conn = conn

    def _exec(self, sql: str, params: Optional[dict] = None):
        return self.conn.execute(sql, params or {})


class PgGoLiveStore(GoLiveStore, ConfigStore):
    """GoLiveStore backed by ``bots`` + ``mexc_golive``."""

    def get(self, bot: str):
        cur = self._exec(
            """SELECT b.paper, g.go_live_token
                 FROM bots b
                 LEFT JOIN mexc_golive g ON g.bot = b.name
                WHERE b.name = %(b)s""",
            {"b": bot},
        )
        row = cur.fetchone()
        if row is None:
            return {}
        return {"paper": bool(row[0]), "go_live_token": row[1]}

    def set_paper(self, bot: str, val: int) -> None:
        self._exec(
            "UPDATE bots SET paper = %(v)s WHERE name = %(b)s",
            {"v": bool(int(val)), "b": bot},
        )
        self.conn.commit()

    def set_token(self, bot: str, tok: Optional[str]) -> None:
        self._exec(
            """INSERT INTO mexc_golive (bot, go_live_token)
               VALUES (%(b)s, %(t)s)
               ON CONFLICT (bot) DO UPDATE SET go_live_token = %(t)s""",
            {"b": bot, "t": tok},
        )
        self.conn.commit()


class PgDecisionStore(DecisionStore, ConfigStore):
    """DecisionStore backed by ``mexc_decisions``."""

    def mark_client_order_id(self, client_order_id: str) -> bool:
        cur = self._exec(
            "SELECT 1 FROM mexc_decisions WHERE client_order_id = %(c)s",
            {"c": client_order_id},
        )
        if cur.fetchone() is not None:
            return False  # already seen -> dedup
        self._exec(
            """INSERT INTO mexc_decisions (decision_id, client_order_id, status)
               VALUES (%(c)s, %(c)s, 'NEW')""",
            {"c": client_order_id},
        )
        self.conn.commit()
        return True

    def get_active_for_decision(self, decision_id: str, side: str):
        cur = self._exec(
            """SELECT decision_id, side FROM mexc_decisions
                WHERE decision_id = %(id)s AND status = 'ACTIVE'""",
            {"id": decision_id},
        )
        return cur.fetchone()

    def mark_active(self, decision_id: str) -> None:
        self._exec(
            """INSERT INTO mexc_decisions (decision_id, status)
               VALUES (%(id)s, 'ACTIVE')
               ON CONFLICT (decision_id) DO UPDATE SET status = 'ACTIVE'""",
            {"id": decision_id},
        )
        self.conn.commit()


class PgPositionStore(PositionStore, ConfigStore):
    """PositionStore backed by ``mexc_positions`` + ``mexc_orders``."""

    def create(self, row: PositionRow) -> None:
        self._exec(
            """INSERT INTO mexc_positions
               (symbol, direction, size, entry, leverage, liq_price,
                status, opened_at, has_sl, has_tp)
               VALUES (%(symbol)s, %(direction)s, %(size)s, %(entry)s,
                       %(leverage)s, %(liq_price)s, %(status)s,
                       %(opened_at)s, %(has_sl)s, %(has_tp)s)""",
            {
                "symbol": row.symbol, "direction": row.direction, "size": row.size,
                "entry": row.entry, "leverage": row.leverage,
                "liq_price": row.liq_price, "status": row.status,
                "opened_at": row.opened_at, "has_sl": row.has_sl, "has_tp": row.has_tp,
            },
        )
        self.conn.commit()

    def get_open_by_pair(self, symbol):
        cur = self._exec(
            """SELECT symbol, direction, size, entry, leverage, liq_price,
                      status, opened_at, has_sl, has_tp
                 FROM mexc_positions
                WHERE symbol = %(s)s AND status = 'OPEN'""",
            {"s": symbol},
        )
        row = cur.fetchone()
        if row is None:
            return None
        return PositionRow(*row)

    def update_status(self, symbol, status) -> None:
        self._exec(
            "UPDATE mexc_positions SET status = %(st)s WHERE symbol = %(sym)s",
            {"st": status, "sym": symbol},
        )
        self.conn.commit()

    def create_order(self, order_id, symbol, side, status="PENDING") -> None:
        self._exec(
            """INSERT INTO mexc_orders (order_id, symbol, side, status)
               VALUES (%(order_id)s, %(symbol)s, %(side)s, %(status)s)
               ON CONFLICT (order_id) DO NOTHING""",
            {"order_id": order_id, "symbol": symbol, "side": side, "status": status},
        )
        self.conn.commit()

    def get_order(self, order_id):
        cur = self._exec(
            "SELECT order_id, symbol, side, status FROM mexc_orders WHERE order_id = %(o)s",
            {"o": order_id},
        )
        row = cur.fetchone()
        if row is None:
            return None
        if isinstance(row, dict):
            return row
        return dict(zip(("order_id", "symbol", "side", "status"), row))


class PgEvalStore(EvalStore, ConfigStore):
    """EvalStore backed by ``mexc_eval`` (per-pair win/loss counters)."""

    def record(self, pair: str, win: bool) -> None:
        w = 1 if win else 0
        l = 0 if win else 1
        self._exec(
            """INSERT INTO mexc_eval (pair, wins, losses)
               VALUES (%(p)s, %(w)s, %(l)s)
               ON CONFLICT (pair) DO UPDATE
               SET wins = mexc_eval.wins + %(w)s, losses = mexc_eval.losses + %(l)s""",
            {"p": pair, "w": w, "l": l},
        )
        self.conn.commit()

    def get(self, pair: str):
        cur = self._exec(
            "SELECT wins, losses FROM mexc_eval WHERE pair = %(p)s",
            {"p": pair},
        )
        row = cur.fetchone()
        if row is None:
            return []
        wins, losses = int(row[0]), int(row[1])
        return [True] * wins + [False] * losses


def init_config_schema(conn) -> None:
    """Idempotent: create the mexc_* tables (bots/risk already exist)."""
    stmts = [
        """CREATE TABLE IF NOT EXISTS mexc_golive (
               bot text PRIMARY KEY REFERENCES bots(name) ON DELETE CASCADE,
               go_live_token text)""",
        """CREATE TABLE IF NOT EXISTS mexc_decisions (
               decision_id text PRIMARY KEY,
               client_order_id text UNIQUE,
               side text,
               status text NOT NULL DEFAULT 'NEW')""",
        """CREATE TABLE IF NOT EXISTS mexc_positions (
               symbol text PRIMARY KEY,
               direction text,
               size double precision,
               entry double precision,
               leverage integer,
               liq_price double precision,
               status text NOT NULL DEFAULT 'OPEN',
               opened_at bigint,
               has_sl boolean DEFAULT false,
               has_tp boolean DEFAULT false)""",
        """CREATE TABLE IF NOT EXISTS mexc_orders (
               order_id text PRIMARY KEY,
               symbol text,
               side text,
               status text NOT NULL DEFAULT 'PENDING')""",
        """CREATE TABLE IF NOT EXISTS mexc_eval (
               pair text PRIMARY KEY,
               wins integer NOT NULL DEFAULT 0,
               losses integer NOT NULL DEFAULT 0)""",
    ]
    for sql in stmts:
        conn.execute(sql)
    conn.commit()
