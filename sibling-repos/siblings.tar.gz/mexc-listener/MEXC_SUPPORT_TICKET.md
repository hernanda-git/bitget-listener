Subject: URGENT — API Futures order placement blocked (code 6002 / 2009); account futures disabled; no notification received. Please inspect account and re-enable.

Hello MEXC Support,

I am writing because my account cannot place ANY futures (contract/perpetual)
order through the API, even though every prerequisite is satisfied and the
API key clearly has futures access (leverage setting and account reads both
succeed). I have received no email and no in-app message, yet the API returns
errors telling me to "check your email or in-app message" — that message does
not exist. I need your team to inspect my account directly and re-enable API
futures order placement.

============================================================
1. ACCOUNT / API KEY IDENTIFIERS (for your inspection)
============================================================
API Access Key : mx0vglIKfIWXxMjNar
API Secret Key : fc7218eb9a554455b33e7a5bc0102a3f   (32 chars)
Key permissions enabled on this key:
  - Futures (Contract) trading : ENABLED
  - Spot trading               : ENABLED
  - Read only                  : ENABLED
  - Withdrawal                 : DISABLED
API IP whitelist : set to "allow all" (no IP restriction)
Account futures trading : ENABLED in the web UI
KYC level : Advanced KYC COMPLETED
Region used : Indonesia (Jakarta)

============================================================
2. WHAT WORKS (proves the key has full futures API access)
============================================================
A) Set leverage — HTTP 200, success
   POST https://api.mexc.com/api/v1/private/position/change_leverage
   Headers: ApiKey: mx0vglIKfIWXxMjNar, Request-Time: 1786819513009
   Body: {"symbol":"BTC_USDT","leverage":10,"openType":2,"positionType":2}
   Response: {"success":true,"code":0}

B) Account assets read — HTTP 200, success
   GET https://api.mexc.com/api/v1/private/account/assets
   Response: {"success":true,"code":0,"data":[...]}   (returns balances)

C) Ticker / market data — works (public + private reads all OK)

============================================================
3. WHAT FAILS (order PLACEMENT only)
============================================================
Request (captured live, verbatim):
   POST https://api.mexc.com/api/v1/private/order/create
   ApiKey: mx0vglIKfIWXxMjNar
   Request-Time: 1786819513009
   Signature: db1116913b446848d8c2db50ee94ec4bdcabc954461d0f1349911639f98ecbc2
   Content-Type: application/json
   Body: {"symbol":"BTC_USDT","vol":1,"leverage":10,"side":2,"openType":2,"positionType":2,"type":2,"timeInForce":"GTC","price":63022.5}

HTTP status: 200
Response body: {"success":false,"code":2009,"message":"Position is nonexistent or closed"}

When the same order is submitted with an alternative (market) field encoding,
the exchange instead returns:
   {"success":false,"code":6002,"message":"Your futures position-opening has been restricted. Please check your email or in-app message for details."}

Notes:
 - HTTP status is 200 (not 401/403), so authentication + signature are VALID.
 - The request is well-formed per MEXC's contract API spec (integer side,
   vol in contracts, leverage, openType/positionType, type 2 = market).
 - I tested BTC_USDT, ETH_USDT and INJ_USDT — ALL return the same 6002/2009.
 - I also tested through a reference library (ccxt, mexc class) with the same
   key — it gets the identical 6002. So this is NOT a client/signing bug.

============================================================
4. THE CONTRADICTION (why this must be an account-side flag)
============================================================
The error says "check your email or in-app message" — but I have checked both
and there is NO such message. No risk-control notice, no maintenance notice,
no restriction notice exists in my account. The restriction is therefore a
silent account-level disable of API futures order placement that only your
team can see/remove.

============================================================
5. STEPS I HAVE ALREADY TAKEN (to rule out user error)
============================================================
 [x] Completed Advanced KYC verification
 [x] Enabled the Futures permission group on the API key
 [x] Enabled account Futures trading in the web UI
 [x] Set API IP whitelist to allow all (no IP restriction)
 [x] Verified signature/auth (leverage + reads succeed with HTTP 200)
 [x] Tested multiple symbols and multiple request encodings
 [x] Tested via two independent clients (custom code + ccxt reference lib)
 [x] Routed traffic via a non-Jakarta egress to rule out geo-block
     (result: still 6002 — so it is NOT geo; it is account permission)

============================================================
6. REQUEST TO SUPPORT
============================================================
Please:
 1. Inspect my account (Access Key mx0vglIKfIWXxMjNar) and confirm whether
    API futures order placement is disabled/restricted.
 2. If it is disabled, re-enable it.
 3. If a specific action is required on my side (e.g. accept futures trading
    terms in the UI, region confirmation, or a manual unlock), give me the
    EXACT steps — because the API error points to a message I never received.
 4. Confirm once lifting the restriction whether any cooldown applies before
    order/create will succeed.

I am happy to provide any additional logs, signatures, or request/response
captures on request. Thank you for your help.
