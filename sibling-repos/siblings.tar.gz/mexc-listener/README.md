# mexc-listener

MEXC USDⓈ-M Futures signal-execution bot for the `@fattyfatclub` Telegram channel —
the 4th sibling after `bybit-listener`, `hyperliquid-fatty-trader`, and
`learnernoearner-listener`.

**4th-sibling edges:** MEXC token coverage · ShadowLedger per-pair signal win-rate
(self-correcting) · execution rigor (validate/repair/dedup). Plus an **LLM brain**
(OpenCode `deepseek-v4-flash-free`, vision + text), **FastAPI Web UI + WebSocket**
as the primary operator surface, and paper-by-default safety with a 2-step go-live gate.

- 📘 **Full docs & handoff:** [`DOCUMENTATION.md`](DOCUMENTATION.md) — status, what's
  done/pending, and how to continue on the Sera VPS.
- 🏗 Architecture: [`docs/DESIGN.md`](docs/DESIGN.md)
- 🔢 Concrete spec: [`docs/CONCRETE-SPEC.md`](docs/CONCRETE-SPEC.md)
- 🗺 TDD plan: [`.hermes/plans/mexc-listener-plan.md`](.hermes/plans/mexc-listener-plan.md)

**Status:** P0–P3 code-complete; 85 fakes-only tests green; not yet connected to live
MEXC/Telegram/LLM and not go-live. Private repo, branch `mexc-listener-design`.
