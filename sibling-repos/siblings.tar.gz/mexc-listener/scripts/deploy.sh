#!/usr/bin/env bash
# Deploy mexc-listener on the VPS under /opt/bots/mexc-listener.
# Builds venv, installs deps, installs systemd unit, reloads Caddy for :8080 + /ws/events.
set -euo pipefail
APP=/opt/bots/mexc-listener
BRANCH=mexc-listener-design

echo "[1/5] pull latest ($BRANCH)"
git -C "$APP" fetch origin
git -C "$APP" checkout "$BRANCH"
git -C "$APP" pull --ff-only origin "$BRANCH"

echo "[2/5] venv + deps"
"$APP/.venv/Scripts/python" -m pip install -q -e "$APP" || python -m venv "$APP/.venv"
"$APP/.venv/Scripts/python" -m pip install -q -e "$APP"

echo "[3/5] systemd unit"
cp "$APP/systemd/mexc-listener.service" /etc/systemd/system/
systemctl daemon-reload
systemctl enable --now mexc-listener

echo "[4/5] Caddy reverse-proxy (:8080 + /ws/events)"
# Add to /etc/caddy/Caddyfile a block:
#   bot.mexc.example.com {
#     reverse_proxy /ws/events localhost:8080
#     reverse_proxy localhost:8080
#   }
# (edit Caddyfile then: caddy reload)

echo "[5/5] health check"
sleep 3
"$APP/.venv/Scripts/python" -c "import urllib.request,sys; \
print(urllib.request.urlopen('http://localhost:8080/api/health').read()[:80])" || echo "WARN: health check failed"

echo "deploy done. Bot is PAPER unless GoLiveGate flips it."
