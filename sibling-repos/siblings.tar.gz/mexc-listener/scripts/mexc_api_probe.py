"""T0.4 mexc_api_probe.py — verify MEXC reality BEFORE any live order.

Probes, in order, and prints GREEN/RED per check:
  1. REST /contract/detail returns an instrument with tick/lot/minNotional.
     MEXC returns instruments keyed as ``BTC_USDT`` (underscore), not
     ``BTCUSDT`` — the probe detects BTC coverage against the real shape.
  2. WS host reachable + login accepts (no listenKey dance). If the host
     redirects / rejects the handshake, report a *clean* RED with the
     actual reason (redirect target or HTTP status) instead of crashing
     with a misleading ``InvalidURI`` exception.
  3. 1000x / contract-multiplier symbols exist for coverage analysis.

Exit code: 0 if all GREEN (safe to proceed), 1 otherwise.
Run: uv run python scripts/mexc_api_probe.py
(Non-destructive: only reads; places NO real orders.)
"""
from __future__ import annotations

import os
import sys
import json
import asyncio
import time

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from dotenv import load_dotenv
import httpx

load_dotenv()

BASE_URL = os.getenv("MEXC_BASE_URL", "https://api.mexc.com")
# Default now points at the Cloudflare Worker proxy (deployed: mexc-proxy.m-hernanda95.workers.dev)
# which tunnels MEXC REST+WS from a non-ID edge, bypassing the Jakarta geo-block.
# Direct fallback (only works outside ID / via a proxy): wss://contract.mexc.com/edge
WS_URL = os.getenv("MEXC_WS_URL", "wss://mexc-proxy.m-hernanda95.workers.dev/ws")


def check(name: str, ok: bool, detail: str = "") -> bool:
    mark = "GREEN" if ok else "RED"
    print(f"[{mark}] {name}: {detail}")
    return ok


def parse_instruments(data) -> dict:
    """Normalize /contract/detail payload into a coverage report.

    MEXC returns ``data`` as a list of dicts, each with a ``symbol`` field
    shaped like ``BTC_USDT`` (underscore). Accept both the underscore and
    no-separator forms. Tolerate empty / malformed payloads (no crash).
    """
    symbols: list[str] = []
    if isinstance(data, list):
        for d in data:
            if isinstance(d, dict):
                s = d.get("symbol")
                if isinstance(s, str) and s:
                    symbols.append(s)
            # bare strings / malformed entries are ignored (never counted)
    has_btc = any(s.replace("_", "") == "BTCUSDT" for s in symbols)
    has_1000 = any("1000" in s for s in symbols)
    return {"count": len(symbols), "has_btc": has_btc, "has_1000x": has_1000}


def probe_rest_instruments() -> bool:
    try:
        r = httpx.get(f"{BASE_URL}/api/v1/contract/detail", timeout=10)
        info = parse_instruments(r.json().get("data", []))
        return check("REST instruments", info["has_btc"],
                     f"{info['count']} symbols; BTC_USDT={'yes' if info['has_btc'] else 'no'}; "
                     f"1000x={info['has_1000x']}")
    except Exception as e:  # noqa
        return check("REST instruments", False, f"error: {e}")


def classify_ws_error(err: Exception) -> tuple[bool, str]:
    """Turn a WS failure into a clean (ok, detail) pair — never crash."""
    # websockets <13 raises InvalidURI('https://www.mexc.com/404', "scheme...")
    inv = getattr(err, "uri", None)
    if inv:
        return False, f"WS host redirects to {inv} (check MEXC_WS_URL / endpoint)"
    resp = getattr(err, "response", None)
    if resp is not None:
        status = getattr(resp, "status_code", None) or getattr(resp, "status", None)
        loc = None
        hdrs = getattr(resp, "headers", None)
        if hdrs is not None:
            loc = hdrs.get("location")
        tail = f" HTTP {status}" + (f" -> {loc}" if loc else "")
        return False, f"WS handshake rejected{tail}"
    return False, f"WS error: {err}"


async def probe_ws_login() -> bool:
    try:
        import websockets  # noqa
    except Exception as e:  # noqa
        return check("WS host + login channel", False, f"websockets unavailable: {e}")
    # Build a real (read-only) login attempt using the repo's auth so we exercise
    # the same path the bot uses. A successful handshake + rs.login response
    # (success OR auth-failure) proves the WS host is reachable through the proxy.
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
    try:
        from exchanges.mexc_auth import MexcAuth
        from streaming.mexc_ws import build_login
    except Exception as e:  # noqa
        return check("WS host + login channel", False, f"import error: {e}")
    auth = MexcAuth(os.getenv("MEXC_API_KEY", ""), os.getenv("MEXC_SECRET", ""))
    req_time = str(int(time.time() * 1000))
    login = build_login(os.getenv("MEXC_API_KEY", ""), auth.sign("", req_time), req_time)
    try:
        async with websockets.connect(WS_URL, open_timeout=12) as ws:
            await ws.send(json.dumps(login))
            resp = await asyncio.wait_for(ws.recv(), timeout=12)
            try:
                j = json.loads(resp)
                ch = j.get("channel", "")
                if ch in ("rs.login", "rs.error"):
                    # rs.login = authenticated (or bad key); rs.error = host up, bad msg.
                    # Either way the WS path is reachable through the proxy.
                    return check("WS host + login channel", True,
                                 f"WS reachable via {WS_URL} (channel={ch})")
                return check("WS host + login channel", True, f"got: {resp[:80]}")
            except Exception:
                return check("WS host + login channel", True, f"got: {resp[:80]}")
    except Exception as e:  # noqa
        ok, detail = classify_ws_error(e)
        return check("WS host + login channel", ok, detail)


def main() -> int:
    print("=== mexc_api_probe ===")
    results = []
    results.append(probe_rest_instruments())
    try:
        results.append(asyncio.run(probe_ws_login()))
    except Exception as e:  # noqa
        results.append(check("WS login", False, str(e)))
    # KYC / key-expiry note (non-blocking)
    print("[INFO] MEXC futures order permission requires KYC; unbound keys expire 90d.")
    print(f"[INFO] WS url={WS_URL}  REST={BASE_URL}")
    all_ok = all(results)
    print("=== " + ("ALL GREEN — safe to proceed" if all_ok else "NOT READY") + " ===")
    return 0 if all_ok else 1


if __name__ == "__main__":
    sys.exit(main())
