#!/usr/bin/env python3
"""Headless mobile-width UI check for the mexc-listener dashboard.

Loads the live dashboard (default http://127.0.0.1:8080) at 390px width,
asserts there is NO horizontal scroll/overflow, and dumps a few key elements.
Run on Sera: chromium must be in PATH.
"""
import sys, subprocess, json, time

URL = sys.argv[1] if len(sys.argv) > 1 else "http://127.0.0.1:8080"
WIDTH, HEIGHT = 390, 844  # iPhone 12/13/14 viewport

HTML = f"""
const page = await browser.newPage();
await page.setViewport({{ width: {WIDTH}, height: {HEIGHT}, deviceScaleFactor: 2 }});
await page.goto('{URL}', {{ waitUntil: 'networkidle0', timeout: 20000 }});
await new Promise(r => setTimeout(r, 1500));
const docW = await page.evaluate(() => document.documentElement.scrollWidth);
const winW = await page.evaluate(() => window.innerWidth);
const bodyOverflow = await page.evaluate(() => getComputedStyle(document.body).overflowX);
const title = await page.evaluate(() => document.title);
const h1 = await page.evaluate(() => (document.querySelector('h1')||{{}}).innerText || '(no h1)');
await page.screenshot({{ path: '/tmp/dash_mobile.png', fullPage: false }});
console.log(JSON.stringify({{ title, h1, docScrollWidth: docW, windowWidth: winW, bodyOverflowX: bodyOverflow, horizontalOverflow: docW > winW + 1 }}));
"""

NODE = f"""
const {{ chromium }} = require('playwright');
(async () => {{
  const browser = await chromium.launch();
  try {{
    {HTML}
  }} finally {{ await browser.close(); }}
}})().catch(e => {{ console.error('ERR', e.message); process.exit(2); }});
"""

# Use playwright if installed; else fall back to chromium --headless dump.
try:
    import playwright  # noqa
    with open("/tmp/check.js", "w") as f:
        f.write(NODE)
    print(subprocess.run(["node", "/tmp/check.js"], capture_output=True, text=True,
                         cwd="/tmp", timeout=60).stdout.strip())
except Exception as e:
    print("playwright not available:", e)
    # Fallback: chromium headless screenshot + manual overflow heuristic via DOM.
    print(subprocess.run(
        ["chromium", "--headless", "--disable-gpu", "--window-size=390,844",
         f"--virtual-time-budget=4000", f"--screenshot=/tmp/dash_mobile.png",
         URL], capture_output=True, text=True, timeout=60).stderr[-500:])
