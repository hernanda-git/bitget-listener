"""Version bump (kept in sync with pyproject + a VERSION file). No LLM."""
import sys, os, re
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

def bump(part: str = "patch") -> str:
    vf = os.path.join(os.path.dirname(__file__), "..", "VERSION")
    cur = open(vf).read().strip() if os.path.exists(vf) else "0.1.0"
    major, minor, patch = (int(x) for x in cur.split("."))
    if part == "major": major += 1; minor = 0; patch = 0
    elif part == "minor": minor += 1; patch = 0
    else: patch += 1
    nxt = f"{major}.{minor}.{patch}"
    open(vf, "w").write(nxt + "\n")
    return nxt

if __name__ == "__main__":
    print(bump(sys.argv[1] if len(sys.argv) > 1 else "patch"))
