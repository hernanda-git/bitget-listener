#!/usr/bin/env python3
"""Interactive Telegram USER login for mexc-listener (Item 2 bootstrap).

Run ONCE on Sera to generate a Telegram user session. TG_API_ID / TG_API_HASH /
TG_PHONE are already in .env, so this only prompts for the login code (and 2FA
password if enabled). It saves the session to TG_SESSION_DIR/mexc_listener.session
(reused by the runtime TelethonListener) and prints a portable TG_SESSION string.

Telegram login codes expire in ~1-2 min: enter the code promptly.
Nothing here places orders or reads channels — pure auth bootstrap.

Usage:
    .venv/bin/python scripts/tg_login.py
"""
from __future__ import annotations

import os
import sys

try:
    from dotenv import load_dotenv
    load_dotenv()
except Exception:  # noqa: BLE001
    pass


def _need(env_key: str) -> str:
    val = os.getenv(env_key, "")
    if not val:
        print(f"ERROR: {env_key} not set in .env", file=sys.stderr)
        sys.exit(1)
    return val


def main() -> int:
    from telethon import TelegramClient

    api_id = _need("TG_API_ID")
    api_hash = _need("TG_API_HASH")
    phone = _need("TG_PHONE")
    session_dir = os.getenv("TG_SESSION_DIR",
                            "/root/.hermes/cron/output/mexc-listener")
    os.makedirs(session_dir, exist_ok=True)
    session_file = os.path.join(session_dir, "mexc_listener")

    client = TelegramClient(session_file, int(api_id), api_hash)

    async def _run():
        await client.connect()
        if await client.is_user_authorized():
            print("[ok] Already authorized — session valid, nothing to do.")
            return 0

        sent = await client.send_code_request(phone)
        code = input("Enter the login code Telegram sent you: ").strip()
        try:
            await client.sign_in(phone, code,
                                 phone_code_hash=sent.phone_code_hash)
        except Exception as e:  # noqa: BLE001
            if "password" in str(e).lower() or "2fa" in str(e).lower():
                pw = input("2FA password: ").strip()
                await client.sign_in(password=pw)
            else:
                raise

        me = await client.get_me()
        print(f"[ok] Logged in as {me.first_name} (@{me.username}) id={me.id}")

        string_session = client.session.save()
        print("\n--- TG_SESSION string (paste into .env if you want portable) ---")
        print(string_session)
        print("--------------------------------------------------------------------")
        print(f"[ok] Session file written to {session_file}.session")
        return 0

    return client.loop.run_until_complete(_run())


if __name__ == "__main__":
    raise SystemExit(main())
