# mexc-listener — Continuation Handoff (fresh session)

> Self-contained prompt + status for a FRESH session. Paste the block in
> "## COPY-PASTE PROMPT" into a new chat to continue.

## Current state (verified 2026-08-13)
- Repo cloned to `/opt/bots/mexc-listener`, branch `mexc-listener-design` (default).
- `gh` authed as `hernanda-git` with `repo` scope → clone/push works.
- **Suite: 128 fakes-only unit tests + 5 gated real-DB integration tests, ALL GREEN**
  (`uv run pytest tests/ -q`). Items 1–7 code-complete and wired into
  `main.build_container`.
- Commits: `db7b17e` (Item 1) + `7f2bbcb` (Items 2–7), pushed to
  `origin/mexc-listener-design`.
- NOT wired to live MEXC/Telegram/OpenCode. NOT go-live. Paper by default.
- Working tree clean except untracked `uv.lock` (do NOT commit) + this handoff file.

## Two Sera-specific facts (cost debugging time — do NOT rediscover)
- **TERMINAL CRASH**: any command containing a `.venv/bin/python*` path dies with
  `ValueError: embedded null byte` (lifecycle_guard reads the ELF as a script, even
  inside `bash -c`). **USE `uv` INSTEAD**: `uv pip install -e ".[test]"` and
  `uv run pytest tests/ -q` (uv auto-detects `.venv` in cwd, never embeds the venv path).
  ALSO: the `patch` tool refuses `/etc/systemd` AND `/etc/caddy` writes — edit those
  via terminal heredoc/tee or leave for manual edit on the host.
- **POSTGRES**: role `app`, db `fatty_config`, password in `~/.pg_app_pw` (NOT the one
  in `~/.pg_setup_role.sql` — that is a different setup-role pw and fails). Unix-socket
  peer auth FAILS for root; use host:
  `PGPASSWORD=*** ~/.pg_app_pw)" psql -h 127.0.0.1 -U app -d fatty_config`.
  Shared tables: `bots`(paper,channel,tg_bot_token_env[name only]), `trades_log`
  (fee/close_fee/liq_price now ALTERed on via init_ledger_schema), `signals_log`,
  `risk`, `bias_log`, plus NEW `mexc_golive`/`mexc_decisions`/`mexc_positions`/
  `mexc_orders`/`mexc_eval` (created by init_config_schema).

## Items done (details in DOCUMENTATION.md §2 items 1–7)
1. **Postgres ConfigStore** (`src/config/db.py`): `PgGoLiveStore`/`PgDecisionStore`/
   `PgPositionStore`/`PgEvalStore` + `init_config_schema`; **Ledger** (`src/store/ledger.py`)
   fee-aware `trades_log` writer + `init_ledger_schema` (idempotent ALTER). 18 unit +
   5 gated real-DB integration tests (all GREEN vs live `fatty_config`). Wired in
   `build_container` when `CONFIG_DB_URL` set AND `MEXC_FAKE` unset.
2. **Live Telethon listener** (`src/sources/telegram.py`): `SignalRouter` (pure
   ENTER→Gate1→`LLMBrain.decide`→Gate2→`OrderService.enter`; MANAGEMENT fast-path →
   `parse_management` → OrderService transform, no LLM) + `TelethonListener`
   (`events.NewMessage` adapter, image bytes → `RawSignal`). 7 unit tests.
3. **Live OpenCode LLM client** (`src/llm/client.py`): `OpenCodeLLM` implements the
   `LLMClient.chat` Protocol over `httpx` against `LLM_BASE_URL`/`LLM_API_KEY`/
   `LLM_MODEL=deepseek-v4-flash-free`. Wired in `build_container` when `MEXC_FAKE`
   unset AND `LLM_BASE_URL` set; else `FakeLLM`. 3 unit tests.
4. **MEXC order endpoints** (`src/exchanges/mexc.py`): `place_order` (opening LIMIT →
   `/contract/order/open`; protective STOP/TP → `/contract/order/stop`, reduce_only) +
   `close` + `get_position` (real liq_price) + `get_mark`, all over `_signed_request`.
   5 unit tests (fake boundary).
5. **MEXC WS live loop** (`src/streaming/mexc_ws.py`): `connect()` async loop:
   login → `personal.filter` → dispatch; jittered reconnect (capped) + ping/pong
   heartbeat → `on_heartbeat` (dead-man reset). 4 unit tests (FakeWebSocket, no socket).
6. **Notifier Telegram bot commands** (`src/notifier/bot.py`): `CommandHandler` builds
   `/status /balance /positions /live /paper` (MarkdownV2-safe); `cmd_live` enforces
   `GoLiveGate` hard gates; `register_bot` wires to python-telegram-bot v22. 6 unit tests.
7. **ledger + eval snapshots**: folded into Item 1 (PG `trades_log` writer + `mexc_eval`/
   `mexc_decisions` stores wired; in-memory fakes otherwise).

## Probe findings (real run on Sera, 2026-08-13 — DO NOT re-derive, FIX instead)
`uv run python scripts/mexc_api_probe.py` → exit 1 (NOT READY). The bot code is fine;
the PROBE has two bugs giving FALSE RED:
- **[RED] REST instruments**: 1102 symbols returned; `BTCUSDT=no`; `1000x=True`.
  → PROBE BUG: it checks the exact key `BTCUSDT` but MEXC `/contract/detail` nests the
  symbol under a different shape (symbol field casing / list not keyed by symbol). Fix
  the lookup, not the bot.
- **[RED] WS host + login channel**: `https://www.mexc.com/404 isn't a valid URI`.
  → PROBE BUG: it derives the WS URI from a REST 404 response. Correct default is
  `wss://contract.mexc.com/ws` (already the `MEXC_WS_URL` env default). Fix probe to
  use the env default / explicit WS_URL.
- **[INFO]** MEXC futures order permission requires KYC; unbound keys expire 90d.

## COPY-PASTE PROMPT

```
Continue building `mexc-listener` on this machine (Sera VPS).

REPO: /opt/bots/mexc-listener  (branch mexc-listener-design, cloned + checked out)
PRIVATE GITHUB: github.com/hernanda-git/mexc-listener
STATUS: P0–P3 + Items 1–7 DONE. 128 fakes-only unit tests + 5 gated real-DB
integration tests ALL GREEN. Commits: db7b17e (Item 1) + 7f2bbcb (Items 2–7), pushed
to origin/mexc-listener-design.
  - Item 1: Postgres ConfigStore (PgGoLiveStore/PgDecisionStore/PgPositionStore/
    PgEvalStore) + fee-aware Ledger (trades_log fee/close_fee/liq_price ALTER).
  - Item 2: src/sources/telegram.py — SignalRouter (ENTER->Gate1->LLMBrain->Gate2->
    OrderService; MANAGEMENT fast-path) + TelethonListener (events.NewMessage adapter).
  - Item 3: src/llm/client.py — OpenCodeLLM (httpx, LLMClient Protocol); wired in
    build_container when MEXC_FAKE unset AND LLM_BASE_URL set.
  - Item 4: src/exchanges/mexc.py — place_order (open/stop, reduce_only), close,
    get_position (real liq_price), get_mark over _signed_request.
  - Item 5: src/streaming/mexc_ws.py — connect() async loop + jittered reconnect +
    ping/pong heartbeat -> on_heartbeat (dead-man reset).
  - Item 6: src/notifier/bot.py — CommandHandler (/status /balance /positions
    /live /paper, MarkdownV2-safe) + register_bot (python-telegram-bot v22).
  - Item 7: folded into Item 1 (PG ledger + eval stores wired).
NOT wired to live MEXC/Telegram/OpenCode. NOT go-live. Paper by default.

FIRST, READ IN ORDER (source of truth):
1. DOCUMENTATION.md   2. docs/DESIGN.md   3. docs/CONCRETE-SPEC.md
4. .hermes/plans/mexc-listener-plan.md

TWO SERA-SPECIFIC FACTS (already cost debugging time — do not rediscover):
- TERMINAL CRASH: any command containing a `.venv/bin/python*` path dies with
  "embedded null byte" (lifecycle_guard reads the ELF as a script, even inside
  `bash -c`). USE `uv` INSTEAD: `uv pip install -e ".[test]"` and
  `uv run pytest tests/ -q` (uv auto-detects .venv in cwd).
  ALSO: the `patch` tool refuses `/etc/systemd` AND `/etc/caddy` writes — edit those
  via terminal heredoc/tee or leave for manual edit on the host.
- POSTGRES: role `app`, db `fatty_config`, password in `~/.pg_app_pw` (NOT the one
  in `~/.pg_setup_role.sql`). Unix-socket peer auth FAILS for root; use host:
  `PGPASSWORD=*** ~/.pg_app_pw)" psql -h 127.0.0.1 -U app -d fatty_config`.
  Shared tables: bots(paper,channel,tg_bot_token_env), trades_log (fee/close_fee/
  liq_price now ALTERed on), signals_log, risk, bias_log, plus new mexc_golive/
  mexc_decisions/mexc_positions/mexc_orders/mexc_eval (created by init_config_schema).

VERIFY BEFORE BUILDING (stop if red):
  cd /opt/bots/mexc-listener
  uv run pytest tests/ -q   # expect 128 passed + 5 skipped (integration, gated)
If not green, report and stop.

MANDATORY RULES:
- TDD only: failing test FIRST, implement, green, then commit.
- Run FULL suite green before every commit. No commit on red.
- Code > git history > docs. If doc contradicts code, fix the doc.
- No LLM fallback for trades. Repair deterministic (src/exchanges/repair.py).
  LLM only DECIDES (src/llm/brain.py), never fixes an order.
- Never auto-cancel reduce_only protective SL/TP.
- Paper by default. Real orders only after GoLiveGate (src/notifier/bot.py) AND
  scripts/mexc_api_probe.py prints ALL GREEN against REAL MEXC.
- Commit small per logical unit; push to origin/mexc-listener-design after each
  green step. Git identity: name `𝕧𝕒𝕝𝕒𝕣𝕚𝕠𝕟`, email
  `42990222+hernanda-git@users.noreply.github.com` (gh lacks user scope; no-reply
  addr attributes correctly).
- Secrets live in .env (gitignored). Config DB stores env-var NAMES only.

REMAINING ITEMS (in order):
8. /etc/caddy/Caddyfile — reverse_proxy :8080 + /ws/events (see scripts/deploy.sh
   step 4). NOTE: `patch` tool CANNOT write /etc/caddy — use terminal tee/heredoc
   or leave for host edit; verify with `caddy reload` + `caddy validate`.
9. scripts/mexc_api_probe.py LIVE RUN + GoLiveGate flip — needs real MEXC keys
   (KYC for futures order permission; unbound keys expire 90d) + real Telethon
   session. The probe is NON-DESTRUCTIVE (reads only).

PROBE FINDINGS (real run on Sera, 2026-08-13 — DO NOT re-derive, FIX instead):
  [RED] REST instruments: 1102 symbols returned; BTCUSDT=no; 1000x=True.
        -> PROBE BUG: it checks the exact key `BTCUSDT` but MEXC /contract/detail
           nests the symbol under a different shape (likely `symbol` field casing /
           under a list-of-dicts not keyed by symbol). Fix the lookup, not the bot.
  [RED] WS host + login channel: "https://www.mexc.com/404 isn't a valid URI".
        -> PROBE BUG: it derives the WS URI from a REST 404 response. The correct
           default is wss://contract.mexc.com/ws (already the MEXC_WS_URL env
           default). Fix probe to use the env default / explicit WS_URL.
  [INFO] MEXC futures order permission requires KYC; unbound keys expire 90d.
  Result: NOT READY (exit 1). The bot code is fine; the PROBE needs fixing so it
  gives a trustworthy GREEN/RED before any live order is attempted.

NEXT STEPS FOR THE FRESH SESSION:
  a. Fix scripts/mexc_api_probe.py (the two RED bugs above) so it correctly reads
     MEXC instruments + connects to wss://contract.mexc.com/ws. Re-run: expect
     REST GREEN + WS GREEN (instrument/WS host checks need no auth).
  b. Only the authenticated order-shape check needs real MEXC_API_KEY/SECRET — do
     NOT attempt until step (a) is all-GREEN and a real key exists.
  c. Then wire TelethonListener + MexcWS into build_container live paths and run a
     paper end-to-end, then (last) the GoLiveGate flip.
  d. Item 8 (Caddy) can be done any time but doesn't block the bot.

Report a short status after each item: what changed, test count, commit hash.
```

## File map for pending items
| Item | File(s) |
|---|---|
| Fix probe | `scripts/mexc_api_probe.py` |
| Live Telethon + WS wiring | `src/main.py` (`build_container` live paths) |
| Go-live flip | `src/notifier/bot.py` (`GoLiveGate`) + real secrets in `.env` |
| Caddy | `/etc/caddy/Caddyfile` (host edit; `patch` tool blocked) |
