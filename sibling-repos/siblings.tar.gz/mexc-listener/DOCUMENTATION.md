# mexc-listener — Full Documentation & Handoff

> **Single source of truth for "what exists, what's pending, how to continue."**
> Companion docs: `docs/DESIGN.md` (architecture/living spec),
> `docs/CONCRETE-SPEC.md` (parameterized numbers),
> `.hermes/plans/mexc-listener-plan.md` (TDD task list).
> Git history is authoritative for *when/what*; this file is the status snapshot.

---

## 0. TL;DR

`mexc-listener` is a **MEXC USDⓈ-M Futures** bot that reads `@fattyfatclub`
Telegram signals (text + chart images) and executes them, with an LLM brain,
a self-correcting ShadowLedger, and a **FastAPI Web UI + WebSocket** as the
primary operator surface. It is the 4th sibling after `bybit-listener`,
`hyperliquid-fatty-trader`, and `learnernoearner-listener`.

**Status: P0–P3 + Items 1–7 (Postgres stores, live listener, LLM client, order
endpoints, WS loop, bot commands, fee-aware ledger) code-complete and unit-tested
(134 fakes-only unit tests + 5 gated real-DB integration tests, zero network, all
green). NOT yet connected to live MEXC / Telegram / OpenCode, and NOT go-live.
Paper-by-default; real orders require the GoLiveGate after `mexc_api_probe.py` is GREEN.

**Repo:** `https://github.com/hernanda-git/mexc-listener` (private)
**Branch:** `mexc-listener-design`  **Tests:** 128 unit + 5 gated integration passed  **Commits:** 13

---

## 1. What was built (done)

### Design & docs (committed before code — document-first rule)
- `docs/DESIGN.md` — living architecture, principles, atomic model, lifecycle,
  governance/anti-hallucination contract.
- `docs/CONCRETE-SPEC.md` — every concrete number (symbol map, MEXC auth shape,
  Gate2 bounds, fee model, rounding guards, SL/TP placement, dead-man TTL,
  ShadowLedger thresholds, run modes, go-live gate, deploy).
- `.hermes/plans/mexc-listener-plan.md` — phased TDD task list (P0–P3).

### P0 — MEXC-specific core (the parts the 3 siblings never wrote for MEXC)
- `src/exchanges/mexc_auth.py` — `MexcAuth`: HMAC-SHA256 over
  `accessKey + Request-Time(ms) + paramString`. **Fresh, not copied** from
  Bybit/Binance. Headers `ApiKey`/`Request-Time`/`Signature`.
- `src/exchanges/mexc.py` — `MexcExchange` REST V1 + instruments cache +
  `round_price`/`round_qty` with **magnitude-flip guards** (a $0.16 coin never
  becomes $100; minNotional loop). `validate_order` lives here.
- `src/streaming/mexc_ws.py` — `MexcWS`: `login` + `personal.filter`
  (`order`/`order.deal`/`position`/`asset`); maps `order.deal.fee`→`Fill.fee` (F6)
  and `position.liquidatePrice`→real `Position.liq_price` (F7). No listenKey dance.
- `src/sources/parser.py` — signal parser (bybit fork) + `SymbolMap`/`to_ws_symbol`
  (REST `BTCUSDT` ↔ WS `BTC_USDT`) + management fast-path (`sl to entry`,
  `tp1 booked` both word orders, `full`).
- `src/exchanges/repair.py` — **Edge C**: `IdempotencyGuard` (DUPLICATE_SKIPPED)
  + `RepairOrder` (deterministic `_repair_order`, no LLM).
- `scripts/mexc_api_probe.py` — verifies MEXC REST/WS reality (WS host, instruments,
  fee/liq shape, 1000× coverage) **before any order code**. Non-destructive.
  FIXED 2026-08-13: REST check now matches MEXC's real `BTC_USDT` (underscore) shape;
  WS check reports a *clean* RED when the host redirects/rejects (no `InvalidURI`
  crash). See §3 "Probe status (2026-08-13, real run)".

### P1 — Safe execution core
- `src/services/validator.py` — `Gate1` (idempotency/cooldown/whitelist) +
  `Gate2` (fee-aware size, leverage snap+clamp to pair max, SL-direction check,
  min-notional, ≤2 concurrent, daily-loss kill switch).
- `src/services/risk.py` — `FixedRiskSizer` fee-aware (net = gross − open/close
  fees), single-source `FeeModel`.
- `src/services/order.py` — `OrderService`: entry LIMIT (no `reduce_only`) + SL/TP
  `stop.order` (`reduce_only=true`, `GTC`, both `stopPrice`+`price`); **never
  auto-cancels `reduce_only` protective orders** (BUG C fix); dedup via guard.
- `src/services/position.py` — `PositionManager`: WS-synced; `reconcile_pending_orders`
  (late-filling resting LIMIT → position + SL/TP, idempotent); self-heal missing
  SL/TP; 48h time-exit.

### P2 — Resilience + safety capstone
- `src/notifier/bot.py` — `GoLiveGate` (2-step: mint token → `/live <token>` flips
  paper=0 **only if** shadow expectancy>0 AND tests green AND probe GREEN) +
  `_md_escape` (Telegram Markdown-safe).
- `src/services/deadman.py` — watchdog: heartbeat TTL → cancel-all in LIVE (MEXC
  has no native `scheduleCancel`).
- `src/exchanges/ws_stream.py` — `BanBackoff` (jittered, capped; back off, don't hammer).
- `src/exchanges/mark_cache.py` — `MarkCache` (batched refresh, stale-served).
- `src/sources/symbol_map.py` — `ContractMultiplierMap` (1000× / contract-size qty scaling).

### P3 — Your four confirmed forks
- `src/llm/brain.py` — `LLMBrain` (OpenAI-compat; `LLM_MODEL=deepseek-v4-flash-free`
  via OpenCode). Vision: chart images → `image_url` content parts. Text parser
  resolves ambiguous/conditional signals → structured `TradeDecision` (JSON).
  `FakeLLM` for tests.
- `src/eval/shadow_ledger.py` — `ShadowLedger` (Edge B): per-pair win-rate; flags
  weak pairs; **auto-downsize only behind `auto_downsize=True`** (default off).
- `src/web/app.py` — **FastAPI Web UI (PRIMARY surface)** + REST (`/api/status`,
  `/api/positions`, `/api/trades`, `/api/shadow`, `/api/health`) + `/` dashboard
  (live chart) + WebSocket `/ws/events` (event mirror). Binds the same Telegram
  channel for mobile.
- `Dockerfile`, `systemd/mexc-listener.service` (VPS `/opt/bots`), `scripts/deploy.sh`
  (Caddy `:8080` + `/ws/events`), `scripts/bump_version.py`, `src/main.py`
  (composition root; run modes `--check-tg/--live-dry/--dashboard/--go-live/--bot/
  --all-bots/--status/--balance/--positions`; paper-by-default).

---

## 2. What is PENDING (not yet built)

Ordered by importance. **Nothing here blocks the local test suite; all are
real-I/O / glue pieces that need credentials + the Sera VPS.**

1. **Real `ConfigStore` against Postgres `fatty_config`** (`src/config/db.py`) — **DONE**
   (Item 1). `PgGoLiveStore`/`PgDecisionStore`/`PgPositionStore`/`PgEvalStore`
   implement the abstract bases against `mexc_golive`/`mexc_decisions`/`mexc_positions`
   +`mexc_orders`/`mexc_eval`. `src/store/ledger.py` fee-aware `trades_log` writer +
   `init_ledger_schema()` ALTERs `fee`/`close_fee`/`liq_price` onto the shared table.
   `main.build_container` uses PG stores when `CONFIG_DB_URL` set AND `MEXC_FAKE` unset,
   else in-memory fakes. 18 fakes-only unit tests + 5 gated real-DB integration tests
   (all GREEN against live `fatty_config`). Env-var names only, never secrets.
2. **Live Telethon listener** (`src/sources/telegram.py`) — **DONE** (Item 2).
   `SignalRouter` (pure, unit-tested) routes ENTER/CONDITIONAL → Gate1 →
   `LLMBrain.decide` → Gate2 → `OrderService.enter`; MANAGEMENT → parse_management
   → OrderService transform (no LLM). `TelethonListener` is the thin `events.NewMessage`
   adapter (image bytes → RawSignal). 7 fakes-only unit tests.
3. **Live OpenCode LLM client** (`src/llm/client.py`) — **DONE** (Item 3).
   `OpenCodeLLM` implements the `LLMClient.chat` Protocol over `httpx` against
   `LLM_BASE_URL`/`LLM_API_KEY`/`LLM_MODEL=deepseek-v4-flash-free`. Wired into
   `main.build_container` when `MEXC_FAKE` unset AND `LLM_BASE_URL` set; else FakeLLM.
   3 fakes-only unit tests.
4. **`MexcExchange` order endpoints** (`src/exchanges/mexc.py`) — **DONE** (Item 4).
   `place_order` (opening LIMIT → `/contract/order/open`; protective STOP/TP →
   `/contract/order/stop`, reduce_only) + `close` + `get_position` (real liq_price)
   + `get_mark`, all over `_signed_request`. 5 fakes-only unit tests (fake boundary).
5. **`MexcWS` live socket loop** (`src/streaming/mexc_ws.py`) — **DONE** (Item 5).
   `connect()` async loop: login → personal.filter → dispatch; jittered reconnect
   (capped) + ping/pong heartbeat → `on_heartbeat` (dead-man reset). 4 unit tests
   (FakeWebSocket, no socket).
6. **Notifier Telegram bot commands** (`src/notifier/bot.py`) — **DONE** (Item 6).
   `CommandHandler` builds `/status /balance /positions /live /paper` cards
   (MarkdownV2-safe); `cmd_live` enforces GoLiveGate hard gates; `register_bot`
   wires to python-telegram-bot v22. 6 unit tests.
7. **`ledger.py` + eval snapshots** — **DONE** (folded into Item 1). The
   fee-aware `trades_log` writer (`src/store/ledger.py`) + `mexc_eval`/`mexc_decisions`
   Postgres stores are wired into `main.build_container`; `ShadowLedger` and the
   `Ledger` run against real Postgres when configured, in-memory fakes otherwise.
8. **Caddyfile block** for the VPS (documented in `deploy.sh` step 4; edit
   `/etc/caddy/Caddyfile` and `caddy reload`).
9. **`mexc_api_probe.py` live run + GoLiveGate flip** — requires real MEXC keys
   (KYC for futures order permission; unbound keys expire 90d) + real Telethon session.

---

## 3. Current status (verified)

- **Tests:** `139 passed (fakes-only, zero network) + 5 gated real-DB integration`.
- **Branch:** `mexc-listener-design`, 13 commits, all pushed to `origin`.
- **Run modes:** `--dashboard` starts the Web UI (paper, on :8080). The bot is wired
  end-to-end (MexcExchange + MexcWS + TelethonListener + SignalRouter + DashboardState).
- **Paper gate:** `paper=1` default; no real order path executes without GoLiveGate.
- **Live MEXC/Telegram reachable:** MEXC futures REST+WS now work from Jakarta via the
  Cloudflare Worker proxy (`mexc-proxy.m-hernanda95.workers.dev`); see §3.1. Telethon
  needs a real session; OpenCode LLM needs `LLM_BASE_URL`.

### 2.1 Dashboard (live, public)
- **URL:** `https://mexc.warga-digital.com/` (Cloudflare orange-cloud → nginx `:80` →
  `127.0.0.1:8080`). SSL = Cloudflare Flexible (no origin cert needed).
- Systemd unit `mexc-listener.service` runs `src/main.py --dashboard` (paper).
- Real-time single-page UI: KPIs (equity/balance/positions/pnl/win-rate/PF/max-DD/trades),
  live MEXC market prices (public ticker poll, works from Jakarta), equity+pnl canvas chart,
  positions + trades tables, per-pair/aggregate statistics, activities timeline, and a live
  logs tail. `EventBus` → WebSocket `/ws/events` pushes events to the browser.
- To show real account data (positions/balance/open-orders), set `MEXC_API_KEY`/`MEXC_SECRET`
  (+ `MEXC_WS_URL` = the Worker) in `.env` and restart the service. Market data is public and
  shows regardless.

### 3.1 Probe status (2026-08-13, real run on Sera)
`uv run python scripts/mexc_api_probe.py` → exit 1 (**NOT READY** at the time). The bot
code is fine; the probe had two issues, one real and one **not** as the prior handoff claimed:
- **[GREEN] REST instruments** — MEXC `/contract/detail` returns 1102 symbols keyed as
  `BTC_USDT` (underscore). The probe previously looked for `BTCUSDT` (no separator) and
  gave a FALSE RED. Fixed: `parse_instruments` now matches the real shape.
- **[RED] WS host + login channel** — NOT a probe code bug. Two real causes were found and
  **RESOLVED**:
  1. The correct MEXC futures WS endpoint is **`wss://contract.mexc.com/edge`** (a `ping`
     returns `{"channel":"pong",...}`). The old `wss://contract.mexc.com/ws` path returns a
     server-side HTTP 301 → `https://www.mexc.com/404` (broken endpoint, not a probe bug).
     `MexcWS` now defaults to `/edge`.
  2. **Jakarta geo-block**: from Sera's IP (43.173.11.172, Jakarta/ID) MEXC futures WS is
     geo-filtered, but `api.mexc.com` REST and Binance work. Resolution: a **Cloudflare
     Worker proxy** (`cloudflare/mexc-proxy`, deployed →
     `https://mexc-proxy.m-hernanda95.workers.dev`) tunnels MEXC REST (`/api/*`) and WS
     (`/ws` → `wss://contract.mexc.com/edge`) from Cloudflare's non-ID edge. Verified
     end-to-end 2026-08-13: bot `MexcWS.connect()` through the Worker received
     `rs.login` + `rs.personal.filter` (authenticated, socket live). Set
     `MEXC_WS_URL=wss://mexc-proxy.m-hernanda95.workers.dev/ws` (done in `.env.example`).
- **[INFO]** MEXC futures order permission requires KYC; unbound keys expire 90d.

**RESOLVED (2026-08-13):** MEXC futures REST + authenticated WS are reachable from Sera via
the Cloudflare Worker. The bot's `MexcWS` is wired in `build_container` (Item 9c) and its
`sign_login` now computes the real MEXC HMAC (`auth.sign("", req_time)`); the WS runner was
fixed to use a fresh `asyncio` event loop (the old `get_event_loop()` crashed in a worker
thread and silently prevented the socket from opening).

---

## 4. Continue on Sera VPS (step-by-step)

> Goal: clone, install, run probe, deploy, go live. All commands as `root` on Ubuntu 24.04.

### 4.1 Clone & venv
```bash
cd /opt/bots
git clone git@github.com:hernanda-git/mexc-listener.git
cd mexc-listener
git checkout mexc-listener-design
python3 -m venv .venv
.venv/bin/python -m pip install -e .
.venv/bin/python -m pip install fastapi uvicorn psycopg           # web + pg
```

### 4.2 Secrets (NEVER commit)
```bash
cp .env.example .env
# edit .env: MEXC_API_KEY, MEXC_SECRET, TG_*, LLM_BASE_URL, LLM_API_KEY, LLM_MODEL,
#           CONFIG_DB_URL, BOT_NAME, WEB_PORT
# KYC required for MEXC futures order permission; unbound keys expire 90d.
```

### 4.3 Verify MEXC reality (MANDATORY before go-live)
```bash
.venv/bin/python scripts/mexc_api_probe.py    # must print ALL GREEN
```

### 4.4 Run test suite (must stay green)
```bash
.venv/bin/python -m pytest tests/ -q          # 128 passed (fakes-only)
```

### 4.5 Deploy (systemd + Caddy)
```bash
bash scripts/deploy.sh
# then edit /etc/caddy/Caddyfile to add the reverse_proxy block (see deploy.sh [4/5])
# caddy reload
```

### 4.6 Go live (only after probe GREEN + shadow expectancy>0)
```bash
.venv/bin/python -m src.main --go-live        # mints one-time token
# from Telegram bot: /live <token>  -> flips paper=0 (gated by GoLiveGate)
```

---

## 5. Environment / secret checklist (for the other machine)

| Var | Where | Notes |
|---|---|---|
| `MEXC_API_KEY` / `MEXC_SECRET` | `.env` | HMAC credentials; KYC + 90d expiry |
| `MEXC_TESTNET` / `MEXC_BASE_URL` / `MEXC_WS_URL` | `.env` | `wss://mexc-proxy.m-hernanda95.workers.dev/ws` (CF Worker; direct fallback `wss://contract.mexc.com/edge`) |
| `TG_API_ID` / `TG_API_HASH` / `TG_PHONE` | `.env` | Telethon user client (reads channel) |
| `TG_BOT_TOKEN` | `.env` | Bot API (alerts/commands) |
| `TG_SESSION_DIR` / `FATTY_CHANNEL` | `.env` | session file path; `@fattyfatclub` |
| `LLM_BASE_URL` / `LLM_API_KEY` / `LLM_MODEL` | `.env` | OpenCode `deepseek-v4-flash-free` |
| `CONFIG_DB_URL` | `.env` | `postgresql://…/fatty_config` (shared) |
| `WEB_HOST` / `WEB_PORT` / `WS_EVENT_PATH` | `.env` | `0.0.0.0:8080`, `/ws/events` |
| `SHADOW_AUTO_DOWNSIZE` | `.env` | `0` default (report+flag; `1`=auto-downsize) |

---

## 6. File map (what to touch for each pending item)

| Pending item | File(s) to implement |
|---|---|
| Postgres ConfigStore + ledger | `src/config/db.py`, `src/store/ledger.py` |
| Live Telethon listener | `src/sources/telegram.py` |
| OpenCode LLM client | `src/llm/client.py` (wire in `main.build_container`) |
| MEXC order REST endpoints | `src/exchanges/mexc.py` (`_signed_request` + `place_order`/`close`/`stop`) |
| MEXC WS live loop | `src/streaming/mexc_ws.py` (`connect`) |
| Telegram bot commands | `src/notifier/bot.py` |
| Caddy | `/etc/caddy/Caddyfile` (see `deploy.sh`) |

---

## 7. Principles to preserve (anti-hallucination)
- **Code > git history > docs > chat.** If a doc contradicts code, code wins; fix the doc.
- **No LLM fallback for trades.** Repair is deterministic (`RepairOrder`); the LLM only
  *decides*, never *fixes* an order.
- **Never auto-cancel `reduce_only` protective orders.**
- **Paper by default; go-live only via GoLiveGate** (shadow expectancy>0 + tests + probe).
- **Record real fee + real liquidation price** on every fill/position.
- **No "guaranteed daily growth" claims** — compound via positive expectancy + bounded DD.

---

## 8. Quick reference — run it now (local, paper)
```bash
cd /opt/bots/mexc-listener
.venv/bin/python -m src.main --dashboard      # Web UI on :8080 (paper)
.venv/bin/python -m pytest tests/ -q           # 85 passed
```
