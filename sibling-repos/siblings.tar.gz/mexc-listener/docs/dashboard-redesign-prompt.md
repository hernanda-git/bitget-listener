# mexc-listener Dashboard — Full Redesign Prompt

**Target file (ONLY this file):** `/opt/bots/mexc-listener/src/web/app.py`

The dashboard is a single self-contained FastAPI module. The entire UI is the
`_DASHBOARD_HTML` string (a Python raw string, `r"""..."""`, starting near line 38).
All data is fetched client-side via `fetch('/api/state')` and rendered with
vanilla JS into the DOM. There is no build step, no external CSS/JS framework,
and no separate `templates/` or `static/` directory. The frontend reads
everything from `/api/state` and renders into the DOM.

**Backend endpoints that must NOT change:** `/api/state`, `/api/status`,
`/api/positions`, `/api/trades`, `/api/shadow`, `/api/balance`, `/api/market`
(their JSON shapes and the Python logic stay exactly as-is). The redesign is
front-end only.

---

## Hard constraints (do not violate)

1. **No backend changes.** Do not alter any `@app.get(...)` route, its JSON
   shape, or the Python logic. Preserve every data field currently displayed:
   - Equity (USDT), Balance, Open positions, Net PnL, Win rate, Profit factor,
     Max drawdown, Trades
   - Per-symbol market prices + % change (BTC/ETH/SOL etc.)
   - Sparklines (per-symbol mini price history)
   - Positions table: Symbol / Side / Size / Entry / Mark / Liq / PnL
   - Trades table: Time / Symbol / PnL
   - Statistics: total trades, wins / losses
   - Activity log (signal / order / fill / connection events)
   - Indicators: PAPER / live mode, ws feed status, connectivity
2. **Single self-contained file.** Keep all CSS in an inline `<style>` and all
   JS in an inline `<script>` inside `_DASHBOARD_HTML`. No CDN dependencies, no
   npm, no framework. Vanilla HTML/CSS/JS only.
3. **Stay functional.** The existing JS render functions (`fetch('/api/state')`
   loop, market / spark / positions / trades / log renderers) must keep working.
   You may restructure markup and classes, but every binding must map to the
   same `/api/state` fields.
4. **Responsive.** Single-column on phones (<=480px), comfortable 2-col on
   tablet (<=820px), multi-col on desktop. **No horizontal scroll at any width
   from 320px up.** Verify mentally at 320 / 390 / 768 / 1280px.

---

## Design direction — "Claymorphism + Aurora UI"

- **Claymorphism:** soft, puffy cards with dual inner shadows (light top-left,
  dark bottom-right) plus a subtle drop shadow; large border radius (~20–28px);
  matte, slightly tactile surfaces; gentle, low-saturation background. Avoid
  glassmorphism / neon-glass clichés.
- **Aurora UI:** a **static, blurred** gradient backdrop (soft aurora-like
  blobs/blurs in cool greens / teals / violets / blues) sitting behind the
  content. **Keep it static (no animation) and heavily blurred** — the blur is
  what makes it read as aurora while staying calm and non-distracting, and it
  pairs with the matte claymorphism surfaces. Do NOT animate it. (Respect
  `prefers-reduced-motion` only as a belt-and-braces guard; the default is
  already static.)
- **Palette:** generic, neutral-friendly; do not lock to any brand color. Use
  CSS custom properties (`--bg`, `--card`, `--fg`, `--mut`, `--ok` / `--bad` for
  PnL sign, etc.) so the theme is centralized and switchable.

---

## Non-bias / generic requirements

- **Typography:** system font stack only —
  `system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial, sans-serif`.
  Do NOT use any identifiable "AI/tech" typeface (no Inter-by-default
  assumption, no all-monospace styling, no trendy display fonts). Numeric /
  price values may use a monospaced system stack
  (`ui-monospace, SFMono-Regular, Menlo, Consolas, monospace`) for column
  alignment only — not as a stylistic signature.
- **No mascots, no emojis, no logo-like or assistant-persona icons.** Any icon
  (if used) is a minimal generic glyph (unicode or inline SVG), never brand- or
  persona-identifying.
- **Neutral labeling:** layout and wording follow standard finance/trading
  dashboard conventions — not "chatbot / AI assistant" framing.
- **Theme-agnostic:** design should read well in a dark aurora theme (default).
  Keep variables centralized so a light theme is trivial to enable later (a
  toggle is NOT required).

---

## Deliverable

Return the full updated `app.py` (or just the rewritten `_DASHBOARD_HTML` block
if that is all that changed) with the redesign applied, plus a one-line note
confirming:

- (a) all `/api/state` fields still render,
- (b) no new external network requests were added,
- (c) layout is responsive and free of horizontal scroll at 320–1280px.

Do not commit. Just produce the file content for review.
