# mexc-listener — Living Design Doc (single source of truth)

> **Status:** P0 in progress. This doc is the canonical reference; `CONCRETE-SPEC.md`
> holds the parameterized numbers; `.hermes/plans/mexc-listener-plan.md` holds the
> bite-sized TDD task list. Code MUST match this doc; if a doc contradicts code,
> code wins and the doc is fixed (anti-hallucination contract, §8).

## 1. Principles

1. **Document-first, commit, then code.** (trading-bot-design rule.)
2. **Paper/shadow by default.** `paper=1` in Config DB + `.env`; real orders only
   after GoLiveGate flips it. No real order before `mexc_api_probe.py` GREEN.
3. **Fee-aware correctness at the model layer.** Real `execFee` recorded on every
   fill; exits booked at **real** `liquidatePrice` (never `0.00`); protective
   `reduce_only` SL/TP are **never** auto-cancelled.
4. **Execution rigor from day 1** (Edge C). Every order passes a central
   `validate_order` before submission; on a recoverable reject we use a
   *deterministic* `_repair_order` (reload filters → re-round → re-validate →
   resubmit once) — **never** an LLM fallback. Idempotent dedup guard prevents
   duplicate fills.
5. **Resilience:** WS-first push monitoring (MEXC `personal.filter`, no listenKey
   refresh dance like Hyperliquid); jittered reconnect; dead-man's-switch watchdog
   (MEXC has no native `scheduleCancel`); ban-aware backoff + optional egress proxy.
6. **Observable:** FastAPI **Web UI is the primary surface** (live charts + data);
   a WebSocket event stream mirrors events to the browser; a Telegram bot binds the
   same channel for mobile alerts/commands.
7. **Self-correcting (Edge B):** `ShadowLedger` tracks per-pair signal win-rate from
   `@fattyfatclub`; reports + flags weak pairs; auto-downsizes only behind
   `SHADOW_AUTO_DOWNSIZE=1` (default off).

## 2. Target Architecture

Fork `bybit-listener` (cleanest SOLID, fee/liq-correct) + graft learner's
`Exchange` ABC (richest interface) + hyperliquid's WS-first / dead-man's-switch
philosophy. MEXC ≈ bybit (CEX USDT perp), so the shape is bybit's.

```
Telegram @fattyfatclub (Telethon user client)
  │ text + image attachments
  ▼ RawSignal([image_bytes])
  ├─ management command? (sl to entry / tp1 booked / full) ─▶ OrderService transform (no LLM, ~200ms)
  └─ trade/conditional signal ─▶ Gate1 (idemp/cooldown/whitelist)
        ▼ LLM brain (deepseek-v4-flash-free): vision on chart image + text parser
        │   → resolves ambiguous/conditional signals, emits TradeDecision
        ▼ Gate2 (fee-aware clamps: size/lev/SL-dir/min-notional/daily-loss)
        ▼ OrderService.build_entry → MexcExchange.place (REST V1)
        ▼ MexcWS push.personal.order.deal → Fill.fee recorded (F6)
        ▼ MexcWS push.personal.position → Position(liq_price real) (F7)
        ▼ Ledger.write (net = gross − fees) + ShadowLedger.update(pair, win/loss)
        ▼ Notifier (Web UI WS + Telegram bot)
```

### Module map
- `src/domain/model.py` — frozen dataclasses: `Instrument`, `RawSignal`, `Signal`,
  `OrderRequest`, `Position`, `Fill`, `TradeDecision`.
- `src/interfaces/ports.py` — `SignalSource`, `MexcExchange`(Exchange ABC),
  `MarketStream`, `Notifier`, `RiskPolicy`, `EvalStore`.
- `src/exchanges/mexc.py` — `MexcExchange` REST V1 + `MexcAuth`; instruments cache.
- `src/streaming/mexc_ws.py` — `MexcWS` login + `personal.filter`.
- `src/sources/parser.py` — bybit parser copy; `SymbolMap`; `to_ws_symbol()`.
- `src/sources/telegram.py` — Telethon reader; `FakeSignalSource`.
- `src/services/{validator,risk,order,position}.py` — gates, sizer, order mgmt.
- `src/llm/brain.py` — OpenAI-compat client; vision + structured decision.
- `src/eval/shadow_ledger.py` — per-pair signal win-rate (F24).
- `src/notifier/{bot.py,web.py}` — Telegram bot + FastAPI/WS.
- `src/config/db.py` — `ConfigStore` (Postgres, env-var names only).
- `src/store/ledger.py` — fee-aware `trades_log` + eval snapshots.
- `main.py` — composition root; run modes.

## 3. Atomic entity model
- `Signal` — normalized call: `pair`, `direction(LONG/SHORT)`, `entry`, `sl`, `tps[]`,
  `leverage`, `raw_text`, `images[]`, `signal_type(ENTRY|CONDITIONAL|MANAGEMENT)`.
- `TradeDecision` — LLM output: `action(ENTER|CONDITIONAL|SKIP|MANAGEMENT)`,
  `confidence_pct`, `reason`, `bias`, plus resolved levels.
- `OrderRequest` — MEXC-specific: `symbol(TOKENUSDT)`, `side`, `price`, `qty`,
  `order_type`, `reduce_only`, `client_order_id`, attached `stop_loss`/`take_profit`.
- `Position` — `liq_price` (real), `entry`, `size`, `leverage`, `pnl`, `fee`, `margin`.
- `Fill` — `fee` (non-zero, USDT), `fill_price`, `qty`, `side`, `ts`.
- `ShadowRecord` — `pair`, `trades`, `wins`, `losses`, `winrate`, `expectancy`, `rating`.

## 4. Lifecycle state machine (position)
`PENDING → OPEN → (PROTECTED) → CLOSING → CLOSED(win|loss)`.
Management commands (`sl to entry`, `tpN`, `full`) mutate an OPEN position.
Resting LIMIT entry that fills late → `reconcile_pending_orders` builds the Position
+ attaches SL/TP (mirrors learner's fix; prevents orphaned positions).

## 5. Gating / filters (do not disable)
- **Gate1 (pre-LLM):** idempotency (message_id), cooldown per pair, whitelist,
  media/noise check.
- **Gate2 (post-LLM):** fixed-risk size, leverage snap+clamp to pair max, SL
  direction check, min-notional, ≤2 concurrent, ≤30% daily loss, margin ≤80%.
- **Immutable safety (never disableable by any tuner):** daily-loss kill switch,
  dead-man's switch, feed-stale circuit breaker.

## 6. Feed layer (MEXC-specific — write fresh)
- `MexcAuth`: sign string = `accessKey + Request-Time(ms) + paramString`;
  headers `ApiKey/Request-Time/Signature`; GET params sorted lexicographically,
  POST = JSON body. Do NOT reuse Bybit/Binance auth.
- `MexcWS`: `wss://contract.mexc.com/ws`; `login` then `personal.filter`
  (`order`,`order.deal`,`position`,`asset`). WS symbols use `_` (`BTC_USDT`);
  REST uses `BTCUSDT` → centralize `to_ws_symbol()`.
- Fee/liq mapping: `order.deal.fee` → `Fill.fee`; `position.liquidatePrice` →
  `Position.liq_price`.

## 7. Risk port
Fee model single-source: maker `0.0002` / taker `0.0005` (VIP0 default; validate in
eval). `FixedRiskSizer.net = gross − (open_fee + close_fee)`.

## 8. Governance / anti-hallucination
- Source of truth hierarchy: **code > git history > this doc > other md > chat/memory**.
- No "guaranteed daily growth" claims — compound via positive expectancy + bounded DD.
- Every metric in the Web UI traces to a real DB row.

## 9. Success metrics
- Zero `-1111`/`-4164`/`-2022`/duplicate-fill in P0–P3 regression.
- `mexc_api_probe.py` GREEN on real (paper) key before go-live.
- ≥81 fakes-only tests, zero network.
- Go-live gate: GoLiveGate token + shadow expectancy > 0 + all tests green.

## 10. Migration path
Fork `bybit-listener` dirs; rename `Bybit*`→`Mexc*`; swap adapters; graft learner
`base.py` + hyperliquid WS watchdog. No shared code with learner/hyperliquid beyond
copied patterns.
