# mexc-listener — Concrete Spec (parameterized, single source of numbers)

> Companion to `DESIGN.md`. Every other doc's examples MUST match these numbers.
> If a value drifts, grep `-rn` and fix (consistency-review discipline).

## 1. Symbol resolution
- REST symbol: `BTCUSDT` (no separator). WS symbol: `BTC_USDT` (underscore).
- `to_ws_symbol("BTCUSDT") -> "BTC_USDT"`; `from_ws_symbol` reverse.
- `SymbolMap`: `$TOKEN`/`#TOKEN` → `TOKENUSDT` (MEXC REST style).
- **1000× / contract-multiplier map** (F11): low-price tokens may trade as
  `1000XXXUSDT` or with a contract multiplier. Registry built from
  `/api/v1/contract/detail` (or `exchangeInfo` equiv) at load; `contract_size`
  applied to qty math. Same hazard class as Binance `1000PEPE`.

## 2. MEXC auth (fresh, not reused)
```
sign = HMAC-SHA256(secret, accessKey + Request-Time + paramString)
headers: ApiKey, Request-Time(ms string), Signature, (Recv-Window optional)
GET: paramString = sorted(query_params, "&")   POST: paramString = json_body
response envelope: { success:bool, code:int(0=ok), data:{} }
```
Server clock skew tolerance ±10s (Recv-Window max 60s). Token bucket: 300/min.

## 3. Safety gates (Gate2 concrete bounds)
| Param | Default | Hard bound |
|---|---|---|
| `risk_per_trade_usd` | 5 | — |
| `max_position_usd` | 100 | — |
| `max_concurrent` | 2 | — |
| `max_daily_loss_pct` | 30 | immutable kill switch |
| `max_leverage` | 20 | `min(config, pair_max_leverage)` |
| `min_notional_usd` | 5 | exchange filter |
| `cooldown_s` | 30 | — |
| `whitelist_only` | true | — |

Leverage snap ladder (MEXC): `1,2,3,5,7,10,15,20,25,30,50,75,100,125`.
Snap UP to nearest valid; clamp to `min(config_max, pair_max)`. Never floor before snap.

## 4. Fee model (single source)
- maker `0.0002`, taker `0.0005` (VIP0 default). Thread via
  `FixedRiskSizer(open_fee=…, close_fee=…)`; validate in eval.
- `Fill.fee_asset = "USDT"` (MEXC deducts in USDT per `deductFeeList`).
- `net_usd = gross_usd − (open_fee + close_fee)`.

## 5. Rounding / validation (Edge C)
- `round_price(symbol, price)`: step DOWN to `tickSize`; clamp UP to `minPrice`
  only if `minPrice <= rounded*10` (never inflate a $0.16 coin to $100).
- `round_qty(symbol, qty, price_ref)`: step to `lotSize`/`stepSize`, then LOOP
  increasing qty until `qty*price_ref >= minNotional` (seed `minNotional/price`).
- `validate_order(symbol, side, price, qty, filters)`: tickSize step, minQty/maxQty,
  `qty*price>=minNotional`, `minPrice<=price<=maxPrice`. Invalid → `VALIDATION_SKIP`.
- Idempotency: `client_order_id` UNIQUE in DB + `get_active_for_decision()` guard
  returns `DUPLICATE_SKIPPED` before placing.

## 6. SL/TP placement (MEXC)
- Entry = LIMIT (opening) → **no** `reduce_only`.
- Protective = MEXC `stop.order` plan orders (`STOP`/`TAKE_PROFIT` conditional) →
  `reduce_only=true`, `timeInForce=GTC`, both `stopPrice`+`price`.
- `-4120`-style reject (Algo-only endpoint): default fallback → TP resting LIMIT,
  SL `UNPROTECTED` + position-manager price monitor. Gate behind opt-in env.
- **Never auto-cancel `reduce_only` protective orders** (BUG C fix).

## 7. Position manager (P1)
- WS-synced (`push.personal.position`). Self-heal missing SL/TP (re-place once,
  idempotent `_protection_placed`/`_sl_monitored` sets). Orphan detect. 48h time-exit.
- `reconcile_pending_orders()` at top of monitor loop: late-filling LIMIT → build
  Position + attach SL/TP.

## 8. Dead-man's switch (F15)
MEXC has no `scheduleCancel`. Watchdog: heartbeat TTL (e.g. 60s). If no heartbeat
(WS dead / process stalled) in live mode → cancel all open orders + flatten logic
guarded by kill switch. Report to Web UI + Telegram.

## 9. ShadowLedger (Edge B)
- Per `pair`: append each resolved trade outcome (win/loss, r-multiple).
- `min_trades=30` before a rating is trusted.
- `poor_winrate=0.50`: below → FLAG (Web UI badge + Telegram). If
  `SHADOW_AUTO_DOWNSIZE=1` → multiply that pair's size by `0.5` (floor 1 trade-sized).
- Report only by default; auto-downsize behind flag (user-confirmed).

## 10. Run modes (`main.py`)
`--check-tg` (connectivity), `--live-dry` (forced paper, never real),
`--dashboard` (paper unless go-live), `--go-live` (mint token), `--bot NAME`,
`--all-bots`, `--status/--balance/--positions`. Degrade to safe paper/testnet if
Config DB unreachable.

## 11. Go-live gate (hardened bybit)
`--go-live` mints one-time token → user `/live <token>` flips `paper=0` ONLY if:
(a) `mexc_api_probe.py` GREEN on real key, (b) shadow expectancy > 0,
(c) all P0–P3 tests green.

## 12. Deploy (P3)
VPS `43.173.11.172` systemd service under `/opt/bots/mexc-listener`; Caddy reverse-
proxies `:8080` Web UI + `/ws/events`. Postgres `fatty_config` shared. Telegram bot
binds `@fattyfatclub` alerts/commands. (Consistent with gateway/vaisravana siblings.)
