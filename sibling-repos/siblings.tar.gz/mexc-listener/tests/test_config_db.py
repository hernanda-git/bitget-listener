"""Item 1 — Postgres ConfigStore + fee-aware Ledger (TDD, zero network).

Tests the Postgres-backed stores against an INJECTED fake `conn`
(records executed SQL+params, simulates fetch). No real DB, no network.

Real-DB coverage lives in tests/test_config_db_integration.py, gated behind
pytest.mark.integration + an availability check so the default suite stays
hermetic at 85+ green.

CONCRETE-SPEC §2/§4/§5; DOCUMENTATION.md §2 item 1.
"""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from config.db import (  # noqa: E402
    PgGoLiveStore,
    PgDecisionStore,
    PgPositionStore,
    PgEvalStore,
    init_config_schema,
)
from store.ledger import Ledger, init_ledger_schema  # noqa: E402
from services.position import PositionRow  # noqa: E402


class FakeCursor:
    def __init__(self, rows=None):
        self._rows = list(rows) if rows else []
        self.rowcount = len(self._rows)

    def fetchone(self):
        return self._rows[0] if self._rows else None

    def fetchall(self):
        return list(self._rows)


class FakeConn:
    """Injected psycopg-like connection. Records calls, simulates fetch."""

    def __init__(self):
        self.calls = []
        self._queue = []
        self.committed = 0

    def queue(self, rows):
        self._queue.append(list(rows))

    def execute(self, sql, params=None):
        self.calls.append((sql, params))
        rows = self._queue.pop(0) if self._queue else []
        return FakeCursor(rows)

    def commit(self):
        self.committed += 1


def _last_sql(conn):
    return conn.calls[-1][0]


# --- GoLiveStore (bots + mexc_golive token) -------------------------------

def test_golive_get_returns_paper_and_token():
    c = FakeConn()
    c.queue([(True, "abc123")])
    s = PgGoLiveStore(c)
    row = s.get("mexc-fatty")
    assert row == {"paper": True, "go_live_token": "abc123"}
    assert "LEFT JOIN mexc_golive" in _last_sql(c)
    assert "bots" in _last_sql(c)


def test_golive_get_missing_bot_returns_empty():
    c = FakeConn()
    c.queue([])  # no row
    s = PgGoLiveStore(c)
    assert s.get("nope") == {}


def test_golive_set_paper_updates_bots():
    c = FakeConn()
    s = PgGoLiveStore(c)
    s.set_paper("mexc-fatty", 0)
    sql, params = c.calls[-1]
    assert "UPDATE bots" in sql
    assert "paper" in sql
    assert params["v"] == 0 and params["b"] == "mexc-fatty"


def test_golive_set_token_writes_mexc_golive():
    c = FakeConn()
    s = PgGoLiveStore(c)
    s.set_token("mexc-fatty", "tok-9")
    sql, params = c.calls[-1]
    assert "mexc_golive" in sql
    assert params["t"] == "tok-9"
    # NULL clears the one-time token
    s.set_token("mexc-fatty", None)
    assert c.calls[-1][1]["t"] is None


# --- DecisionStore (mexc_decisions) ---------------------------------------

def test_decision_mark_client_order_id_dedup():
    c = FakeConn()
    s = PgDecisionStore(c)
    # first call: SELECT finds nothing -> INSERT -> True
    c.queue([])
    assert s.mark_client_order_id("cid-1") is True
    # second call: SELECT finds existing -> False (no insert attempted path)
    c.queue([(1,)])
    assert s.mark_client_order_id("cid-1") is False


def test_decision_get_active_for_decision():
    c = FakeConn()
    s = PgDecisionStore(c)
    c.queue([("d1", "ACTIVE")])
    assert s.get_active_for_decision("d1", "BUY") is not None
    sql, params = c.calls[-1]
    assert "mexc_decisions" in sql and params["id"] == "d1"


def test_decision_get_active_missing_returns_none():
    c = FakeConn()
    s = PgDecisionStore(c)
    c.queue([])
    assert s.get_active_for_decision("zzz", "BUY") is None


def test_decision_mark_active_upserts():
    c = FakeConn()
    s = PgDecisionStore(c)
    s.mark_active("d2")
    sql, params = c.calls[-1]
    assert "mexc_decisions" in sql
    assert params["id"] == "d2"


# --- PositionStore (mexc_positions + mexc_orders) -------------------------

def test_position_create_inserts_row():
    c = FakeConn()
    s = PgPositionStore(c)
    row = PositionRow(symbol="BTCUSDT", direction="LONG", size=0.01, entry=60000.0,
                      leverage=10, liq_price=54000.0, status="OPEN", opened_at=1,
                      has_sl=True, has_tp=False)
    s.create(row)
    sql, params = c.calls[-1]
    assert "INSERT INTO mexc_positions" in sql
    assert params["symbol"] == "BTCUSDT" and params["liq_price"] == 54000.0


def test_position_get_open_by_pair_returns_positionrow():
    c = FakeConn()
    s = PgPositionStore(c)
    c.queue([("BTCUSDT", "LONG", 0.01, 60000.0, 10, 54000.0, "OPEN", 1, True, False)])
    r = s.get_open_by_pair("BTCUSDT")
    assert isinstance(r, PositionRow)
    assert r.symbol == "BTCUSDT" and r.liq_price == 54000.0 and r.status == "OPEN"


def test_position_get_open_returns_none_when_closed():
    c = FakeConn()
    s = PgPositionStore(c)
    c.queue([])
    assert s.get_open_by_pair("BTCUSDT") is None


def test_position_update_status():
    c = FakeConn()
    s = PgPositionStore(c)
    s.update_status("BTCUSDT", "CLOSED")
    sql, params = c.calls[-1]
    assert "UPDATE mexc_positions" in sql and params["st"] == "CLOSED"


def test_position_create_order_and_get():
    c = FakeConn()
    s = PgPositionStore(c)
    s.create_order("o1", "BTCUSDT", "BUY", "PENDING")
    sql, params = c.calls[-1]
    assert "INSERT INTO mexc_orders" in sql and params["order_id"] == "o1"
    c.queue([{"order_id": "o1", "symbol": "BTCUSDT", "side": "BUY", "status": "PENDING"}])
    assert s.get_order("o1")["status"] == "PENDING"


# --- EvalStore (mexc_eval) ------------------------------------------------

def test_eval_record_upserts_wins_losses():
    c = FakeConn()
    s = PgEvalStore(c)
    s.record("BTCUSDT", win=True)
    s.record("BTCUSDT", win=False)
    # two inserts/upserts
    assert sum("mexc_eval" in sql for sql, _ in c.calls) == 2
    # verify the win/loss params: first win -> w=1,l=0 ; second -> w=0,l=1
    wins = [p for sql, p in c.calls if "mexc_eval" in sql]
    assert wins[0]["w"] == 1 and wins[0]["l"] == 0
    assert wins[1]["w"] == 0 and wins[1]["l"] == 1


def test_eval_get_returns_bool_list():
    c = FakeConn()
    s = PgEvalStore(c)
    c.queue([(2, 1)])  # 2 wins, 1 loss
    outs = s.get("BTCUSDT")
    assert outs == [True, True, False]
    c.queue([])
    assert s.get("NONE") == []


# --- init_schema (idempotent CREATE TABLE) --------------------------------

def test_init_config_schema_creates_all_tables():
    c = FakeConn()
    init_config_schema(c)
    sql_blob = " ".join(sql for sql, _ in c.calls)
    for t in ("mexc_golive", "mexc_decisions", "mexc_positions", "mexc_orders", "mexc_eval"):
        assert f"CREATE TABLE IF NOT EXISTS {t}" in sql_blob


# --- Ledger (fee-aware trades_log) ----------------------------------------

def test_ledger_init_schema_alters_fee_columns():
    c = FakeConn()
    init_ledger_schema(c)
    cols = [p for sql, p in
            [(s, None) for s in
             ("fee", "close_fee", "liq_price")]]
    # three ALTER statements, each adding one of the new columns
    alter_sqls = [sql for sql, _ in c.calls if "ALTER TABLE trades_log" in sql
                  and "ADD COLUMN IF NOT EXISTS" in sql]
    assert len(alter_sqls) == 3
    joined = " ".join(alter_sqls)
    assert "fee" in joined and "close_fee" in joined and "liq_price" in joined


def test_ledger_write_inserts_fee_columns():
    c = FakeConn()
    ledger = Ledger(c)
    ledger.write({
        "ts_open": 1.0, "iso_open": "2026-01-01T00:00:00Z", "bot": "mexc-fatty",
        "symbol": "BTCUSDT", "side": "BUY", "entry": 60000.0, "exit_px": 61000.0,
        "size": 0.01, "lev": 10, "sl": 59000.0, "tp": 63000.0, "margin": 6.0,
        "pnl": 10.0, "close_reason": "tp", "dry": False, "source_msg_id": 7,
        "fee": 0.5, "close_fee": 0.5, "liq_price": 54000.0,
    })
    sql, params = c.calls[-1]
    assert "INSERT INTO trades_log" in sql
    assert "fee" in sql and "close_fee" in sql and "liq_price" in sql
    assert params["fee"] == 0.5 and params["close_fee"] == 0.5
    assert params["liq_price"] == 54000.0
