"""T0.6 signal parser (fork of bybit-listener/src/sources/parser.py) + SymbolMap.

@fattyfatclub format (from COMPARISON.md §3.2): #TOKEN $TOKEN LONG/SHORT, ENTRY/SL/TP/LEV.
Management commands: 'sl to entry', 'tp1 booked', 'full', 'close'.
SymbolMap: $TOKEN -> TOKENUSDT (MEXC REST). to_ws_symbol() -> TOKEN_USDT (WS).
No LLM on management commands (fast path, ~200ms).
"""
import sys, os, re
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from sources.parser import parse_signal, parse_management, SymbolMap, normalize_pair


def test_symbol_map_rest_and_ws():
    assert SymbolMap.to_rest("$BTC") == "BTCUSDT"
    assert SymbolMap.to_ws("BTCUSDT") == "BTC_USDT"
    assert SymbolMap.to_rest("#SOL") == "SOLUSDT"


def test_parse_long_entry_signal():
    text = "#BTC $BTC LONG\nEntry 60000\nSL 59000\nTP 63000 / 65000\nLev 10x"
    sig = parse_signal(text)
    assert sig is not None
    assert sig.pair == "BTCUSDT"
    assert sig.direction.value == "LONG"
    assert sig.entry == 60000.0
    assert sig.sl == 59000.0
    assert sig.tps == (63000.0, 65000.0)
    assert sig.leverage == 10


def test_parse_short_signal_with_dashes():
    text = "$ETH SHORT\nentry 3000\nsl 3100\ntp 2800\nlev 5"
    sig = parse_signal(text)
    assert sig.direction.value == "SHORT"
    assert sig.entry == 3000.0
    assert sig.sl == 3100.0


def test_parse_conditional_signal():
    text = "$AAVE broke out, looking for long if holds above 95.45 on 4H"
    sig = parse_signal(text)
    assert sig is not None
    assert sig.signal_type.value == "CONDITIONAL"
    assert sig.entry == 95.45


def test_parse_management_sl_to_entry():
    m = parse_management("$BTC sl to entry")
    assert m is not None
    assert m["command"] == "SL_TO_ENTRY"
    assert m["pair"] == "BTCUSDT"


def test_parse_management_tp1_booked_both_word_orders():
    a = parse_management("$ZAMA book tp1 here")
    b = parse_management("$ZAMA tp1 booked here")
    assert a["command"] == "TP1_PARTIAL" and b["command"] == "TP1_PARTIAL"


def test_parse_management_full_close():
    m = parse_management("$DOGE full")
    assert m["command"] == "FULL_CLOSE"


def test_no_signal_on_noise():
    assert parse_signal("gm everyone, market looking choppy") is None
