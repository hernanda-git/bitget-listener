"""TDD tests for MexcWS proxy/WS-URL env-readiness (zero network).

Proves the bot can target a Cloudflare Worker (MEXC_WS_URL) or an HTTP/WS
proxy (MEXC_WS_PROXY / HTTPS_PROXY / WSS_PROXY) to bypass a region geo-block
(e.g. Jakarta -> contract.mexc.com/ws 301 -> /404).
"""
import os
import importlib

import pytest


@pytest.fixture(autouse=True)
def _no_env_ws(monkeypatch):
    # Isolate from any host env so the test is deterministic.
    for k in ("MEXC_WS_URL", "MEXC_WS_PROXY", "HTTPS_PROXY", "WSS_PROXY",
              "MEXC_API_KEY", "MEXC_SECRET"):
        monkeypatch.delenv(k, raising=False)


def _load():
    import sys
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
    return importlib.import_module("streaming.mexc_ws")


def test_default_ws_url_is_contract_mexc_edge():
    m = _load()
    ws = m.MexcWS("k", "s", ws_url=None)
    # Verified 2026-08-13: contract.mexc.com/ws 301->/404 (broken); the real
    # futures WS endpoint is /edge, reachable via the Cloudflare Worker or directly
    # outside ID. Default points at /edge.
    assert ws.ws_url == "wss://contract.mexc.com/edge"


def test_explicit_ws_url_override_used():
    m = _load()
    ws = m.MexcWS("k", "s", ws_url="wss://mexc-proxy.example.workers.dev/ws")
    assert ws.ws_url == "wss://mexc-proxy.example.workers.dev/ws"


def test_env_mexc_ws_url_override():
    m = _load()
    os.environ["MEXC_WS_URL"] = "wss://worker.dev/ws"
    try:
        ws = m.MexcWS("k", "s", ws_url=None)
        assert ws.ws_url == "wss://worker.dev/ws"
    finally:
        os.environ.pop("MEXC_WS_URL", None)


def test_from_env_picks_up_worker_url_and_proxy():
    m = _load()
    os.environ["MEXC_API_KEY"] = "ak"
    os.environ["MEXC_SECRET"] = "sk"
    os.environ["MEXC_WS_URL"] = "wss://mexc-proxy.x.workers.dev/ws"
    os.environ["MEXC_WS_PROXY"] = "http://proxy.internal:8080"
    try:
        ws = m.MexcWS.from_env()
        assert ws.ws_url == "wss://mexc-proxy.x.workers.dev/ws"
        assert ws.proxy == "http://proxy.internal:8080"
    finally:
        for k in ("MEXC_API_KEY", "MEXC_SECRET", "MEXC_WS_URL", "MEXC_WS_PROXY"):
            os.environ.pop(k, None)


def test_https_proxy_env_fallback():
    m = _load()
    os.environ["HTTPS_PROXY"] = "http://corp:3128"
    try:
        ws = m.MexcWS("k", "s", ws_url=None)
        assert ws.proxy == "http://corp:3128"
    finally:
        os.environ.pop("HTTPS_PROXY", None)
