"""P3 T3.3 FastAPI Web UI (PRIMARY surface) + WebSocket event stream + Telegram
channel binding. Serves live status/positions/trades/shadow + a dashboard page with
charts. WS /ws/events mirrors events to the browser. Telegram bot binds the same
channel for mobile alerts/commands (handled by notifier.bot + sources.telegram).
No network in tests: InMemoryEventBus + FakeExchange.
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from fastapi.testclient import TestClient
from web.app import create_app, EventBus


def _client():
    bus = EventBus()
    app = create_app(bus=bus, get_state=lambda: {
        "paper": 1, "bot": "mexc-fatty",
        "market": {"BTCUSDT": {"price": 60000.0, "ts": 1, "change24h": 1.2}},
        "positions": [
            {"symbol": "BTCUSDT", "direction": "LONG", "size": 0.001,
             "entry": 60000.0, "liq_price": 54000.0, "pnl": 1.5}],
        "balance": {"equity": 1000.0},
        "open_orders": [],
        "equity_history": [{"ts": 1, "equity": 1000.0}],
        "pnl_history": [{"ts": 1, "pnl": 1.5}],
        "stats": {"total_trades": 1, "wins": 1, "losses": 0, "win_rate": 100.0,
                  "net_pnl": 1.5, "profit_factor": 1.0, "expectancy": 1.5,
                  "max_drawdown": 0.0, "avg_hold": 0.0, "open_positions": 1,
                  "balance": 1000.0, "equity": 1000.0},
        "logs": [{"ts": 1, "type": "fill", "data": {"pair": "BTCUSDT"}}],
        "activities": [{"ts": 1, "type": "fill", "data": {"pair": "BTCUSDT"}}],
        "health": {"ts": 1, "poll_interval": 5.0},
    })
    return TestClient(app), bus


def test_status_endpoint():
    c, _ = _client()
    r = c.get("/api/status")
    assert r.status_code == 200
    assert r.json()["paper"] == 1


def test_positions_endpoint():
    c, _ = _client()
    r = c.get("/api/positions")
    assert r.status_code == 200
    assert r.json()[0]["symbol"] == "BTCUSDT"


def test_trades_and_shadow_endpoints():
    c, _ = _client()
    assert c.get("/api/trades").status_code == 200
    assert c.get("/api/shadow").status_code == 200
    assert c.get("/api/shadow").json()["total_trades"] == 1


def test_dashboard_page_renders():
    c, _ = _client()
    r = c.get("/")
    assert r.status_code == 200
    assert "mexc-listener" in r.text.lower()


def test_state_includes_spark_and_ws_feed_flag():
    # The real DashboardState snapshot must expose spark + ws_feed_live (Item 4/5b).
    from web.dashboard_state import DashboardState
    from web.app import EventBus
    ds = DashboardState(EventBus(), poll_interval=5.0)
    snap = ds.snapshot()
    assert "spark" in snap
    assert "ws_feed_live" in snap
    assert snap["ws_feed_live"] is False


def test_ws_event_stream_broadcasts():
    c, bus = _client()
    with c.websocket_connect("/ws/events") as ws:
        bus.publish({"type": "FILL", "pair": "BTCUSDT", "price": 60000.0})
        msg = ws.receive_json()
        assert msg["type"] == "FILL"
        assert msg["pair"] == "BTCUSDT"


def test_health_endpoint():
    c, _ = _client()
    assert c.get("/api/health").status_code == 200
