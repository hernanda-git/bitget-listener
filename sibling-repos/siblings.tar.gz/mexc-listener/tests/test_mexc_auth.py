"""T0.2 MexcAuth tests — MEXC signs accessKey + Request-Time(ms) + paramString.

Must NOT match Bybit (timestamp+apiKey+recvWindow+body) or Binance (querystring
with X-MBX-APIKEY). Verified against MEXC documented signing model
(MEXC_FEATURE_MINING §1.1).
"""
import sys, os, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from exchanges.mexc_auth import MexcAuth


def _auth():
    return MexcAuth(api_key="mx_a", secret="mx_s")


def test_sign_string_contains_access_key_and_timestamp_and_params():
    auth = _auth()
    ts = "1611038237237"
    param_string = "symbol=BTCUSDT&price=60000"
    sig = auth.sign(param_string, ts)
    # signature is a stable HMAC-SHA256 hex of "apiKey+ts+paramString"
    import hmac, hashlib
    expected = hmac.new(b"mx_s", (f"mx_a{ts}{param_string}").encode(), hashlib.sha256).hexdigest()
    assert sig == expected


def test_get_headers_shape_and_values():
    auth = _auth()
    ts = str(int(time.time() * 1000))
    headers = auth.get_headers(ts, param_string="symbol=BTCUSDT")
    assert headers["ApiKey"] == "mx_a"
    assert headers["Request-Time"] == ts
    assert "Signature" in headers
    # signature built from accessKey + Request-Time + paramString
    import hmac, hashlib
    assert headers["Signature"] == hmac.new(
        b"mx_s", (f"mx_a{ts}symbol=BTCUSDT").encode(), hashlib.sha256
    ).hexdigest()


def test_sort_query_params_for_get():
    auth = _auth()
    # GET params are sorted lexicographically and joined with &
    params = {"symbol": "BTCUSDT", "open": "1", "a": "z"}
    assert auth.build_param_string(params) == "a=z&open=1&symbol=BTCUSDT"


def test_post_param_string_is_json_body():
    auth = _auth()
    body = '{"symbol":"BTCUSDT","vol":1}'
    assert auth.build_param_string(body) == body  # POST uses raw JSON body, no sort
