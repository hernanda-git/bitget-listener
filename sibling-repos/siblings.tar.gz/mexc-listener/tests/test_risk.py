"""P1 T1.5 FixedRiskSizer (fee-aware). net = gross - (open_fee + close_fee).

CONCRETE-SPEC §4 single-source fee model: maker 0.0002 / taker 0.0005 (VIP0).
Sizer derives qty from a USD risk budget / (entry - sl) distance, then applies
fees so the REAL risk stays within budget. No LLM.
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from services.risk import FixedRiskSizer, FeeModel


def _sizer():
    fees = FeeModel(maker=0.0002, taker=0.0005)
    return FixedRiskSizer(risk_per_trade_usd=5.0, fees=fees, max_position_usd=100.0)


def test_size_derives_qty_from_risk_distance():
    s = _sizer()
    # distance = 1000; raw units = 5/1000 = 0.005; notional 0.005*60000 = 300 > max(100)
    # -> capped to max_position_usd/price = 100/60000 = 0.0016667
    qty = s.size(pair="BTCUSDT", entry=60000.0, sl=59000.0, price=60000.0, leverage=10)
    assert abs(qty - (100.0 / 60000.0)) < 1e-9


def test_size_respects_risk_budget_when_small():
    s = _sizer()
    # wide SL -> small notional, no cap; raw units = 5/10000 = 0.0005; notional=30 <= 100
    qty = s.size(pair="BTCUSDT", entry=60000.0, sl=50000.0, price=60000.0, leverage=10)
    assert abs(qty - 0.0005) < 1e-9


def test_size_caps_at_max_position():
    s = _sizer()
    qty = s.size(pair="BTCUSDT", entry=60000.0, sl=59900.0, price=60000.0, leverage=10)
    # tight SL -> large raw units; capped by max_position_usd
    notional = qty * 60000.0
    assert notional <= 100.0 + 1e-6


def test_fee_model_net_after_fees():
    fees = FeeModel(maker=0.0002, taker=0.0005)
    gross = 300.0
    qty = 0.005
    price = 60000.0
    net = fees.net(gross, qty, price)
    expected_open = qty * price * fees.taker
    expected_close = qty * price * fees.taker
    assert abs(net - (gross - expected_open - expected_close)) < 1e-6


def test_sizer_raises_on_bad_sl():
    s = _sizer()
    try:
        s.size("BTCUSDT", 60000.0, 60000.0, 60000.0, 10)
        assert False, "should reject zero-distance SL"
    except ValueError:
        pass
