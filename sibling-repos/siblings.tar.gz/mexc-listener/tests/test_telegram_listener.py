"""Item 2 — Live Telegram listener for @fattyfatclub (TDD, zero network).

Tests the pure orchestration: a RawSignal (text + image bytes) is routed
  ENTER/CONDITIONAL -> Gate1 -> LLMBrain.decide -> Gate2 -> OrderService.enter
  MANAGEMENT        -> parse_management -> OrderService transform
Skipping/blocked signals must NOT place orders. The live Telethon network
client (events.NewMessage) is a thin adapter over this pure router.

No real Telegram / MEXC / LLM touched (FakeLLM, FakeMexcExchange, fake Gate1).

HANDOFF-CONTINUE "Next items" #2; DOCUMENTATION.md §2 item 2.
"""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from domain.model import RawSignal, SignalType  # noqa: E402
from sources.telegram import SignalRouter  # noqa: E402


class _FakeExchange:
    """FakeMexcExchange-shaped; records placed orders."""

    def __init__(self):
        self.orders = []
        self.positions = {}

    def place_order(self, req):
        self.orders.append(req)
        return {"order_id": f"o{len(self.orders)}"}

    def get_mark(self, symbol):
        return 100.0


class _FakeGate1:
    """Configurable Gate1 stub (returns ok unless told to block)."""

    def __init__(self, ok=True, reason="ok"):
        self.ok = ok
        self.reason = reason
        self.checked = None

    def check(self, message_id, pair, ts=None):
        self.checked = (message_id, pair)
        from services.validator import GateResult
        return GateResult(self.ok, self.reason)


class _FakeGate2:
    def __init__(self, ok=True, reason="ok", size_usd=10.0, leverage=10):
        self.ok = ok
        self.reason = reason
        self.size_usd = size_usd
        self.leverage = leverage

    def check(self, decision, open_positions, daily_loss_pct):
        from services.validator import GateResult
        if not self.ok:
            return GateResult(False, self.reason)
        return GateResult(True, "", leverage=self.leverage, size_usd=self.size_usd)


class _FakeOrderService:
    def __init__(self):
        self.enters = []
        self.sl_moves = []

    def enter(self, decision_id, pair, side, price, qty, leverage, sl, tps=(),
              order_type="LIMIT"):
        from services.order import OrderResult
        self.enters.append((decision_id, pair, side, price, qty, leverage, sl, tps,
                            order_type))
        return OrderResult(True, "ENTERED", ("x",))

    def modify_sl_to_entry(self, pair, new_sl):
        from services.order import OrderResult
        self.sl_moves.append((pair, new_sl))
        return OrderResult(True, "SL_MOVED")


class _FakeBrain:
    def __init__(self, decision):
        self._d = decision

    def decide(self, raw):
        return self._d


def _enter_decision(side="BUY", pair="BTCUSDT", entry=100.0, sl=95.0, tps=(110.0,),
                    lev=10):
    from domain.model import TradeDecision, Action, Direction
    return TradeDecision(action=Action.ENTER, pair=pair,
                         direction=Direction.LONG if side == "BUY" else Direction.SHORT,
                         entry=entry, sl=sl, tps=tps, leverage=lev,
                         confidence_pct=80, bias="", reason="x")


def _router(brain_decision, gate1_ok=True, gate1_reason="ok",
            gate2_ok=True, gate2_reason="ok", size_usd=10.0):
    from services.validator import RiskConfig
    ex = _FakeExchange()
    g1 = _FakeGate1(ok=gate1_ok, reason=gate1_reason)
    g2 = _FakeGate2(ok=gate2_ok, reason=gate2_reason, size_usd=size_usd)
    os_ = _FakeOrderService()
    brain = _FakeBrain(brain_decision)
    r = SignalRouter(ex, g1, g2, os_, brain, RiskConfig())
    return r, ex, g1, g2, os_


def test_enter_signal_routes_to_order_service():
    r, ex, g1, g2, os_ = _router(_enter_decision())
    raw = RawSignal(message_id=1, channel="fattyfatclub", text="$BTC LONG entry 100 sl 95 tp 110",
                    images=(b"imgbytes",))
    res = r.handle(raw)
    assert res["placed"] is True
    assert len(os_.enters) == 1
    dec_id, pair, side, price, qty, lev, sl, tps, otype = os_.enters[0]
    assert pair == "BTCUSDT" and side == "BUY" and price == 100.0
    assert sl == 95.0 and tps == (110.0,) and otype == "LIMIT"


def test_skip_decision_does_not_place():
    from domain.model import TradeDecision, Action
    d = TradeDecision(action=Action.SKIP, pair="", direction=None)
    r, ex, g1, g2, os_ = _router(d)
    raw = RawSignal(message_id=2, channel="fattyfatclub", text="noise", images=())
    res = r.handle(raw)
    assert res["placed"] is False
    assert len(os_.enters) == 0


def test_gate1_blocks_before_llm():
    r, ex, g1, g2, os_ = _router(_enter_decision(), gate1_ok=False,
                                 gate1_reason="pair not whitelisted")
    raw = RawSignal(message_id=3, channel="fattyfatclub", text="$BTC LONG", images=())
    res = r.handle(raw)
    assert res["placed"] is False
    assert "whitelist" in res["reason"]
    assert len(os_.enters) == 0  # LLM/order never reached


def test_gate2_blocks_after_llm():
    r, ex, g1, g2, os_ = _router(_enter_decision(), gate2_ok=False,
                                 gate2_reason="size < min_notional")
    raw = RawSignal(message_id=4, channel="fattyfatclub", text="$BTC LONG", images=())
    res = r.handle(raw)
    assert res["placed"] is False
    assert len(os_.enters) == 0


def test_management_sl_to_entry_transforms():
    r, ex, g1, g2, os_ = _router(_enter_decision())
    raw = RawSignal(message_id=5, channel="fattyfatclub",
                    text="$BTC sl to entry", images=())
    res = r.handle(raw)
    # MANAGEMENT fast path (no LLM): OrderService.modify_sl_to_entry
    assert res.get("management") == "SL_TO_ENTRY"
    assert len(os_.sl_moves) == 1
    assert os_.sl_moves[0][0] == "BTCUSDT"


def test_management_full_close_transforms():
    from sources.parser import parse_management
    from domain.model import TradeDecision, Action, Direction
    r, ex, g1, g2, os_ = _router(
        TradeDecision(action=Action.MANAGEMENT, pair="BTCUSDT",
                      direction=Direction.LONG))
    raw = RawSignal(message_id=6, channel="fattyfatclub",
                    text="$BTC full close", images=())
    res = r.handle(raw)
    assert res.get("management") == "FULL_CLOSE"


def test_image_bytes_passed_to_brain():
    captured = {}

    class _CapBrain(_FakeBrain):
        def decide(self, raw):
            captured["images"] = raw.images
            return self._d

    from services.validator import RiskConfig
    ex = _FakeExchange(); g1 = _FakeGate1(); g2 = _FakeGate2()
    os_ = _FakeOrderService(); brain = _CapBrain(_enter_decision())
    r = SignalRouter(ex, g1, g2, os_, brain, RiskConfig())
    # Ambiguous/conditional text the deterministic parser cannot resolve into a
    # clean ENTRY, so it falls through to the LLM path (which must still receive
    # the raw image bytes).
    raw = RawSignal(message_id=7, channel="fattyfatclub",
                    text="BTC looks bullish if it breaks above 100",
                    images=(b"chartbytes",))
    r.handle(raw)
    assert captured["images"] == (b"chartbytes",)
