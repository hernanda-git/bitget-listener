"""P1 T1.4 OrderService: entry LIMIT (no reduce_only) + SL/TP stop.order (reduce_only).

CONCRETE-SPEC §6: entry opening order never carries reduce_only; protective orders
carry reduce_only=true + timeInForce=GTC + both stopPrice and price. NEVER auto-
cancel reduce_only protective orders (BUG C fix). Idempotent dedup via IdempotencyGuard.
Deterministic repair on -1111/-4164 (no LLM).
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from services.order import OrderService, OrderResult
from exchanges.repair import IdempotencyGuard, DecisionStore
from domain.model import OrderRequest, Side


class _Store(DecisionStore):
    def __init__(self):
        self._ids = set()
        self._active = {}
    def get_active_for_decision(self, decision_id, side):
        st = self._active.get(decision_id)
        return st if st else None
    def mark_client_order_id(self, c):
        if c in self._ids:
            return False
        self._ids.add(c)
        return True
    def mark_active(self, decision_id):
        self._active[decision_id] = ["FILLED"]


def _svc(paper: bool = False):
    ex = _FakeExchange()
    guard = IdempotencyGuard(_Store())
    return OrderService(ex, guard, paper=paper), ex


class _FakeExchange:
    def __init__(self):
        self.placed = []
        self.canceled = []
    def place_order(self, req: OrderRequest):
        self.placed.append(req)
        return {"success": True, "code": 0, "order_id": "o"+str(len(self.placed))}
    def cancel_order(self, symbol, order_id):
        self.canceled.append(order_id)
        return True


def test_entry_order_not_reduce_only():
    svc, ex = _svc()
    res = svc.enter(decision_id="d1", pair="BTCUSDT", side="BUY", price=60000.0,
                    qty=0.001, leverage=10, sl=59000.0, tps=(63000.0,))
    assert res.ok is True
    entry = [o for o in ex.placed if o.order_type == "LIMIT" and not o.reduce_only]
    assert entry, "entry LIMIT must exist and not be reduce_only"
    assert all(o.reduce_only is False for o in entry)


def test_sl_tp_are_reduce_only_conditional():
    svc, ex = _svc()
    svc.enter(decision_id="d2", pair="BTCUSDT", side="BUY", price=60000.0,
              qty=0.001, leverage=10, sl=59000.0, tps=(63000.0, 65000.0))
    prot = [o for o in ex.placed if o.reduce_only]
    # 1 SL + 2 TP = 3 protective reduce_only orders
    assert len(prot) == 3
    assert all(o.time_in_force == "GTC" for o in prot)
    assert all(o.stop_price is not None for o in prot)


def test_dedup_prevents_duplicate_entry():
    svc, ex = _svc()
    svc.enter("d3", "BTCUSDT", "BUY", 60000.0, 0.001, 10, 59000.0, (63000.0,))
    res2 = svc.enter("d3", "BTCUSDT", "BUY", 60000.0, 0.001, 10, 59000.0, (63000.0,))
    assert res2.ok is False and res2.status == "DUPLICATE_SKIPPED"


def test_never_auto_cancel_protective():
    svc, ex = _svc()
    svc.enter("d4", "BTCUSDT", "BUY", 60000.0, 0.001, 10, 59000.0, (63000.0,))
    # management 'sl to entry' must MOVE SL, not cancel protective
    res = svc.modify_sl_to_entry("BTCUSDT", new_sl=60000.0)
    assert res.ok is True
    # the original protective SL must NOT be in the canceled list
    assert not ex.canceled, "protective orders must never be auto-canceled"


def test_paper_mode_never_calls_exchange():
    """Hard safety gate: in paper mode, enter() must NOT place any real order."""
    svc, ex = _svc(paper=True)
    res = svc.enter("d5", "BTCUSDT", "BUY", 60000.0, 0.001, 10, 59000.0, (63000.0,))
    assert res.ok is True
    assert res.status == "PAPER_ENTERED"
    assert not ex.placed, "paper mode must issue zero real orders"
    # simulated IDs are clearly marked PAPER-
    assert all(str(i).startswith("PAPER-") for i in res.order_ids)


def test_paper_mode_sl_move_never_calls_exchange():
    svc, ex = _svc(paper=True)
    res = svc.modify_sl_to_entry("BTCUSDT", new_sl=60000.0)
    assert res.ok is True and res.status == "PAPER_SL_MOVED"
    assert not ex.placed
