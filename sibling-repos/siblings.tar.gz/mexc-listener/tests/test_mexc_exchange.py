"""T0.3 + T1.2 MexcExchange REST skeleton + instruments cache + rounding.

Rounding guards (Edge C, CONCRETE-SPEC §5):
- round_price: step DOWN to tickSize; clamp UP to minPrice ONLY if minPrice <= rounded*10
  (never inflate a $0.16 coin to $100).
- round_qty: step to lotSize; loop up until qty*price >= minNotional (seed minNotional/price).
No network: tested against a FakeExchange that returns a fixed instruments dict.
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from exchanges.mexc import MexcExchange, FakeMexcExchange
from exchanges.mexc_auth import MexcAuth


def _fake() -> FakeMexcExchange:
    return FakeMexcExchange(api_key="k", secret="s")


def test_instruments_cache_populated():
    ex = _fake()
    inst = ex.get_instrument("BTCUSDT")
    assert inst.symbol == "BTCUSDT"
    assert inst.tick_size > 0
    assert inst.max_leverage >= 1


def test_get_instrument_1000x_uses_contract_size():
    ex = _fake()
    inst = ex.get_instrument("1000PEPEUSDT")
    assert inst.contract_size > 0  # multiplier handled in qty math


def test_round_price_steps_down_to_tick():
    ex = _fake()
    # BTC tick 0.1 -> 60000.16 rounds DOWN to 60000.1 (no float residue)
    assert ex.round_price("BTCUSDT", 60000.16) == 60000.1


def test_round_price_does_not_inflate_small_coin():
    ex = _fake()
    # APE-like coin: 0.162 is already >= minPrice 0.1 -> stays 0.162 (never $100)
    assert ex.round_price("APEUSDT", 0.162) == 0.162
    # A sub-minPrice price gets clamped UP to minPrice (within 10x), not inflated huge
    assert ex.round_price("APEUSDT", 0.05) == 0.1  # below minPrice -> clamp to 0.1
    # below-minPrice but the guard would never jump a tiny price to a large minPrice
    assert ex.round_price("APEUSDT", 0.05) < 1.0


def test_round_qty_meets_min_notional():
    ex = _fake()
    # DOGE-like: price 0.08, minNotional 5 -> qty must be >= ~62.5
    qty = ex.round_qty("DOGEUSDT", 1.0, price_ref=0.08)
    inst = ex.get_instrument("DOGEUSDT")
    assert qty * 0.08 >= inst.min_notional - 1e-9


def test_validate_order_rejects_bad_price_and_qty():
    ex = _fake()
    inst = ex.get_instrument("BTCUSDT")
    bad = ex.validate_order("BTCUSDT", "BUY", 60000.0, 0.0, inst)
    assert bad.ok is False
    good = ex.validate_order("BTCUSDT", "BUY", 60000.0, 0.001, inst)
    assert good.ok is True


def test_signing_used_on_request():
    ex = _fake()
    # GET /contract/order/open uses signed headers
    headers = ex._auth.get_headers("1000", param_string="symbol=BTCUSDT")
    assert headers["ApiKey"] == "k"
    assert "Signature" in headers
