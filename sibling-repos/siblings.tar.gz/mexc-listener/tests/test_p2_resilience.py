"""P2 T2.2 dead-man watchdog: MEXC has no native scheduleCancel. If heartbeat TTL
lapses (WS dead / process stalled) in LIVE mode, cancel all open orders. T2.3
ban-aware backoff: on rate-limit, back off instead of hammering. T2.4 mark cache:
single batched refresh, stale-served while banned. T2.5 1000x/contract-multiplier
symbol map. No LLM, no network (fakes)."""
import sys, os, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from services.deadman import DeadManWatchdog
from exchanges.ws_stream import BanBackoff
from exchanges.mark_cache import MarkCache
from sources.symbol_map import ContractMultiplierMap


def test_deadman_triggers_on_heartbeat_timeout_live():
    fired = []
    wd = DeadManWatchdog(ttl_s=60, on_stale=lambda: fired.append(1), live=True)
    wd.beat()
    # simulate time passing beyond TTL
    assert wd.check(now=int(time.time()) + 120) is True
    assert fired == [1]


def test_deadman_no_fire_when_recent_beat():
    wd = DeadManWatchdog(ttl_s=60, on_stale=lambda: None, live=True)
    wd.beat()
    assert wd.check(now=int(time.time()) + 10) is False


def test_deadman_no_fire_in_paper_mode():
    fired = []
    wd = DeadManWatchdog(ttl_s=60, on_stale=lambda: fired.append(1), live=False)
    wd.beat()
    assert wd.check(now=int(time.time()) + 120) is False
    assert fired == []


def test_ban_backoff_increases_then_caps():
    b = BanBackoff(base_s=5, max_s=60)
    assert b.next_wait() == 5
    b.note_ban()
    assert b.next_wait() == 10
    for _ in range(20):
        b.note_ban()
    assert b.next_wait() <= 60


def test_ban_backoff_resets_on_success():
    b = BanBackoff(base_s=5, max_s=60)
    b.note_ban(); b.note_ban()
    b.note_success()
    assert b.next_wait() == 5


def test_mark_cache_refresh_and_stale_serve():
    calls = {"n": 0}
    def fetcher(symbol):
        calls["n"] += 1
        return 60000.0
    mc = MarkCache(fetcher, ttl_s=30)
    assert mc.get("BTCUSDT") == 60000.0
    assert mc.get("BTCUSDT") == 60000.0  # served from cache, no 2nd fetch
    assert calls["n"] == 1
    # force expire
    mc._ts["BTCUSDT"] = 0
    assert mc.get("BTCUSDT") == 60000.0
    assert calls["n"] == 2


def test_contract_multiplier_map_resolves_1000x():
    m = ContractMultiplierMap({"1000PEPEUSDT": 1000.0, "BTCUSDT": 1.0})
    assert m.multiplier("1000PEPEUSDT") == 1000.0
    assert m.multiplier("BTCUSDT") == 1.0
    # qty math: contract_size scales the order qty
    assert m.scale_qty("1000PEPEUSDT", 1.0) == 1000.0
