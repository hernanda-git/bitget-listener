"""Item 6 — Telegram bot commands /status /balance /positions /live /paper (TDD).

Tests the command-handler logic (pure text builders + GoLiveGate wiring) without
a live Telegram socket:
- cmd_status / cmd_positions render state pulled from get_state()
- cmd_balance renders a "balance" view (paper/live + equity placeholder)
- cmd_paper forces paper=1 (safe); cmd_live requires the one-time token AND the
  hard gates (shadow expectancy>0 + tests green + probe green) via GoLiveGate
- MarkdownV2 escaping is applied so Telegram never crashes on symbols/numbers

HANDOFF-CONTINUE "Next items" #6; DOCUMENTATION.md §2 item 6.
"""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from notifier.bot import CommandHandler, GoLiveGate, _md_escape  # noqa: E402


def _state(paper=1):
    return {
        "paper": paper, "bot": "mexc-fatty",
        "positions": [{"symbol": "BTCUSDT", "direction": "LONG", "entry": 60000.0,
                       "pnl": 1.0}],
        "trades": [{"pnl": 1.0}, {"pnl": -0.5}],
        "shadow": [{"pair": "BTCUSDT", "winrate": 0.6, "flag": False}],
        "health": {},
    }


def test_status_renders_mode_and_positions():
    h = CommandHandler(get_state=lambda: _state(0))
    out = h.cmd_status()
    assert "LIVE" in out and "BTCUSDT" in out and "60000" in out


def test_positions_lists_open_positions():
    h = CommandHandler(get_state=lambda: _state(1))
    out = h.cmd_positions()
    assert "BTCUSDT" in out and "60000" in out and "LONG" in out


def test_balance_renders_mode_and_equity():
    h = CommandHandler(get_state=lambda: _state(1))
    out = h.cmd_balance()
    assert "PAPER" in out
    assert "equity" in out.lower() or "pnl" in out.lower()


def test_md_escape_used_in_output():
    # the handler's _md_escape keeps Telegram from crashing on special chars
    assert _md_escape("BTC price *up* (win)") == "BTC price \\*up\\* \\(win\\)"
    h = CommandHandler(get_state=lambda: _state())
    # no exception building a card containing special chars
    assert isinstance(h.cmd_status(), str)


def test_paper_command_forces_paper_and_is_safe():
    golive = _FakeGoLive()
    h = CommandHandler(get_state=lambda: _state(0), golive_store=golive)
    out = h.cmd_paper()
    assert golive.set_paper_calls == [("mexc-fatty", 1)]
    assert "PAPER" in out


def test_live_command_requires_token_and_gates():
    golive = _FakeGoLive()
    gate = GoLiveGate(golive)
    h = CommandHandler(get_state=lambda: _state(1), golive_store=golive, gate=gate,
                       shadow_expectancy=0.3, tests_green=False, probe_green=False)
    # no token -> blocked
    out = h.cmd_live("")
    assert "token" in out.lower()
    assert golive.set_paper_calls == []  # not flipped
    # wrong token -> blocked
    out = h.cmd_live("wrong")
    assert golive.set_paper_calls == []
    # correct token but gates not all green -> blocked
    golive.token = "tok-9"
    out = h.cmd_live("tok-9")
    assert golive.set_paper_calls == []
    # correct token + all green -> flips live
    h2 = CommandHandler(get_state=lambda: _state(1), golive_store=golive, gate=gate,
                         shadow_expectancy=0.3, tests_green=True, probe_green=True)
    out = h2.cmd_live("tok-9")
    assert golive.set_paper_calls == [("mexc-fatty", 0)]
    assert "LIVE" in out


class _FakeGoLive:
    def __init__(self):
        self.token = None
        self.set_paper_calls = []
        self.set_token_calls = []
    def get(self, bot):
        return {"paper": 1, "go_live_token": self.token}
    def set_paper(self, bot, val):
        self.set_paper_calls.append((bot, val))
    def set_token(self, bot, tok):
        self.set_token_calls.append((bot, tok))
        self.token = tok


class _FakeGate:
    def __init__(self, store, green=False):
        self.store = store
        self.green = green
        self.activate_calls = []
    def mint(self, bot):
        self.store.token = "tok-9"
        return "tok-9"
    def activate(self, bot, token, shadow_expectancy=0, tests_green=False,
                 probe_green=False):
        self.activate_calls.append((bot, token))
        # only true when green flag (simulates all gates passing)
        return self.green and token == self.store.token
