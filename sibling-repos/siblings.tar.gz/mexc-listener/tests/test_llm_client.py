"""Item 3 — OpenCodeLLM client tests (TDD, zero network via fake httpx)."""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

import pytest

from llm.client import OpenCodeLLM  # noqa: E402


class _FakeResp:
    def __init__(self, payload):
        self._payload = payload
    def raise_for_status(self):
        pass
    def json(self):
        return self._payload


class _FakeClient:
    def __init__(self):
        self.last = None
    def post(self, url, headers=None, json=None):
        self.last = {"url": url, "headers": headers, "json": json}
        return _FakeResp({"choices": [{"message": {"content": '{"action":"SKIP"}'}}]})
    def close(self):
        pass


def test_chat_posts_to_completions_and_returns_content():
    fc = _FakeClient()
    c = OpenCodeLLM(base_url="https://llm.example/v1", api_key="k",
                    model="deepseek-v4-flash-free", client=fc)
    out = c.chat([{"role": "user", "content": "hi"}], "deepseek-v4-flash-free",
                 1024, 0.0)
    assert out == '{"action":"SKIP"}'
    assert fc.last["url"].endswith("/chat/completions")
    assert fc.last["headers"]["Authorization"] == "Bearer k"
    assert fc.last["json"]["model"] == "deepseek-v4-flash-free"
    assert fc.last["json"]["max_tokens"] == 1024


def test_chat_uses_default_model_from_env(monkeypatch):
    monkeypatch.setenv("LLM_MODEL", "deepseek-v4-flash-free")
    fc = _FakeClient()
    c = OpenCodeLLM(base_url="https://llm.example/v1", api_key="k", client=fc)
    c.chat([{"role": "user", "content": "x"}], "deepseek-v4-flash-free", 10, 0.0)
    assert fc.last["json"]["model"] == "deepseek-v4-flash-free"


def test_chat_raises_when_base_url_missing():
    c = OpenCodeLLM(base_url="", api_key="", client=_FakeClient())
    with pytest.raises(RuntimeError):
        c.chat([], "m", 1, 0.0)
