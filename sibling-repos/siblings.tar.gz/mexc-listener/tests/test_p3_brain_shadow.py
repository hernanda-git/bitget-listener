"""P3 T3.1 LLM brain (OpenAI-compat, deepseek-v4-flash-free): vision on chart image
attachments + text parser for ambiguous/conditional signals; emits structured
TradeDecision. T3.2 ShadowLedger (Edge B): per-pair win-rate, flag + (opt) downsize.

No network in tests: FakeLLM returns a canned structured decision; FakeEvalStore.
"""
import sys, os, json
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from llm.brain import LLMBrain, FakeLLM, build_messages
from domain.model import RawSignal, TradeDecision, Action, Direction
from eval.shadow_ledger import ShadowLedger, EvalStore


def test_build_messages_includes_text_and_image():
    raw = RawSignal(message_id=1, channel="fattyfatclub", text="$BTC LONG entry 60k",
                    images=(b"\x89PNG",))
    msgs = build_messages(raw)
    # system + user text + image content part present
    assert any(m["role"] == "system" for m in msgs)
    user = [m for m in msgs if m["role"] == "user"][0]
    content = user["content"]
    assert isinstance(content, list)
    assert any(c.get("type") == "image_url" for c in content)


def test_llm_brain_parses_structured_decision():
    fake = FakeLLM(json_reply=json.dumps({
        "action": "ENTER", "pair": "BTCUSDT", "direction": "LONG",
        "entry": 60000.0, "sl": 59000.0, "tps": [63000.0], "leverage": 10,
        "confidence_pct": 82.0, "bias": "bullish", "reason": "text+chart agree"}))
    brain = LLMBrain(client=fake, model="deepseek-v4-flash-free")
    raw = RawSignal(1, "fattyfatclub", "$BTC LONG", images=(b"img",))
    d = brain.decide(raw)
    assert isinstance(d, TradeDecision)
    assert d.action is Action.ENTER
    assert d.pair == "BTCUSDT"
    assert d.direction is Direction.LONG
    assert d.confidence_pct == 82.0


def test_llm_brain_resolves_ambiguous_signal():
    fake = FakeLLM(json_reply=json.dumps({
        "action": "ENTER", "pair": "SOLUSDT", "direction": "SHORT",
        "entry": 150.0, "sl": 155.0, "tps": [140.0], "leverage": 5,
        "confidence_pct": 70.0, "bias": "bearish", "reason": "ambiguous resolved"}))
    brain = LLMBrain(client=fake, model="x")
    d = brain.decide(RawSignal(2, "fattyfatclub", "maybe short sol? not sure"))
    assert d.action is Action.ENTER
    assert d.direction is Direction.SHORT


class _Eval(EvalStore):
    def __init__(self): self.rows = {}
    def record(self, pair, win): self.rows.setdefault(pair, []).append(win)
    def get(self, pair): return self.rows.get(pair, [])


def test_shadow_ledger_winrate_and_flag():
    ledger = ShadowLedger(_Eval(), min_trades=3, poor_winrate=0.5)
    for _ in range(5):
        ledger.record("SHIBUSDT", win=False)
    rec = ledger.rating("SHIBUSDT")
    assert rec.trades == 5
    assert rec.winrate == 0.0
    assert rec.flag is True  # poor winrate -> flag


def test_shadow_ledger_downsize_behind_flag():
    store = _Eval(); ledger = ShadowLedger(store, min_trades=3, poor_winrate=0.5,
                                            auto_downsize=False)
    for _ in range(5): ledger.record("SHIBUSDT", win=False)
    # auto_downsize off -> size multiplier stays 1.0
    assert ledger.size_multiplier("SHIBUSDT") == 1.0
    ledger.auto_downsize = True
    assert ledger.size_multiplier("SHIBUSDT") == 0.5


def test_shadow_ledger_not_flagged_when_trusted_and_good():
    ledger = ShadowLedger(_Eval(), min_trades=3, poor_winrate=0.5)
    for _ in range(5): ledger.record("BTCUSDT", win=True)
    rec = ledger.rating("BTCUSDT")
    assert rec.winrate == 1.0
    assert rec.flag is False
