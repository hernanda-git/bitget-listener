"""Item 5 — MexcWS live connect() loop + jittered reconnect + dispatch (TDD).

Tests the live socket loop logic without a real socket:
- _dispatch routes order.deal -> on_fill (fee-aware), position -> on_position
  (real liq price), order -> on_order
- on_heartbeat is called on ping/pong so the dead-man watchdog can reset its TTL
- connect() reconnects with jittered backoff on socket close and respects a
  max-retries cap; the loop is exercised with a FakeWebSocket (no network)

CONCRETE-SPEC §6; HANDOFF-CONTINUE "Next items" #5.
"""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from streaming.mexc_ws import MexcWS, parse_fill, parse_position  # noqa: E402
import streaming.mexc_ws as mws  # noqa: E402


def test_dispatch_routes_fill_and_position():
    fills, positions, orders, hearts = [], [], [], []

    def on_fill(f): fills.append(f)
    def on_position(p): positions.append(p)
    def on_order(o): orders.append(o)
    def on_heartbeat(): hearts.append(1)

    ws = MexcWS("k", "s", "wss://x", on_fill=on_fill, on_position=on_position,
                on_order=on_order, on_heartbeat=on_heartbeat)
    ws._dispatch({"channel": "push.personal.order.deal", "data": {
        "symbol": "BTC_USDT", "side": "BUY", "price": "60000", "vol": "0.01",
        "fee": "0.5", "feeCoin": "USDT", "ts": "1000", "orderId": "d-E",
        "pnl": "2.0"}})
    ws._dispatch({"channel": "push.personal.position", "data": {
        "symbol": "BTC_USDT", "positionType": "LONG", "holdVol": "0.01",
        "holdAvgPrice": "60000", "leverage": "10", "liquidatePrice": "54000",
        "pnl": "1.0", "margin": "6.0", "markPrice": "61000"}})
    ws._dispatch({"channel": "push.personal.order", "data": {"orderId": "o1"}})
    ws._dispatch({"channel": "pong", "data": {}})

    assert len(fills) == 1 and fills[0].symbol == "BTCUSDT" and fills[0].fee == 0.5
    assert fills[0].pnl == 2.0  # realized pnl on a closing fill is captured
    assert len(positions) == 1 and positions[0].liq_price == 54000.0
    assert len(orders) == 1
    assert len(hearts) == 1


def test_dispatch_heartbeat_on_ping_pong():
    hearts = []
    ws = MexcWS("k", "s", "wss://x", on_heartbeat=lambda: hearts.append(1))
    # both ping and pong reset the watchdog
    ws._dispatch({"channel": "ping", "data": {}})
    ws._dispatch({"channel": "pong", "data": {}})
    assert len(hearts) == 2


def test_connect_reconnects_with_jitter_and_caps():
    # FakeWebSocket: an async context manager. The first session delivers a
    # login ack + one fill then raises ConnectionError (server closed); each
    # subsequent session immediately raises, so connect() exhausts max_retries.
    class FakeWebSocket:
        instances = []

        def __init__(self, url, **kw):
            FakeWebSocket.instances.append(self)
            self.url = url
            self.sent = []
            self._open_count = len(FakeWebSocket.instances)
            self._i = 0

        async def __aenter__(self):
            if self._open_count > 1:
                raise ConnectionError("refused after first")
            return self

        async def __aexit__(self, *a):
            pass

        async def send(self, payload):
            self.sent.append(payload)

        async def recv(self):
            self._i += 1
            if self._i == 1:
                return '{"channel":"login","data":{"success":true}}'
            if self._i == 2:
                return ('{"channel":"push.personal.order.deal","data":'
                        '{"symbol":"BTC_USDT","side":"BUY","price":"1","vol":"1",'
                        '"fee":"0.1","feeCoin":"USDT","ts":"1","orderId":"x"}}')
            raise ConnectionError("server closed")

    fills = []
    ws = MexcWS("k", "s", "wss://x", on_fill=lambda f: fills.append(f))
    ws._sleep = lambda s: None  # deterministic, fast
    n = ws.connect(websocket_class=FakeWebSocket, max_retries=3,
                   login_builder=lambda: {"method": "login"})
    # first session delivered 1 fill; reconnect attempts then cap out at 3 retries
    assert len(fills) == 1
    assert n == 4  # 1 successful session + 3 reconnect attempts (max_retries)


def test_jittered_backoff_bounds():
    # backoff should be capped and never negative
    vals = [mws._jittered_backoff(i) for i in range(8)]
    assert all(v >= 0 for v in vals)
    assert all(v <= 30 for v in vals)  # cap
    # increasing attempt -> non-decreasing base trend (with jitter tolerance)
    assert vals[5] >= vals[1] - 1.0
