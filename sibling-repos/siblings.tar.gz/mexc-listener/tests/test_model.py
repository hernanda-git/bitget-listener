"""T0.1 domain model tests (no network, no exchange)."""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from domain.model import (
    Instrument, RawSignal, Signal, OrderRequest, Position, Fill, TradeDecision,
    Side, Direction, SignalType, Action,
)


def test_instrument_to_ws_symbol():
    inst = Instrument(symbol="BTCUSDT", base="BTC")
    assert inst.to_ws_symbol() == "BTC_USDT"
    inst2 = Instrument(symbol="1000PEPEUSDT", base="1000PEPE")
    assert inst2.to_ws_symbol() == "1000PEPE_USDT"


def test_fill_records_nonzero_fee():
    f = Fill(symbol="BTCUSDT", side=Side.BUY, fill_price=60000.0, qty=0.001, fee=0.012)
    assert f.fee != 0.0
    assert f.fee_asset == "USDT"


def test_position_liq_price_real_not_zero():
    p = Position(symbol="BTCUSDT", direction=Direction.LONG, size=0.001, entry=60000.0,
                 leverage=10, liq_price=54000.0)
    assert p.liq_price == 54000.0
    assert p.liq_price != 0.0


def test_entry_order_not_reduce_only():
    o = OrderRequest(symbol="BTCUSDT", side=Side.BUY, price=60000.0, qty=0.001,
                     order_type="LIMIT", reduce_only=False)
    assert o.reduce_only is False


def test_signal_peg_is_usdt_no_mismatch():
    s = Signal(pair="BTCUSDT", direction=Direction.LONG, entry=60000.0, sl=59000.0)
    assert s.pair.endswith("USDT")


def test_raw_signal_carries_images():
    r = RawSignal(message_id=1, channel="fattyfatclub", text="long btc", images=(b"\x89PNG",))
    assert len(r.images) == 1


def test_trade_decision_skip_action():
    d = TradeDecision(action=Action.SKIP, pair="BTCUSDT", direction=None)
    assert d.action is Action.SKIP
