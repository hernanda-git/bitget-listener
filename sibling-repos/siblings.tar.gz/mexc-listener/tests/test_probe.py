"""TDD tests for scripts/mexc_api_probe.py parse/classify logic.

These run with zero network (fakes only). They lock in the two real
behaviors the probe must have after the 2026-08-13 findings:

1. MEXC returns instruments keyed as `BTC_USDT` (underscore), NOT
   `BTCUSDT`. The probe must detect BTC coverage against the real shape.
2. When the WS host redirects/refuses, the probe must report a *clean*
   RED with the actual reason (redirect target / HTTP status) instead of
   crashing with a misleading `InvalidURI` exception. A trustworthy
   GREEN/RED is the whole point of the probe.
"""
import sys
import os
import types

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "scripts"))

import mexc_api_probe as probe


def test_parse_instruments_finds_btc_underscore():
    # Real MEXC /contract/detail shape: symbol field is "BTC_USDT".
    data = [
        {"symbol": "BTC_USDT"},
        {"symbol": "ETH_USDT"},
        {"symbol": "1000PEPE_USDT"},
    ]
    info = probe.parse_instruments(data)
    assert info["has_btc"] is True
    assert info["count"] == 3
    assert info["has_1000x"] is True


def test_parse_instruments_accepts_both_casings():
    data = [{"symbol": "BTCUSDT"}]  # also accept the no-separator form
    assert probe.parse_instruments(data)["has_btc"] is True


def test_parse_instruments_handles_empty_and_malformed():
    # No crash on empty / non-list / entries missing 'symbol'.
    assert probe.parse_instruments([])["has_btc"] is False
    assert probe.parse_instruments({"data": []})["has_btc"] is False
    assert probe.parse_instruments([{"foo": "bar"}, "junk"])["count"] == 0


def test_classify_ws_error_redirect_is_clean_red():
    # Simulate the real 301 -> https://www.mexc.com/404 from contract.mexc.com/ws.
    fake = types.SimpleNamespace(uri="https://www.mexc.com/404")
    err = probe.InvalidURI(fake) if hasattr(probe, "InvalidURI") else None
    # Build a minimal stand-in if websockets not importable in this path.
    if err is None:
        class _Inv(Exception):
            def __init__(self, ns):
                super().__init__("x")
                self.uri = ns.uri
        err = _Inv(fake)
    ok, detail = probe.classify_ws_error(err)
    assert ok is False
    assert "www.mexc.com/404" in detail


def test_classify_ws_error_invalid_status_reports_http_code():
    # Server rejects the handshake with an HTTP status (e.g. 403/404).
    resp = types.SimpleNamespace(status_code=403, headers={})
    class _InvStatus(Exception):
        def __init__(self, r):
            super().__init__("x")
            self.response = r
    err = _InvStatus(resp)
    ok, detail = probe.classify_ws_error(err)
    assert ok is False
    assert "403" in detail
