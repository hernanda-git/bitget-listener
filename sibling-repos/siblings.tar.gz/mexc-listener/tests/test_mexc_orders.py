"""Item 4 — MexcExchange real order/position/mark endpoints (TDD, fake boundary).

Tests the real order plumbing over `_signed_request` using a fake `_signed_request`
that records the exact path/params/body and returns a MEXC envelope. Confirms:
- place_order builds a LIMIT opening order (no reduce_only) and calls /api/v1/private/order/create
  with the MEXC contract shape: integer side (1=long/2=short), string price/vol,
  vol expressed in CONTRACTS (BTC contractSize=0.0001 -> 0.01 base = 100 contracts).
- close builds a reduce_only market close and calls /api/v1/private/order/submit
- stop builds a reduce_only plan order and calls /api/v1/private/order/submit
- get_position / get_mark parse MEXC responses into domain models
No real network; the FakeMexcExchange still overrides _signed_request.

HANDOFF-CONTINUE "Next items" #4; DOCUMENTATION.md §2 item 4.
"""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from exchanges.mexc import MexcExchange  # noqa: E402
from domain.model import Side, Position  # noqa: E402


class _RecordingExchange(MexcExchange):
    def __init__(self):
        super().__init__("k", "s")
        self.calls = []
        self._resp = {"success": True, "code": 0, "data": {"orderId": "X1"}}

    def _signed_request(self, method, path, params=None, body=None):
        self.calls.append((method, path, params, body))
        return dict(self._resp)


def test_place_order_opening_limit_calls_open_endpoint():
    ex = _RecordingExchange()
    res = ex.place_order(_order(Side.BUY, 60000.0, 0.01, order_type="LIMIT",
                                client_order_id="d-E"))
    assert res["order_id"] == "X1"
    method, path, params, body = ex.calls[-1]
    assert method == "POST" and path == "/api/v1/private/order/create"
    # opening order must NOT be reduce_only (field omitted for opens)
    assert "reduceOnly" not in body
    assert body.get("symbol") == "BTCUSDT"
    # MEXC contract shape: numeric price, vol in CONTRACTS (0.01 base / 0.0001 csize = 100)
    assert body.get("price") == 60000.0
    assert body.get("vol") == 100
    # integer side: 1 = open BUY / long
    assert body.get("side") == 1 and body.get("positionType") == 1
    assert body.get("type") == 1  # 1 = limit


def test_place_order_protective_stop_is_reduce_only():
    ex = _RecordingExchange()
    ex.place_order(_order(Side.SELL, 59000.0, 0.01, order_type="STOP",
                          reduce_only=True, stop_price=59000.0,
                          client_order_id="d-SL"))
    method, path, params, body = ex.calls[-1]
    assert path == "/api/v1/private/order/submit"
    assert body.get("reduceOnly") is True
    assert body.get("stopPrice") == 59000.0
    assert body.get("timeInForce") == "GTC"
    # protective order is the SAME side as the position (SELL -> side 2, positionType 2)
    assert body.get("side") == 2 and body.get("positionType") == 2


def test_close_calls_submit_endpoint():
    ex = _RecordingExchange()
    ex.close("BTCUSDT", Side.BUY, 0.01)
    method, path, params, body = ex.calls[-1]
    # MEXC closes via /order/submit with reduceOnly=True (opposite side).
    assert path == "/api/v1/private/order/submit"
    assert body.get("symbol") == "BTCUSDT"
    assert body.get("reduceOnly") is True
    # closing a SHORT (BUY) -> buy to close -> side 2 (close short), positionType 2
    # MEXC side: 1=open long, 2=close short, 3=open short, 4=close long
    assert body.get("side") == 2 and body.get("positionType") == 2
    assert body.get("type") == 2  # market close


def test_get_position_parses_open_positions():
    ex = _RecordingExchange()
    ex._resp = {"success": True, "code": 0, "data": [{
        "symbol": "BTCUSDT", "positionId": "p1", "openPrice": "60000.0",
        "holdVol": "0.01", "leverage": "10", "liquidatePrice": "54000.0",
        "positionType": 1, "margin": "6.0", "unrealizedPNL": "1.0",
    }]}
    pos = ex.get_position("BTCUSDT")
    assert isinstance(pos, Position)
    assert pos.symbol == "BTCUSDT" and pos.liq_price == 54000.0
    assert pos.entry == 60000.0 and pos.size == 0.01 and pos.leverage == 10


def test_get_mark_returns_price():
    ex = _RecordingExchange()
    # get_mark reads the public /contract/ticker endpoint (lastPrice field).
    class _StubResp:
        status_code = 200
        def json(self):
            return {"success": True, "code": 0, "data": {"lastPrice": "61000.5"}}
    ex._client = type("C", (), {"get": lambda *a, **k: _StubResp()})()
    assert ex.get_mark("BTCUSDT") == 61000.5


def _order(side, price, qty, order_type="LIMIT", reduce_only=False,
           stop_price=None, client_order_id=""):
    from domain.model import OrderRequest
    return OrderRequest(symbol="BTCUSDT", side=side, price=price, qty=qty,
                        order_type=order_type, reduce_only=reduce_only,
                        stop_price=stop_price, time_in_force="GTC",
                        client_order_id=client_order_id)
