"""Smoke test: main.build_container wires in PAPER mode with no network (fakes)."""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
os.environ["MEXC_FAKE"] = "1"

from main import build_container


def test_build_container_paper_no_network():
    c = build_container(paper=True)
    assert c["paper"] is True
    assert c["ex"] is not None
    assert c["gate1"] is not None and c["gate2"] is not None
    assert c["order"] is not None and c["pm"] is not None
    assert c["brain"] is not None and c["ledger"] is not None
    assert c["app"] is not None


def test_build_container_golive_flips_paper():
    c = build_container(paper=False)
    assert c["paper"] is False


def test_build_container_uses_pg_stores_when_configured():
    # Without CONFIG_DB_URL + MEXC_FAKE -> in-memory fakes (default hermetic run)
    os.environ.pop("CONFIG_DB_URL", None)
    os.environ.pop("LLM_BASE_URL", None)
    c = build_container(paper=True)
    assert c["trade_ledger"] is None
    assert c["golive_store"] is None
    # default brain is the deterministic FakeLLM (no LLM_BASE_URL)
    from llm.brain import FakeLLM
    assert isinstance(c["brain"].client, FakeLLM)

    # With CONFIG_DB_URL set and MEXC_FAKE unset -> PG stores (fake conn injected)
    from config.db import PgGoLiveStore, PgDecisionStore, PgPositionStore, PgEvalStore
    from store.ledger import Ledger

    class _FakeConn:
        def execute(self, *a, **k):
            return None
        def commit(self):
            pass

    import main as _m
    _orig = _m._pg_conn
    _m._pg_conn = lambda: _FakeConn()
    try:
        os.environ.pop("MEXC_FAKE", None)
        os.environ["LLM_BASE_URL"] = "https://llm.example/v1"
        c = build_container(paper=True)
        assert isinstance(c["golive_store"], PgGoLiveStore)
        assert isinstance(c["trade_ledger"], Ledger)
        assert isinstance(c["ledger"].store, PgEvalStore)
        assert isinstance(c["pm"].store, PgPositionStore)
        assert isinstance(c["guard"].store, PgDecisionStore)
        # real LLM client wired when LLM_BASE_URL present
        from llm.client import OpenCodeLLM
        assert isinstance(c["brain"].client, OpenCodeLLM)
    finally:
        _m._pg_conn = _orig
        os.environ["MEXC_FAKE"] = "1"
        os.environ.pop("LLM_BASE_URL", None)


def test_build_container_live_feeds_constructs_real_listeners_under_fake():
    # --live-feeds must build the real MEXC WS + Telegram listener even with
    # MEXC_FAKE=1 (paper dashboard that ingests real market/signal data).
    os.environ["MEXC_FAKE"] = "1"
    os.environ["MEXC_API_KEY"] = "ak"
    os.environ["MEXC_SECRET"] = "sk"
    os.environ["TG_API_ID"] = "123"
    os.environ["TG_API_HASH"] = "h"
    os.environ["TG_PHONE"] = "+628000000000"
    try:
        c = build_container(paper=True, live_feeds=True)
        assert c["mexc_ws"] is not None, "mexc_ws should be built with live_feeds"
        assert c["telegram_listener"] is not None, \
            "telegram_listener should be built with live_feeds"
        assert c["paper"] is True, "orders remain paper under live_feeds"
    finally:
        os.environ.pop("MEXC_API_KEY", None)
        os.environ.pop("MEXC_SECRET", None)
        os.environ.pop("TG_API_ID", None)
        os.environ.pop("TG_API_HASH", None)
        os.environ.pop("TG_PHONE", None)

