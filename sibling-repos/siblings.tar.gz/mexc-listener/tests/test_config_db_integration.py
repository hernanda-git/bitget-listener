"""Real-DB integration test for Postgres ConfigStore + Ledger (Item 1).

GATED: skipped unless CONFIG_DB_URL is set AND the DB is reachable. The default
suite stays hermetic (no network, 85+ green). Run explicitly with:

    CONFIG_DB_URL=postgresql://app:***@127.0.0.1:5432/fatty_config \\
        uv run pytest tests/test_config_db_integration.py -q -m integration

Uses throwaway identifiers (test bot / pair / decision) and deletes every row it
creates, so it never pollutes the shared fatty_config DB.

CONCRETE-SPEC §2/§4/§5; HANDOFF-CONTINUE "Next items" #1.
"""
import os
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

pytestmark = pytest.mark.integration


def _connect():
    url = os.getenv("CONFIG_DB_URL")
    if not url:
        pytest.skip("CONFIG_DB_URL not set (integration test gated)")
    try:
        import psycopg
        conn = psycopg.connect(url, connect_timeout=3)
        conn.execute("SELECT 1")
        return conn
    except Exception as e:  # noqa: BLE001
        pytest.skip(f"Postgres unavailable: {e}")


BOT = "mexc-ci-test"
PAIR = "MEXCCITESTUSDT"
DEC = "ci-dec-1"


@pytest.fixture
def conn():
    c = _connect()
    yield c
    # cleanup throwaway rows
    for sql in [
        "DELETE FROM mexc_orders WHERE order_id LIKE 'ci-%'",
        "DELETE FROM mexc_positions WHERE symbol = %(p)s",
        "DELETE FROM mexc_decisions WHERE decision_id = %(d)s",
        "DELETE FROM mexc_eval WHERE pair = %(p)s",
        "DELETE FROM mexc_golive WHERE bot = %(b)s",
        "DELETE FROM bots WHERE name = %(b)s",
    ]:
        try:
            c.execute(sql, {"p": PAIR, "d": DEC, "b": BOT})
        except Exception:  # noqa: BLE001
            pass
    c.commit()
    c.close()


def test_go_live_token_roundtrip(conn):
    from config.db import PgGoLiveStore, init_config_schema
    init_config_schema(conn)
    conn.execute(
        "INSERT INTO bots (name, paper, channel) VALUES (%(b)s, true, 'fattyfatclub') "
        "ON CONFLICT (name) DO NOTHING", {"b": BOT})
    conn.commit()
    s = PgGoLiveStore(conn)
    s.set_token(BOT, "tok-xyz")
    assert s.get(BOT)["go_live_token"] == "tok-xyz"
    s.set_paper(BOT, 0)
    assert s.get(BOT)["paper"] is False
    s.set_token(BOT, None)
    assert s.get(BOT)["go_live_token"] is None


def test_decision_dedup_roundtrip(conn):
    from config.db import PgDecisionStore, init_config_schema
    init_config_schema(conn)
    s = PgDecisionStore(conn)
    assert s.mark_client_order_id(DEC) is True
    assert s.mark_client_order_id(DEC) is False  # duplicate


def test_position_roundtrip(conn):
    from config.db import PgPositionStore, init_config_schema
    from services.position import PositionRow
    init_config_schema(conn)
    s = PgPositionStore(conn)
    row = PositionRow(symbol=PAIR, direction="LONG", size=0.01, entry=1.0,
                      leverage=10, liq_price=0.5, status="OPEN", opened_at=1,
                      has_sl=True, has_tp=False)
    s.create(row)
    got = s.get_open_by_pair(PAIR)
    assert got is not None and got.liq_price == 0.5 and got.status == "OPEN"
    s.create_order("ci-o1", PAIR, "BUY", "PENDING")
    assert s.get_order("ci-o1")["status"] == "PENDING"
    s.update_status(PAIR, "CLOSED")
    assert s.get_open_by_pair(PAIR) is None


def test_eval_roundtrip(conn):
    from config.db import PgEvalStore, init_config_schema
    init_config_schema(conn)
    s = PgEvalStore(conn)
    s.record(PAIR, win=True)
    s.record(PAIR, win=True)
    s.record(PAIR, win=False)
    outs = s.get(PAIR)
    assert outs == [True, True, False]


def test_ledger_write_roundtrip(conn):
    from store.ledger import Ledger, init_ledger_schema
    init_ledger_schema(conn)
    ledger = Ledger(conn)
    ledger.write({
        "ts_open": 1.0, "iso_open": "2026-01-01T00:00:00Z", "bot": BOT,
        "symbol": PAIR, "side": "BUY", "entry": 1.0, "exit_px": 1.1,
        "size": 0.01, "lev": 10, "sl": 0.9, "tp": 1.2, "margin": 1.0,
        "pnl": 1.0, "close_reason": "tp", "dry": False, "source_msg_id": 1,
        "fee": 0.01, "close_fee": 0.01, "liq_price": 0.5,
    })
    cur = conn.execute(
        "SELECT fee, close_fee, liq_price FROM trades_log WHERE symbol = %(p)s",
        {"p": PAIR})
    row = cur.fetchone()
    assert row is not None and row[0] == 0.01 and row[2] == 0.5
    conn.execute("DELETE FROM trades_log WHERE symbol = %(p)s", {"p": PAIR})
    conn.commit()
