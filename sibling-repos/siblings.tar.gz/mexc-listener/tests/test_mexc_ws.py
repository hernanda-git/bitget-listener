"""T0.5 + T0.6 MexcWS login/personal.filter + fee/liq mapping (F6/F7).

WS symbols use '_' (BTC_USDT). Login then personal.filter for order/order.deal/
position/asset. We parse pushes into domain Fill (fee) and Position (liq_price).
No real socket: tests feed raw dict messages into the parser + use FakeMarketStream.
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from streaming.mexc_ws import MexcWS, parse_fill, parse_position, build_login, build_filter
from domain.model import Fill, Position, Direction


def test_build_login_shape():
    msg = build_login(api_key="k", signature="sig", req_time="1611038237237")
    assert msg["method"] == "login"
    assert msg["param"]["apiKey"] == "k"
    assert msg["param"]["signature"] == "sig"


def test_build_filter_includes_required_channels():
    msg = build_filter(["BTC_USDT"])
    filters = {f["filter"] for f in msg["param"]["filters"]}
    assert {"order", "order.deal", "position", "asset"} <= filters
    # position filter scoped to symbol with underscore separator
    pos = [f for f in msg["param"]["filters"] if f["filter"] == "position"][0]
    assert "BTC_USDT" in pos["rules"]


def test_parse_fill_maps_fee():
    raw = {"channel": "push.personal.order.deal", "data": {
        "symbol": "BTC_USDT", "side": "BUY", "price": "60000.0",
        "vol": "0.001", "fee": "0.012", "feeCoin": "USDT", "ts": "1611038237237",
        "orderId": "abc"}}
    f = parse_fill(raw["data"])
    assert isinstance(f, Fill)
    assert f.fee == 0.012
    assert f.fee_asset == "USDT"
    assert f.fill_price == 60000.0
    assert f.side.value == "BUY"


def test_parse_position_maps_real_liq_price():
    raw = {"channel": "push.personal.position", "data": {
        "symbol": "BTC_USDT", "positionType": "LONG", "holdVol": "0.001",
        "holdAvgPrice": "60000.0", "leverage": "10", "liquidatePrice": "54000.0",
        "pnl": "1.5", "margin": "6.0"}}
    p = parse_position(raw["data"])
    assert isinstance(p, Position)
    assert p.liq_price == 54000.0       # real, never 0.00
    assert p.direction is Direction.LONG
    assert p.entry == 60000.0


def test_mexc_ws_callback_dispatch():
    ws = MexcWS(api_key="k", secret="s", ws_url="wss://x")
    fills, positions = [], []
    ws.on_fill = lambda f: fills.append(f)
    ws.on_position = lambda p: positions.append(p)
    ws._dispatch({"channel": "push.personal.order.deal", "data": {
        "symbol": "BTC_USDT", "side": "SELL", "price": "61000.0", "vol": "0.001",
        "fee": "0.005", "feeCoin": "USDT", "ts": "1", "orderId": "x"}})
    ws._dispatch({"channel": "push.personal.position", "data": {
        "symbol": "BTC_USDT", "positionType": "LONG", "holdVol": "0.001",
        "holdAvgPrice": "60000.0", "leverage": "10", "liquidatePrice": "54000.0",
        "pnl": "0", "margin": "6.0"}})
    assert len(fills) == 1 and fills[0].fee == 0.005
    assert len(positions) == 1 and positions[0].liq_price == 54000.0
