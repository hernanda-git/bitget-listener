"""T0.7 / Edge C: idempotent dedup + deterministic _repair_order (no LLM fallback).

From crypto-auto-trader-reliability: duplicate fills happen when a decision is
re-sent/retried. Guard: get_active_for_decision() returns DUPLICATE_SKIPPED before
placing. On a recoverable reject (-1111/-4164), _repair_order reloads filters,
re-rounds, re-validates, resubmits ONCE — never calls an LLM.
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from exchanges.repair import IdempotencyGuard, RepairOrder, DecisionStore
from domain.model import OrderRequest, Side


class _MemStore(DecisionStore):
    def __init__(self):
        self.active = {}      # decision_id -> list of statuses
        self.order_ids = set()

    def get_active_for_decision(self, decision_id, side):
        st = self.active.get(decision_id, [])
        if any(s in ("PENDING", "NEW", "FILLED") for s in st):
            return st
        return None

    def mark_client_order_id(self, client_order_id):
        if client_order_id in self.order_ids:
            return False
        self.order_ids.add(client_order_id)
        return True


def test_dedup_blocks_duplicate_decision():
    store = _MemStore()
    store.active["d1"] = ["FILLED"]
    g = IdempotencyGuard(store)
    res = g.check("d1", Side.BUY)
    assert res.skipped is True
    assert res.status == "DUPLICATE_SKIPPED"


def test_dedup_allows_new_decision():
    store = _MemStore()
    g = IdempotencyGuard(store)
    res = g.check("d2", Side.BUY)
    assert res.skipped is False


def test_dedup_allows_reentry_of_canceled_decision():
    store = _MemStore()
    store.active["d3"] = ["CANCELED"]
    g = IdempotencyGuard(store)
    assert g.check("d3", Side.BUY).skipped is False


def test_client_order_id_unique():
    store = _MemStore()
    assert store.mark_client_order_id("c1") is True
    assert store.mark_client_order_id("c1") is False


def test_repair_fixes_below_minnotional():
    # simulate: first attempt rejected -4164 (below minNotional), repair bumps qty
    r = RepairOrder()
    fixed = r.repair(symbol="DOGEUSDT", side="BUY", price=0.08, qty=1.0,
                     min_notional=5.0, lot_size=1.0)
    assert fixed.qty * 0.08 >= 5.0 - 1e-9
    assert fixed.reduce_only is False  # entry, opening order


def test_repair_keeps_reduce_only_for_protective():
    r = RepairOrder()
    fixed = r.repair(symbol="BTCUSDT", side="SELL", price=59000.0, qty=0.001,
                     min_notional=5.0, lot_size=0.0001, reduce_only=True)
    assert fixed.reduce_only is True


def test_repair_is_deterministic_no_llm():
    r = RepairOrder()
    a = r.repair("DOGEUSDT", "BUY", 0.08, 1.0, 5.0, 1.0)
    b = r.repair("DOGEUSDT", "BUY", 0.08, 1.0, 5.0, 1.0)
    assert a.qty == b.qty
