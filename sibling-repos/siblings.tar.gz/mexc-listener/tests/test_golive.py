"""P2 T2.1 GoLiveGate: two-step go-live (mint token -> user /live <token> flips
paper=0) gated on shadow expectancy > 0 + all tests green + probe GREEN.

CONCRETE-SPEC §11. Strongest safety capstone (from bybit-listener). Plus Markdown-
safe Telegram event cards (_md_escape, from learner).
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from notifier.bot import GoLiveGate, GoLiveStore, _md_escape


class _Store(GoLiveStore):
    def __init__(self):
        self.rows = {"mexc-fatty": {"paper": 1, "go_live_token": None}}
    def get(self, bot): return self.rows.get(bot, {})
    def set_paper(self, bot, val): self.rows[bot]["paper"] = val
    def set_token(self, bot, tok): self.rows[bot]["go_live_token"] = tok


def test_mint_token_stored():
    s = _Store(); g = GoLiveGate(s)
    tok = g.mint("mexc-fatty")
    assert tok and s.get("mexc-fatty")["go_live_token"] == tok


def test_live_requires_matching_token():
    s = _Store(); g = GoLiveGate(s)
    tok = g.mint("mexc-fatty")
    assert g.activate("mexc-fatty", "wrong", shadow_expectancy=0.3,
                      tests_green=True, probe_green=True) is False
    assert g.activate("mexc-fatty", tok, shadow_expectancy=0.3,
                      tests_green=True, probe_green=True) is True
    assert s.get("mexc-fatty")["paper"] == 0


def test_live_blocked_when_shadow_expectancy_negative():
    s = _Store(); g = GoLiveGate(s)
    tok = g.mint("mexc-fatty")
    # shadow expectancy < 0 -> must NOT flip live even with correct token
    assert g.activate("mexc-fatty", tok, shadow_expectancy=-0.1,
                      tests_green=True, probe_green=True) is False
    assert s.get("mexc-fatty")["paper"] == 1


def test_live_blocked_when_tests_red():
    s = _Store(); g = GoLiveGate(s)
    tok = g.mint("mexc-fatty")
    assert g.activate("mexc-fatty", tok, shadow_expectancy=0.3,
                      tests_green=False, probe_green=True) is False


def test_live_allowed_only_when_all_green():
    s = _Store(); g = GoLiveGate(s)
    tok = g.mint("mexc-fatty")
    assert g.activate("mexc-fatty", tok, shadow_expectancy=0.35,
                      tests_green=True, probe_green=True) is True
    assert s.get("mexc-fatty")["paper"] == 0


def test_md_escape_prevents_telegram_crash():
    assert _md_escape("BTC price *up* (win)") == "BTC price \\*up\\* \\(win\\)"
    assert _md_escape("plain text") == "plain text"
