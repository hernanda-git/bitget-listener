"""Item 4 + 5 — DashboardState WS ingestion, sparklines, efficient polling.

TDD for:
- MexcWS position/fill/wallet callbacks feed live state (Item 4)
- per-symbol sparkline history (Item 5b)
- WS-driven polling efficiency: REST account poll is skipped while the WS feed
  is live (the socket is the source of truth), with a slow backstop (Item 5c)

All fakes-only, zero network. Uses EventBus + a FakeExchange to drive ingestion.
"""
import os
import sys
import time

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from web.app import EventBus
from web.dashboard_state import DashboardState


def _ds(ex=None, poll=5.0, market=("BTC_USDT",)):
    bus = EventBus()
    return DashboardState(bus, exchange=ex, poll_interval=poll,
                          market_symbols=market), bus


# ---------------------------------------------------------------------------
# Item 4 — WS position/fill/wallet -> live state
# ---------------------------------------------------------------------------

def test_position_event_upserts_into_positions():
    ds, bus = _ds()
    # MexcWS _on_position publishes Position.__dict__ (underscore symbol fixed
    # upstream; dashboard keys on 'symbol' + 'size').
    bus.publish({"type": "position", "data": {
        "symbol": "BTCUSDT", "direction": "LONG", "size": 0.01,
        "entry": 60000.0, "leverage": 10, "liq_price": 54000.0,
        "mark": 61000.0, "pnl": 1.5, "margin": 6.0, "status": "OPEN"}})
    ds._loop_once()  # fold bus events
    assert len(ds.positions) == 1
    p = ds.positions[0]
    assert p["symbol"] == "BTCUSDT" and p["size"] == 0.01
    assert p["liq_price"] == 54000.0
    assert ds.ws_feed_live is True


def test_position_event_zero_size_removes_position():
    ds, bus = _ds()
    bus.publish({"type": "position", "data": {
        "symbol": "BTCUSDT", "direction": "LONG", "size": 0.01,
        "entry": 60000.0, "leverage": 10, "liq_price": 54000.0}})
    ds._loop_once()
    assert len(ds.positions) == 1
    # MEXC sends size 0 / empty when a position is closed/flattened
    bus.publish({"type": "position", "data": {
        "symbol": "BTCUSDT", "direction": "LONG", "size": 0.0,
        "entry": 0.0, "leverage": 10, "liq_price": 0.0}})
    ds._loop_once()
    assert ds.positions == []


def test_position_event_upserts_not_appends_multiple():
    ds, bus = _ds()
    bus.publish({"type": "position", "data": {
        "symbol": "BTCUSDT", "direction": "LONG", "size": 0.01, "entry": 1.0,
        "leverage": 10, "liq_price": 0.5}})
    bus.publish({"type": "position", "data": {
        "symbol": "ETHUSDT", "direction": "SHORT", "size": 0.1, "entry": 2000.0,
        "leverage": 5, "liq_price": 2200.0}})
    ds._loop_once()
    assert len(ds.positions) == 2
    # update BTC size only -> still 2 positions, BTC replaced
    bus.publish({"type": "position", "data": {
        "symbol": "BTCUSDT", "direction": "LONG", "size": 0.02, "entry": 1.1,
        "leverage": 10, "liq_price": 0.5}})
    ds._loop_once()
    assert len(ds.positions) == 2
    btcs = [p for p in ds.positions if p["symbol"] == "BTCUSDT"]
    assert btcs[0]["size"] == 0.02


def test_fill_event_updates_stats_and_equity():
    ds, bus = _ds()
    bus.publish({"type": "fill", "data": {
        "symbol": "BTCUSDT", "side": "BUY", "fill_price": 60000.0,
        "qty": 0.01, "fee": 0.5, "fee_asset": "USDT", "pnl": 2.0}})
    ds._loop_once()
    assert ds.stats["total_trades"] == 1
    assert ds.stats["wins"] == 1
    assert ds.stats["net_pnl"] == 2.0
    assert len(ds.pnl_history) == 1 and ds.pnl_history[0]["pnl"] == 2.0
    assert ds.ws_feed_live is True


def test_wallet_event_updates_balance_and_equity_history():
    ds, bus = _ds()
    bus.publish({"type": "wallet", "data": {
        "equity": 1005.0, "available": 1000.0, "currency": "USDT"}})
    ds._loop_once()
    assert ds.balance.get("equity") == 1005.0
    assert len(ds.equity_history) == 1
    assert ds.equity_history[0]["equity"] == 1005.0
    assert ds.ws_feed_live is True


# ---------------------------------------------------------------------------
# Item 5b — per-symbol sparklines
# ---------------------------------------------------------------------------

def test_market_poll_appends_spark_history():
    ds, bus = _ds(market=("BTC_USDT",))
    # stub the public price fetch (no network)
    ds._fetch_public_price = lambda s: (61000.0, 1.2) if s == "BTC_USDT" else (0.0, 0.0)
    ds._poll_market()
    ds._poll_market()
    assert "BTC_USDT" in ds.spark
    assert len(ds.spark["BTC_USDT"]) == 2
    assert ds.spark["BTC_USDT"][-1]["price"] == 61000.0


def test_snapshot_includes_spark():
    ds, bus = _ds(market=("BTC_USDT",))
    ds._fetch_public_price = lambda s: (61000.0, 1.2)
    ds._poll_market()
    snap = ds.snapshot()
    assert "spark" in snap and "BTC_USDT" in snap["spark"]
    assert snap["spark"]["BTC_USDT"][0]["price"] == 61000.0


# ---------------------------------------------------------------------------
# Item 5c — efficient polling: skip REST account poll while WS feed is live
# ---------------------------------------------------------------------------

class _FakeEx:
    """Minimal fake exchange that records account-poll calls."""
    _is_fake = True  # dashboard treats as fake -> never REST-polls by default

    def __init__(self):
        self.balance_calls = 0
        self.positions_calls = 0

    def get_balance(self):
        self.balance_calls += 1
        return {"equity": 1000.0, "available": 995.0}

    def get_open_positions(self):
        self.positions_calls += 1
        return []


def test_account_poll_skipped_for_fake_exchange():
    ex = _FakeEx()
    ds, _ = _ds(ex=ex)
    ds._poll_account()
    assert ex.balance_calls == 0 and ex.positions_calls == 0


def test_account_poll_runs_for_live_exchange_not_ws_live():
    class _LiveEx(_FakeEx):
        _is_fake = False
    ex = _LiveEx()
    ds, _ = _ds(ex=ex)
    ds._poll_account()
    assert ex.balance_calls == 1 and ex.positions_calls == 1


def test_account_poll_skipped_when_ws_feed_live():
    class _LiveEx(_FakeEx):
        _is_fake = False
    ex = _LiveEx()
    ds, bus = _ds(ex=ex)
    ds.ws_feed_live = True
    ds._last_account_ts = time.time()  # steady state: polled recently
    ds._poll_account()
    assert ex.balance_calls == 0 and ex.positions_calls == 0


def test_account_backstop_runs_while_ws_live_after_interval():
    class _LiveEx(_FakeEx):
        _is_fake = False
    ex = _LiveEx()
    ds, bus = _ds(ex=ex, poll=5.0)
    ds.ws_feed_live = True
    ds.account_backstop_interval = 1.0  # force backstop quickly
    ds._last_account_ts = 0
    ds._poll_account()
    # backstop elapsed -> REST poll happens as safety net
    assert ex.balance_calls == 1


def test_poll_once_market_every_cycle_account_throttled():
    class _LiveEx(_FakeEx):
        _is_fake = False
    ex = _LiveEx()
    ds, _ = _ds(ex=ex, poll=5.0)
    ds.account_poll_interval = 100.0  # throttle
    ds._last_account_ts = time.time()
    ds._poll_once()
    # market polled every cycle; account throttled (recent) -> skipped
    assert ex.positions_calls == 0
    snap = ds.snapshot()
    assert "BTC_USDT" in snap["market"]


def test_loop_once_folds_bus_then_polls():
    ds, bus = _ds()
    bus.publish({"type": "position", "data": {
        "symbol": "BTCUSDT", "direction": "LONG", "size": 0.01,
        "entry": 60000.0, "leverage": 10, "liq_price": 54000.0}})
    ds._fetch_public_price = lambda s: (61000.0, 1.2)
    ds._loop_once()
    assert len(ds.positions) == 1
    assert "BTC_USDT" in ds.market
