"""P1 T1.1 safety gates (Gate1 pre-LLM, Gate2 post-LLM fee-aware clamps).

CONCRETE-SPEC §3 bounds. Immutable safety (kill switch / feed-stale) is enforced
separately and never disableable. Gate1: idempotency, cooldown, whitelist.
Gate2: fixed-risk size, lev snap+clamp, SL direction, min-notional, concurrent,
daily-loss. No LLM involved — deterministic.
"""
import sys, os, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from services.validator import Gate1, Gate2, GateResult, RiskConfig


_CFG = RiskConfig(
    risk_per_trade_usd=5, max_position_usd=100, max_concurrent=2,
    max_daily_loss_pct=30, max_leverage=20, min_notional_usd=5,
    cooldown_s=30, whitelist_only=True, whitelist={"BTCUSDT", "ETHUSDT", "SOLUSDT"},
)


def test_gate1_rejects_non_whitelisted_pair():
    g = Gate1(_CFG)
    res = g.check(message_id=1, pair="SHIBUSDT", ts=int(time.time()))
    assert res.ok is False and "whitelist" in res.reason.lower()


def test_gate1_cooldown_blocks_repeat_pair():
    g = Gate1(_CFG)
    now = int(time.time())
    assert g.check(1, "BTCUSDT", now).ok is True
    # second signal for same pair within cooldown window
    res = g.check(2, "BTCUSDT", now + 5)
    assert res.ok is False and "cooldown" in res.reason.lower()


def test_gate1_idempotency_blocks_same_message():
    g = Gate1(_CFG)
    assert g.check(7, "BTCUSDT", int(time.time())).ok is True
    assert g.check(7, "BTCUSDT", int(time.time()) + 1).ok is False


def test_gate2_clamps_leverage_to_pair_max():
    g = Gate2(_CFG)
    decision = {"pair": "BTCUSDT", "direction": "LONG", "entry": 60000.0,
                "sl": 59000.0, "leverage": 100, "price": 60000.0,
                "pair_max_leverage": 20}
    res = g.check(decision, open_positions=0, daily_loss_pct=0.0)
    assert res.ok is True
    assert res.leverage <= 20


def test_gate2_rejects_sl_on_wrong_side():
    g = Gate2(_CFG)
    decision = {"pair": "BTCUSDT", "direction": "LONG", "entry": 60000.0,
                "sl": 61000.0, "leverage": 10, "price": 60000.0,
                "pair_max_leverage": 20}
    res = g.check(decision, open_positions=0, daily_loss_pct=0.0)
    assert res.ok is False and "sl" in res.reason.lower()


def test_gate2_blocks_when_daily_loss_exceeded():
    g = Gate2(_CFG)
    decision = {"pair": "BTCUSDT", "direction": "LONG", "entry": 60000.0,
                "sl": 59000.0, "leverage": 10, "price": 60000.0,
                "pair_max_leverage": 20}
    res = g.check(decision, open_positions=0, daily_loss_pct=31.0)
    assert res.ok is False and "loss" in res.reason.lower()


def test_gate2_blocks_concurrent_over_limit():
    g = Gate2(_CFG)
    decision = {"pair": "BTCUSDT", "direction": "LONG", "entry": 60000.0,
                "sl": 59000.0, "leverage": 10, "price": 60000.0,
                "pair_max_leverage": 20}
    res = g.check(decision, open_positions=2, daily_loss_pct=0.0)
    assert res.ok is False and "concurrent" in res.reason.lower()
