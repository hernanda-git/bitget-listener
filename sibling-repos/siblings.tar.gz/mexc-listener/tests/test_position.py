"""P1 T1.6 PositionManager: WS-synced, self-heal missing SL/TP, orphan detect,
48h time-exit, reconcile resting LIMIT that fills late (prevents orphaned positions).

Mirrors learnernoearner-listener fixes (resting-limit-reconcile, management-race).
No LLM. Uses FakeExchange + in-memory position store.
"""
import sys, os, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from services.position import PositionManager, PositionStore, PositionRow
from domain.model import Position, Direction, OrderRequest, Side


class _Store(PositionStore):
    def __init__(self):
        self.rows = {}
        self.orders = {}  # order_id -> {status, symbol, side}
    def create(self, row: PositionRow):
        self.rows[row.symbol] = row
    def get_open_by_pair(self, symbol):
        r = self.rows.get(symbol)
        return r if r and r.status == "OPEN" else None
    def update_status(self, symbol, status):
        if symbol in self.rows: self.rows[symbol].status = status
    def create_order(self, order_id, symbol, side, status="PENDING"):
        self.orders[order_id] = {"status": status, "symbol": symbol, "side": side}
    def get_order(self, order_id):
        return self.orders.get(order_id)


class _FakeExchange:
    def __init__(self): self.placed=[]
    def place_order(self, req): self.placed.append(req); return {"order_id":"x"+str(len(self.placed))}
    def get_order(self, order_id):
        o=self.orders.get(order_id)
        return {"status": o["status"]} if o else None


def _pm(paper: bool = False):
    store = _Store(); ex = _FakeExchange()
    return PositionManager(ex, store, paper=paper), store, ex


def test_reconcile_late_filling_limit_builds_position():
    pm, store, ex = _pm()
    # a PENDING entry order that fills late
    store.create_order("o1", "BTCUSDT", "BUY", status="PENDING")
    ex.orders = {"o1": {"status": "FILLED", "symbol": "BTCUSDT", "side": "BUY",
                       "direction": "LONG", "size": 0.001, "entry": 60000.0,
                       "leverage": 10, "liq_price": 54000.0, "sl": 59000.0,
                       "tps": (63000.0, 65000.0)}}
    created = pm.reconcile_pending_orders()
    assert "BTCUSDT" in created
    assert store.get_open_by_pair("BTCUSDT") is not None
    # SL/TP attached (self-heal)
    assert any(o.order_type == "STOP" and o.reduce_only for o in ex.placed)
    assert any(o.order_type == "TAKE_PROFIT" and o.reduce_only for o in ex.placed)


def test_reconcile_idempotent_on_rerun():
    pm, store, ex = _pm()
    store.create_order("o2", "BTCUSDT", "BUY", status="PENDING")
    ex.orders = {"o2": {"status": "FILLED", "symbol": "BTCUSDT", "side": "BUY"}}
    pm.reconcile_pending_orders()
    placed_after_first = len(ex.placed)
    store.create_order("o3", "ETHUSDT", "BUY", status="PENDING")
    ex.orders["o3"] = {"status": "PENDING", "symbol": "ETHUSDT", "side": "BUY"}
    pm.reconcile_pending_orders()  # o2 already done -> no duplicate; o3 still pending
    assert len(ex.placed) == placed_after_first  # no duplicate BTC position


def test_48h_time_exit_flattens_stale():
    pm, store, ex = _pm()
    row = PositionRow(symbol="BTCUSDT", direction="LONG", size=0.001, entry=60000.0,
                      leverage=10, liq_price=54000.0, status="OPEN",
                      opened_at=int(time.time()) - 49*3600)
    store.rows["BTCUSDT"] = row
    closed = pm.time_exit_check(now=int(time.time()))
    assert "BTCUSDT" in closed
    assert store.rows["BTCUSDT"].status == "CLOSED"


def test_self_heal_attaches_missing_sl():
    pm, store, ex = _pm()
    row = PositionRow(symbol="BTCUSDT", direction="LONG", size=0.001, entry=60000.0,
                      leverage=10, liq_price=54000.0, status="OPEN", opened_at=int(time.time()),
                      has_sl=False)
    store.rows["BTCUSDT"] = row
    pm.self_heal_protection("BTCUSDT", sl_price=59000.0)
    assert any(o.order_type == "STOP" and o.reduce_only for o in ex.placed)
    assert store.rows["BTCUSDT"].has_sl is True


def test_paper_mode_never_places_protection():
    """Hard safety gate: in paper mode, PositionManager must not place real orders."""
    pm, store, ex = _pm(paper=True)
    row = PositionRow(symbol="BTCUSDT", direction="LONG", size=0.001, entry=60000.0,
                      leverage=10, liq_price=54000.0, status="OPEN", opened_at=int(time.time()),
                      has_sl=False)
    store.rows["BTCUSDT"] = row
    pm.self_heal_protection("BTCUSDT", sl_price=59000.0)
    assert not ex.placed, "paper mode must issue zero real protection orders"
    # state still updated locally (simulated self-heal)
    assert store.rows["BTCUSDT"].has_sl is True
