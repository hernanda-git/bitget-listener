#!/usr/bin/env bash
#
# tg_auth.sh — Bootstrap the mexc-listener Telegram user session from YOUR laptop.
#
# No local repo needed: it SSHes into Sera and runs scripts/tg_login.py
# interactively (your terminal is attached, so you can type the phone + Telegram
# login code / 2FA password). TG_API_ID / TG_API_HASH are already in .env on Sera.
#
# Usage:
#   ./tg_auth.sh                 # uses ssh target "sera"
#   SERA_SSH=root@1.2.3.4 ./tg_auth.sh
#
set -euo pipefail

SERA_SSH="${SERA_SSH:-sera}"
REMOTE_REPO="${REMOTE_REPO:-/opt/bots/mexc-listener}"

echo "[*] Connecting to ${SERA_SSH} and running interactive Telegram login..."
echo "    (enter your phone number, then the code Telegram sends you)"
ssh -t "${SERA_SSH}" "cd ${REMOTE_REPO} && .venv/bin/python scripts/tg_login.py"
echo "[*] Done. Session saved on Sera; the runtime TelethonListener reuses it."
