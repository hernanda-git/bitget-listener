# mexc-listener — Phased TDD Implementation Plan

> Every task = write failing test → implement → pass → commit. Tasks are 2–5 min.
> Source of truth: `docs/DESIGN.md` + `docs/CONCRETE-SPEC.md`.

## Phase 0 — Skeleton + verify MEXC reality
- [ ] T0.1 `src/domain/model.py` dataclasses (Instrument, RawSignal, Signal, OrderRequest, Position, Fill, TradeDecision) + tests
- [ ] T0.2 `src/exchanges/mexc_auth.py` MexcAuth HMAC over `accessKey+ts+paramString`; header builder; sorted GET / JSON POST; unit test sign string
- [ ] T0.3 `src/exchanges/mexc.py` base REST GET/POST via httpx; token bucket; instruments-info cache (`_round_price`/`_round_qty`); tests w/ FakeExchange
- [ ] T0.4 `scripts/mexc_api_probe.py` — probes WS host, fee field, liquidatePrice, 1000x symbols (prints GREEN/RED)
- [ ] T0.5 `src/streaming/mexc_ws.py` — login + `personal.filter`; callbacks on_fill/on_position/on_order/on_wallet/on_heartbeat; jittered reconnect; FakeMarketStream
- [ ] T0.6 map `order.deal.fee`→`Fill.fee` (F6), `position.liquidatePrice`→`liq_price` (F7); tests

## Phase 1 — Safe execution core (Edge C rigor)
- [ ] T1.1 `src/services/validator.py` Gate1 (idemp/cooldown/whitelist) + Gate2 (size/lev/SL-dir/min-notional/daily-loss); tests
- [ ] T1.2 `src/exchanges/validation.py` `validate_order`; `round_price`/`round_qty` magnitude-flip guards; pair-matrix tests (BTC/ETH/APE/DOGE/1000PEPE)
- [ ] T1.3 `src/exchanges/repair.py` deterministic `_repair_order` (no LLM); tests on simulated -1111/-4164
- [ ] T1.4 `src/services/order.py` idempotent dedup guard; entry LIMIT; SL/TP `stop.order` (reduce_only); never-cancel-protective (F8); tests
- [ ] T1.5 `src/services/risk.py` FixedRiskSizer fee-aware (F5); net = gross − fees; tests
- [ ] T1.6 `src/services/position.py` PositionManager WS-synced; self-heal SL/TP; orphan detect; 48h exit; reconcile_pending; tests (FakeExchange)

## Phase 2 — Safety capstone + resilience
- [ ] T2.1 `src/notifier/bot.py` GoLiveGate 2-step + Telegram cards + `_md_escape` (F3/F17)
- [ ] T2.2 `src/services/deadman.py` watchdog heartbeat TTL → cancel-all in live; tests
- [ ] T2.3 `src/exchanges/ws_stream.py` ban-aware backoff + optional egress proxy (F12); tests
- [ ] T2.4 `src/exchanges/mark_cache.py` mark-price cache (F13); tests
- [ ] T2.5 `src/sources/symbol_map.py` 1000x/contract-multiplier map (F11) + `to_ws_symbol`; tests

## Phase 3 — Observability + Edge B + ship
- [ ] T3.1 `src/llm/brain.py` OpenAI-compat (deepseek-v4-flash-free); vision on image + text parser; structured TradeDecision; FakeLLM
- [ ] T3.2 `src/eval/shadow_ledger.py` per-pair win-rate; flag + (opt) downsize (F24); tests
- [ ] T3.3 `src/notifier/web.py` FastAPI Web UI (charts + live data PRIMARY) + WebSocket event stream; tests (TestClient)
- [ ] T3.4 `src/config/db.py` ConfigStore Postgres env-var names only (F20); tests (FakeConfigStore)
- [ ] T3.5 `Dockerfile` + `systemd/mexc-listener.service` + `deploy.sh` + version bump (F22)
- [ ] T3.6 full suite ≥81 fakes-only tests, zero network; commit; go-live review
