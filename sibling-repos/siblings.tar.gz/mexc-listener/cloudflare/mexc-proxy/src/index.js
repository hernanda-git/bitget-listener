/**
 * mexc-proxy — Cloudflare Worker that proxies MEXC REST + WebSocket from the
 * Cloudflare edge (non-Jakarta egress). Sera connects here instead of directly
 * to MEXC, so the Indonesia geo-block on contract.mexc.com is bypassed.
 *
 * MEXC splits its API across two hosts:
 *   - Unified account/balance/spot  -> https://api.mexc.com   (/api/v1/private/*)
 *   - Futures (contract) orders     -> https://contract.mexc.com (/api/v1/contract/*)
 * The futures host is geo-blocked from Jakarta (403), so order traffic must be
 * routed there via the Cloudflare edge. We pick the upstream by path prefix.
 *
 * Client:
 *   REST  -> https://mexc-proxy.<sub>.workers.dev/api/...   (proxies the right host)
 *   WS    -> wss://mexc-proxy.<sub>.workers.dev/ws            (proxies wss://contract.mexc.com/ws)
 *
 * Security: only upstreams to api.mexc.com (REST) / contract.mexc.com (WS) are
 * allowed (not open).
 */
const API_UPSTREAM = "https://api.mexc.com";       // unified + futures contract REST
const WS_UPSTREAM = "wss://contract.mexc.com/edge"; // futures WebSocket (geo-blocked -> proxied)

function upstreamFor(pathname) {
  // MEXC serves BOTH account/balance (unified) AND futures contract REST from
  // api.mexc.com. contract.mexc.com only serves the WebSocket (/edge) and blocks
  // REST at the WAF. So all /api/* REST (private + contract) routes to api.mexc.com.
  if (pathname.startsWith("/api/")) return API_UPSTREAM;
  return API_UPSTREAM;
}

function isWebSocketRequest(request) {
  const u = request.headers.get("Upgrade") || request.headers.get("upgrade");
  return (u && u.toLowerCase() === "websocket") ||
         request.headers.has("Sec-WebSocket-Key");
}

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);

    if (isWebSocketRequest(request)) {
      if (url.pathname !== "/ws") {
        return new Response("only /ws is proxied", { status: 404 });
      }
      return handleWs(request);
    }

    if (url.pathname.startsWith("/api/")) {
      const target = upstreamFor(url.pathname) + url.pathname + url.search;
      const headers = new Headers(request.headers);
      headers.delete("host");
      headers.delete("cf-connecting-ip");
      headers.delete("cf-ipcountry");
      const init = {
        method: request.method,
        headers,
        redirect: "follow",
      };
      if (request.method !== "GET" && request.method !== "HEAD") {
        init.body = request.body;
      }
      const upstream = await fetch(target, init);
      const out = new Headers(upstream.headers);
      out.delete("content-encoding");
      out.delete("transfer-encoding");
      return new Response(upstream.body, {
        status: upstream.status,
        headers: out,
      });
    }

    return new Response(
      "mexc-proxy: use /api/* for REST or /ws for WebSocket",
      { status: 200, headers: { "content-type": "text/plain" } }
    );
  },
};

async function handleWs(request) {
  const upgradeHeader = request.headers.get("Upgrade") || request.headers.get("upgrade");
  if (!upgradeHeader || upgradeHeader.toLowerCase() !== "websocket") {
    return new Response("expected websocket upgrade", { status: 426 });
  }
  const [client, server] = Object.values(new WebSocketPair());
  server.accept();

  let upstream = null;
  let diag = "";
  try {
    // MEXC /edge may require Origin/Host headers on the outbound WS handshake.
    upstream = new WebSocket(WS_UPSTREAM, [], {
      headers: {
        "Origin": "https://www.mexc.com",
        "Host": "contract.mexc.com",
      },
    });
    await new Promise((resolve, reject) => {
      upstream.addEventListener("open", () => { diag += "open;"; resolve(); }, { once: true });
      upstream.addEventListener("error", (e) => { diag += "err:" + (e.message || "?"); reject(new Error(diag)); }, { once: true });
    });

    server.addEventListener("message", (e) => {
      try { upstream.send(e.data); } catch (_) {}
    });
    upstream.addEventListener("message", (e) => {
      try { server.send(e.data); } catch (_) {}
    });
    server.addEventListener("close", () => { try { upstream.close(); } catch (_) {} });
    upstream.addEventListener("close", () => { try { server.close(); } catch (_) {} });
    upstream.addEventListener("error", () => { try { server.close(); } catch (_) {} });
    server.addEventListener("error", () => { try { upstream.close(); } catch (_) {} });

    return new Response(null, { status: 101, webSocket: client });
  } catch (err) {
    try { server.close(); } catch (_) {}
    try { upstream?.close(); } catch (_) {}
    return new Response("ws proxy error: " + diag + " | " + String(err), { status: 502 });
  }
}
