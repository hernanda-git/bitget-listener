#!/usr/bin/env python3
"""Bybit TESTNET recovery/health probe.

VERIFIES the V5 schemas against TESTNET (spec §4, rule #8) WITHOUT ever touching
mainnet. Safe by construction: it forces testnet and never sends a mainnet request.

What it does (all on testnet):
  1. Server time sync (clock-drift check, retCode 10002 avoidance).
  2. Refresh instruments-info; print real lotSizeFilter/priceFilter for BTCUSDT.
  3. Set leverage (ignore 110012).
  4. Place a TINY market order with attached SL/TP ($1 / 3x) using a fresh ulid
     orderLinkId.
  5. Read the execution fill and assert `execFee` is NON-ZERO (BUG A closed).
  6. set-trading-stop SL->entry; read back the position.
  7. Flatten via cancel-all (dead-man path) and close any residual.
  8. Write data/hl_api_status.json-equivalent: bybit_api_status.json with
     {placeable, detail, ts_ms, fills_fee_nonzero, steps}.

The script only RUNS the live calls if BYBIT_API_KEY is set in the environment.
If keys are absent it prints the planned steps and exits 0 (so CI/no-key runs pass).

Captures the FULL retCode/retMsg verbatim on any non-zero so schema drift is
SURFACED, never hacked around (spec §21: "probe blind to error body" is a fork bug
we fixed).
"""

from __future__ import annotations

import asyncio
import json
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.exchanges.bybit import BybitAdapter, BybitConfig  # noqa: E402
from src.domain.model import Instrument, OrderRequest  # noqa: E402
from ulid import ULID  # noqa: E402

STATUS_PATH = Path(__file__).resolve().parent.parent / "data" / "bybit_api_status.json"


def _status(placeable: bool, detail: str, extra: dict | None = None) -> dict:
    out = {"placeable": placeable, "detail": detail,
           "ts_ms": int(asyncio.get_event_loop().time() * 1000)}
    if extra:
        out.update(extra)
    STATUS_PATH.parent.mkdir(parents=True, exist_ok=True)
    STATUS_PATH.write_text(json.dumps(out, indent=2))
    return out


async def run() -> dict:
    key = os.getenv("BYBIT_API_KEY", "")
    secret = os.getenv("BYBIT_API_SECRET", "")
    if not key or not secret:
        msg = "No BYBIT_API_KEY/BYBIT_API_SECRET in env — skipping live testnet probe. " \
              "Add TESTNET keys to .env and re-run to verify schemas against testnet."
        print(msg)
        return _status(False, msg, {"skipped": True})

    cfg = BybitConfig(api_key=key, api_secret=secret, testnet=True)
    adapter = BybitAdapter(cfg)
    steps: list[str] = []
    try:
        # 1) time sync
        srv = await adapter.server_time_ms()
        steps.append(f"server_time={srv}")
        # 2) instruments
        await adapter.refresh_instruments()
        info = adapter.get_instrument_info("BTCUSDT")
        steps.append(f"instruments BTCUSDT base_prec={info.base_precision if info else None} "
                     f"minQty={info.min_order_qty if info else None} "
                     f"minNotional={info.min_notional if info else None}")
        # 3) leverage
        inst = Instrument.from_token("BTC")
        await adapter.set_leverage(inst, 3)
        steps.append("set_leverage=3")
        # 4) tiny market order w/ attached SL/TP
        mark = (await adapter.ticker("BTCUSDT")).get("markPrice")
        mark = float(mark) if mark else 60000.0
        qty = adapter.round_qty("BTCUSDT", 1.0 / mark / 3.0)  # ~$1 / 3x
        qty = max(qty, info.min_order_qty if info else 0.001)
        o = OrderRequest(
            instrument=inst, side="BUY", order_type="Market", qty=qty,
            time_in_force="IOC", sl=round(mark * 0.99, 1), tp=round(mark * 1.02, 1),
            tpsl_mode="Full", sl_trigger_by="MarkPrice", tp_trigger_by="MarkPrice",
            client_order_id="b-" + ULID().hex, is_market=True,
        )
        oid = await adapter.place_order(o)
        steps.append(f"place_order orderId={oid}")
        # 5) fill fee non-zero (BUG A)
        await asyncio.sleep(1.5)
        fills = await adapter.get_fills()
        fee_nonzero = any(f.fee > 0 for f in fills)
        steps.append(f"fills={len(fills)} fee_nonzero={fee_nonzero}")
        # 6) set-trading-stop SL->entry
        await adapter.set_trading_stop(inst, sl=mark, tp=None, sl_trigger_by="MarkPrice")
        steps.append("set_trading_stop SL->entry ok")
        # 7) flatten
        await adapter.cancel_all(inst)
        steps.append("cancel_all ok")
        await adapter.close()
        detail = "testnet schema verified"
        return _status(True, detail, {"fee_nonzero": fee_nonzero, "steps": steps,
                                      "oid": oid})
    except Exception as e:  # noqa: BLE001
        steps.append(f"ERROR {type(e).__name__}: {e}")
        await adapter.close()
        return _status(False, f"probe failed: {e}", {"steps": steps})


def main() -> None:
    res = asyncio.get_event_loop().run_until_complete(run())
    print(json.dumps(res, indent=2))
    # A skipped (no-key) run is not a failure; a real failure exits non-zero.
    if res.get("skipped"):
        sys.exit(0)
    sys.exit(0 if res["placeable"] else 2)


if __name__ == "__main__":
    main()
