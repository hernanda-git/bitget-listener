#!/usr/bin/env python3
"""Phase 10 replay — real channel messages + chart images through the orchestrator.

Runs the pipeline against the recorded channel payloads (docs/channel_sample.json) and
a generated set of 100 realistic @fattyfatclub-style messages, driving the orchestrator
with the FAKE adapters (no Telegram, no Bybit, no network — spec rule #1). It asserts
the pipeline processes them with ZERO crashes and that the decision statistics are sane.

This proves the wiring end-to-end (parser -> normalize -> gate1 -> fast-path -> LLM
escalation -> entry build -> paper ledger) without contacting any exchange. Charts are
referenced from data/samples/*.jpg so the attachment code path is exercised too.

Exit codes: 0 = replay clean; 2 = crashes or zero decisions (wiring broken).
"""

from __future__ import annotations

import asyncio
import json
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.domain.model import RawSignal  # noqa: E402
from src.orchestrator import Orchestrator, OrchestratorConfig  # noqa: E402
from src.sources.parser import parse_message  # noqa: E402
from src.sources.telegram import FakeSignalSource  # noqa: E402
from src.exchanges.fake import FakeExchangeAdapter, FakeMarketStream  # noqa: E402
from src.notifier.bot import TelegramNotifier  # noqa: E402
from src.store.ledger import Ledger  # noqa: E402
from src.store.eval import EvalWriter  # noqa: E402
from src.services.risk import FixedRiskSizer, RiskConfig  # noqa: E402

REPO = Path(__file__).resolve().parent.parent


def _load_samples() -> list[str]:
    p = REPO / "docs" / "channel_sample.json"
    if p.exists():
        data = json.loads(p.read_text())
        return [row["text"] for row in data]
    return []


def _generate(n: int) -> list[str]:
    """Generate `n` realistic @fattyfatclub-style messages (long/short/TP/mgmt)."""
    toks = ["BTC", "ETH", "SOL", "BNB", "XRP", "DOGE", "AVAX", "LINK", "ARB", "OP"]
    out: list[str] = []
    for i in range(n):
        t = toks[i % len(toks)]
        kind = i % 6
        if kind == 0:
            out.append(f"{t}USDT LONG entry {60000+i} sl {59000-i} tp {62000+i} lev 3 conf 0.8")
        elif kind == 1:
            out.append(f"#{t} SHORT entry {3000-i} sl {3100+i} tp {2800-i} lev 5 conf 0.7")
        elif kind == 2:
            out.append(f"{t}USDT LONG entry {1000+i} tp {1050+i} lev 2")
        elif kind == 3:
            out.append("sl to entry")
        elif kind == 4:
            out.append(f"tp1 {2000+i}")
        else:
            out.append("full close")
    return out


async def run() -> int:
    samples = _load_samples()
    generated = _generate(100 - len(samples))
    texts = (samples + generated)[:100]
    if not texts:
        print("no messages to replay", file=sys.stderr)
        return 2

    raws: list[RawSignal] = []
    now_ms = int(time.time() * 1000)
    for i, t in enumerate(texts):
        r = parse_message(t, message_id=1000 + i, ts_ms=now_ms - i * 1000,
                          channel="fattyfatclub", source="fattyfatclub")
        # exercise the media/attachment path for a few messages
        if i % 20 == 0:
            r.has_media = True
        raws.append(r)

    source = FakeSignalSource(raws)
    exchange = FakeExchangeAdapter(market_prices={
        f"{t}USDT": 1000.0 + i * 10 for i, t in enumerate(
            ["BTC", "ETH", "SOL", "BNB", "XRP", "DOGE", "AVAX", "LINK", "ARB", "OP"])})
    # Seed marks so the fast-path has a mark price to size against (realistic of a
    # live run where WS tickers feed markPrice). Without marks the fast-path
    # legitimately escalates (can't size safely) -> IGNORE; we want to exercise ENTER.
    market = FakeMarketStream(marks={
        f"{t}USDT": 1000.0 + i * 10 for i, t in enumerate(
            ["BTC", "ETH", "SOL", "BNB", "XRP", "DOGE", "AVAX", "LINK", "ARB", "OP"])})
    notifier = TelegramNotifier()
    risk = FixedRiskSizer(RiskConfig())
    ledger = Ledger()       # no-op (no CONFIG_DB_TEST_URL in replay)
    eval_writer = EvalWriter()

    orch = Orchestrator(
        source=source, exchange=exchange, market=market, notifier=notifier,
        risk=risk, ledger=ledger, eval_writer=eval_writer,
        cfg=OrchestratorConfig(bot_name="bybit-main", paper=True),
        tradable={f"{t}USDT" for t in
                  ["BTC", "ETH", "SOL", "BNB", "XRP", "DOGE", "AVAX", "LINK", "ARB", "OP"]},
    )
    orch.learning = None  # learning loop optional; not required for replay

    # wire market handlers + start source (drives the queue synchronously)
    orch._wire_market(market)
    await source.start()

    stats = {"ENTER": 0, "IGNORE": 0, "MANAGE": 0, "errors": 0}
    for r in raws:
        try:
            d = await orch.handle(r)
            stats[d.action] = stats.get(d.action, 0) + 1
        except Exception as e:  # pragma: no cover - we want zero of these
            stats["errors"] += 1
            print(f"CRASH on msg {r.raw_text!r}: {e!r}", file=sys.stderr)

    print(f"replayed {len(raws)} messages")
    print(f"decisions: {stats}")
    print(f"notifier buffered alerts: {len(notifier.buffered)}")
    if stats["errors"] > 0:
        print("REPLAY FAILED: crashes detected", file=sys.stderr)
        return 2
    if stats["ENTER"] == 0 and stats["MANAGE"] == 0 and stats["IGNORE"] == 0:
        print("REPLAY FAILED: no decisions produced (wiring broken)", file=sys.stderr)
        return 2
    print("REPLAY OK: zero crashes, pipeline produced decisions")
    return 0


if __name__ == "__main__":
    raise SystemExit(asyncio.run(run()))
