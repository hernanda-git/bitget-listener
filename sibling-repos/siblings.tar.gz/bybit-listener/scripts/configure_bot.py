#!/usr/bin/env python3
"""Create / update the bybit bot's Postgres config row (spec §17, §7).

Writes the bot row into the shared `fatty_config` DB (single psycopg driver, no new
server). Stores ONLY non-secret runtime settings + env-var NAMES (never values).
The `paper` flag is the live/dry gate and is persisted here so it survives restarts.

Usage examples:
  # create the default paper/testnet bot
  python scripts/configure_bot.py --name bybit-main --channel fattyfatclub

  # flip a bot to live (only after the go-live gate is met; two-step)
  python scripts/configure_bot.py --name bybit-main --paper false

Secrets (BYBIT_API_KEY, BYBIT_API_SECRET, TG_BOT_TOKEN, ...) belong in the
git-ignored .env, never here. Run with the project venv:
  /usr/local/lib/hermes-agent/venv/bin/python3 scripts/configure_bot.py ...
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from dotenv import load_dotenv  # noqa: E402

load_dotenv(Path(__file__).resolve().parent.parent / ".env")

from src.config.db import BotConfig, ConfigStore, ensure_default_bot  # noqa: E402
from src.services.risk import RiskConfig  # noqa: E402


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(description="configure bybit bot Postgres row")
    p.add_argument("--name", default="bybit-main")
    p.add_argument("--channel", default=None)
    p.add_argument("--min-confidence", type=float, default=None)
    p.add_argument("--testnet", type=lambda v: str(v).lower() == "true", default=None)
    p.add_argument("--paper", type=lambda v: str(v).lower() == "true", default=None)
    p.add_argument("--enabled", type=lambda v: str(v).lower() == "true", default=None)
    p.add_argument("--tg-bot-token-env", default=None)
    p.add_argument("--tg-bot-chat-env", default=None)
    p.add_argument("--risk-default-leverage", type=int, default=None)
    p.add_argument("--risk-max-leverage", type=int, default=None)
    p.add_argument("--risk-default-margin-usd", type=float, default=None)
    p.add_argument("--risk-max-notional-usd", type=float, default=None)
    args = p.parse_args(argv)

    store = ConfigStore()
    cfg = ensure_default_bot(store, args.name)

    if args.channel is not None:
        cfg.channel = args.channel
    if args.min_confidence is not None:
        cfg.min_confidence = args.min_confidence
    if args.testnet is not None:
        cfg.testnet = args.testnet
    if args.paper is not None:
        cfg.paper = args.paper
    if args.enabled is not None:
        cfg.enabled = args.enabled
    if args.tg_bot_token_env is not None:
        cfg.tg_bot_token_env = args.tg_bot_token_env
    if args.tg_bot_chat_env is not None:
        cfg.tg_bot_chat_env = args.tg_bot_chat_env

    store.upsert_bot(cfg)

    # risk row
    risk = store.get_risk(cfg.name)
    if args.risk_default_leverage is not None:
        risk.default_leverage = args.risk_default_leverage
    if args.risk_max_leverage is not None:
        risk.max_leverage = args.risk_max_leverage
    if args.risk_default_margin_usd is not None:
        risk.default_margin_usd = args.risk_default_margin_usd
    if args.risk_max_notional_usd is not None:
        risk.max_notional_usd = args.risk_max_notional_usd
    store.upsert_risk(cfg.name, risk)

    print(f"configured bot '{cfg.name}':")
    print(f"  enabled={cfg.enabled} paper={cfg.paper} testnet={cfg.testnet} "
          f"channel={cfg.channel} min_confidence={cfg.min_confidence}")
    print(f"  live={cfg.live} (live means paper=False AND enabled=True)")
    print(f"  risk: lev={risk.default_leverage}/{risk.max_leverage} "
          f"margin=${risk.default_margin_usd} max_notional=${risk.max_notional_usd}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
