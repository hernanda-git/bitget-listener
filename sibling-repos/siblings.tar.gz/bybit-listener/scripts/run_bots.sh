#!/usr/bin/env bash
# run_bots.sh — supervisor entrypoint invoked by deploy.sh.
# Launches ONE `main.py --dashboard` child per enabled bot in the config DB.
# Each bot is PAPER/testnet unless its DB row has paper=0 (flipped only via the
# two-step go-live gate). Exactly one listener per bot token (spec §18.6).
#
# No secrets here. main.py reads them from the git-ignored .env. If the config DB
# is unreachable, main.py degrades to safe paper/testnet defaults (no crash).
set -euo pipefail
cd "$(dirname "$0")/.."

PY="${PY:-/usr/local/lib/hermes-agent/venv/bin/python3}"
[[ -x "$PY" ]] || PY="python3"
export PYTHONPATH="$(pwd)"

# If a single bot name is given as $1, run just that bot; else run all enabled bots.
if [[ -n "${1:-}" ]]; then
  echo "launching bot: $1"
  exec "$PY" main.py --dashboard --bot "$1"
fi

echo "launching all enabled bots (paper/testnet unless go-live gate passed)"
# Default single-bot launch; --all-bots expansion can be added when multiple
# bot rows exist in the config DB.
exec "$PY" main.py --dashboard --bot "${BOT_NAME:-bybit-main}"
