#!/usr/bin/env python3
"""Phase 10 replay — management messages against seeded positions.

Drives PositionManager + OrderService transforms directly (FAKE exchange, no network)
to verify the management routing from the orchestrator:
  * `sl to entry`  -> set-trading-stop SL=entry (protective reduce_only preserved)
  * `tp1 booked`/'partial' -> close 50% reduce_only + SL->entry + keep TP
  * `full close`/`cutting` -> full reduce_only close (opposite side)
  * `tp1 <price>` / `tp2 <price>` -> set-trading-stop TP modify
  * NEVER cancels reduce_only protective orders (spec §2.3, §18.5).

Asserts: (1) zero crashes, (2) every management action produced the right exchange
call(s), (3) no reduce_only protective order was ever cancelled.

Exit: 0 = all assertions pass; 2 = any assertion fails.
"""

from __future__ import annotations

import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.domain.model import Instrument, Position  # noqa: E402
from src.exchanges.fake import FakeExchangeAdapter, FakeMarketStream  # noqa: E402
from src.notifier.bot import TelegramNotifier  # noqa: E402
from src.orchestrator import Orchestrator, OrchestratorConfig  # noqa: E402
from src.sources.parser import parse_message  # noqa: E402
from src.sources.telegram import FakeSignalSource  # noqa: E402


def _seed_position(orch: Orchestrator, sym: str, side: str, entry: float,
                   size: float, sl: float, tp: float) -> None:
    inst = Instrument.from_token(sym)
    pos = Position(instrument=inst,
                   side="BUY" if side == "BUY" else "SELL",
                   size=size, entry_price=entry,
                   leverage=3, sl_price=sl, tp_price=tp)
    orch.pos_mgr.positions[sym] = pos


def _clear(ex: FakeExchangeAdapter) -> None:
    ex.placed.clear()
    ex.trading_stops.clear()
    ex.cancelled.clear()
    ex.cancel_all_calls.clear()


async def run() -> int:
    source = FakeSignalSource([])
    exchange = FakeExchangeAdapter()
    market = FakeMarketStream()
    notifier = TelegramNotifier()
    orch = Orchestrator(
        source=source, exchange=exchange, market=market, notifier=notifier,
        cfg=OrchestratorConfig(bot_name="bybit-main", paper=True),
        tradable={"BTCUSDT", "ETHUSDT"},
    )
    orch._wire_market(market)

    failures: list[str] = []

    # --- case 1: sl to entry (token included so the symbol resolves) ---
    _seed_position(orch, "BTCUSDT", "BUY", 60000.0, 0.01, 59000.0, 62000.0)
    await orch._handle_management(parse_message("BTCUSDT sl to entry", message_id=1,
                                                ts_ms=1, channel="fattyfatclub",
                                                source="fattyfatclub"))
    if "BTCUSDT" not in orch.pos_mgr.positions:
        failures.append("sl_to_entry cancelled/dropped the position")
    if not any(s[0] == "BTCUSDT" and abs((s[1] or 0) - 60000.0) < 1e-6
               for s in exchange.trading_stops):
        failures.append("sl_to_entry did not move SL to entry price")

    # --- case 2: partial / tp1 booked ---
    _clear(exchange)
    _seed_position(orch, "ETHUSDT", "SELL", 3000.0, 0.5, 2900.0, 2800.0)
    await orch._handle_management(parse_message("ETHUSDT tp1 booked", message_id=2,
                                                ts_ms=1, channel="fattyfatclub",
                                                source="fattyfatclub"))
    if not any(o.reduce_only for o in exchange.placed):
        failures.append("partial: close was not reduce_only")
    if not any(s[0] == "ETHUSDT" and (s[1] or 0) != 0 for s in exchange.trading_stops
               if abs((s[1] or 0) - 3000.0) < 1e-6):
        failures.append("partial: SL->entry not issued")

    # --- case 3: full close ---
    _clear(exchange)
    _seed_position(orch, "BTCUSDT", "BUY", 60000.0, 0.01, 59000.0, 62000.0)
    await orch._handle_management(parse_message("BTCUSDT full close", message_id=3,
                                                ts_ms=1, channel="fattyfatclub",
                                                source="fattyfatclub"))
    if not any(o.reduce_only for o in exchange.placed):
        failures.append("full_close: no reduce_only close order")

    # --- case 4: tp modify ---
    _clear(exchange)
    _seed_position(orch, "ETHUSDT", "BUY", 3000.0, 0.5, 2900.0, 2800.0)
    await orch._handle_management(parse_message("ETHUSDT tp1 3100", message_id=4,
                                                ts_ms=1, channel="fattyfatclub",
                                                source="fattyfatclub"))
    if not any(s[0] == "ETHUSDT" and abs((s[2] or 0) - 3100.0) < 1e-6
               for s in exchange.trading_stops):
        failures.append("tp_modify: TP not updated to 3100")

    # --- invariant: no reduce_only protective order was ever cancelled ---
    if exchange.cancelled:
        failures.append("a cancel_order was issued during management (forbidden)")

    if failures:
        print("REPLAY MGMT FAILED:")
        for f in failures:
            print(f"  - {f}")
        return 2
    print("REPLAY MGMT OK: sl_to_entry / partial / full_close / tp_modify verified;")
    print("  no reduce_only protective orders cancelled.")
    return 0


if __name__ == "__main__":
    raise SystemExit(asyncio.run(run()))
