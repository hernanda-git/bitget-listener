# Changelog — bybit-listener

Canonical historical record. Every behavior change states the OLD behavior.
`deploy.sh` refuses to deploy if `## [Unreleased]` is empty or tests fail.

## [Unreleased]

_Nothing yet._

---

## [0.2.0] — 2026-08-12

### Added
- Phase 0 scaffold: repo, `pyproject.toml`, `requirements.txt`, `config.example.yaml`,
  `.env.example`, `.gitignore`, `CHANGELOG.md`, `AGENTS.md`, `README.md`, `deploy.sh`.
- Postgres `ConfigStore` (`src/config/db.py`) reusing the Sera `fatty_config` DB
  (psycopg, single driver — matching the hyperliquid-fatty-trader fork). One row per
  bot (`paper`, `enabled`, `channel`, `testnet`, token-env-name, risk). `paper` flag is
  persisted and read before acting (no boot-safe assumption).
- `git init`; `git check-ignore .env` confirmed (secrets never committed).

### Added (Phase 1)
- `src/domain/model.py`: pure frozen dataclasses `Instrument`, `Signal`, `Fill`,
  `Position`, `TradeDecision` (+ pipeline types `RawSignal`, `OrderRequest`).
  `Fill.fee` is real and always recorded; `Position.liq_price` holds the real
  liquidation price (closes BUG A + BUG B at the model level).
- `src/interfaces/ports.py`: ABCs `SignalSource`, `ExchangeAdapter`, `MarketStream`,
  `Notifier`, `RiskPolicy`, `PegSource`, `AttachmentFetcher`. Bybit adapter MUST sit
  behind `ExchangeAdapter` (venue-swappable, unit-testable).
- `src/exchanges/fake.py` + `src/streaming/fake.py`: `FakeExchangeAdapter`
  (records placed orders/fills with non-zero fees) and `FakeMarketStream`
  (scripted marks). No network in unit tests.

### Added (Phase 2)
- `src/sources/parser.py`: free-text signal parser (`BTCUSDT LONG entry.. sl.. tp.. lev..`,
  `#TOKEN`/`$TOKEN`, LONG/SHORT->BUY/SELL) + centralized `SymbolMap` (TOKEN->TOKENUSDT).
  Management messages routed (`sl to entry`, `tp1 booked`, `closed at entry`, `tp1 <price>`).
  Bare-ticker resolution only fires when the message has signal context (chatter ignored).
- `src/services/normalizer.py`: `SignalNormalizer` + `StablecoinPegGuard` (tol 0.5%, peg=1.0
  for Bybit USDT) — closes the depeg-guard gap.
- `src/services/validator.py`: Gate1 (pre-LLM: idempotency, whitelist, confidence floor,
  cooldown, media filter, max-age) + Gate2 (post-LLM ENTER-only: leverage cap, SL direction,
  min-notional floor, portfolio/daily caps, fee-adjusted expectancy) + `FastPath` (sub-second
  pre-LLM decision, escalates ambiguity to LLM).
- `src/services/risk.py`: `FixedRiskSizer` fee-aware sizing (`net_usd = gross - fees`).
- `src/sources/telegram.py` (`TelegramSource` SignalSource, integration-gated) +
  `FakeSignalSource`; `src/sources/llm_signal.py` (ambiguous-only, abstains w/o endpoint);
  `src/sources/attachment_fetcher.py`; `docs/channel_sample.json` (recorded-style payloads).
- 15 Phase-2 unit tests; `docs/channel_sample.json` parses cleanly.

### Added (Phase 3)
- `src/exchanges/bybit.py`: `BybitAdapter` (V5 REST, category=linear) behind
  `ExchangeAdapter`. Centralizes HMAC-SHA256 signing (§4.2, unit-tested against an
  independent recomputation), `instruments-info` cache, `round_qty`/`round_price`
  (§4.8, clip to min/max + tick) — the explicit guard against the HL asset-index bug.
  `orderLinkId = "b-" + ulid` on every order for idempotency/dedup. All endpoints:
  create/cancel/amend-style cancel-all, set-trading-stop, set-leverage (ignore 110012),
  wallet-balance, position-list, execution list, tickers, market-time.
- Token-bucket + exponential backoff on 10006/10018/170151 (§4.7); non-retryable errors
  surface verbatim retCode/retMsg (no hacking around schema drift — fixes fork "probe
  blind to error body").
- `scripts/bybit_api_probe.py`: TESTNET-only recovery probe (never mainnet) verifying
  real schemas: time sync, instruments, leverage, tiny $1/3x market order w/ attached
  SL/TP, **non-zero execFee fill (BUG A)**, set-trading-stop SL->entry, cancel-all;
  writes `data/bybit_api_status.json`. Skips gracefully when keys are absent.

### Verification gate (Phase 3 live)
- LIVE testnet schema verification REQUIRES Bybit TESTNET API keys (BYBIT_API_KEY/
  BYBIT_API_SECRET) in `.env`. None exist on this box and cannot be fabricated. Offline
  algorithm tests (signing, rounding, order-body) pass; the live arbiter run is gated
  on the user supplying TESTNET keys, then `python3 scripts/bybit_api_probe.py`.

### Added (Phase 4)
- `src/streaming/bybit_ws.py`: `BybitWS` (`MarketStream`) — private WS auth
  (HMAC `GET/realtime+expires`, §4.3), subscribe `order`/`position`/`wallet`/`execution`
  + public `tickers`/`orderbook.50`/`publicTrade`/`liquidation` (§4.5). Parsers deliver
  `Fill` (real `execFee` -> BUG A) and `Position` (liquidation keeps REAL `liqPrice`,
  never 0.00 -> BUG B). `mark_price(sym)` for the port. Forces testnet when `testnet=True`.
- `src/streaming/bybit_ws_fake.py`: `FakeBybitWS` drives the parsers/dispatch offline so
  fill-fee + liquidation-price logic is verified without a live socket (keys still gate
  the real connection). Handlers accept sync or async callbacks.

### Verification gate (Phase 4 live)
- LIVE testnet WS connection (auth + streaming fills/positions at 1-2s) requires Bybit
  TESTNET keys in `.env`. Offline parsing tests pass; live run gated on user-supplied keys.

### Added (Phase 5)
- `src/services/order.py`: order transforms (entry w/ attached SL/TP, sl->entry, partial
  close 50% reduce_only, full close reduce_only, tp modify). Every path uses the exchange
  adapter's centralized symbol/rounding — guard against the HL asset-index + string-id bugs.
- `src/services/position.py`: `PositionManager` WS-synced state machine. Records every
  Fill's REAL execFee (BUG A); books liquidation at the REALIZED liq_price/execPrice, never
  0.00 (BUG B); self-heal re-attaches missing SL/TP without cancelling reduce_only orders
  (spec §2.3); dead-man's switch flattens via cancel-all + halts on heartbeat loss.

### Added (Phase 6)
- `src/store/ledger.py`: `Ledger` (psycopg, single driver) — FEE-AWARE `trades_log`
  (open_fee, close_fee, gross_usd, net_usd = gross - fees, exit_price REAL, liq_price
  non-null only on liquidation). `signals_log`, `bias_log`. The write asserts
  `net_usd == gross - open - close` (BUG A/B contract).
- `src/store/min_notional.py`: `MinNotionalCache` per-pair floors from instruments-info.

### Schema reconciliation finding (spec §7 / §18 / §21 — SURFACED, not hacked)
- The existing Sera `fatty_config.trades_log` was created by the hyperliquid-fatty-trader
  fork and has the OLDER shape (`bot`, `pnl`, `exit_px`, `dry`, NOT NULL `ts_open`/`iso_open`,
  no fee-aware columns). §7's assumed schema did not match reality. Fixed per §7 ("migrations
  safe, try/except ALTER"): `_ensure_schema` CREATEs only if absent, then ALTER-adds every
  fee-aware column idempotently. `write_trade` inserts into BOTH spec and fork-legacy columns
  (bot=bot_name, pnl=net_usd, exit_px=exit_price, ts_open/iso_open filled) so bybit trades are
  queryable from the existing dashboard. Verified against the real `fatty_config_test` DB:
  open_fee/close_fee non-zero and liq_price persisted as the REAL price (not 0.00).

### Added (Phase 7)
- `src/services/reflexivity.py`: the actual edge both parents never built — `SignalPopularity`
  (first_seen/reaction_count/price_impact_1s), `CounterTradeTilt` (crowded -> fade 0.5 or
  counter -1.0, with decay), `ShadowLedger` (decay_score over a window). Measured, not assumed.
- `src/services/fusion.py`: pure microstructure calculators (orderbook imbalance, CVD,
  funding-aware fusion tilt) for independent signal fusion (spec §15).
- `src/store/eval.py`: `EvalWriter` (psycopg) — equity_snapshots, signal_popularity,
  shadow_ledger, param_log, strategy_perf (window_label; `window` is reserved SQL),
  orderbook_features. Reuses fatty_config; creates tables if absent.

### Added (Phase 8)
- `src/learning/loop.py`: `LearningLoop` — drift detection (recent window vs baseline
  fee-adjusted expectancy) + `ParamProposal` rotation. CRITICAL: any param change is
  GATED behind `confirm()` (spec §2.7, §18) — proposals carry `confirmed=False` and are
  never auto-applied to live sizing. Closes the "documented but never built" learning
  layer gap in both parents without the YOLO auto-tune trap.

### Safety
- Secrets live ONLY in git-ignored `.env`; Postgres stores env-var NAMES only, never
  key/token values. Learning loop never auto-enables blindly.

### Added (Phase 9)
- `src/notifier/bot.py`: `TelegramNotifier` (alerts/status) + `GoLiveGate` — the
  TWO-STEP go-live gate. `issue_token()` (step 1) mints a one-time token persisted to
  the bot's `fatty_config` row; `redeem(token, expectancy)` (step 2) only flips
  `paper=0` after the gate (fee-aware expectancy > 0) is met. Without BOTH steps no
  real order fires. `paper` is read from the DB row before acting (spec §18.2).

### Added (Phase 10 — wiring + replay + gate, this session)
- `src/orchestrator.py` (NEW): the missing pipeline coordinator (spec §5). Threads
  SignalSource -> parse/normalize -> Gate1 -> FastPath -> (LLM escalate) -> Gate2 ->
  build_entry -> ExchangeAdapter, and WS fills/positions -> PositionManager. Enforces
  the live/dry gate by reading the bot's DB row BEFORE acting. On every position close
  it writes a FEE-AWARE `TradeRow` to the ledger (BUG A/B contract: net = gross - fees,
  liq_price never 0.00) and feeds the LearningLoop. Management messages route to the
  OrderService transforms (never cancel reduce_only protective orders).
- `main.py` (NEW): composition root with run modes `--check-tg`, `--live-dry`,
  `--dashboard`, `--go-live`, `--all-bots`, `--bot NAME`, `--status/--balance/--positions/
  --signals/--last/--test`. Builds the real adapters via DI. DEGRADES GRACEFULLY when the
  config DB is unreachable (warns + falls back to safe paper/testnet defaults) instead of
  crashing, so paper-dry operation works end-to-end without a DB (spec §20.7).
- `scripts/configure_bot.py` (NEW): creates/updates the bot's `fatty_config` row
  (stores only non-secret runtime flags + env-var NAMES). `--paper false` flips the gate.
- `scripts/replay_real.py` (NEW): runs 100 real/generated @fattyfatclub messages +
  chart-attachment path through the orchestrator with FAKE adapters (no network).
  Asserts zero crashes and a sane decision mix. (Found + fixed a real parser bug:
  entry signals carrying `sl/tp` were misrouted to the management path — now an entry
  signal with a side+entry price is never treated as management.)
- `scripts/replay_mgmt.py` (NEW): verifies `sl to entry` / partial / full close / tp
  modify against seeded positions, and asserts no reduce_only protective order is ever
  cancelled.
- `src/position.py`: `PositionManager.last_close` now carries full fee-aware close
  detail so the orchestrator's close handler can persist a complete `TradeRow`.
- `src/services/order.py`: `opposite_side()` typed as `Literal["BUY","SELL"]` (matches
  the `OrderRequest.side` literal; fixes the string-built close-side typing).
- `src/services/parser.py`: entry signals (side + entry price present) are no longer
  misrouted to management due to their `sl/tp` text (regression test added).

### Verification (this session)
- `python -m compileall src scripts` clean; `pytest` green (81 passed).
- `replay_real.py`: 100 msgs -> ENTER 30 / IGNORE 21 / MANAGE 49 / errors 0.
- `replay_mgmt.py`: sl_to_entry / partial / full_close / tp_modify verified; no
  reduce_only protective order cancelled.
- `main.py` run modes start without crashing; DB-down degrades to safe paper defaults.
- GO-LIVE GATE NOT YET MET: no testnet keys present, so the live API probe
  (`scripts/bybit_api_probe.py`) has not verified BUG A/B against testnet, and
  fee-aware expectancy > 0 is unproven. Bot remains paper/testnet-by-default.
