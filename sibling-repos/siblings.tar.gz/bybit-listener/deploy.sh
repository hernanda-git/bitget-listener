#!/usr/bin/env bash
# deploy.sh — guard-then-deploy for bybit-listener.
# Adapted from the hyperliquid-fatty-trader contract: refuses to deploy unless
# (1) the pytest suite is green and (2) CHANGELOG.md documents the change under
# '## [Unreleased]'. Bumps VERSION, restarts the dashboard supervisor, confirms
# exactly one listener per bot token.
set -euo pipefail

cd "$(dirname "$0")"

BUMP="${1:-patch}"
PY="${PY:-/usr/local/lib/hermes-agent/venv/bin/python3}"
[[ -x "$PY" ]] || PY="python3"

if [[ ! -f VERSION ]]; then echo "0.1.0" > VERSION; fi
OLD="$(cat VERSION)"
IFS='.' read -r MAJ MIN PAT <<< "$OLD"
case "$BUMP" in
  major) MAJ=$((MAJ+1)); MIN=0; PAT=0 ;;
  minor) MIN=$((MIN+1)); PAT=0 ;;
  patch|*) PAT=$((PAT+1)) ;;
esac
NEW="$MAJ.$MIN.$PAT"

if [[ "${SKIP_GUARDS:-0}" != "1" ]]; then
  echo "Running test suite..."
  if ! "$PY" -m pytest -q > /tmp/bybit_deploy_pytest.log 2>&1; then
    echo "DEPLOY BLOCKED: tests are failing."
    tail -25 /tmp/bybit_deploy_pytest.log
    exit 1
  fi
  echo "Tests green: $(tail -1 /tmp/bybit_deploy_pytest.log)"

  if [[ ! -f CHANGELOG.md ]]; then
    echo "DEPLOY BLOCKED: CHANGELOG.md is missing (canonical history)."
    exit 1
  fi
  # Promote [Unreleased] -> [NEW] only if it has real content.
  if grep -q "^## \[$NEW\]" CHANGELOG.md; then
    :
  elif grep -q "^## \[Unreleased\]" CHANGELOG.md; then
    BODY="$(awk '/^## \[Unreleased\]/{f=1;next} /^## \[/{f=0} f' CHANGELOG.md \
            | grep -v '^\s*$' | grep -v '^_Nothing yet\._$' | grep -v '^---$' || true)"
    if [[ -z "$BODY" ]]; then
      echo "DEPLOY BLOCKED: CHANGELOG.md '## [Unreleased]' is empty."
      echo "Describe the change (Added/Changed/Fixed/Removed/Safety) before deploying."
      exit 1
    fi
    TODAY="$(date +%F)"
    "$PY" - "$NEW" "$TODAY" <<'PYEOF'
import sys, pathlib, re
new, today = sys.argv[1], sys.argv[2]
p = pathlib.Path("CHANGELOG.md")
lines = p.read_text().split("\n")
for i, ln in enumerate(lines):
    if re.fullmatch(r"## \[Unreleased\]\s*", ln):
        lines[i:i+1] = [
            "## [Unreleased]",
            "",
            "_Nothing yet._",
            "",
            "---",
            "",
            f"## [{new}] — {today}",
        ]
        break
else:
    sys.exit("CHANGELOG.md: no '## [Unreleased]' heading line found")
p.write_text("\n".join(lines))
print(f"CHANGELOG.md: [Unreleased] promoted to [{new}] - {today}")
PYEOF
  else
    echo "DEPLOY BLOCKED: CHANGELOG.md has no '## [Unreleased]' or '## [$NEW]' section."
    exit 1
  fi
fi

echo "$NEW" > VERSION
echo "VERSION bumped: $OLD -> $NEW"

# Restart exactly one supervisor (one child per enabled bot). Kill supervisor
# FIRST so it cannot respawn a duplicate listener on the same token.
echo "Restarting bot processes..."
pkill -f "scripts/run_bots.sh" 2>/dev/null || true
PIDS="$(pgrep -f "python3 -m src[.]main --dashboard" || true) $(pgrep -f "python3 -m src[.]main --bot" || true)"
if [[ -n "$PIDS" ]]; then
  for pid in $PIDS; do kill "$pid" 2>/dev/null || true; done
  sleep 2
  for pid in $PIDS; do kill -9 "$pid" 2>/dev/null || true; done
fi
sleep 1
mkdir -p logs
PYTHONPATH=. nohup bash scripts/run_bots.sh > logs/bots_supervisor.log 2>&1 &
echo "Started bot supervisor (pid $!) — log: logs/bots_supervisor.log"
sleep 6

RUNNING="$(pgrep -fc "python3 -m src[.]main --bot" || true)"
echo "Running bot --bot processes: ${RUNNING:-0}"
if [[ "${RUNNING:-0}" -gt 1 ]]; then
  echo "WARNING: MORE THAN ONE bot process (${RUNNING}) — Telegram Conflict risk."
fi
echo "Done. Deploy v$NEW."
