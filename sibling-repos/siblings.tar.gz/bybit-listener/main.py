#!/usr/bin/env python3
"""Composition root for bybit-listener (spec §5, §17).

Builds the orchestrator from the real adapters via Dependency Injection and launches
the requested run mode. Safety-first: it reads the bot's persisted DB row for the
live/dry gate BEFORE acting (spec §18.2) and never places a real order unless paper=0
AND the go-live gate is satisfied.

Run modes (spec §17):
  --check-tg            Verify TG client + channel reachable, then exit.
  --live-dry            Real signal source, DRY-RUN, forced paper (never real orders).
  --dashboard           Default: run the bot (paper unless --go-live + /live done).
  --go-live             Mint a one-time token, print it (no real order can fire yet).
  --all-bots            Launch one orchestrator child per enabled bot (distinct token).
  --bot NAME            Target a specific bot row (default bybit-main).
  --status / --balance / --positions / --signals / --last / --test
                        One-shot diagnostics via the bot row / adapters (no orders).

Secrets come from the git-ignored .env (BYBIT_API_KEY, BYBIT_API_SECRET, TG_*,
CONFIG_DB_URL). Never echo them. The DB stores only env-var NAMES + runtime flags.

Interpreter: /usr/local/lib/hermes-agent/venv/bin/python3 (NOT system python3).
"""

from __future__ import annotations

import argparse
import asyncio
import os
import sys
from pathlib import Path

# Ensure repo root is importable.
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from dotenv import load_dotenv  # noqa: E402

load_dotenv(ROOT / ".env")

from src.config.db import ConfigStore, ensure_default_bot  # noqa: E402
from src.exchanges.bybit import BybitAdapter, BybitConfig  # noqa: E402
from src.notifier.bot import GoLiveGate, TelegramNotifier  # noqa: E402
from src.orchestrator import Orchestrator, OrchestratorConfig  # noqa: E402
from src.services.risk import RiskConfig  # noqa: E402
from src.sources.telegram import TelegramSource  # noqa: E402
from src.store.eval import EvalWriter  # noqa: E402
from src.store.ledger import Ledger  # noqa: E402
from src.streaming.bybit_ws import BybitWS, WSConfig  # noqa: E402


def _bybit_cfg(testnet: bool) -> BybitConfig:
    return BybitConfig(
        api_key=os.getenv("BYBIT_API_KEY", ""),
        api_secret=os.getenv("BYBIT_API_SECRET", ""),
        testnet=testnet,
    )


def _ws_cfg(testnet: bool) -> WSConfig:
    return WSConfig(
        api_key=os.getenv("BYBIT_API_KEY", ""),
        api_secret=os.getenv("BYBIT_API_SECRET", ""),
        testnet=testnet,
    )


def build_orchestrator(bot_name: str = "bybit-main", force_paper: bool = False,
                        live_source: bool = True, tradable: set[str] | None = None):
    """Construct the orchestrator with REAL adapters wired in (DI).

    Degrades gracefully: if the Postgres config DB is unreachable (e.g. missing .env
    or the shared `app` role auth fails), it falls back to safe paper/testnet defaults
    rather than crashing. The ledger/eval writers already no-op when no DB URL is set,
    so paper-dry operation still works end-to-end (spec §20.7)."""
    store = None
    row = None
    try:
        store = ConfigStore()
        row = ensure_default_bot(store, bot_name)
    except Exception as e:
        print(f"[warn] config DB unavailable ({e!r}); running with safe "
              f"paper/testnet defaults, no persisted config.", file=sys.stderr)
        store = None
    testnet = row.testnet if row else True
    paper = True if force_paper else (row.paper if row else True)

    exchange = BybitAdapter(_bybit_cfg(testnet))
    market = BybitWS(_ws_cfg(testnet), symbols=list(tradable or set()))

    channel = row.channel if row else "fattyfatclub"
    source = TelegramSource(channel=channel) if live_source else None
    if source is None:  # pragma: no cover - dry mode still needs a source for tests
        from src.sources.telegram import FakeSignalSource
        source = FakeSignalSource([])

    notifier = TelegramNotifier(
        token_env=row.tg_bot_token_env if row else "TG_BOT_TOKEN",
        chat_env=row.tg_bot_chat_env if row else "TG_BOT_CHAT",
    )
    risk_cfg = RiskConfig(default_margin_usd=1.0, default_leverage=3, max_notional_usd=50.0)
    from src.services.risk import FixedRiskSizer
    risk = FixedRiskSizer(risk_cfg)
    ledger = Ledger()        # no-op unless CONFIG_DB_URL (or TEST) is set
    eval_writer = EvalWriter()

    orch = Orchestrator(
        source=source, exchange=exchange, market=market, notifier=notifier,
        risk=risk, ledger=ledger, eval_writer=eval_writer, store=store,
        cfg=OrchestratorConfig(
            bot_name=bot_name, paper=paper, min_confidence=row.min_confidence if row else 0.5,
            default_leverage=risk_cfg.default_leverage, max_notional_usd=risk_cfg.max_notional_usd,
        ),
        tradable=tradable,
    )
    return orch, store, row


async def _cmd_check_tg(bot_name: str) -> int:
    orch, _store, row = build_orchestrator(bot_name, live_source=True)
    try:
        await orch.source.start()
        print(f"OK: Telegram listener started for channel '{orch.source.channel}'")
        await asyncio.sleep(2)
        await orch.source.stop()
        return 0
    except Exception as e:
        print(f"TG check FAILED: {e!r}", file=sys.stderr)
        return 1


async def _cmd_go_live(bot_name: str) -> int:
    try:
        store = ConfigStore()
        ensure_default_bot(store, bot_name)
    except Exception as e:
        print(f"go-live FAILED: config DB unavailable ({e!r}). "
              f"Cannot persist token without the DB.", file=sys.stderr)
        return 1
    gate = GoLiveGate(store, bot_name)
    token = gate.issue_token()
    print("=== TWO-STEP GO-LIVE (step 1 of 2) ===")
    print(f"Token minted for bot '{bot_name}'. Send /live {token} in chat to go live.")
    print("No real order can fire until step 2 (the /live command) succeeds AND the")
    print("go-live gate (fee-aware expectancy > 0, P0 verified) is met.")
    return 0


async def _cmd_live_dry(bot_name: str) -> int:
    orch, _store, _row = build_orchestrator(bot_name, force_paper=True, live_source=True)
    print("=== LIVE-DRY: real @fattyfatclub source, DRY-RUN (no real orders) ===")
    await orch.start()
    return 0


async def _cmd_dashboard(bot_name: str) -> int:
    orch, _store, row = build_orchestrator(bot_name, live_source=True)
    mode = "LIVE" if (row and row.live) else "PAPER(dry-run)"
    print(f"=== bybit-listener '{bot_name}' starting in {mode} mode ===")
    await orch.start()
    return 0


async def _cmd_status(bot_name: str) -> int:
    orch, _store, row = build_orchestrator(bot_name, live_source=False)
    ex = orch.exchange
    try:
        await ex.refresh_instruments()
        syms = sorted(ex.tradable_symbols())[:10]
        bal = await ex.get_balance_usdt()
        print(f"bot={bot_name} paper={row.paper if row else '?'} testnet={row.testnet if row else '?'}")
        print(f"balance_usdt={bal:.2f}")
        print(f"tradable samples={syms}")
        positions = await ex.get_positions()
        print(f"open_positions={len(positions)}")
    except Exception as e:
        print(f"status FAILED (no keys / network?): {e!r}", file=sys.stderr)
        return 1
    return 0


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(description="bybit-listener composition root")
    p.add_argument("--bot", default="bybit-main")
    p.add_argument("--all-bots", action="store_true")
    p.add_argument("--check-tg", action="store_true")
    p.add_argument("--live-dry", action="store_true")
    p.add_argument("--go-live", action="store_true")
    p.add_argument("--dashboard", action="store_true")
    p.add_argument("--status", action="store_true")
    p.add_argument("--balance", action="store_true")
    p.add_argument("--positions", action="store_true")
    p.add_argument("--signals", action="store_true")
    p.add_argument("--last", action="store_true")
    p.add_argument("--test", action="store_true")
    args = p.parse_args(argv)

    bot = args.bot

    if args.check_tg:
        return asyncio.run(_cmd_check_tg(bot))
    if args.go_live:
        return asyncio.run(_cmd_go_live(bot))
    if args.live_dry:
        return asyncio.run(_cmd_live_dry(bot))
    if args.status or args.balance or args.positions or args.signals or args.last or args.test:
        return asyncio.run(_cmd_status(bot))
    # default: dashboard (run the bot)
    return asyncio.run(_cmd_dashboard(bot))


if __name__ == "__main__":
    raise SystemExit(main())
