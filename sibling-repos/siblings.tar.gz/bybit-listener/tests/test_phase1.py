"""Phase 1 tests — domain model, ports contracts, fakes (no network)."""

from __future__ import annotations

from src.domain.model import (
    Fill,
    Instrument,
    OrderRequest,
    Position,
    RawSignal,
    Signal,
    TradeDecision,
)
from src.exchanges.fake import FakeExchangeAdapter, FakeMarketStream
from src.interfaces.ports import (
    ExchangeAdapter,
    MarketStream,
    Notifier,
    RiskPolicy,
    SignalSource,
)


def test_instrument_from_token() -> None:
    inst = Instrument.from_token("btc")
    assert inst.symbol == "BTCUSDT"
    assert inst.base == "BTC"
    assert inst.quote == "USDT"
    inst2 = Instrument.from_token("ETHUSDT")
    assert inst2.symbol == "ETHUSDT"
    assert inst2.base == "ETH"


def test_signal_is_normalized_usdt() -> None:
    inst = Instrument.from_token("BTC")
    sig = Signal(
        instrument=inst, side="BUY", entry=60000.0, sl=58000.0, tp=64000.0,
        notional_usd=1.0, leverage=3, confidence=0.7,
    )
    assert sig.entry == 60000.0
    assert sig.instrument.quote == "USDT"
    assert sig.peg_rate == 1.0


def test_fill_has_real_fee() -> None:
    f = Fill(order_link_id="b-1", price=60000.0, qty=0.001, side="Buy",
             fee=0.033, fee_asset="USDT", ts_ms=1)
    assert f.fee > 0  # BUG A guard: fee must be recorded, never implicitly 0


def test_position_liq_price_attribute() -> None:
    inst = Instrument.from_token("BTC")
    p = Position(instrument=inst, side="BUY", size=0.001, entry_price=60000.0,
                 leverage=3, liq_price=55000.0)
    assert p.liq_price == 55000.0


def test_order_request_roundtrip_fields() -> None:
    inst = Instrument.from_token("BTC")
    o = OrderRequest(instrument=inst, side="BUY", order_type="Market", qty=0.001,
                     reduce_only=False, sl=58000.0, tp=64000.0, client_order_id="b-x")
    assert o.client_order_id == "b-x"
    assert o.sl_trigger_by == "MarkPrice"
    assert o.tpsl_mode == "Full"


def test_raw_signal_management_flag() -> None:
    r = RawSignal(symbol_usdt="BTCUSDT", side="BUY", is_management=True,
                  management_action="sl_to_entry")
    assert r.is_management is True
    assert r.management_action == "sl_to_entry"


def test_trade_decision_reflexivity_tilt_default() -> None:
    inst = Instrument.from_token("BTC")
    d = TradeDecision(action="ENTER", signal=None, leverage=3, size_coin=0.001,
                      sl=58000.0, tp=64000.0, reason="fast-path")
    assert d.reflexivity_tilt == 0.0


def test_fakes_implement_ports() -> None:
    assert isinstance(FakeExchangeAdapter(), ExchangeAdapter)
    assert isinstance(FakeMarketStream(), MarketStream)


def test_fake_exchange_records_fills_with_fee() -> None:
    import asyncio
    fake = FakeExchangeAdapter(balance_usdt=500.0, market_prices={"BTCUSDT": 60000.0})
    inst = Instrument.from_token("BTC")
    o = OrderRequest(instrument=inst, side="BUY", order_type="Market", qty=0.001,
                     is_market=True, client_order_id="b-1")
    oid = asyncio.get_event_loop().run_until_complete(fake.place_order(o))
    assert oid.startswith("fake-")
    fills = asyncio.get_event_loop().run_until_complete(fake.get_fills())
    assert len(fills) == 1
    assert fills[0].fee > 0  # BUG A exercisable offline
    assert fills[0].order_link_id == "b-1"


def test_fake_exchange_cancel_all_records() -> None:
    import asyncio
    fake = FakeExchangeAdapter()
    ok = asyncio.get_event_loop().run_until_complete(fake.cancel_all())
    assert ok is True
    assert len(fake.cancel_all_calls) == 1


def test_fake_market_stream_marks() -> None:
    import asyncio
    ms = FakeMarketStream({"BTCUSDT": 60000.0})
    asyncio.get_event_loop().run_until_complete(ms.start())
    assert ms.mark_price("BTCUSDT") == 60000.0
    assert ms.mark_price("ETHUSDT") is None
    ms.set_mark("ETHUSDT", 3000.0)
    assert ms.mark_price("ETHUSDT") == 3000.0


def test_port_protocols_are_abc() -> None:
    # Ports must be abstract base classes (spec: "ABCS").
    import abc
    for cls in (SignalSource, ExchangeAdapter, MarketStream, Notifier, RiskPolicy):
        assert issubclass(cls, abc.ABC)
