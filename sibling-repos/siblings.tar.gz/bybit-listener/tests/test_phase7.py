"""Phase 7 tests — reflexivity guard + fusion features + eval writer.

Offline: popularity/tilt/shadow ledger, fusion calculators. DB integration (gated on a
reachable test DB): eval writer round-trips into the real fatty_config_test.
"""

from __future__ import annotations

import os

import pytest

from src.services.fusion import cvd_update, fuse_tilt, orderbook_imbalance
from src.services.reflexivity import (
    CounterTradeTilt, ReflexivityConfig, ShadowLedger, ShadowLedgerRow,
    SignalPopularity,
)
from src.store.eval import EvalWriter


def test_popularity_tracks_reactions() -> None:
    pop = SignalPopularity(ReflexivityConfig(popularity_threshold=3))
    for i in range(3):
        pop.observe("BTCUSDT-LONG", price_impact=0.001)
    assert pop.is_crowded("BTCUSDT-LONG")
    rec = pop._recs["BTCUSDT-LONG"]
    assert rec.reaction_count == 3
    assert rec.price_impact_1s > 0


def test_counter_tilt_fades_when_crowded() -> None:
    cfg = ReflexivityConfig(popularity_threshold=2, fade_tilt=0.5)
    pop = SignalPopularity(cfg)
    tilt = CounterTradeTilt(cfg)
    for i in range(3):
        rec = pop.observe("ETHUSDT-LONG", price_impact=0.002)
    t = tilt.tilt(rec)
    assert 0.0 < t <= 0.5   # faded (half size or less)


def test_counter_tilt_not_faded_when_fresh() -> None:
    cfg = ReflexivityConfig(popularity_threshold=5)
    pop = SignalPopularity(cfg)
    tilt = CounterTradeTilt(cfg)
    rec = pop.observe("SOLUSDT-SHORT", price_impact=0.0)
    assert tilt.tilt(rec) == 1.0   # full size, not crowded


def test_shadow_ledger_decay_score() -> None:
    sl = ShadowLedger(window=5)
    for i in range(3):
        sl.record(ShadowLedgerRow("BTCUSDT-LONG", "BUY", "BUY", 0.001, 0.5, 0.0))
    score = sl.decay_score("BTCUSDT-LONG")
    assert score > 0   # positive edge
    # now record losses
    for i in range(3):
        sl.record(ShadowLedgerRow("BTCUSDT-LONG", "BUY", "BUY", -0.001, -0.5, 0.0))
    assert sl.decay_score("BTCUSDT-LONG") < 0   # decaying edge


def test_orderbook_imbalance_bounds() -> None:
    assert orderbook_imbalance(10, 10) == 0.0
    assert orderbook_imbalance(30, 10) > 0.0    # bid-heavy
    assert orderbook_imbalance(0, 0) == 0.0


def test_cvd_accumulates() -> None:
    c = cvd_update(0.0, 5.0, 2.0)
    assert c == 3.0
    c = cvd_update(c, 1.0, 4.0)
    assert c == 0.0


def test_fuse_tilt_clamped() -> None:
    assert -1.0 <= fuse_tilt(0.3, 0.0005) <= 1.0


def _test_db_url() -> str | None:
    url = os.getenv("CONFIG_DB_TEST_URL")
    if url:
        return url
    from pathlib import Path
    import re
    fork_env = "/root/workspace/repos/hyperliquid-fatty-trader/.env"
    try:
        m = re.search(r"^CONFIG_DB_URL=(\S+)", Path(fork_env).read_text(), re.MULTILINE)
        if m:
            return m.group(1).rsplit("/", 1)[0] + "/fatty_config_test"
    except Exception:
        return None
    return None


@pytest.mark.skipif(_test_db_url() is None, reason="no test DB available")
def test_eval_writer_round_trip() -> None:
    ev = EvalWriter(db_url=_test_db_url())
    ev.equity_snapshot(1, "test-bot", 1000.0, 0)
    ev.signal_popularity("BTCUSDT-LONG", "fattyfatclub", 1, 7, 0.001)
    ev.shadow_row("BTCUSDT-LONG", "BUY", "BUY", 0.001, 0.5, 0.3)
    ev.param_log(1, "test-bot", 3, 0.1, 0.5, 0.05)
    ev.strategy_perf("1h", 10, 0.6, 1.2, 0.3, "trend")
    ev.orderbook_features(1, "BTCUSDT", 0.2, 3.0, 0.0001)
    # read back a couple
    import psycopg
    with ev._conn() as c:
        r = c.execute("SELECT reaction_count, price_impact_1s FROM signal_popularity "
                      "WHERE signal_id=%s ORDER BY first_seen_ms DESC LIMIT 1",
                      ("BTCUSDT-LONG",)).fetchone()
        assert r is not None
        assert int(r[0]) == 7
        sp = c.execute("SELECT net_usd FROM strategy_perf WHERE window_label=%s", ("1h",)).fetchone()
        assert float(sp[0]) == 1.2
    # cleanup
    with ev._conn() as c:
        c.execute("DELETE FROM signal_popularity WHERE signal_id=%s", ("BTCUSDT-LONG",))
        c.execute("DELETE FROM strategy_perf WHERE window_label=%s", ("1h",))
        c.execute("DELETE FROM shadow_ledger WHERE signal_id=%s", ("BTCUSDT-LONG",))
        c.commit()
