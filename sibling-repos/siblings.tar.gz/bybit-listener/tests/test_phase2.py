"""Phase 2 tests — signal ingestion (parser, normalizer, validator, fast path).

No network, no LLM, no exchange. Uses recorded channel-style payloads.
"""

from __future__ import annotations

import json
from pathlib import Path

from src.domain.model import Instrument, RawSignal, Signal
from src.services.normalizer import ConstantPegSource, SignalNormalizer
from src.services.validator import FastPath, GateConfig, Validator
from src.sources.parser import SymbolMap, parse_message, parse_messages
from src.sources.telegram import FakeSignalSource

REPO = Path(__file__).resolve().parent.parent
SAMPLE = json.loads((REPO / "docs" / "channel_sample.json").read_text())


def _raw(text: str, mid=None, **kw) -> RawSignal:
    return parse_message(text, message_id=mid, **kw)


def test_symbol_map_resolves_usdt() -> None:
    assert SymbolMap.resolve("BTC").symbol == "BTCUSDT"
    assert SymbolMap.resolve("$ETH").symbol == "ETHUSDT"
    assert SymbolMap.resolve("#Sol").symbol == "SOLUSDT"
    assert SymbolMap.resolve("BTCUSDT").symbol == "BTCUSDT"


def test_parse_long_signal() -> None:
    r = _raw("BTCUSDT LONG entry 60000 sl 58000 tp 64000 lev 3", mid=1)
    assert r.symbol_usdt == "BTCUSDT"
    assert r.side == "BUY"
    assert r.entry == 60000.0 and r.sl == 58000.0 and r.tp == 64000.0
    assert r.leverage == 3


def test_parse_short_signal_hash() -> None:
    r = _raw("#ETH SHORT entry 3000 sl 2850 tp 3300 lev 5 conf 0.8", mid=2)
    assert r.symbol_usdt == "ETHUSDT"
    assert r.side == "SELL"
    assert r.sl == 2850.0 and r.tp == 3300.0 and r.confidence == 0.8


def test_parse_management_sl_to_entry() -> None:
    r = _raw("sl to entry", mid=3)
    assert r.is_management is True
    assert r.management_action == "sl_to_entry"


def test_parse_management_tp_modify_captures_price() -> None:
    r = _raw("tp1 3350", mid=4)
    assert r.is_management is True
    assert r.management_action == "tp_modify"
    assert r.raw.get("mgmt_price") == 3350.0


def test_parse_nonsignal_chatter() -> None:
    r = _raw("random chatter no signal", mid=5)
    assert r.symbol_usdt == ""


def test_normalizer_peg_guard_passes_at_1() -> None:
    norm = SignalNormalizer(ConstantPegSource(1.0))
    r = _raw("BTCUSDT LONG entry 60000 sl 58000 tp 64000 lev 3", mid=6)
    sig = __import__("asyncio").get_event_loop().run_until_complete(norm.normalize(r))
    assert isinstance(sig, Signal)
    assert sig.instrument.symbol == "BTCUSDT"
    assert sig.peg_rate == 1.0


def test_validator_gate1_whitelist_and_confidence() -> None:
    v = Validator(GateConfig(min_confidence=0.5), tradable={"BTCUSDT", "ETHUSDT"})
    ok = v.gate1(_raw("BTCUSDT LONG entry 60000 sl 58000 tp 64000 lev 3 conf 0.7", mid=7))
    assert ok.passed
    bad = v.gate1(_raw("DOGEUSDT LONG entry 1 sl 0.9 tp 1.1 lev 3 conf 0.7", mid=8))
    assert not bad.passed and "tradable" in bad.reason


def test_validator_gate1_dedup() -> None:
    v = Validator(GateConfig(), tradable={"BTCUSDT"})
    r = _raw("BTCUSDT LONG entry 60000 sl 58000 tp 64000 lev 3 conf 0.7", mid=9)
    assert v.gate1(r).passed
    assert v.claim(9) is True
    assert v.claim(9) is False  # already claimed


def test_validator_gate2_sl_direction_long() -> None:
    v = Validator(GateConfig(), tradable={"BTCUSDT"})
    inst = Instrument.from_token("BTC")
    sig = Signal(instrument=inst, side="BUY", entry=60000.0, sl=61000.0,
                 tp=64000.0, notional_usd=1.0, leverage=3, confidence=0.7)
    res = v.gate2(sig, size_coin=0.001, leverage=3, entry_mark=60000.0)
    assert not res.passed and "SL must be < entry" in res.reason


def test_validator_gate2_short_ok() -> None:
    v = Validator(GateConfig(), tradable={"BTCUSDT"})
    inst = Instrument.from_token("BTC")
    sig = Signal(instrument=inst, side="SELL", entry=61000.0, sl=62500.0,
                 tp=58000.0, notional_usd=1.0, leverage=3, confidence=0.7)
    # realistic small size: ~$3 notional (well above $1 min, under $50 cap)
    res = v.gate2(sig, size_coin=0.00005, leverage=3, entry_mark=61000.0)
    assert res.passed


def test_fast_path_clear_enter() -> None:
    from src.services.risk import FixedRiskSizer
    v = Validator(GateConfig(min_confidence=0.5), tradable={"BTCUSDT"})
    risk = FixedRiskSizer()
    fp = FastPath(v, risk, GateConfig(), available_usd=1000.0)
    r = _raw("BTCUSDT LONG entry 60000 sl 58000 tp 64000 lev 3 conf 0.8", mid=10)
    sig = __import__("asyncio").get_event_loop().run_until_complete(
        SignalNormalizer(ConstantPegSource(1.0)).normalize(r))
    d = fp.decide(r, sig, mark=60000.0)
    assert d.action == "ENTER"
    assert d.size_coin > 0


def test_fast_path_escalates_ambiguous() -> None:
    from src.services.risk import FixedRiskSizer
    v = Validator(GateConfig(), tradable={"BTCUSDT"})
    risk = FixedRiskSizer()
    fp = FastPath(v, risk, GateConfig(), available_usd=1000.0)
    r = _raw("BTCUSDT LONG conf 0.3", mid=11)  # missing entry/sl, low conf
    sig = __import__("asyncio").get_event_loop().run_until_complete(
        SignalNormalizer(ConstantPegSource(1.0)).normalize(r))
    d = fp.decide(r, sig, mark=60000.0)
    assert d.action == "IGNORE"
    assert "escalate" in d.reason.lower()


def test_fake_signal_source_pushes() -> None:
    import asyncio
    items = [_raw("BTCUSDT LONG entry 60000 sl 58000 tp 64000 lev 3", mid=12)]
    src = FakeSignalSource(items)
    asyncio.get_event_loop().run_until_complete(src.start())
    q = src.subscribe()
    got = q.get_nowait()
    assert got.symbol_usdt == "BTCUSDT"


def test_channel_sample_parses() -> None:
    for row in SAMPLE:
        r = parse_message(row["text"], message_id=row.get("id"))
        assert isinstance(r, RawSignal)


def test_entry_with_sl_tp_is_not_management() -> None:
    # Regression: a full signal carrying sl/tp must NOT be misrouted to the
    # management path (the management regex matches the bare "sl 59000" tokens).
    r = _raw("BTCUSDT LONG entry 60000 sl 59000 tp 62000 lev 3 conf 0.8", mid=20)
    assert r.is_management is False
    assert r.management_action is None
    assert r.side == "BUY"
    assert r.entry == 60000.0 and r.sl == 59000.0 and r.tp == 62000.0


def test_pure_management_sl_to_entry_has_no_entry_price() -> None:
    # A pure management instruction has no entry price, so it stays management.
    r = _raw("sl to entry", mid=21)
    assert r.is_management is True
    assert r.management_action == "sl_to_entry"
    assert r.entry is None
