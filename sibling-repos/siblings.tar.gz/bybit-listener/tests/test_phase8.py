"""Phase 8 tests — learning loop (drift detection + param rotation, confirmation-gated).

No network. Verifies the loop NEVER auto-applies a live change (spec §2.7, §18).
"""

from __future__ import annotations

from src.learning.loop import Baseline, LearningLoop, ParamProposal


def test_record_close_builds_baseline() -> None:
    loop = LearningLoop(min_samples=5)
    for n in [0.1, 0.2, 0.15, 0.05, 0.1]:
        loop.record_close(n, won=True)
    assert loop.baseline.sample == 5
    assert abs(loop.baseline.expectancy_net_usd - 0.12) < 1e-9


def test_no_proposal_without_drift() -> None:
    loop = LearningLoop(min_samples=5, drift_threshold=0.3)
    for n in [0.1, 0.2, 0.15, 0.05, 0.1]:
        loop.record_close(n, won=True)
    # steady baseline, small new samples -> no drift over threshold
    for n in [0.12, 0.11]:
        loop.record_close(n, won=True)
    assert loop.propose(3, 0.1, 0.5) is None


def test_decaying_expectancy_proposes_tighten() -> None:
    loop = LearningLoop(min_samples=5, drift_threshold=0.3)
    # baseline: strongly positive
    for n in [0.5, 0.6, 0.4, 0.5, 0.55]:
        loop.record_close(n, won=True)
    # then a sharp decay
    for n in [-0.5, -0.6, -0.4]:
        loop.record_close(n, won=False)
    prop = loop.propose(3, 0.10, 0.5)
    assert prop is not None
    assert prop.confirmed is False        # NOT auto-applied
    assert prop.leverage_cap < 3          # tightened
    assert prop.size_pct < 0.10          # tightened
    assert "tighten" in prop.reason.lower()


def test_proposal_not_applied_until_confirmed() -> None:
    loop = LearningLoop(min_samples=5, drift_threshold=0.3)
    for n in [0.5, 0.6, 0.4, 0.5, 0.55]:
        loop.record_close(n, won=True)
    for n in [-0.5, -0.6, -0.4]:
        loop.record_close(n, won=False)
    prop = loop.propose(3, 0.10, 0.5)
    assert prop in loop.pending           # still pending
    loop.confirm(prop)
    assert prop.confirmed is True
    assert prop not in loop.pending


def test_learning_loop_is_gated_not_blind() -> None:
    # The whole point: the bot must not auto-enable blindly (spec §2.7).
    loop = LearningLoop(min_samples=5, drift_threshold=0.3)
    for n in [0.5, 0.6, 0.4, 0.5, 0.55]:
        loop.record_close(n, won=True)
    for n in [-0.5, -0.6, -0.4]:
        loop.record_close(n, won=False)
    prop = loop.propose(3, 0.10, 0.5)
    # even though a proposal exists, it is NOT confirmed -> live params unchanged
    assert prop is not None
    assert prop.confirmed is False
