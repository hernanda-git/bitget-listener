"""Phase 4 tests — Bybit WS parsing (offline). Drives FakeBybitWS with real Bybit
shaped payloads. The live testnet socket still requires API keys (gate).
"""

from __future__ import annotations

import asyncio

from src.streaming.bybit_ws import BybitWS, WSConfig, ws_signature
from src.streaming.bybit_ws_fake import FakeBybitWS


def test_ws_signature_recipe() -> None:
    import hashlib, hmac
    sign = ws_signature("SECRET", 1234567890)
    expect = hmac.new("SECRET".encode(), "GET/realtime1234567890".encode(),
                      hashlib.sha256).hexdigest()
    assert sign == expect


def test_config_ws_urls_testnet_vs_mainnet() -> None:
    t = WSConfig(testnet=True)
    m = WSConfig(testnet=False)
    assert t.private_url.endswith("/v5/private")
    assert "testnet" in t.private_url
    assert "testnet" not in m.private_url


def test_parse_execution_fill_real_fee() -> None:
    ws = FakeBybitWS(symbols=["BTCUSDT"])
    asyncio.get_event_loop().run_until_complete(ws.start())
    payload = {
        "topic": "execution",
        "data": [{
            "orderLinkId": "b-x", "symbol": "BTCUSDT", "side": "Buy",
            "execPrice": "60000.0", "execQty": "0.001", "execFee": "0.033",
            "feeCurrency": "USDT", "execTime": "1700000000000",
            "isClosed": False, "execType": "Trade", "orderId": "o1",
        }],
    }
    asyncio.get_event_loop().run_until_complete(ws.inject_private(payload))
    assert len(ws.fills) == 1
    f = ws.fills[0]
    assert f.fee == 0.033          # BUG A: real fee recorded, non-zero
    assert f.price == 60000.0
    assert f.qty == 0.001


def test_parse_position_liquidation_real_price() -> None:
    ws = FakeBybitWS(symbols=["BTCUSDT"])
    asyncio.get_event_loop().run_until_complete(ws.start())
    # size -> 0, liqPrice present, closedPnl present: liquidation. Real liq price kept.
    payload = {
        "topic": "position",
        "data": [{
            "symbol": "BTCUSDT", "side": "Buy", "size": "0",
            "avgPrice": "60000.0", "leverage": "3", "stopLoss": "",
            "takeProfit": "", "liqPrice": "55000.0", "unrealisedPnl": "-3.0",
        }],
    }
    asyncio.get_event_loop().run_until_complete(ws.inject_private(payload))
    assert len(ws.positions) == 1
    p = ws.positions[0]
    assert p.size == 0.0
    assert p.liq_price == 55000.0   # BUG B: REAL liq price, never 0.00
    assert p.unrealized_pnl == -3.0


def test_parse_tickers_mark_price() -> None:
    ws = FakeBybitWS(symbols=["BTCUSDT"])
    asyncio.get_event_loop().run_until_complete(ws.start())
    payload = {"topic": "tickers.BTCUSDT", "data": [{"markPrice": "60100.5"}]}
    asyncio.get_event_loop().run_until_complete(ws.inject_public(payload))
    assert ws.mark_price("BTCUSDT") == 60100.5
    assert ("BTCUSDT", 60100.5) in ws.marks


def test_public_topics_built() -> None:
    ws = FakeBybitWS(symbols=["BTCUSDT", "ETHUSDT"])
    topics = ws._public_topics()
    assert "tickers.BTCUSDT" in topics
    assert "liquidation.ETHUSDT" in topics
    assert "publicTrade.BTCUSDT" in topics


def test_ws_implements_market_stream() -> None:
    from src.interfaces.ports import MarketStream
    assert isinstance(FakeBybitWS(), MarketStream)
