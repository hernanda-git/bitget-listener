"""Phase 0 smoke tests — pure (no network, no DB)."""

from __future__ import annotations

import importlib
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))


def test_python_version() -> None:
    import sys as _s
    assert _s.version_info >= (3, 11), "Python 3.11+ required"


def test_config_db_imports() -> None:
    # Importing db.py must NOT open a socket (lazy connection).
    from src.config import db
    assert hasattr(db, "ConfigStore")
    assert hasattr(db, "BotConfig")
    assert hasattr(db, "RiskRow")


def test_default_db_url_placeholder() -> None:
    from src.config.db import DEFAULT_DB_URL
    # The default points at the Sera fatty_config DB app role.
    assert "fatty_config" in DEFAULT_DB_URL
    assert DEFAULT_DB_URL.startswith("postgresql://")


def test_config_example_yaml_loads() -> None:
    import yaml  # PyYAML is a transitive dep of pydantic-settings; skip if absent
    cfg = yaml.safe_load((REPO_ROOT / "config.example.yaml").read_text())
    assert cfg["bybit"]["category"] == "linear"
    assert cfg["bybit"]["position_idx"] == 0
    assert cfg["risk"]["default_margin_usd"] == 1.0
