"""Phase 9 tests — notifier + two-step go-live gate.

GoLiveGate is tested against the real ConfigStore (fatty_config_test): token mint,
mismatch, expiry, gate-not-met, and successful live flip. Notifier buffering tested
offline. No real TG messages sent.
"""

from __future__ import annotations

import os
import time

import pytest

from src.config.db import BotConfig, ConfigStore
from src.notifier.bot import GoLiveGate, TelegramNotifier


def _test_db_url() -> str | None:
    url = os.getenv("CONFIG_DB_TEST_URL")
    if url:
        return url
    from pathlib import Path
    import re
    fork_env = "/root/workspace/repos/hyperliquid-fatty-trader/.env"
    try:
        m = re.search(r"^CONFIG_DB_URL=(\S+)", Path(fork_env).read_text(), re.MULTILINE)
        if m:
            return m.group(1).rsplit("/", 1)[0] + "/fatty_config_test"
    except Exception:
        return None
    return None


@pytest.fixture
def store():
    url = _test_db_url()
    if url is None:
        pytest.skip("no test DB")
    s = ConfigStore(db_url=url)
    name = "gate-test-bot"
    s.upsert_bot(BotConfig(name=name, paper=True, testnet=True))
    yield s
    s.delete_bot(name)


def test_golive_requires_two_steps(store) -> None:
    gate = GoLiveGate(store, "gate-test-bot")
    ok, reason = gate.redeem("whatever", expectancy_net_usd=1.0)
    assert ok is False
    assert "no go-live token" in reason


def test_golive_token_mismatch(store) -> None:
    gate = GoLiveGate(store, "gate-test-bot")
    gate.issue_token()
    ok, reason = gate.redeem("wrongtoken", expectancy_net_usd=1.0)
    assert ok is False
    assert "token mismatch" in reason
    assert store.get_bot("gate-test-bot").paper is True


def test_golive_gate_blocks_negative_expectancy(store) -> None:
    gate = GoLiveGate(store, "gate-test-bot")
    token = gate.issue_token()
    ok, reason = gate.redeem(token, expectancy_net_usd=0.0)
    assert ok is False
    assert "GATE not met" in reason
    assert store.get_bot("gate-test-bot").paper is True


def test_golive_success_flips_paper(store) -> None:
    gate = GoLiveGate(store, "gate-test-bot")
    token = gate.issue_token()
    ok, reason = gate.redeem(token, expectancy_net_usd=0.05)
    assert ok is True
    assert store.get_bot("gate-test-bot").paper is False
    assert store.get_bot("gate-test-bot").go_live_token is None


def test_golive_token_expiry(store, monkeypatch) -> None:
    gate = GoLiveGate(store, "gate-test-bot")
    token = gate.issue_token()
    real_time = time.time
    monkeypatch.setattr(time, "time", lambda: real_time() + 1000)
    ok, reason = gate.redeem(token, expectancy_net_usd=1.0)
    assert ok is False
    assert "expired" in reason


def test_notifier_buffers_without_token() -> None:
    saved = {k: os.environ.pop(k, None) for k in ("TG_BOT_TOKEN", "TG_BOT_CHAT")}
    try:
        n = TelegramNotifier()
        import asyncio
        asyncio.get_event_loop().run_until_complete(n.send("hello"))
        assert n.buffered[-1] == "hello"
    finally:
        for k, v in saved.items():
            if v is not None:
                os.environ[k] = v


def test_paper_toggle() -> None:
    url = _test_db_url()
    if url is None:
        pytest.skip("no test DB")
    s = ConfigStore(db_url=url)
    s.upsert_bot(BotConfig(name="gate-test-bot2", paper=False))
    try:
        gate = GoLiveGate(s, "gate-test-bot2")
        gate.go_paper()
        assert s.get_bot("gate-test-bot2").paper is True
    finally:
        s.delete_bot("gate-test-bot2")
