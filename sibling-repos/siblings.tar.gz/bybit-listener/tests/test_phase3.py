"""Phase 3 tests — Bybit REST adapter (offline: signing, rounding, order body).

The LIVE testnet verification (place tiny order, read fill w/ non-zero execFee) is
performed by scripts/bybit_api_probe.py against TESTNET only, gated on BYBIT_API_KEY
being present. These unit tests verify the algorithms offline (spec rule #8: testnet
is the arbiter, but the crypto + rounding must be correct before any call).
"""

from __future__ import annotations

import hashlib
import hmac

from src.domain.model import Instrument, OrderRequest
from src.exchanges.bybit import (
    BybitAdapter, BybitAuth, BybitConfig, InstrumentInfo, _decimals,
)


def test_decimals_helper() -> None:
    assert _decimals("0.001") == 3
    assert _decimals("0.01") == 2
    assert _decimals("1") == 0
    assert _decimals("0.00001") == 5


def test_signing_matches_v5_algorithm() -> None:
    # Reproduce the V5 signing recipe independently and compare to BybitAuth.
    auth = BybitAuth(api_key="KEY", api_secret="SECRET", recv_window_ms=5000)
    method, path = "POST", "/v5/order/create"
    body = {"category": "linear", "symbol": "BTCUSDT", "side": "Buy", "orderType": "Market",
            "qty": "0.001", "timeInForce": "IOC", "positionIdx": 0}
    headers = auth.headers(method, path, params=None, body=body)
    # independent recomputation
    ts = headers["X-BAPI-TIMESTAMP"]
    recv = headers["X-BAPI-RECV-WINDOW"]
    param_str = __import__("json").dumps(body, separators=(",", ":"))
    expect = hmac.new(
        "SECRET".encode(),
        (ts + "KEY" + recv + param_str).encode(),
        hashlib.sha256,
    ).hexdigest()
    assert headers["X-BAPI-SIGN"] == expect
    assert headers["X-BAPI-API-KEY"] == "KEY"
    assert "Content-Type" in headers


def test_config_rest_base_testnet_vs_mainnet() -> None:
    t = BybitConfig(testnet=True)
    m = BybitConfig(testnet=False)
    assert t.rest_base == "https://api-testnet.bybit.com"
    assert m.rest_base == "https://api.bybit.com"


def test_round_qty_clips_to_min_max() -> None:
    cfg = BybitConfig()
    a = BybitAdapter(cfg)
    a._instruments["BTCUSDT"] = InstrumentInfo(
        symbol="BTCUSDT", base_precision=3, min_order_qty=0.001,
        max_order_qty=100.0, min_notional=1.0, tick_precision=1,
        price_filter_min=1.0, price_filter_max=900000.0,
    )
    # too-small qty is clipped up to min
    assert a.round_qty("BTCUSDT", 0.0001) == 0.001
    # over-precise qty rounds to 3 decimals
    assert a.round_qty("BTCUSDT", 0.123456) == 0.123
    # too-large clipped to max
    assert a.round_qty("BTCUSDT", 500.0) == 100.0


def test_round_price_uses_tick() -> None:
    cfg = BybitConfig()
    a = BybitAdapter(cfg)
    a._instruments["BTCUSDT"] = InstrumentInfo(
        symbol="BTCUSDT", base_precision=3, min_order_qty=0.001,
        max_order_qty=100.0, min_notional=1.0, tick_precision=1,
        price_filter_min=1.0, price_filter_max=900000.0,
    )
    # tick = 0.1 -> round 60000.04 to 60000.0
    assert a.round_price("BTCUSDT", 60000.04) == 60000.0
    assert a.round_price("BTCUSDT", 60000.07) == 60000.1


def test_order_body_market_with_attached_sl_tp() -> None:
    cfg = BybitConfig()
    a = BybitAdapter(cfg)
    a._instruments["BTCUSDT"] = InstrumentInfo(
        symbol="BTCUSDT", base_precision=3, min_order_qty=0.001,
        max_order_qty=100.0, min_notional=1.0, tick_precision=1,
        price_filter_min=1.0, price_filter_max=900000.0,
    )
    inst = Instrument.from_token("BTC")
    o = OrderRequest(instrument=inst, side="BUY", order_type="Market", qty=0.001,
                     time_in_force="IOC", sl=58000.0, tp=64000.0,
                     tpsl_mode="Full", sl_trigger_by="MarkPrice",
                     tp_trigger_by="MarkPrice", client_order_id="b-x", is_market=True)
    body = a._order_body(o)
    assert body["category"] == "linear"
    assert body["symbol"] == "BTCUSDT"
    assert body["side"] == "BUY"
    assert body["orderType"] == "Market"
    assert body["qty"] == "0.001"
    assert body["timeInForce"] == "IOC"
    assert body["orderLinkId"] == "b-x"
    assert body["stopLoss"] == "58000.0"
    assert body["takeProfit"] == "64000.0"
    assert body["slTriggerBy"] == "MarkPrice"
    assert body["tpslMode"] == "Full"
    assert "price" not in body  # market has no price


def test_order_body_limit_sets_price_and_reduce_only() -> None:
    cfg = BybitConfig()
    a = BybitAdapter(cfg)
    a._instruments["BTCUSDT"] = InstrumentInfo(
        symbol="BTCUSDT", base_precision=3, min_order_qty=0.001,
        max_order_qty=100.0, min_notional=1.0, tick_precision=1,
        price_filter_min=1.0, price_filter_max=900000.0,
    )
    inst = Instrument.from_token("BTC")
    o = OrderRequest(instrument=inst, side="SELL", order_type="Limit", qty=0.002,
                     price=59000.5, time_in_force="GTC", reduce_only=True,
                     client_order_id="b-y")
    body = a._order_body(o)
    assert body["orderType"] == "Limit"
    assert body["price"] == "59000.5"
    assert body["reduceOnly"] is True


def test_adapter_implements_exchange_adapter() -> None:
    from src.interfaces.ports import ExchangeAdapter
    assert isinstance(BybitAdapter(BybitConfig()), ExchangeAdapter)
