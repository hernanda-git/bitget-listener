"""Phase 6 tests — fee-aware ledger + min_notional cache.

Offline: TradeRow fee-aware invariant (net = gross - open - close), Ledger no-op when
no DB URL, MinNotionalCache. Integration (gated on a reachable test DB): write a
fee-aware trade and assert open_fee/close_fee/net_usd + liq_price persisted (BUG A/B).
"""

from __future__ import annotations

import os

from pathlib import Path

import pytest

from src.store.ledger import Ledger, TradeRow
from src.store.min_notional import MinNotionalCache


def test_trade_row_fee_aware_invariant() -> None:
    r = TradeRow(
        correlation_id="c1", bot_name="bybit-main", symbol="BTCUSDT", side="BUY",
        entry_price=60000.0, exit_price=64000.0, sl_price=58000.0, tp_price=64000.0,
        leverage=3, size_coin=0.00005, margin_usd=1.0,
        open_fee=0.033, close_fee=0.035, gross_usd=0.20, net_usd=0.132,
        close_reason="tp",
    )
    assert r.fee_aware
    # net must equal gross - open - close
    assert abs(r.net_usd - (r.gross_usd - r.open_fee - r.close_fee)) < 1e-9


def test_trade_row_liquidation_keeps_real_liq_price() -> None:
    r = TradeRow(
        correlation_id="c2", bot_name="bybit-main", symbol="BTCUSDT", side="BUY",
        entry_price=60000.0, exit_price=55000.0, sl_price=None, tp_price=None,
        leverage=3, size_coin=0.00005, margin_usd=1.0,
        open_fee=0.033, close_fee=0.03, gross_usd=-2.5, net_usd=-2.563,
        close_reason="liquidation", liq_price=55000.0,
    )
    assert r.close_reason == "liquidation"
    assert r.liq_price == 55000.0   # BUG B: real price, not 0.00


def test_ledger_noop_without_url() -> None:
    saved = {k: os.environ.pop(k, None) for k in ("CONFIG_DB_TEST_URL", "CONFIG_DB_URL")}
    try:
        led = Ledger(db_url="")   # no DB configured
        assert led._enabled is False
        led.write_signal(0, "BTCUSDT", "BUY", 60000, 58000, 64000, 3, 0.8, "x", "ok")
        led.write_trade(TradeRow("c", "b", "BTCUSDT", "BUY", 1, 2, None, None, 3, 0.001,
                                 1.0, 0.01, 0.01, 0.1, 0.08, "tp"))
        assert led.recent_trades() == []
    finally:
        for k, v in saved.items():
            if v is not None:
                os.environ[k] = v


def test_min_notional_cache() -> None:
    cache = MinNotionalCache()
    cache.update("BTCUSDT", 1.0)
    cache.update("PEPEUSDT", 5.0)
    assert cache.floor("BTCUSDT") == 1.0
    assert cache.meets("BTCUSDT", 0.001, 60000.0)      # 60 >= 1
    assert not cache.meets("PEPEUSDT", 1.0, 1.0)        # 1.0 < 5 floor


def _test_db_url() -> str | None:
    url = os.getenv("CONFIG_DB_TEST_URL")
    if url:
        return url
    # Read the Sera fatty_config_test URL from the fork's real .env WITHOUT polluting
    # os.environ (so Ledger's no-op path stays testable).
    fork_env = "/root/workspace/repos/hyperliquid-fatty-trader/.env"
    try:
        import re
        text = Path(fork_env).read_text()
        m = re.search(r"^CONFIG_DB_URL=(\S+)", text, re.MULTILINE)
        if m:
            base = m.group(1)
            return base.rsplit("/", 1)[0] + "/fatty_config_test"
    except Exception:
        return None
    return None


@pytest.mark.skipif(_test_db_url() is None, reason="no test DB available")
def test_ledger_writes_fee_aware_trade_to_db() -> None:
    led = Ledger(db_url=_test_db_url())
    # clean slate for this bot
    import psycopg
    with led._conn() as c:
        c.execute("DELETE FROM trades_log WHERE bot_name=%s", ("test-bot",))
        c.commit()
    row = TradeRow(
        correlation_id="ct", bot_name="test-bot", symbol="BTCUSDT", side="BUY",
        entry_price=60000.0, exit_price=55000.0, sl_price=None, tp_price=None,
        leverage=3, size_coin=0.00005, margin_usd=1.0,
        open_fee=0.033, close_fee=0.030, gross_usd=-2.5, net_usd=-2.563,
        close_reason="liquidation", liq_price=55000.0,
        opened_ts_ms=1, closed_ts_ms=2,
    )
    led.write_trade(row)
    # direct read-back of the written row (spec columns) — the authoritative check
    import psycopg
    with led._conn() as c:
        r = c.execute(
            "SELECT open_fee, close_fee, net_usd, liq_price, close_reason FROM trades_log "
            "WHERE bot_name=%s ORDER BY id DESC LIMIT 1", ("test-bot",)
        ).fetchone()
    assert r is not None
    assert float(r[0]) == 0.033      # BUG A: open_fee non-zero
    assert float(r[1]) == 0.030      # BUG A: close_fee non-zero
    assert float(r[2]) == -2.563     # net = gross - fees
    assert float(r[3]) == 55000.0    # BUG B: liq_price real, not 0.00
    assert r[4] == "liquidation"
    # cleanup
    with led._conn() as c:
        c.execute("DELETE FROM trades_log WHERE bot_name=%s", ("test-bot",))
        c.commit()
