"""Phase 5 tests — order transforms + position manager (real-time stops, liquidation,
dead-man's switch). Offline: uses FakeExchangeAdapter + FakeMarketStream (no network).
"""

from __future__ import annotations

import asyncio

from src.domain.model import Fill, Instrument, Position
from src.exchanges.fake import FakeExchangeAdapter, FakeMarketStream
from src.services.order import (
    build_entry, build_full_close, build_partial_close, opposite_side,
)
from src.services.position import PositionManager, PositionManagerConfig


def test_opposite_side() -> None:
    assert opposite_side("BUY") == "SELL"
    assert opposite_side("SELL") == "BUY"


def test_build_entry_has_attached_sl_tp() -> None:
    from src.domain.model import Signal, TradeDecision
    inst = Instrument.from_token("BTC")
    sig = Signal(instrument=inst, side="BUY", entry=60000.0, sl=58000.0, tp=64000.0,
                 notional_usd=1.0, leverage=3, confidence=0.8)
    d = TradeDecision(action="ENTER", signal=sig, leverage=3, size_coin=0.00005,
                      sl=58000.0, tp=64000.0, reason="x")
    o = build_entry(d, sl=58000.0, tp=64000.0)
    assert o.order_type == "Market"
    assert o.sl == 58000.0 and o.tp == 64000.0
    assert o.client_order_id.startswith("b-")
    assert o.reduce_only is False


def test_build_full_close_is_reduce_only() -> None:
    inst = Instrument.from_token("BTC")
    o = build_full_close(inst)
    assert o.reduce_only is True
    assert o.client_order_id.startswith("b-")


def test_build_partial_close_half_size() -> None:
    inst = Instrument.from_token("BTC")
    o = build_partial_close(inst, current_size=0.002)
    assert o.qty == 0.001
    assert o.reduce_only is True


def test_position_manager_records_fee_on_open_BUG_A() -> None:
    ex = FakeExchangeAdapter(market_prices={"BTCUSDT": 60000.0})
    ms = FakeMarketStream({"BTCUSDT": 60000.0})
    pm = PositionManager(ex, ms)
    f = Fill(order_link_id="b-1", price=60000.0, qty=0.001, side="Buy",
             fee=0.033, symbol="BTCUSDT", ts_ms=1)
    asyncio.get_event_loop().run_until_complete(pm.on_fill(f))
    assert "BTCUSDT" in pm.positions
    assert pm._open_fee["BTCUSDT"] == 0.033  # real fee accumulated


def test_position_manager_books_liquidation_at_real_price_BUG_B() -> None:
    ex = FakeExchangeAdapter(market_prices={"BTCUSDT": 60000.0})
    ms = FakeMarketStream({"BTCUSDT": 60000.0})
    closed: list[tuple] = []
    pm = PositionManager(ex, ms, on_close=lambda s, e, x, r, l: closed.append((s, e, x, r, l)))
    asyncio.get_event_loop().run_until_complete(pm.on_fill(
        Fill(order_link_id="b-1", price=60000.0, qty=0.001, side="Buy",
             fee=0.033, symbol="BTCUSDT", ts_ms=1)))
    asyncio.get_event_loop().run_until_complete(pm.on_position(Position(
        instrument=Instrument.from_token("BTC"), side="BUY", size=0.0,
        entry_price=60000.0, leverage=3, liq_price=55000.0, unrealized_pnl=-3.0)))
    assert len(closed) == 1
    sym, entry, exit_px, reason, liq = closed[0]
    assert reason == "liquidation"
    assert exit_px == 55000.0          # BUG B: REAL price, never 0.00
    assert liq == 55000.0
    assert len(pm._liquidation_log) == 1
    assert "never 0.00" in pm._liquidation_log[0]["note"]


def test_position_manager_deadman_flattens() -> None:
    ex = FakeExchangeAdapter(market_prices={"BTCUSDT": 60000.0})
    ms = FakeMarketStream({"BTCUSDT": 60000.0})
    pm = PositionManager(ex, ms, cfg=PositionManagerConfig(deadman_seconds=0.0))
    triggered = asyncio.get_event_loop().run_until_complete(pm.check_deadman())
    assert triggered is True
    assert pm.halted is True
    assert len(ex.cancel_all_calls) == 1


def test_position_manager_self_heal_does_not_cancel_reduce_only() -> None:
    ex = FakeExchangeAdapter(market_prices={"BTCUSDT": 60000.0})
    ms = FakeMarketStream({"BTCUSDT": 60000.0})
    pm = PositionManager(ex, ms)
    asyncio.get_event_loop().run_until_complete(pm.on_fill(
        Fill(order_link_id="b-1", price=60000.0, qty=0.001, side="Buy",
             fee=0.033, symbol="BTCUSDT", ts_ms=1)))
    pm.positions["BTCUSDT"].sl_price = None
    asyncio.get_event_loop().run_until_complete(pm.self_heal())
    assert len(ex.cancelled) == 0  # never cancel reduce_only protective orders
