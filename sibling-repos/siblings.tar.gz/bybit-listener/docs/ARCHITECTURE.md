# Architecture — bybit-listener

Mandatory SOLID + dependency-injection design. The Bybit adapter sits **behind**
`ExchangeAdapter`; domain types are pure; fakes stand in for network adapters in tests.

---

## Module map

```
bybit-listener/
├── main.py                      # Composition root. Run modes (--check-tg, --live-dry,
│                                #   --dashboard, --go-live, --all-bots, --status, ...).
│                                #   Builds real adapters via DI; degrades gracefully if
│                                #   the config DB is unreachable.
├── src/
│   ├── domain/model.py          # Pure frozen dataclasses: Instrument, Signal, Fill,
│   │                            #   Position, TradeDecision, RawSignal, OrderRequest.
│   │                            #   Fill.fee is real; Position.liq_price is the real price.
│   ├── interfaces/ports.py      # ABCs: SignalSource, ExchangeAdapter, MarketStream,
│   │                            #   Notifier, RiskPolicy, PegSource, AttachmentFetcher.
│   ├── exchanges/
│   │   ├── bybit.py             # BybitAdapter — REST V5 (testnet/mainnet). Reads
│   │   │                        #   BYBIT_API_KEY/SECRET from env. Consumes execFee.
│   │   └── fake.py              # FakeExchangeAdapter — records fills w/ non-zero fees.
│   ├── streaming/
│   │   ├── bybit_ws.py          # BybitWS — V5 execution + ticker WebSocket.
│   │   └── fake.py              # FakeMarketStream — scripted marks.
│   ├── sources/
│   │   ├── parser.py            # Free-text signal parser + SymbolMap. Management routing.
│   │   ├── telegram.py          # TelegramSource (Telethon) + FakeSignalSource.
│   │   └── llm_signal.py        # Optional LLM escalation path (FastPath → LLM).
│   ├── services/
│   │   ├── normalizer.py        # SignalNormalizer + StablecoinPegGuard (USDT peg=1.0).
│   │   ├── validator.py         # Gate1 (pre-LLM) + Gate2 (post-LLM) + FastPath.
│   │   ├── risk.py              # FixedRiskSizer — fee-aware sizing (net_usd = gross - fees).
│   │   ├── order.py             # OrderService — build_entry + management transforms
│   │   │                        #   (sl_to_entry / partial / full_close / tp_modify).
│   │   │                        #   Never cancels reduce_only protective orders (BUG C).
│   │   ├── position.py          # PositionManager — open/close, liquidation at real price
│   │   │                        #   (BUG B), last_close fee-aware detail.
│   │   ├── reflexivity.py       # SignalPopularity, CounterTradeTilt, ShadowLedger.
│   │   └── fusion.py            # Microstructure fusion (orderbook imbalance, CVD, funding).
│   ├── notifier/bot.py          # TelegramNotifier (alerts) + GoLiveGate (two-step gate).
│   ├── config/db.py             # ConfigStore — psycopg; reuses fatty_config. Holds
│   │                            #   env-var NAMES only, never key/token values.
│   ├── learning/loop.py         # LearningLoop — drift detection + param rotation,
│   │                            #   confirmation-gated (never auto-applies live).
│   ├── store/
│   │   ├── ledger.py            # Ledger — fee-aware trades_log (BUG A). net = gross - fees.
│   │   └── eval.py              # EvalWriter — equity_snapshots, signal_popularity, etc.
│   └── orchestrator.py          # Pipeline coordinator. Wires everything; enforces the
│                                #   live/dry gate via the DB row BEFORE acting.
├── scripts/
│   ├── bybit_api_probe.py       # Testnet verification of BUG A/B (no keys → clean skip).
│   ├── configure_bot.py         # Create/update the bot's fatty_config row (no secrets).
│   ├── replay_real.py           # 100 real/generated channel messages through the pipeline.
│   ├── replay_mgmt.py           # Management-message verification against seeded positions.
│   └── run_bots.sh              # Supervisor entrypoint (one listener per enabled bot).
├── tests/                       # 81 tests. No network (fakes only).
├── docs/                        # SETUP.md, ARCHITECTURE.md, SECURITY.md, channel_sample.json
├── CHANGELOG.md                 # Canonical history; [Unreleased] required for deploy.sh.
├── AGENTS.md                    # Condensed operating manual.
└── deploy.sh                    # Guard-then-deploy: blocks if tests fail or [Unreleased] empty.
```

---

## Data flow (signal → order)

```
Telegram (@fattyfatclub)
   │  TelegramSource (Telethon)
   ▼
RawSignal ──parser.py──▶ Signal (normalized, peg-guarded)
   │                              │
   │  management action? ──yes──▶ OrderService transforms (PositionManager)
   │                              │   (sl_to_entry / partial / full / tp_modify)
   │                              │   NEVER cancels reduce_only protective orders (BUG C)
   │
   └──no──▶ Gate1 (validator.py)
              │ pass
              ▼
          FastPath (sub-second, pre-LLM)
              │ clear-shape → ENTER
              │ ambiguous  → escalate to LLM (llm_signal.py)
              ▼
          Gate2 (leverage cap, SL direction, min-notional, portfolio/daily caps,
                 fee-adjusted expectancy)
              │ pass
              ▼
          build_entry (OrderService) → ExchangeAdapter.place (BybitAdapter, testnet/mainnet)
              │
              ▼
          BybitWS fills/positions ──▶ PositionManager (open/close; liquidation at real
              │                                                      price = BUG B)
              ▼
          Ledger.write_trade (fee-aware TradeRow: net = gross - fees = BUG A)
              │
              ▼
          LearningLoop (drift + param rotation, confirmation-gated)
              │
              ▼
          Notifier (alerts) + EvalWriter (dashboards)
```

---

## Live / dry gate (critical)

The `paper` flag is **persisted in Postgres** (`bots.paper`) and **read before acting**
in `src/orchestrator.py` and `main.py`. The orchestrator never places a real order
unless `paper == 0` **and** the two-step go-live token was redeemed **and** the gate
(fee-aware expectancy > 0, P0 verified) passed. On a missing/down DB, `main.py` degrades
to safe **paper/testnet defaults** — it cannot reach mainnet without explicit config.

---

## Why fakes everywhere

Every network adapter has a fake (`exchanges/fake.py`, `streaming/fake.py`,
`sources/telegram.py::FakeSignalSource`). Unit tests run with zero network and zero
secrets. `replay_real.py` / `replay_mgmt.py` use the fakes to exercise the full pipeline
against recorded/generated data, asserting zero crashes — this is how the Phase 10 parser
misroute bug was caught and fixed.
