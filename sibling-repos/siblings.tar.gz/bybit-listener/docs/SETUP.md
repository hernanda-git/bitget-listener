# Setup & Configuration — bybit-listener

This is the **"where do I paste my Bybit token"** guide. Everything here goes into the
git-ignored `.env` file. **Nothing you paste ever leaves your machine or gets committed.**

---

## 0. Prerequisites

- Python 3.11+ (project uses `/usr/local/lib/hermes-agent/venv/bin/python3` on Sera;
  anywhere with a venv works).
- A Bybit **TESTNET** account (recommended for everything until the go-live gate passes):
  generate keys at <https://testnet.bybit.com/>.
- A Telegram API id/hash (for the listener user client) + a BotFather bot token (for
  alerts and `/commands`).

> ⚠️ **Do NOT use a live/mainnet key for setup.** The bot is testnet-first by design and
> the go-live gate is not met. If you only have a live key, generate a testnet key first
> and use that here. A leaked live API secret should be revoked in the Bybit dashboard
> immediately.

---

## 1. Create your `.env`

```bash
cd ~/workspace/repos/bybit-listener
cp .env.example .env
```

`cp` is safe — `.env` is already in `.gitignore`. Confirm:

```bash
git check-ignore .env   # → prints ".env" (good)
```

---

## 2. Paste your Bybit token (the only edit most users need)

Open `.env` and fill these two lines:

```dotenv
# ---- Bybit API (TESTNET keys for all build/verification work) ----
BYBIT_API_KEY=your_testnet_api_key_here
BYBIT_API_SECRET=your_testnet_api_secret_here
BYBIT_TESTNET=true
```

- `BYBIT_TESTNET=true` keeps the bot on testnet until you deliberately go live via the
  two-step gate. **Leave it `true` unless you have explicitly passed the go-live gate.**
- The key/secret are read by `src/exchanges/bybit.py` at runtime from the environment
  only. They are **never** written to the database or any log.

That is the single "paste my token here" step. The remaining fields below are optional
for a first run but required for live operation.

---

## 3. Telegram listener credentials (read @fattyfatclub)

```dotenv
TG_API_ID=your_api_id
TG_API_HASH=your_api_hash
SESSION_STRING=            # leave blank first run; telethon prompts once then caches it
CHANNEL_USERNAME=fattyfatclub
```

- Get `TG_API_ID` / `TG_API_HASH` at <https://my.telegram.org/> → API development tools.
- `SESSION_STRING` is a Telethon user-session login. On first run, leave it blank; the
  client will prompt for your phone number + code. Copy the resulting session string
  back into `.env` to avoid re-login. **Treat it like a password.**

## 4. Telegram bot (alerts + /commands)

```dotenv
TG_BOT_TOKEN=your_botfather_token
TG_BOT_CHAT=your_chat_id
```

- `TG_BOT_TOKEN` from [@BotFather](https://t.me/BotFather).
- `TG_BOT_CHAT` is the chat/user id where the bot posts alerts and reads `/live <token>`.

## 5. Postgres config DB (reuse existing `fatty_config` on Sera)

```dotenv
CONFIG_DB_URL=postgresql://app:***@127.0.0.1:5432/fatty_config
# CONFIG_DB_TEST_URL=   # optional throwaway DB for tests
```

- Single driver: **psycopg** (do not add asyncpg).
- This DB stores **env-var names only** (`bots.tg_bot_token_env`, etc.) — never the
  actual key/token values. The real secrets stay in `.env`.

---

## 6. Install & verify

```bash
PY=/usr/local/lib/hermes-agent/venv/bin/python3
$PY -m pip install -r requirements.txt
$PY -m pytest -q                 # expect 81 passed
```

---

## 7. Run modes (main.py)

| Command | What it does |
|---------|--------------|
| `python main.py --check-tg` | Verify Telegram session + channel reach. **No orders.** |
| `python main.py --live-dry` | Real source, dry-run, testnet. **Can never place a real order.** |
| `python main.py --dashboard` | Run the supervised bot (paper by default; one listener per bot token). |
| `python main.py --go-live` | Step 1 of go-live: mint a one-time token. Prints instructions. |
| `python main.py --all-bots` | Run every enabled bot row (one child each). |
| `python main.py --status` | Print bot status (degrades gracefully if DB is down). |
| `python main.py --balance / --positions / --signals / --last / --test` | Inspector sub-commands. |

### Verify BUG A/B against testnet

With testnet keys in `.env`:

```bash
python scripts/bybit_api_probe.py
```

It reports whether fills carry a non-zero `execFee` (BUG A) and whether liquidation/close
books the real price (BUG B). No keys → it skips cleanly (no secrets, no crash).

---

## 8. Two-step go-live (only after the gate is met)

1. `python main.py --go-live` → mints a one-time token, persisted to the bot's DB row.
2. In Telegram, send `/live <token>` → only flattens the gate (fee-aware expectancy > 0)
   and flips `paper=0`. **No single command can enable live trading.**

See [`docs/SECURITY.md`](SECURITY.md) for the full gate conditions.

---

## 9. Common pitfalls

- **"config DB unavailable" warning on start** — expected if `fatty_config` Postgres is
  not reachable. The bot degrades to safe **paper/testnet defaults** and keeps running.
- **All signals IGNOREd in replay** — check `ts_ms` is recent; the gate rejects signals
  older than the max-age window (a replay bug fixed in Phase 10 — use current timestamps).
- **Entry signals routed to MANAGE** — fixed in Phase 10: an entry with a side + entry
  price is never treated as management even if it carries `sl`/`tp` text.
