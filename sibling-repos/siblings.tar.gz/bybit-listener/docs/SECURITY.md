# Security — bybit-listener

The bot can trade real money once the go-live gate passes. These rules are
**non-negotiable** and are enforced in code, not just in prose.

---

## Hard safety rules

1. **Never place a real order to test.** Use Bybit **TESTNET** for all live-API checks
   (`BYBIT_TESTNET=true`). The testnet probe (`scripts/bybit_api_probe.py`) is the only
   code path that should hit Bybit with credentials during build/verification.
2. **`paper` is the live/dry gate**, persisted in Postgres (`bots.paper`). The bot reads
   the DB row **before acting** in `src/orchestrator.py`. No code path flips it to live
   without the two-step gate.
3. **Secrets only in the git-ignored `.env`.** Never echo keys/tokens to chat, logs, or
   commits. `git check-ignore .env` must return `.env`. The Postgres config DB stores
   **env-var NAMES only** (`bots.tg_bot_token_env`), never the values.
4. **A pasted private key is permanently compromised.** If a live API secret is ever
   exposed, revoke it in the Bybit dashboard immediately and rotate. (Bybit API secrets
   are not blockchain private keys — they can't be "swept", only revoked.)
5. **Never cancel `reduce_only` protective orders** during management (BUG C). The
   OrderService management transforms preserve them.
6. **Exactly one listener per Telegram bot token.** `--all-bots` spawns one child per
   enabled bot; `run_bots.sh` enforces a single supervisor to avoid Telegram conflict.
7. **SL is mandatory**; liquidation is booked at the **real** price, never `0.00` (BUG B).
8. **Dead-man's switch** flattens positions + halts on heartbeat loss.
9. **Go-live gate (spec §20):** P0 (fees recorded, real-time stops, no `0.00` liquidation)
   verified **and** fee-adjusted expectancy > 0 **before any live order**.
10. **Never assert root cause without proof.** Retract overclaims; verify against real
    testnet/data.

---

## Secret handling (where your Bybit token lives)

```
.env                      ← you paste BYBIT_API_KEY / BYBIT_API_SECRET here
  │  (git-ignored; never committed)
  ▼
src/exchanges/bybit.py    ← reads from environment at runtime only
  │
  ▼
BybitAdapter (REST V5)    ← uses the key/secret for signed requests

Postgres fatty_config     ← stores env-var NAMES only (bots.tg_bot_token_env etc.)
                             NEVER the actual key/token value.
```

Nothing you paste into `.env` is ever written to the database, logs, chat, or git.

---

## The two-step go-live gate

A single command cannot enable live trading:

1. `python main.py --go-live` mints a **one-time** token, persisted to the bot's DB row.
2. In Telegram, send `/live <token>`. The `GoLiveGate.redeem(token, expectancy)` only
   flips `paper=0` **after** the gate (fee-aware expectancy > 0, P0 verified) is met.
   If the gate is not met, the token is rejected and the bot stays in paper mode.

This means a compromised chat, a stray command, or a config mistake cannot silently
enable real orders.

---

## Incident response

- **Live key leaked** → revoke it in the Bybit dashboard now; rotate. The bot only ever
  used it via signed REST/WS calls; revoking kills further access.
- **Unexpected live order** → the dead-man's switch flattens + halts on heartbeat loss;
  set `bots.paper = 1` in the DB and restart via `scripts/run_bots.sh`.
- **Liquidation booked at 0.00** → would be a BUG B regression; check `trades_log.liq_price`
  non-null on liquidation rows; re-run `scripts/bybit_api_probe.py` against testnet.
- **Fees missing (BUG A)** → verify `trades_log.open_fee` / `close_fee` are non-zero; the
  ledger write asserts `net_usd == gross - open - close`.

---

## Verification evidence (this commit)

- `pytest` green (81 passed) — no network, fakes only.
- `scripts/replay_real.py`: 100 msgs → ENTER 30 / IGNORE 21 / MANAGE 49 / errors 0.
- `scripts/replay_mgmt.py`: management transforms verified; no `reduce_only` protective
  order cancelled.
- Secret scan of the committed tree: **0 hits** (no key/token in source, git, or logs).
- **Go-live gate: NOT MET** — no testnet keys present here, so BUG A/B are unverified
  against testnet and fee-aware expectancy is unproven. Bot is paper/testnet-by-default.
