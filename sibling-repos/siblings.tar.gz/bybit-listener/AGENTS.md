# AGENTS.md — bybit-listener (condensed spec for agents)

Read `/root/workspace/bybit_listener_build_spec.md` for the full contract. This is the
operating manual. **Rules below are not style preferences — the bot trades real money
once the go-live gate passes.**

## What this is
A Bybit V5 (`@fattyfatclub` Telegram signal → rule/LLM decision → Bybit USDT perpetuals)
auto-trader. Goal: **strictly better than both parents** (`learnernoearner-listener`
Binance, `hyperliquid-fatty-trader` HL) by closing their shared fatal gaps:
- BUG A: fees never recorded → **we record real `execFee` on every fill** (trades_log.open_fee/close_fee).
- BUG B: liquidation booked at `0.00` → **we book at the real `liq_price`/`execPrice`**.
- BUG C: reduce-only protective orders dropped → **we never auto-cancel reduce_only orders**.

## Hard safety rules (non-negotiable)
1. **Never place a real order to test.** Use Bybit **TESTNET** for ALL live-API checks.
2. **`paper` is the live/dry gate, persisted in Postgres.** Always read the DB row before acting.
3. **Secrets only in git-ignored `.env`.** Never echo keys/tokens to chat/logs; `git check-ignore .env`.
4. A pasted private key is permanently compromised — advise sweeping funds.
5. **Never cancel `reduce_only` protective orders** during management.
6. Exactly one listener per Telegram bot token (`--all-bots` spawns one child per enabled bot).
7. SL mandatory; liquidation booked at real price, never 0.00.
8. Dead-man's switch flattens + halts on heartbeat loss.
9. Go-live gate (spec §20): P0 (fees, real-time stops, no-0.00) verified + fee-adjusted
   expectancy > 0 before any live order.
10. Never assert root cause without proof; retract overclaims; verify against real testnet/data.

## Architecture (mandatory SOLID + DI)
Bybit adapter sits behind `ExchangeAdapter` (src/interfaces/ports.py). Pure domain
(src/domain/model.py). Fakes for tests (no network in unit tests). Composition at main.py.

## Build sequence (do in order; each independently testable)
P0 scaffold → P1 domain/ports/fakes → P2 signal ingestion → P3 Bybit REST (testnet) →
P4 Bybit WS (testnet) → P5 order+position+real-time stops → P6 fee-aware ledger →
P7 reflexivity+fusion → P8 learning loop → P9 notifier+go-live → P10 replay+gate.

## Verification (spec §20)
- `python -m compileall src` clean; `pytest` green.
- Testnet: fill has non-zero `execFee` in trades_log (BUG A closed).
- Liquidation sim: `exit_price`/`liq_price` = real price, not 0.00 (BUG B closed).
- Management messages behave; protective orders never auto-cancelled.
- `replay_real.py` / `replay_mgmt.py` zero crashes.
- Paper e2e: no mainnet contact when `BYBIT_TESTNET=true`.
- Go-live gate: fee-aware expectancy > 0; P0 verified; secrets never in chat.

## Driver / DB
- Single Postgres driver: **psycopg** (keep it that way; do NOT add asyncpg).
- Reuse existing `fatty_config` DB (no new server). Secrets are env-var NAMES only.
- Interpreter: `/usr/local/lib/hermes-agent/venv/bin/python3` (NOT system python3).

## Documentation contract
Any behavior change → `CHANGELOG.md` entry under `## [Unreleased]` (state OLD behavior).
`deploy.sh` blocks deploy if `[Unreleased]` empty or tests fail.
