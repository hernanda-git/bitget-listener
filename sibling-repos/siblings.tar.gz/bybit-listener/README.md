# bybit-listener

A Bybit V5 (USDT perpetuals) **listener trading bot**. It ingests free-text trade
signals from the Telegram channel `@fattyfatclub`, runs them through a rule + optional
LLM decision engine, and executes them on Bybit with a clean **SOLID + dependency-
injection** architecture. It is built to be **strictly better than the two parent bots**
([`learnernoearner-listener`](https://github.com/hernanda-git/learnernoearner-listener)
on Binance, [`hyperliquid-fatty-trader`](https://github.com/hernanda-git/hyperliquid-fatty-trader)
on Hyperliquid) by closing their shared fatal gaps.

> **Status:** Phases P0–P10 complete and committed. **Paper / testnet by default.**
> The go-live gate (spec §20) is **not yet met** — no live order can fire until the
> testnet probe verifies fee/liquidation handling and fee-aware expectancy > 0.

---

## Why this exists

Both parents share three fatal gaps this bot closes:

| Bug | What went wrong in the parents | What we do |
|-----|-------------------------------|------------|
| **BUG A** — fees never recorded | PnL was computed gross; trading fees invisible | Record the real `execFee` from the Bybit `execution` WebSocket on **every** fill. `net_usd = gross_usd - (open_fee + close_fee)` |
| **BUG B** — liquidation booked at `0.00` | Liquidations closed at `(avg_price or 0.00)` | Book exits at the **real** realized `liq_price` / `execPrice`, never `0.00` |
| **BUG C** — protective orders dropped | `reduce_only` SL/TP were auto-cancelled during management | We **never** auto-cancel `reduce_only` protective orders |

## Differentiators

- Fee-aware from day one (BUG A).
- Real-time stops via WebSocket (1–2s), never 10s polling.
- Reflexivity guard + independent signal fusion (orderbook imbalance, CVD, funding,
  liquidation heatmap) with a **pre-LLM fast path** for clear signals.
- Learning loop (gated behind human confirmation) writing `param_log` / `strategy_perf`.
- Single Postgres `fatty_config` ledger, externally queryable from a dashboard.
- **Two-step go-live gate** — no single command can flip it to live trading.

---

## Documentation

| File | Purpose |
|------|---------|
| [`docs/SETUP.md`](docs/SETUP.md) | **Where you paste your Bybit token** + full install & run instructions |
| [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md) | Module map, data flow, the pipeline, DI boundaries |
| [`docs/SECURITY.md`](docs/SECURITY.md) | Safety rules, secret handling, the go-live gate, incident response |
| [`CHANGELOG.md`](CHANGELOG.md) | Canonical per-phase history (mandatory for `deploy.sh`) |
| [`AGENTS.md`](AGENTS.md) | Condensed operating manual for AI agents working on the repo |

---

## Quick start

```bash
cd ~/workspace/repos/bybit-listener

# 1) Create your config from the template (git-ignored — safe)
cp .env.example .env
#    → now EDIT .env and paste your TESTNET Bybit key/secret + Telegram creds
#      (full steps in docs/SETUP.md)

# 2) Use the project venv
PY=/usr/local/lib/hermes-agent/venv/bin/python3   # or: python3 -m venv .venv && . .venv/bin/activate
$PY -m pip install -r requirements.txt

# 3) Run the test suite (no network needed — fakes are used)
$PY -m pytest -q

# 4) Verify the Telegram session + channel reach. NO orders are placed.
$PY -m src.main --check-tg

# 5) Real source, dry-run, TESTNET, CAN NEVER place a real order.
$PY -m src.main --live-dry
```

---

## Safety (read this first)

- **Never place a real mainnet order to test.** The persisted `paper` flag (Postgres)
  gates live mode — the bot reads it **before** acting.
- **Two-step go-live** (`--go-live` mints a one-time token; `/live <token>` in chat
  flips `paper=0`). Both steps are required, and the second only works after the
  gate (fee-aware expectancy > 0) is met.
- **Secrets live only in the git-ignored `.env`.** Never commit, echo, or paste a
  live secret into chat. The Postgres config DB stores **env-var NAMES only**, never
  key/token values.
- See [`docs/SECURITY.md`](docs/SECURITY.md) for the full ruleset and incident response.

---

## Build status

Phases P0–P10 per `bybit_listener_build_spec.md`. See [`CHANGELOG.md`](CHANGELOG.md)
for the per-phase record and the verification evidence for this commit.

| Check | Result |
|-------|--------|
| `compileall src scripts` | clean |
| `pytest` | 81 passed |
| `scripts/replay_real.py` | 100 msgs → ENTER 30 / IGNORE 21 / MANAGE 49 / errors 0 |
| `scripts/replay_mgmt.py` | sl_to_entry / partial / full_close / tp_modify verified; no `reduce_only` protective order cancelled |
| `main.py` run modes | start without crashing; DB-down degrades to safe paper defaults |
| **Go-live gate** | **NOT MET** — no testnet keys present; BUG A/B unverified against testnet; expectancy unproven |
