"""Free-text signal parser for @fattyfatclub (USDT pairs).

Turns a channel message into a :class:`RawSignal`. Handles both an explicit
``TOKENUSDT`` form and ``#TOKEN`` / ``$TOKEN`` mentions, LONG/SHORT -> BUY/SELL,
entry/sl/tp/leverage/confidence, and routes management messages (``sl to entry``,
``tp1 booked``, ``full``, ``tp1 <price>`` ...) to PositionManager instead of ENTER.

Design rules (spec §8, §13):
  * Map TOKEN -> Bybit symbol ``TOKENUSDT`` via ``SymbolMap`` (centralized, like the
    HL ``symbol_map.py``). This is the guard against the HL asset-index latent bug.
  * Emit RawSignal with USDT prices; normalization/peg-guard happens downstream.
  * Idempotency + dedup handled by the caller (orchestrator) using ``message_id``.
"""

from __future__ import annotations

import re
from typing import Iterable

from src.domain.model import Instrument, RawSignal

# Side aliases
_LONG = {"long", "buy", "l", "b"}
_SHORT = {"short", "sell", "s", "sh"}

# Management action patterns (lowercased). First match wins.
_MANAGEMENT = [
    (r"\b(sl to entry|sl be|breakeven|be)\b", "sl_to_entry"),
    (r"\b(tp1 booked|partial|tp booked)\b", "partial"),
    (r"\b(closed at entry|cutting|full|close full|exit full|closed)\b", "full_close"),
    (r"\btp[12]?\s*[<=>]?\s*[\$]?([\d.]+)\b", "tp_modify"),
    (r"\bsl\s*[<=>]?\s*[\$]?([\d.]+)\b", "sl_modify"),
]


class SymbolMap:
    """Centralized TOKEN -> Bybit ``TOKENUSDT`` resolution (spec §11, §8)."""

    @staticmethod
    def resolve(text_token: str) -> Instrument:
        """Resolve a raw token/mention to a Bybit instrument.

        Accepts ``BTC``, ``$BTC``, ``#BTC``, ``BTCUSDT``. Returns the canonical
        ``TOKENUSDT`` Instrument. Tradability is checked later by the validator
        against instruments-info (the live tradable set), not here.
        """
        t = text_token.strip().lstrip("$#").upper()
        return Instrument.from_token(t)

    @staticmethod
    def looks_like_symbol(word: str) -> bool:
        w = word.lstrip("$#").upper()
        return bool(re.fullmatch(r"[A-Z0-9]{2,10}USDT", w)) or bool(
            re.fullmatch(r"[A-Z0-9]{2,10}", w)
        )


_TOKEN_RE = re.compile(r"[$#]?([A-Za-z][A-Za-z0-9]{1,12})")
_FLOAT_RE = re.compile(r"[\$]?(\d+(?:\.\d+)?)")
_NUM_KEY_RE = re.compile(
    r"(entry|entry price|ep|sl|stoploss|stop loss|tp|takeprofit|take profit|"
    r"lev|leverage|conf|confidence|liq|liquidation|size|risk)\s*[:\-=]?\s*"
    r"[\$]?(-?\d+(?:\.\d+)?)"
)


_SIDE_WORDS = _LONG | _SHORT
_NUM_KEY_AT_ALL = re.compile(r"(entry|sl|tp|lev|leverage|long|short|buy|sell)", re.IGNORECASE)
_BARE_TICKER = re.compile(r"\b([A-Z]{2,6})\b")  # e.g. BTC, ETH (all-caps)


def _find_symbol(text: str) -> str | None:
    # 1) Explicit USDT-quoted pair wins.
    m = re.search(r"\b([A-Za-z][A-Za-z0-9]{1,12}USDT)\b", text, re.IGNORECASE)
    if m:
        return m.group(1)
    # 2) A $TOKEN or #TOKEN mention.
    m = re.search(r"[$#]([A-Za-z][A-Za-z0-9]{1,12})", text)
    if m:
        return m.group(1)
    # 3) Bare all-caps ticker ONLY when the message looks like a signal (has a side
    #    word or a numeric key). This prevents "random chatter" from resolving a
    #    symbol out of thin air.
    if _NUM_KEY_AT_ALL.search(text):
        m = _BARE_TICKER.search(text)
        if m:
            tok = m.group(1)
            if tok in {"USDT", "THE", "AND", "FOR", "YOU", "ALL"}:
                return None
            return tok
    return None


def _side(text: str) -> str | None:
    low = text.lower()
    if any(re.search(rf"\b{k}\b", low) for k in _LONG):
        return "BUY"
    if any(re.search(rf"\b{k}\b", low) for k in _SHORT):
        return "SELL"
    return None


def _management_action(text: str) -> tuple[str | None, dict] | None:
    low = text.lower()
    for pat, action in _MANAGEMENT:
        m = re.search(pat, low)
        if m:
            extra: dict = {}
            if action in ("tp_modify", "sl_modify") and m.groups():
                try:
                    extra["price"] = float(m.group(1))
                except (ValueError, TypeError):
                    pass
            return action, extra
    return None


def _extract_num_map(text: str) -> dict[str, float]:
    """Build a key->value map from 'word number' style tokens."""
    out: dict[str, float] = {}
    for key, val in _NUM_KEY_RE.findall(text.lower()):
        # normalize key
        k = key.replace(" ", "").replace("entryprice", "entry")
        k = {
            "ep": "entry", "stoploss": "sl", "stoplossprice": "sl",
            "takeprofit": "tp", "takeprofitprice": "tp", "lev": "leverage",
            "conf": "confidence", "confidence": "confidence",
        }.get(k, k)
        out[k] = float(val)
    return out


def parse_message(text: str, message_id: int | None = None,
                  ts_ms: int | None = None, source: str = "fattyfatclub",
                  channel: str = "") -> RawSignal:
    """Parse a channel message into a RawSignal.

    If the message is a management instruction, ``is_management`` is True and the
    appropriate ``management_action`` is set; prices (e.g. tp modify target) live in
    ``raw`` under ``mgmt_price``.
    """
    from typing import Literal

    text = (text or "").strip()
    raw: dict[str, object] = {"text": text}

    sym = _find_symbol(text)
    side = _side(text)
    chosen_side: Literal["BUY", "SELL"] = (side or "BUY")  # type: ignore[assignment]
    nums = _extract_num_map(text)

    mgmt = _management_action(text)
    is_mgmt = mgmt is not None
    # A message carrying BOTH a side and an entry price is an ENTRY signal, even if
    # it also includes sl/tp fields. The SL/TP text must NOT re-route it to the
    # management path (that misroutes every real signal — see replay_real.py).
    # Management instructions are PURE (no side, no entry price): "sl to entry",
    # "tp1 3350", "full", ...
    is_entry = side is not None and nums.get("entry") is not None
    if is_entry:
        mgmt = None
        is_mgmt = False

    if sym:
        inst = SymbolMap.resolve(sym)
    else:
        inst = Instrument(symbol="", base="", quote="USDT")
        # Even on a pure management message, remember the symbol so the orchestrator
        # can route it to the right position. Store it for downstream use.
        if mgmt:
            raw["mgmt_symbol"] = None  # no symbol known without one

    rs = RawSignal(
        symbol_usdt=inst.symbol,
        base=inst.base,
        side=chosen_side,
        entry=nums.get("entry"),
        sl=nums.get("sl"),
        tp=nums.get("tp"),
        notional_usd=nums.get("size", 0.0) or nums.get("risk", 0.0),
        leverage=int(nums.get("leverage", 1) or 1),
        confidence=min(1.0, max(0.0, nums.get("confidence", 0.0))),
        raw=raw,
        source=source,
        message_id=message_id,
        ts_ms=ts_ms,
        channel=channel,
        raw_text=text,
        is_management=is_mgmt,
        management_action=mgmt[0] if mgmt else None,
    )
    if mgmt:
        raw["mgmt_price"] = mgmt[1].get("price")
    return rs


def parse_messages(items: Iterable[str], **kw) -> list[RawSignal]:
    return [parse_message(t, **kw) for t in items]
