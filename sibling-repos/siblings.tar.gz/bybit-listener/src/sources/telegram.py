"""Telegram @fattyfatclub listener (SignalSource via Telethon).

Listens to the channel and pushes parsed RawSignals onto the queue. Credentials
(TG_API_ID, TG_API_HASH, SESSION_STRING, CHANNEL_USERNAME) come from the git-ignored
``.env``. The listener never places orders and never echoes secrets.

Integration-gated: requires real TG credentials; unit tests use ``FakeSignalSource``.
"""

from __future__ import annotations

import asyncio
import os
from asyncio import Queue

from src.domain.model import RawSignal
from src.interfaces.ports import SignalSource
from src.sources.parser import parse_message


class TelegramSource(SignalSource):
    def __init__(self, channel: str = "", session: str | None = None,
                 api_id: str | None = None, api_hash: str | None = None) -> None:
        self.channel = channel or os.getenv("CHANNEL_USERNAME", "fattyfatclub")
        self.api_id = api_id or os.getenv("TG_API_ID", "")
        self.api_hash = api_hash or os.getenv("TG_API_HASH", "")
        self.session = session or os.getenv("SESSION_STRING", "")
        self.queue: Queue = Queue()
        self._client = None
        self._running = False

    async def start(self) -> None:
        """Connect a Telethon client and begin listening.

        Raises if credentials are missing (integration environment only).
        """
        from telethon import TelegramClient
        if not self.api_id or not self.api_hash:
            raise RuntimeError("TG_API_ID/TG_API_HASH missing — cannot start listener")
        self._client = TelegramClient(
            "bybit_listener_session", int(self.api_id), self.api_hash,
            session_string=self.session or None,
        )
        await self._client.start()
        self._running = True
        asyncio.create_task(self._pump())

    async def _pump(self) -> None:
        from telethon import events
        @self._client.on(events.NewMessage(chats=self.channel))
        async def handler(event):  # pragma: no cover - requires live TG
            msg = event.message
            text = msg.message or ""
            rs = parse_message(
                text, message_id=getattr(msg, "id", None),
                ts_ms=getattr(msg, "date", None) and int(msg.date.timestamp() * 1000),
                channel=self.channel, source="fattyfatclub",
            )
            rs.has_media = bool(msg.media)
            if msg.media:
                rs.image_path = ""  # fetcher fills this later
            await self.queue.put(rs)
        await self._client.run_until_disconnected()

    def subscribe(self) -> Queue:
        return self.queue

    async def stop(self) -> None:
        self._running = False
        if self._client is not None:
            await self._client.disconnect()


class FakeSignalSource(SignalSource):
    """Test double: inject RawSignals without Telegram."""

    def __init__(self, items: list[RawSignal] | None = None) -> None:
        self.queue: Queue = Queue()
        self._items = items or []

    async def start(self) -> None:
        for it in self._items:
            await self.queue.put(it)

    async def stop(self) -> None:
        pass

    def subscribe(self) -> Queue:
        return self.queue

    def inject(self, raw: RawSignal) -> None:
        self.queue.put_nowait(raw)
