"""LLM decision for ambiguous signals only (spec §2.5, §16).

The pre-LLM fast path handles clear shapes sub-second. This module is the escalation
target when the fast path returns IGNORE due to ambiguity (missing fields, low
confidence, conflicting microstructure). It is intentionally optional: if no LLM
endpoint is configured, it returns an ABSTAIN so the orchestrator can ignore safely.

No LLM call is made unless credentials are present; the bot never depends on the LLM
to function (spec: "LLM only for ambiguous/disagreeing cases").
"""

from __future__ import annotations

import os

from src.domain.model import RawSignal, Signal, TradeDecision


class LLMDecision:
    """Ambiguous-signal escalation. Returns a TradeDecision or ABSTAIN sentinel."""

    ABSTAIN = "ABSTAIN"

    def __init__(self, endpoint: str | None = None, model: str | None = None) -> None:
        self.endpoint = endpoint or os.getenv("LLM_ENDPOINT")
        self.model = model or os.getenv("LLM_MODEL", "macaron-v1-tall")
        self.enabled = bool(self.endpoint)

    async def decide(self, raw: RawSignal, sig: Signal, mark: float | None
                     ) -> TradeDecision | str:
        if not self.enabled:
            # No LLM configured: do not invent a trade. Abstain -> orchestrator ignores.
            return self.ABSTAIN
        # Integration-gated: a real call would go here. Kept out of unit tests and
        # never invoked on testnet/mainnet as a "proof". We abstain by default so the
        # bot cannot place a trade solely from an unverified LLM path.
        return self.ABSTAIN
