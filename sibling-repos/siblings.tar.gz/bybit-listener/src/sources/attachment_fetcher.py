"""Attachment fetcher (stub, spec §5 layout). Downloads Telegram media to disk.

Integration-gated (needs a live Telethon client). The listener calls ``download``;
without media present it returns an empty path. Kept minimal: media signals require
manual review unless a vision path is wired (Gate1 media filter).
"""

from __future__ import annotations

from src.interfaces.ports import AttachmentFetcher


class AttachmentFetcherImpl(AttachmentFetcher):
    def __init__(self, out_dir: str = "data/samples") -> None:
        self.out_dir = out_dir

    async def download(self, client, message, channel: str = "") -> tuple[str, str]:
        if not getattr(message, "media", None):
            return "", ""
        # Integration path: real download via client.download_media. Not exercised in
        # unit tests; we return empty path so the pipeline treats it as manual-review.
        return "", "image"
