"""Pure domain types. No IO, no async, no framework imports.

All prices in ``Signal``/``Fill``/``Position`` are in **USDT** (Bybit perps settle in
USDT; the channel is USDT). The peg is 1.0 USDT->USDT and a StablecoinPegGuard
(tolerance 0.5%) guards it for safety (spec §9).

Modeled after spec §6 (Instrument, Signal, Position, Fill, TradeDecision) plus the
pipeline types RawSignal (parser output) and OrderRequest (exchange input) that the
orchestrator threads between layers. ``net_usd = gross_usd - (open_fee + close_fee)``
is the contract that closes BUG A (fees recorded) and BUG B (real liquidation price).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal


@dataclass(frozen=True)
class Instrument:
    """Bybit canonical instrument. ``symbol`` is e.g. ``BTCUSDT``."""

    symbol: str                      # Bybit canonical: "BTCUSDT"
    base: str                        # "BTC"
    quote: str = "USDT"              # Bybit perps settle in USDT
    venue: str = "bybit"

    @classmethod
    def from_token(cls, token: str) -> "Instrument":
        """Map a channel TOKEN (e.g. ``BTC``) to a Bybit ``TOKENUSDT`` instrument."""
        token = token.upper().strip()
        if token.endswith("USDT"):
            base = token[:-4]
            symbol = token
        else:
            base = token
            symbol = f"{token}USDT"
        return cls(symbol=symbol, base=base, quote="USDT", venue="bybit")


@dataclass
class RawSignal:
    """Unnormalized signal as produced by the source (Telegram @fattyfatclub).

    Prices are in the *source* quote asset (USDT). ``SignalNormalizer`` consumes
    them and emits a ``Signal``. ``symbol_usdt`` keeps the raw pairing for audit.
    """

    symbol_usdt: str = ""            # e.g. "BTCUSDT" (filled by parser)
    base: str = ""                   # resolved base, e.g. "BTC"
    side: Literal["BUY", "SELL"] = "BUY"
    entry: float | None = None
    sl: float | None = None
    tp: float | None = None
    tp_extra: list[float] = field(default_factory=list)
    notional_usd: float = 0.0
    leverage: int = 1
    confidence: float = 0.0
    raw: dict = field(default_factory=dict)
    source: str = "fattyfatclub"
    message_id: int | None = None
    ts_ms: int | None = None
    has_media: bool = False
    channel: str = ""
    raw_text: str = ""
    image_path: str = ""
    is_management: bool = False       # routed to PositionManager, not ENTER
    management_action: str | None = None  # sl_to_entry|partial|full_close|tp_modify|...


@dataclass
class Signal:
    """Normalized, execution-ready signal. All prices in USDT (post-peg-guard)."""

    instrument: Instrument
    side: Literal["BUY", "SELL"]     # mapped from LONG/SHORT
    entry: float | None              # USDT (post-normalization; = channel USDT, peg 1.0)
    sl: float | None
    tp: float | None
    notional_usd: float              # risk budget in USD
    leverage: int
    confidence: float               # 0..1
    raw: dict = field(default_factory=dict)
    source: str = "fattyfatclub"
    message_id: int | None = None
    ts_ms: int | None = None
    peg_rate: float = 1.0            # USDT per USDT used during normalization


@dataclass
class OrderRequest:
    """A single order to be placed on Bybit (USDT-settled, coin-sized).

    Centralizes the Bybit-specific fields so every path (entry, manage, close,
    cancel) uses one builder. The Bybit adapter translates this to the V5 POST
    body (spec §4.6).
    """

    instrument: Instrument
    side: Literal["BUY", "SELL"]
    order_type: Literal["Market", "Limit", "Stop", "StopLimit",
                        "TakeProfit", "TakeProfitLimit", "TrailingProfit"]
    qty: float                       # base-asset size (e.g. BTC)
    price: float | None = None       # required for Limit/Stop
    reduce_only: bool = False
    time_in_force: Literal["IOC", "FOK", "GTC", "PostOnly"] = "GTC"
    trigger_price: float | None = None
    trigger_direction: int | None = None   # 1 = rises to, 2 = falls to
    sl: float | None = None                # attached SL (atomic at create)
    tp: float | None = None                # attached TP (atomic at create)
    tpsl_mode: Literal["Full", "Partial"] = "Full"
    sl_trigger_by: Literal["LastPrice", "MarkPrice", "IndexPrice"] = "MarkPrice"
    tp_trigger_by: Literal["LastPrice", "MarkPrice", "IndexPrice"] = "MarkPrice"
    position_idx: int = 0
    client_order_id: str | None = None     # orderLinkId ("b-" + ulid)
    is_market: bool = False


@dataclass
class Position:
    """Local position state, WS-synced from the exchange (spec §6, §13)."""

    instrument: Instrument
    side: Literal["BUY", "SELL"]
    size: float                      # base-asset size
    entry_price: float
    leverage: int
    sl_price: float | None = None
    tp_price: float | None = None
    liq_price: float | None = None   # populated from exchange; used on liquidation booking
    unrealized_pnl: float = 0.0
    updated_at_ms: int | None = None


@dataclass
class Fill:
    """A real execution. ``fee`` is the REAL exchange fee, recorded always (BUG A)."""

    order_link_id: str
    price: float
    qty: float
    side: str
    fee: float                       # <- REAL fee, recorded always
    fee_asset: str = "USDT"
    ts_ms: int = 0
    is_reduce: bool = False
    exec_type: str = ""              # "Trade" | "AdlTrade" | "BustTrade" | "LiqTrade" ...
    order_id: str = ""
    symbol: str = ""                 # symbol this fill belongs to (e.g. "BTCUSDT")


@dataclass
class TradeDecision:
    """Output of the decision pipeline (validator fast-path or LLM)."""

    action: Literal["ENTER", "MANAGE", "IGNORE"]
    signal: Signal | None
    leverage: int
    size_coin: float
    sl: float | None
    tp: float | None
    reason: str
    reflexivity_tilt: float = 0.0    # size multiplier from reflexivity guard
