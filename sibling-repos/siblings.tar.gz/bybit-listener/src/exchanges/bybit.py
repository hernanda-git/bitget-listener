"""Bybit V5 REST adapter (USDT perpetuals, category=linear).

Centralizes:
  * HMAC-SHA256 signing (spec §4.2) — one place, unit-tested against the algorithm.
  * Symbol resolution + rounding from ``instruments-info`` (spec §4.8) — the explicit
    guard against the HL asset-index latent bug. EVERY order path uses these.
  * Order create/cancel/amend, set-trading-stop, set-leverage, wallet-balance,
    position-list, tickers, market-time.

All requests go through ``_request`` which adds auth headers and applies a token-bucket
+ exponential backoff on 10006/10018/170151 (spec §4.7). The live path is exercised on
TESTNET only (spec rule #1); mainnet is never contacted when ``testnet=True``.

NOTE: schemas below follow the spec blueprint. Testnet is the arbiter (spec rule #8) —
any field Bybit refines must be corrected here, NOT hacked around. The probe script
captures the verbatim retCode/retMsg so drift is surfaced, not hidden.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import time
from dataclasses import dataclass, field
from typing import Any

import httpx

from src.domain.model import Fill, Instrument, OrderRequest, Position
from src.interfaces.ports import ExchangeAdapter


@dataclass
class InstrumentInfo:
    symbol: str
    base_precision: int      # lotSizeFilter.basePrecision (decimals)
    min_order_qty: float
    max_order_qty: float
    min_notional: float      # minNotionalValue
    tick_precision: int      # priceFilter.tickSize (decimals)
    price_filter_min: float
    price_filter_max: float


@dataclass
class BybitConfig:
    api_key: str = ""
    api_secret: str = ""
    testnet: bool = True
    category: str = "linear"
    position_idx: int = 0
    recv_window_ms: int = 5000
    rate_limit_per_s: int = 10
    timeout_s: float = 10.0
    # endpoint overrides (None -> derived from testnet flag)
    rest_url: str | None = None

    @property
    def rest_base(self) -> str:
        if self.rest_url:
            return self.rest_url.rstrip("/")
        return "https://api-testnet.bybit.com" if self.testnet \
            else "https://api.bybit.com"

    @property
    def is_testnet(self) -> bool:
        return self.testnet


class BybitRateLimitError(RuntimeError):
    pass


class BybitAuth:
    """HMAC-SHA256 request signing per Bybit V5 (spec §4.2)."""

    def __init__(self, api_key: str, api_secret: str, recv_window_ms: int = 5000) -> None:
        self.api_key = api_key
        self.api_secret = api_secret
        self.recv_window = str(recv_window_ms)

    def headers(self, method: str, path: str, params: dict | None = None,
                body: dict | None = None) -> dict[str, str]:
        ts = str(int(time.time() * 1000))
        if method.upper() == "GET":
            param_str = "&".join(f"{k}={v}" for k, v in sorted((params or {}).items()))
        else:
            param_str = json.dumps(body or {}, separators=(",", ":"))
        sign = hmac.new(
            self.api_secret.encode(),
            (ts + self.api_key + self.recv_window + param_str).encode(),
            hashlib.sha256,
        ).hexdigest()
        return {
            "X-BAPI-API-KEY": self.api_key,
            "X-BAPI-TIMESTAMP": ts,
            "X-BAPI-RECV-WINDOW": self.recv_window,
            "X-BAPI-SIGN": sign,
            "Content-Type": "application/json",
        }


class BybitAdapter(ExchangeAdapter):
    def __init__(self, cfg: BybitConfig) -> None:
        self.cfg = cfg
        self._auth = BybitAuth(cfg.api_key, cfg.api_secret, cfg.recv_window_ms)
        self._client = httpx.AsyncClient(base_url=cfg.rest_base, timeout=cfg.timeout_s)
        self._instruments: dict[str, InstrumentInfo] = {}
        self._last_instruments_fetch: float = 0.0
        # simple in-process token bucket
        self._tokens = float(cfg.rate_limit_per_s)
        self._last_ts = time.monotonic()

    # ---- token bucket ----
    def _acquire(self) -> None:
        now = time.monotonic()
        self._tokens += (now - self._last_ts) * self.cfg.rate_limit_per_s
        self._tokens = min(self._tokens, self.cfg.rate_limit_per_s)
        self._last_ts = now
        if self._tokens < 1:
            time.sleep((1 - self._tokens) / self.cfg.rate_limit_per_s)
        self._tokens -= 1

    # ---- low-level request ----
    async def _request(self, method: str, path: str, params: dict | None = None,
                       body: dict | None = None) -> dict:
        self._acquire()
        headers = self._auth.headers(method, path, params, body)
        for attempt in range(5):
            if method.upper() == "GET":
                resp = await self._client.get(path, params=params, headers=headers)
            else:
                resp = await self._client.post(path, params=params, json=body, headers=headers)
            data = resp.json()
            rc = data.get("retCode", -1)
            if rc == 0:
                return data
            if rc in (10006, 10018, 170151):
                # rate limit -> exponential backoff
                await asyncio_sleep(min(2 ** attempt, 8))
                continue
            # non-retryable error: surface verbatim
            raise BybitRateLimitError(
                f"Bybit {method} {path} retCode={rc} retMsg={data.get('retMsg')} "
                f"ext={data.get('retExtInfo')}"
            )
        raise BybitRateLimitError(f"Bybit {method} {path} exhausted retries (rate limited)")

    # ---- instruments cache + rounding (spec §4.8) ----
    async def refresh_instruments(self) -> None:
        """Fetch instruments-info for the linear category and cache per-symbol filters."""
        data = await self._request(
            "GET", "/v5/market/instruments-info",
            params={"category": self.cfg.category, "limit": "1000"},
        )
        for row in data.get("result", {}).get("list", []):
            sym = row.get("symbol")
            if not sym:
                continue
            lot = row.get("lotSizeFilter", {})
            price = row.get("priceFilter", {})
            info = InstrumentInfo(
                symbol=sym,
                base_precision=int(_decimals(lot.get("basePrecision", "0.001"))),
                min_order_qty=float(lot.get("minOrderQty", 0)),
                max_order_qty=float(lot.get("maxOrderQty", 0)),
                min_notional=float(row.get("minNotionalValue", 0) or lot.get("minNotionalValue", 0)),
                tick_precision=int(_decimals(price.get("tickSize", "0.01"))),
                price_filter_min=float(price.get("minPrice", 0)),
                price_filter_max=float(price.get("maxPrice", 0)),
            )
            self._instruments[sym] = info
        self._last_instruments_fetch = time.time()

    def get_instrument_info(self, symbol: str) -> InstrumentInfo | None:
        return self._instruments.get(symbol)

    def round_qty(self, symbol: str, qty: float) -> float:
        """Round qty to the instrument's base precision; clip to [min,max]."""
        info = self._instruments.get(symbol)
        if info is None:
            return qty
        factor = 10 ** info.base_precision
        q = round(qty * factor) / factor
        q = max(q, info.min_order_qty)
        q = min(q, info.max_order_qty)
        return q

    def round_price(self, symbol: str, price: float) -> float:
        info = self._instruments.get(symbol)
        if info is None:
            return price
        factor = 10 ** info.tick_precision
        p = round(price * factor) / factor
        p = max(p, info.price_filter_min)
        p = min(p, info.price_filter_max)
        return p

    def tradable_symbols(self) -> set[str]:
        return set(self._instruments.keys())

    # ---- order building (centralized) ----
    def _order_body(self, order: OrderRequest) -> dict:
        sym = order.instrument.symbol
        body: dict[str, Any] = {
            "category": self.cfg.category,
            "symbol": sym,
            "side": order.side,
            "orderType": order.order_type,
            "qty": str(self.round_qty(sym, order.qty)),
            "timeInForce": order.time_in_force,
            "positionIdx": order.position_idx or self.cfg.position_idx,
        }
        if order.client_order_id:
            body["orderLinkId"] = order.client_order_id
        if order.order_type in ("Limit", "Stop", "StopLimit", "TakeProfitLimit") and order.price is not None:
            body["price"] = str(self.round_price(sym, order.price))
        if order.reduce_only:
            body["reduceOnly"] = True
        if order.trigger_price is not None and order.order_type in ("Stop", "StopLimit"):
            body["triggerPrice"] = str(self.round_price(sym, order.trigger_price))
            if order.trigger_direction is not None:
                body["triggerDirection"] = order.trigger_direction
        # attached SL/TP (atomic at create)
        if order.sl is not None:
            body["stopLoss"] = str(self.round_price(sym, order.sl))
            body["slTriggerBy"] = order.sl_trigger_by
        if order.tp is not None:
            body["takeProfit"] = str(self.round_price(sym, order.tp))
            body["tpTriggerBy"] = order.tp_trigger_by
        if order.sl is not None or order.tp is not None:
            body["tpslMode"] = order.tpsl_mode
        return body

    # ---- ExchangeAdapter interface ----
    async def place_order(self, order: OrderRequest) -> str:
        body = self._order_body(order)
        data = await self._request("POST", "/v5/order/create", body=body)
        result = data.get("result", {})
        return result.get("orderId") or result.get("orderLinkId") or ""

    async def cancel_order(self, instrument: Instrument, client_order_id: str) -> bool:
        body = {
            "category": self.cfg.category,
            "symbol": instrument.symbol,
            "orderLinkId": client_order_id,
        }
        data = await self._request("POST", "/v5/order/cancel", body=body)
        return data.get("retCode", -1) == 0

    async def cancel_all(self, instrument: Instrument | None = None) -> bool:
        body: dict = {"category": self.cfg.category}
        if instrument is not None:
            body["symbol"] = instrument.symbol
        data = await self._request("POST", "/v5/order/cancel-all", body=body)
        return data.get("retCode", -1) == 0

    async def get_open_orders(self) -> list[OrderRequest]:
        # Minimal: returns raw list mapping; full OrderRequest reconstruction is done
        # by the caller via position/fill streams. Here we return empty list if the
        # account has no open orders endpoint mapping yet.
        data = await self._request(
            "GET", "/v5/order/realtime",
            params={"category": self.cfg.category, "openOnly": "1", "limit": "50"},
        )
        out: list[OrderRequest] = []
        for o in data.get("result", {}).get("list", []):
            inst = Instrument.from_token(o.get("symbol", ""))
            out.append(OrderRequest(
                instrument=inst, side=o.get("side", "BUY"),
                order_type=o.get("orderType", "Market"),
                qty=float(o.get("qty", 0)),
                price=float(o["price"]) if o.get("price") not in (None, "0.00", "") else None,
                reduce_only=bool(o.get("reduceOnly")),
                client_order_id=o.get("orderLinkId"),
                position_idx=int(o.get("positionIdx", 0)),
            ))
        return out

    async def get_positions(self) -> list[Position]:
        data = await self._request(
            "GET", "/v5/position/list",
            params={"category": self.cfg.category, "settleCoin": "USDT"},
        )
        out: list[Position] = []
        for p in data.get("result", {}).get("list", []):
            size = float(p.get("size", 0))
            if size == 0:
                continue
            inst = Instrument.from_token(p.get("symbol", ""))
            out.append(Position(
                instrument=inst,
                side="BUY" if p.get("side") == "Buy" else "SELL",
                size=size,
                entry_price=float(p.get("avgPrice", 0)),
                leverage=int(float(p.get("leverage", 1))),
                sl_price=float(p.get("stopLoss")) if p.get("stopLoss") not in (None, "") else None,
                tp_price=float(p.get("takeProfit")) if p.get("takeProfit") not in (None, "") else None,
                liq_price=float(p.get("liqPrice")) if p.get("liqPrice") not in (None, "") else None,
                unrealized_pnl=float(p.get("unrealisedPnl", 0)),
            ))
        return out

    async def get_fills(self) -> list[Fill]:
        """Recent executions (fallback; the WS `execution` stream is the primary source)."""
        data = await self._request(
            "GET", "/v5/execution/list",
            params={"category": self.cfg.category, "limit": "50"},
        )
        out: list[Fill] = []
        for f in data.get("result", {}).get("list", []):
            out.append(Fill(
                order_link_id=f.get("orderLinkId", ""),
                price=float(f.get("execPrice", 0)),
                qty=float(f.get("execQty", 0)),
                side=f.get("side", ""),
                fee=float(f.get("execFee", 0)),
                fee_asset=f.get("feeCurrency", "USDT"),
                ts_ms=int(f.get("execTime", "0")),
                is_reduce=bool(f.get("isClosed", False)),
                order_id=f.get("orderId", ""),
            ))
        return out

    async def get_balance_usdt(self) -> float:
        data = await self._request(
            "GET", "/v5/account/wallet-balance",
            params={"accountType": "UNIFIED"},
        )
        for acc in data.get("result", {}).get("list", []):
            for coin in acc.get("coin", []):
                if coin.get("coin") == "USDT":
                    return float(coin.get("availableBalance", 0))
        return 0.0

    async def set_leverage(self, instrument: Instrument, leverage: int) -> None:
        body = {
            "category": self.cfg.category,
            "symbol": instrument.symbol,
            "buyLeverage": str(leverage),
            "sellLeverage": str(leverage),
        }
        data = await self._request("POST", "/v5/position/set-leverage", body=body)
        rc = data.get("retCode", -1)
        if rc not in (0, 110012):  # 110012 = already set, safe to ignore
            raise BybitRateLimitError(
                f"set-leverage {instrument.symbol} {leverage}: retCode={rc} "
                f"retMsg={data.get('retMsg')}"
            )

    async def set_trading_stop(
        self, instrument: Instrument, sl: float | None, tp: float | None,
        sl_trigger_by: str = "MarkPrice", position_idx: int = 0,
    ) -> None:
        body: dict[str, Any] = {
            "category": self.cfg.category,
            "symbol": instrument.symbol,
            "positionIdx": position_idx or self.cfg.position_idx,
            "slTriggerBy": sl_trigger_by,
        }
        if sl is not None:
            body["stopLoss"] = str(self.round_price(instrument.symbol, sl))
        else:
            body["stopLoss"] = "0"  # 0 = no change / clear handled by caller
        if tp is not None:
            body["takeProfit"] = str(self.round_price(instrument.symbol, tp))
        data = await self._request("POST", "/v5/position/set-trading-stop", body=body)
        if data.get("retCode", -1) != 0:
            raise BybitRateLimitError(
                f"set-trading-stop {instrument.symbol}: retCode={data.get('retCode')} "
                f"retMsg={data.get('retMsg')}"
            )

    async def ticker(self, symbol: str) -> dict:
        data = await self._request(
            "GET", "/v5/market/tickers",
            params={"category": self.cfg.category, "symbol": symbol},
        )
        lst = data.get("result", {}).get("list", [])
        return lst[0] if lst else {}

    async def server_time_ms(self) -> int:
        data = await self._request("GET", "/v5/market/time")
        return int(data.get("result", {}).get("timeSecond", 0)) * 1000

    async def close(self) -> None:
        await self._client.aclose()


def _decimals(s: str | float) -> int:
    """Return number of decimal places in a filter step string (e.g. '0.001' -> 3)."""
    s = str(s)
    if "." not in s:
        return 0
    return len(s.split(".", 1)[1].rstrip("0")) if s.split(".", 1)[1].rstrip("0") else 0


# local import to avoid pulling asyncio at module import time in some environments
import asyncio  # noqa: E402


def asyncio_sleep(sec: float):  # pragma: no cover - thin wrapper
    return asyncio.sleep(sec)
