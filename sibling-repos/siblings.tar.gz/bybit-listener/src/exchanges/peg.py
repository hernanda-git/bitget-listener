"""Peg sources (spec §5 layout). Bybit is USDT, so the default is a constant 1.0.

A live USDT/USDC index source can be slotted in later (future-proof), but the guard
in ``services/normalizer.py`` uses ``ConstantPegSource(1.0)`` by default per spec §9.
"""

from __future__ import annotations

from src.interfaces.ports import PegSource


class ConstantPegSource(PegSource):
    """Constant peg rate (USDT->USDT = 1.0). Guard-only; no network."""

    def __init__(self, rate: float = 1.0) -> None:
        self.rate = rate

    async def peg_rate(self) -> float:
        return self.rate


class LivePegSource(PegSource):
    """Optional live index source (e.g. USDT/USDC from an oracle). Not used by default.

    Kept as an extensibility point; the bot runs on ConstantPegSource(1.0).
    """

    def __init__(self, url: str = "") -> None:
        self.url = url

    async def peg_rate(self) -> float:
        # Intentionally not wired to a real feed; the guard expects 1.0 from Bybit.
        raise NotImplementedError("Live peg source not configured; use ConstantPegSource(1.0)")
