"""In-memory fakes for unit tests. No network, no real exchange.

``FakeExchangeAdapter`` records placed orders and returns canned positions/fills so
the ledger, position manager, and validator can be tested deterministically. Fills
carry REAL-ish fees (non-zero) so BUG A (fee-awareness) is exercisable without testnet.
``FakeMarketStream`` returns scripted mark prices so stop logic is testable.
"""

from __future__ import annotations

import asyncio
from collections import defaultdict

from src.domain.model import (
    Fill,
    Instrument,
    OrderRequest,
    Position,
)
from src.interfaces.ports import ExchangeAdapter, MarketStream


class FakeExchangeAdapter(ExchangeAdapter):
    def __init__(self, balance_usdt: float = 1000.0,
                 market_prices: dict[str, float] | None = None) -> None:
        self.balance_usdt = balance_usdt
        # symbol -> last price, used as the fill price for market orders (which
        # carry no limit price). Lets the fake produce realistic non-zero fees.
        self.market_prices: dict[str, float] = dict(market_prices or {})
        self.placed: list[OrderRequest] = []
        self.cancelled: list[str] = []
        self.cancel_all_calls: list[Instrument | None] = []
        self.leverages: dict[str, int] = {}
        self.trading_stops: list[tuple[str, float | None, float | None, str, int]] = []
        self._positions: list[Position] = []
        self._fills: list[Fill] = []
        self._next_order_id = 0
        self._lock = asyncio.Lock()

    async def place_order(self, order: OrderRequest) -> str:
        async with self._lock:
            self.placed.append(order)
            oid = f"fake-{self._next_order_id}"
            self._next_order_id += 1
            # Simulate a fill price: limit/stop use their price; market uses the
            # last known mark (or 0.0 if unknown — test should seed market_prices).
            if order.is_market or order.order_type == "Market":
                px = order.price if order.price is not None \
                    else self.market_prices.get(order.instrument.symbol, 0.0)
            else:
                px = order.price if order.price is not None else (
                    order.trigger_price or order.sl or order.tp or 0.0)
            fee = round(px * order.qty * 0.00055, 8)  # realistic taker fee
            self._fills.append(
                Fill(
                    order_link_id=order.client_order_id or oid,
                    price=px, qty=order.qty, side=order.side,
                    fee=fee, fee_asset="USDT", ts_ms=0,
                    is_reduce=order.reduce_only, order_id=oid,
                )
            )
            return oid

    async def cancel_order(self, instrument: Instrument, client_order_id: str) -> bool:
        self.cancelled.append(client_order_id)
        return True

    async def cancel_all(self, instrument: Instrument | None = None) -> bool:
        self.cancel_all_calls.append(instrument)
        return True

    async def get_open_orders(self) -> list[OrderRequest]:
        return list(self.placed)

    async def get_positions(self) -> list[Position]:
        return list(self._positions)

    async def get_fills(self) -> list[Fill]:
        return list(self._fills)

    async def get_balance_usdt(self) -> float:
        return self.balance_usdt

    async def set_leverage(self, instrument: Instrument, leverage: int) -> None:
        self.leverages[instrument.symbol] = leverage

    async def set_trading_stop(
        self, instrument: Instrument, sl: float | None, tp: float | None,
        sl_trigger_by: str = "MarkPrice", position_idx: int = 0,
    ) -> None:
        self.trading_stops.append((instrument.symbol, sl, tp, sl_trigger_by, position_idx))

    # ---- test helpers ----
    def seed_position(self, pos: Position) -> None:
        self._positions.append(pos)

    def inject_fill(self, fill: Fill) -> None:
        self._fills.append(fill)


class FakeMarketStream(MarketStream):
    def __init__(self, marks: dict[str, float] | None = None) -> None:
        self._marks: dict[str, float] = dict(marks or {})
        self.started = False
        self.stopped = False

    async def start(self) -> None:
        self.started = True

    async def stop(self) -> None:
        self.stopped = True

    def mark_price(self, symbol: str) -> float | None:
        return self._marks.get(symbol)

    def set_mark(self, symbol: str, price: float) -> None:
        self._marks[symbol] = price
