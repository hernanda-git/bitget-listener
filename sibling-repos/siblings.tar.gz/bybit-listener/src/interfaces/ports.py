"""Port interfaces (Dependency Inversion). High-level modules depend on these,
never on concrete adapters (spec §5). Each interface is intentionally narrow
(Interface Segregation). The Bybit adapter MUST sit behind ``ExchangeAdapter`` so
the bot is venue-swappable and unit-testable.

Use ``abc.ABC`` (not just typing.Protocol) so the spec's "ABCS" wording holds and
coverage of required methods is statically checkable.
"""

from __future__ import annotations

import abc
from asyncio import Queue

from src.domain.model import (
    Fill,
    Instrument,
    OrderRequest,
    Position,
    Signal,
)


class SignalSource(abc.ABC):
    """Produces raw signals (e.g. from Telegram @fattyfatclub)."""

    @abc.abstractmethod
    async def start(self) -> None: ...

    @abc.abstractmethod
    async def stop(self) -> None: ...

    @abc.abstractmethod
    def subscribe(self) -> "Queue": ...


class ExchangeAdapter(abc.ABC):
    """Executes orders on the venue (Bybit V5). Centralizes symbol/rounding.

    Every order path (entry, manage, close, cancel) goes through this port, so the
    bot can be unit-tested with ``FakeExchangeAdapter`` and venue-swapped later.
    """

    @abc.abstractmethod
    async def place_order(self, order: OrderRequest) -> str:
        """Return the exchange order id (or client order id)."""

    @abc.abstractmethod
    async def cancel_order(self, instrument: Instrument, client_order_id: str) -> bool: ...

    @abc.abstractmethod
    async def cancel_all(self, instrument: Instrument | None = None) -> bool:
        """Emergency flatten / dead-man's switch (Bybit has no native scheduleCancel)."""

    @abc.abstractmethod
    async def get_open_orders(self) -> list[OrderRequest]: ...

    @abc.abstractmethod
    async def get_positions(self) -> list[Position]: ...

    @abc.abstractmethod
    async def get_fills(self) -> list[Fill]: ...

    @abc.abstractmethod
    async def get_balance_usdt(self) -> float:
        """USDT available balance (for fee-aware sizing)."""

    @abc.abstractmethod
    async def set_leverage(self, instrument: Instrument, leverage: int) -> None: ...

    @abc.abstractmethod
    async def set_trading_stop(
        self, instrument: Instrument, sl: float | None, tp: float | None,
        sl_trigger_by: str = "MarkPrice", position_idx: int = 0,
    ) -> None:
        """Modify SL/TP post-open (Bybit POST /v5/position/set-trading-stop)."""


class MarketStream(abc.ABC):
    """Delivers realtime market + user events via pushes (spec §13, §15)."""

    @abc.abstractmethod
    async def start(self) -> None: ...

    @abc.abstractmethod
    async def stop(self) -> None: ...

    @abc.abstractmethod
    def mark_price(self, symbol: str) -> float | None: ...


class Notifier(abc.ABC):
    """Sends alerts + receives /commands (Telegram bot)."""

    @abc.abstractmethod
    async def send(self, text: str) -> None: ...


class RiskPolicy(abc.ABC):
    """Computes coin size + leverage from a USD notional and portfolio state."""

    @abc.abstractmethod
    def compute_size(
        self, notional_usd: float, mark_price: float, max_leverage: int
    ) -> tuple[float, int]:
        """Return (coin_size, effective_leverage)."""


class PegSource(abc.ABC):
    """Provides the live USDT->USDT peg rate (1.0 for Bybit; guard only)."""

    @abc.abstractmethod
    async def peg_rate(self) -> float: ...


class AttachmentFetcher(abc.ABC):
    """Downloads Telegram image attachments to local disk."""

    @abc.abstractmethod
    async def download(self, client, message, channel: str = "") -> tuple[str, str]:
        """Return (local_path, media_type). Empty path = no media."""
