"""Orchestrator — pipeline coordinator (spec §5, §13, §16).

Wires the SOLID layers together via Dependency Injection. It does NOT depend on any
concrete adapter; it receives ports (SignalSource, ExchangeAdapter, MarketStream,
Notifier, RiskPolicy, Ledger, EvalWriter, ConfigStore) and coordinates the flow:

    RawSignal (Telegram) -> parse/normalize -> Gate1 -> FastPath -> (LLM escalate)
       -> Gate2 -> build_entry -> exchange(place_order, attached SL/TP)
    WS fills/positions -> PositionManager (real-time stops, liquidation @ real price)
       -> on_close -> fee-aware Ledger write (BUG A/B contract: net = gross - fees,
          liq_price never 0.00) -> LearningLoop.record_close -> EvalWriter.
    Management messages -> PositionManager/OrderService transforms (never cancel
       reduce_only protective orders).

Paper vs live is enforced by reading the bot's DB row (`paper` flag) BEFORE acting
(spec §18.2). The orchestrator never places a real order unless paper=False AND the
go-live gate is satisfied. ConfigLoader supplies settings (config.yaml + .env).

Pure logic is unit-testable with the fakes (FakeSignalSource, FakeBybitWS,
FakeExchangeAdapter); the live composition lives in main.py.
"""

from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Literal
from uuid import uuid4

from src.domain.model import (
    RawSignal,
    Signal,
    TradeDecision,
)
from src.interfaces.ports import (
    ExchangeAdapter,
    MarketStream,
    Notifier,
    RiskPolicy,
    SignalSource,
)
from src.services.normalizer import ConstantPegSource, SignalNormalizer
from src.services.order import (
    build_entry,
    build_full_close,
    build_partial_close,
    build_sl_to_entry,
    opposite_side,
)
from src.services.position import PositionManager, PositionManagerConfig
from src.services.reflexivity import (
    CounterTradeTilt,
    ReflexivityConfig,
    ShadowLedger,
    SignalPopularity,
)
from src.services.risk import FixedRiskSizer, RiskConfig
from src.services.validator import FastPath, GateConfig, Validator

# Ledger / eval are optional (no-op when no DB URL); imported lazily to avoid a hard
# psycopg dependency in pure offline unit tests.
LedgerWriter = Any
EvalWriter = Any
ConfigStore = Any


@dataclass
class OrchestratorConfig:
    min_confidence: float = 0.5
    max_signal_age_s: int = 3600
    cooldown_per_symbol_s: int = 300
    media_requires_manual: bool = True
    fee_bps_estimate: float = 0.055
    default_margin_usd: float = 1.0
    default_leverage: int = 3
    max_notional_usd: float = 50.0
    available_usd: float = 1000.0
    position_idx: int = 0
    bot_name: str = "bybit-main"
    paper: bool = True  # live/dry gate (mirrors the DB row; never the boot default)


CloseHandler = Callable[[str, float, float, str, float | None], None]


class Orchestrator:
    """Composes the pipeline over injected ports. No network at construction."""

    def __init__(
        self,
        source: SignalSource,
        exchange: ExchangeAdapter,
        market: MarketStream,
        notifier: Notifier | None = None,
        risk: RiskPolicy | None = None,
        ledger: LedgerWriter | None = None,
        eval_writer: EvalWriter | None = None,
        store: ConfigStore | None = None,
        cfg: OrchestratorConfig | None = None,
        tradable: set[str] | None = None,
    ) -> None:
        self.cfg = cfg or OrchestratorConfig()
        self.source = source
        self.exchange = exchange
        self.market = market
        self.notifier = notifier
        self.ledger = ledger
        self.eval = eval_writer
        self.store = store

        self.normalizer = SignalNormalizer(ConstantPegSource(1.0))
        self.validator = Validator(
            GateConfig(
                min_confidence=self.cfg.min_confidence,
                max_signal_age_s=self.cfg.max_signal_age_s,
                cooldown_per_symbol_s=self.cfg.cooldown_per_symbol_s,
                media_requires_manual=self.cfg.media_requires_manual,
                fee_bps_estimate=self.cfg.fee_bps_estimate,
                max_notional_usd=self.cfg.max_notional_usd,
                default_margin_usd=self.cfg.default_margin_usd,
            ),
            tradable=tradable,
        )
        self.risk = risk or FixedRiskSizer(
            RiskConfig(default_margin_usd=self.cfg.default_margin_usd,
                       default_leverage=self.cfg.default_leverage,
                       max_notional_usd=self.cfg.max_notional_usd)
        )
        self.fast = FastPath(self.validator, self.risk,
                             self.validator.cfg, self.cfg.available_usd)
        # Reflexivity guard (spec §14) — measured, persisted via eval_writer.
        self.reflex = SignalPopularity(ReflexivityConfig())
        self.tilt = CounterTradeTilt(ReflexivityConfig())
        self.shadow = ShadowLedger()

        self.pos_mgr = PositionManager(
            exchange, market, PositionManagerConfig(sl_trigger_by="MarkPrice"),
            on_close=self._on_position_close,
        )
        # learning loop is optional; wired externally so a missing dep is non-fatal
        self.learning = None  # type: ignore[assignment]

        self._running = False
        self._queue = None  # set on start()

    # ---- helpers ----
    def _is_live(self) -> bool:
        """Live/dry gate: prefer the persisted DB row, fall back to cfg.paper."""
        if self.store is not None:
            try:
                row = self.store.get_bot(self.cfg.bot_name)
                if row is not None:
                    return row.live  # (not paper) and enabled
            except Exception:
                pass
        return not self.cfg.paper

    async def _notify(self, text: str) -> None:
        if self.notifier is not None:
            try:
                await self.notifier.send(text)
            except Exception:
                pass

    # ---- WS wiring ----
    def _wire_market(self, market: MarketStream) -> None:
        """Attach the PositionManager's event handlers to the market stream."""
        if hasattr(market, "on_fill"):
            market.on_fill = self.pos_mgr.on_fill  # type: ignore[assignment]
        if hasattr(market, "on_position"):
            market.on_position = self.pos_mgr.on_position  # type: ignore[assignment]
        if hasattr(market, "on_heartbeat"):
            market.on_heartbeat = lambda: self.pos_mgr.heartbeat()  # type: ignore[assignment]

    # ---- main loop ----
    async def start(self) -> None:
        self._queue = self.source.subscribe()
        self._wire_market(self.market)
        await self.source.start()
        if hasattr(self.market, "start"):
            try:
                await self.market.start()
            except Exception as e:  # live WS needs keys; fake WS is fine
                await self._notify(f"market stream unavailable: {e!r}")
        self._running = True
        mode = "LIVE" if self._is_live() else "PAPER(dry-run)"
        await self._notify(f"bybit-listener {self.cfg.bot_name} started in {mode} mode")
        while self._running:
            try:
                raw = await asyncio.wait_for(self._queue.get(), timeout=1.0)
            except asyncio.TimeoutError:
                # dead-man / self-heal housekeeping
                await self._housekeeping()
                continue
            try:
                await self.handle(raw)
            except Exception as e:  # never crash the loop on one bad message
                await self._notify(f"handle error: {e!r}")
            await self._housekeeping()

    async def _housekeeping(self) -> None:
        try:
            if await self.pos_mgr.check_deadman():
                await self._notify("DEAD-MAN switch: flattened + halted (WS heartbeat loss)")
            await self.pos_mgr.self_heal()
        except Exception:
            pass

    async def handle(self, raw: RawSignal) -> TradeDecision:
        """Process one RawSignal through the full pipeline."""
        # Management messages -> routed to PositionManager, never ENTER.
        if raw.is_management and raw.management_action:
            await self._handle_management(raw)
            return TradeDecision(action="MANAGE", signal=None, leverage=0,
                                 size_coin=0.0, sl=None, tp=None,
                                 reason=f"mgmt:{raw.management_action}")

        g1 = self.validator.gate1(raw)
        if not g1.passed:
            return TradeDecision(action="IGNORE", signal=None, leverage=0,
                                 size_coin=0.0, sl=None, tp=None,
                                 reason=f"gate1: {g1.reason}")

        sig = await self.normalizer.normalize(raw)

        # Reflexivity: observe popularity, compute tilt (the actual edge, spec §14).
        sig_id = f"{sig.instrument.symbol}:{sig.side}:{int(raw.ts_ms or 0)}"
        rec = self.reflex.observe(sig_id)
        reflex_tilt = self.tilt.tilt(rec)
        if self.eval is not None:
            try:
                self.eval.signal_popularity(sig_id, raw.channel or "fattyfatclub",
                                            rec.first_seen_ms, rec.reaction_count,
                                            rec.price_impact_1s)
            except Exception:
                pass

        mark = self.market.mark_price(sig.instrument.symbol)
        decision = self.fast.decide(raw, sig, mark)
        decision.reflexivity_tilt = reflex_tilt

        if decision.action == "IGNORE" and "escalate" in decision.reason.lower():
            # LLM escalation path would go here; when absent it safely abstains.
            return decision

        if decision.action != "ENTER":
            return decision

        # Gate2 already passed in FastPath; apply reflexivity size tilt + paper gate.
        size = decision.size_coin * max(0.0, reflex_tilt) if reflex_tilt > 0 else decision.size_coin
        if reflex_tilt < 0:
            # counter-direction tilt: invert side (measured fade), keep small.
            inv_side: Literal["BUY", "SELL"] = opposite_side(sig.side)
            decision = TradeDecision(
                action="ENTER",
                signal=Signal(sig.instrument, inv_side, sig.entry,
                              sig.sl, sig.tp, sig.notional_usd,
                              sig.leverage, sig.confidence, sig.raw,
                              sig.source, sig.message_id, sig.ts_ms),
                leverage=decision.leverage, size_coin=size, sl=decision.sl,
                tp=decision.tp, reason="reflexivity counter-tilt",
                reflexivity_tilt=reflex_tilt)
            sig = decision.signal  # type: ignore[assignment]

        ok = await self._execute_entry(decision, sig)
        return decision if ok else TradeDecision(
            action="IGNORE", signal=sig, leverage=decision.leverage,
            size_coin=size, sl=decision.sl, tp=decision.tp,
            reason="entry execution failed (paper or order error)")

    async def _execute_entry(self, decision: TradeDecision, sig: Signal) -> bool:
        live = self._is_live()
        order = build_entry(decision, decision.sl, decision.tp, self.cfg.position_idx)
        if not live:
            # PAPER: never touch the exchange; record intent in the ledger as dry.
            await self._notify(
                f"[PAPER] would ENTER {sig.instrument.symbol} {sig.side} "
                f"qty={order.qty:.6f} sl={decision.sl} tp={decision.tp} "
                f"tilt={decision.reflexivity_tilt}")
            if self.ledger is not None:
                try:
                    self.ledger.write_signal(
                        int(time.time() * 1000), sig.instrument.symbol, sig.side,
                        sig.entry, sig.sl, sig.tp, sig.leverage, sig.confidence,
                        sig.raw.get("text", ""), "paper")
                except Exception:
                    pass
            return True

        # LIVE (only after go-live gate): set leverage, place order w/ attached SL/TP.
        try:
            await self.exchange.set_leverage(sig.instrument, decision.leverage)
            oid = await self.exchange.place_order(order)
            await self._notify(
                f"[LIVE] ENTER {sig.instrument.symbol} {sig.side} qty={order.qty:.6f} "
                f"orderId={oid} sl={decision.sl} tp={decision.tp}")
            if self.ledger is not None:
                self.ledger.write_signal(
                    int(time.time() * 1000), sig.instrument.symbol, sig.side,
                    sig.entry, sig.sl, sig.tp, sig.leverage, sig.confidence,
                    sig.raw.get("text", ""), "live")
            return bool(oid)
        except Exception as e:
            await self._notify(f"[LIVE] entry FAILED: {e!r}")
            return False

    # ---- management routing (spec §8, §13) ----
    async def _handle_management(self, raw: RawSignal) -> None:
        action = raw.management_action
        # Prefer the resolved symbol on the message; fall back to mgmt_symbol hint.
        sym = raw.symbol_usdt or (
            (raw.raw.get("mgmt_symbol") if isinstance(raw.raw, dict) else None))
        pos = self.pos_mgr.positions.get(sym) if sym else None
        await self._notify(f"[MGMT] {action} for {sym or '?'} (pos={'yes' if pos else 'no'})")
        if action == "sl_to_entry" and pos is not None:
            try:
                await self.exchange.set_trading_stop(
                    pos.instrument, sl=pos.entry_price, tp=None,
                    sl_trigger_by="MarkPrice", position_idx=self.cfg.position_idx)
            except Exception as e:
                await self._notify(f"[MGMT] sl_to_entry failed: {e!r}")
        elif action == "partial" and pos is not None:
            try:
                close = build_partial_close(pos.instrument, pos.size,
                                            self.cfg.position_idx)
                close.side = opposite_side(pos.side)
                await self.exchange.place_order(close)
                await self.exchange.set_trading_stop(
                    pos.instrument, sl=pos.entry_price, tp=None,
                    sl_trigger_by="MarkPrice", position_idx=
                    self.cfg.position_idx)
            except Exception as e:
                await self._notify(f"[MGMT] partial failed: {e!r}")
        elif action in ("full_close",) and pos is not None:
            try:
                close = build_full_close(pos.instrument, self.cfg.position_idx)
                close.side = opposite_side(pos.side)
                close.qty = pos.size
                await self.exchange.place_order(close)
            except Exception as e:
                await self._notify(f"[MGMT] full_close failed: {e!r}")
        elif action in ("tp_modify", "sl_modify") and pos is not None:
            price = raw.raw.get("mgmt_price") if isinstance(raw.raw, dict) else None
            if price is not None:
                try:
                    if action == "tp_modify":
                        await self.exchange.set_trading_stop(
                            pos.instrument, sl=None, tp=float(price),
                            sl_trigger_by="MarkPrice", position_idx=self.cfg.position_idx)
                    else:
                        await self.exchange.set_trading_stop(
                            pos.instrument, sl=float(price), tp=None,
                            sl_trigger_by="MarkPrice", position_idx=self.cfg.position_idx)
                except Exception as e:
                    await self._notify(f"[MGMT] {action} failed: {e!r}")

    # ---- close handler: fee-aware ledger write (BUG A/B contract) ----
    def _on_position_close(self, sym: str, entry: float, exit_px: float,
                           reason: str, liq_price: float | None) -> None:
        """Called by PositionManager on every close. Writes a FEE-AWARE trade row."""
        detail = self.pos_mgr.last_close
        if detail is None:
            return
        if self.ledger is not None:
            try:
                from src.store.ledger import TradeRow
                cid = uuid4().hex
                levy = int(detail.get("leverage", self.cfg.default_leverage))
                size = float(detail.get("size", 0.0))
                margin = (size * float(detail.get("entry", 0.0))) / levy if levy else 0.0
                row = TradeRow(
                    correlation_id=cid, bot_name=self.cfg.bot_name, symbol=sym,
                    side=detail.get("side", "BUY"), entry_price=float(entry),
                    exit_price=float(exit_px), sl_price=None, tp_price=None,
                    leverage=levy, size_coin=size, margin_usd=margin,
                    open_fee=float(detail.get("open_fee", 0.0)),
                    close_fee=float(detail.get("close_fee", 0.0)),
                    gross_usd=float(detail.get("gross", 0.0)),
                    net_usd=float(detail.get("net", 0.0)),
                    close_reason=reason, liq_price=liq_price,
                    opened_ts_ms=int(time.time() * 1000),
                    closed_ts_ms=int(time.time() * 1000),
                    reflexivity_tilt=0.0,
                )
                self.ledger.write_trade(row)
            except Exception as e:
                # never let a ledger error kill the loop; surface it
                asyncio.ensure_future(self._notify(f"[LEDGER] write failed: {e!r}"))
        # feed the learning loop (fee-adjusted outcome)
        if self.learning is not None:
            try:
                net = float(detail.get("net", 0.0))
                won = net > 0
                self.learning.record_close(net, won)
            except Exception:
                pass
        # shadow ledger / eval persistence for reflexivity measurement
        if self.eval is not None and liq_price is not None:
            try:
                self.eval.shadow_row(sym, detail.get("side", "BUY"), "crowd",
                                     0.0, float(detail.get("net", 0.0)),
                                     self.shadow.decay_score(sym))
            except Exception:
                pass

    async def stop(self) -> None:
        self._running = False
        try:
            await self.source.stop()
        except Exception:
            pass
        try:
            if hasattr(self.market, "stop"):
                await self.market.stop()
        except Exception:
            pass
