"""Bybit V5 WebSocket streams (spec §4.3, §4.5, §13, §15).

Two connections:
  * PRIVATE (wss://.../v5/private): auth via HMAC(GET/realtime+expires); subscribe
    ``order``, ``position``, ``wallet``, ``execution``.
  * PUBLIC  (wss://.../v5/public/linear): subscribe ``tickers.{SYM}``,
    ``orderbook.50.{SYM}``, ``publicTrade.{SYM}``, ``liquidation.{SYM}``.

Events are delivered to registered callbacks:
  * ``on_fill``    — real execution with execFee (BUG A: record it, never 0).
  * ``on_position``— position update; liquidation detected when size->0 with a liq
    marker / closedPnl; the REAL liqPrice is passed (BUG B: never book 0.00).
  * ``on_mark``    — markPrice (1-2s cadence fallback).
  * ``on_order``   — order status.
  * ``on_wallet``  — balance.
  * ``on_heartbeat`` — any WS message (dead-man's switch uses it).

All callbacks run off the event loop (async). The adapter exposes ``mark_price(sym)``
for the MarketStream port. TESTNET endpoints are forced when testnet=True (spec rule #1);
mainnet is never contacted in paper/testnet mode.

The connection is built but the LIVE testnet connection requires API keys (gate). Unit
tests use ``FakeBybitWS`` (scripts/bybit_ws_fake or streaming/fake) to drive callbacks.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import time
from dataclasses import dataclass
from typing import Awaitable, Callable

import websockets

from src.domain.model import Fill, Position
from src.interfaces.ports import MarketStream

FillHandler = Callable[[Fill], None]
PositionHandler = Callable[[Position], None]
OrderHandler = Callable[[dict], None]
WalletHandler = Callable[[float], None]
MarkHandler = Callable[[str, float], None]
HeartbeatHandler = Callable[[], None]


@dataclass
class WSConfig:
    api_key: str = ""
    api_secret: str = ""
    testnet: bool = True
    private_ws: str | None = None
    public_ws: str | None = None

    @property
    def private_url(self) -> str:
        if self.private_ws:
            return self.private_ws
        return ("wss://stream-testnet.bybit.com/v5/private" if self.testnet
                else "wss://stream.bybit.com/v5/private")

    @property
    def public_url(self) -> str:
        if self.public_ws:
            return self.public_ws
        return ("wss://stream-testnet.bybit.com/v5/public/linear" if self.testnet
                else "wss://stream.bybit.com/v5/public/linear")


def ws_signature(api_secret: str, expires: int) -> str:
    """V5 private WS signature: HMAC-SHA256(secret, 'GET/realtime' + expires)."""
    return hmac.new(api_secret.encode(), f"GET/realtime{expires}".encode(),
                    hashlib.sha256).hexdigest()


async def _maybe_await(handler, *args):
    """Call a handler that may be sync or async (tests use sync lambdas)."""
    result = handler(*args)
    if hasattr(result, "__await__"):
        await result


class BybitWS(MarketStream):
    def __init__(self, cfg: WSConfig, symbols: list[str] | None = None) -> None:
        self.cfg = cfg
        self.symbols = symbols or []
        self._priv_ws = None
        self._pub_ws = None
        self._marks: dict[str, float] = {}
        self._last_heartbeat = time.monotonic()
        # handlers
        self.on_fill: FillHandler | None = None
        self.on_position: PositionHandler | None = None
        self.on_order: OrderHandler | None = None
        self.on_wallet: WalletHandler | None = None
        self.on_mark: MarkHandler | None = None
        self.on_heartbeat: HeartbeatHandler | None = None
        self._running = False

    # ---- auth payload ----
    def _auth_payload(self) -> dict:
        expires = int(time.time() * 1000) + 5000
        sign = ws_signature(self.cfg.api_secret, expires)
        return {"op": "auth", "args": [self.cfg.api_key, expires, sign]}

    # ---- public subscribe topics ----
    def _public_topics(self) -> list[str]:
        topics: list[str] = []
        for s in self.symbols:
            topics += [f"tickers.{s}", f"orderbook.50.{s}",
                       f"publicTrade.{s}", f"liquidation.{s}"]
        return topics

    # ---- MarketStream port ----
    def mark_price(self, symbol: str) -> float | None:
        return self._marks.get(symbol)

    def set_mark(self, symbol: str, price: float) -> None:
        self._marks[symbol] = price

    @property
    def last_heartbeat_s(self) -> float:
        return time.monotonic() - self._last_heartbeat

    # ---- lifecycle (async) ----
    async def start(self) -> None:
        """Connect private + public, authenticate, subscribe. Requires keys (gate)."""
        self._running = True
        # private
        self._priv_ws = await websockets.connect(self.cfg.private_url)
        await self._priv_ws.send(json.dumps(self._auth_payload()))
        # wait for auth ack
        auth_ok = False
        async for msg in self._priv_ws:
            data = json.loads(msg)
            if data.get("op") == "auth" and data.get("success"):
                auth_ok = True
                break
        if not auth_ok:
            raise RuntimeError("Bybit WS auth failed")
        await self._priv_ws.send(
            json.dumps({"op": "subscribe", "args": ["order", "position", "wallet", "execution"]}))
        # public
        self._pub_ws = await websockets.connect(self.cfg.public_url)
        topics = self._public_topics()
        if topics:
            await self._pub_ws.send(json.dumps({"op": "subscribe", "args": topics}))
        # pump loops
        import asyncio
        asyncio.create_task(self._pump_private())
        asyncio.create_task(self._pump_public())

    async def _pump_private(self) -> None:
        assert self._priv_ws is not None
        async for msg in self._priv_ws:
            self._last_heartbeat = time.monotonic()
            if self.on_heartbeat:
                await self.on_heartbeat()
            await self._dispatch_private(json.loads(msg))

    async def _pump_public(self) -> None:
        assert self._pub_ws is not None
        async for msg in self._pub_ws:
            self._last_heartbeat = time.monotonic()
            if self.on_heartbeat:
                await self.on_heartbeat()
            await self._dispatch_public(json.loads(msg))

    # ---- dispatch ----
    async def _dispatch_private(self, data: dict) -> None:
        topic = data.get("topic")
        if topic == "execution" and self.on_fill:
            for f in data.get("data", []):
                fill = self._parse_fill(f)
                await _maybe_await(self.on_fill, fill)
        elif topic == "position" and self.on_position:
            for p in data.get("data", []):
                pos = self._parse_position(p)
                if pos is not None:
                    await _maybe_await(self.on_position, pos)
        elif topic == "order" and self.on_order:
            for o in data.get("data", []):
                await _maybe_await(self.on_order, o)
        elif topic == "wallet" and self.on_wallet:
            for w in data.get("data", []):
                for c in w.get("coin", []):
                    if c.get("coin") == "USDT":
                        await _maybe_await(self.on_wallet, float(c.get("availableBalance", 0)))

    async def _dispatch_public(self, data: dict) -> None:
        topic = data.get("topic", "")
        if topic.startswith("tickers."):
            sym = topic.split(".", 1)[1]
            ts = data.get("data", [{}])[0]
            mp = ts.get("markPrice")
            if mp is not None:
                self._marks[sym] = float(mp)
                if self.on_mark:
                    await _maybe_await(self.on_mark, sym, float(mp))

    # ---- parsers ----
    def _parse_fill(self, f: dict) -> Fill:
        # V5 execution: execFee, feeRate, execPrice, execQty, orderLinkId, closedPnl
        return Fill(
            order_link_id=f.get("orderLinkId", ""),
            price=float(f.get("execPrice", 0)),
            qty=float(f.get("execQty", 0)),
            side=f.get("side", ""),
            fee=float(f.get("execFee", 0)),        # REAL fee (BUG A)
            fee_asset=f.get("feeCurrency", "USDT"),
            ts_ms=int(f.get("execTime", "0")),
            is_reduce=bool(f.get("isClosed", False)),
            exec_type=f.get("execType", ""),
            order_id=f.get("orderId", ""),
            symbol=f.get("symbol", ""),
        )

    def _parse_position(self, p: dict) -> Position | None:
        from src.domain.model import Instrument
        size = float(p.get("size", 0))
        # liquidation: size -> 0 with liqPrice/closedPnl marker. We keep liq_price
        # populated so the position manager can book the REAL exit (BUG B).
        inst = Instrument.from_token(p.get("symbol", ""))
        return Position(
            instrument=inst,
            side="BUY" if p.get("side") == "Buy" else "SELL",
            size=size,
            entry_price=float(p.get("avgPrice", 0)),
            leverage=int(float(p.get("leverage", 1))),
            sl_price=float(p.get("stopLoss")) if p.get("stopLoss") not in (None, "") else None,
            tp_price=float(p.get("takeProfit")) if p.get("takeProfit") not in (None, "") else None,
            liq_price=float(p.get("liqPrice")) if p.get("liqPrice") not in (None, "") else None,
            unrealized_pnl=float(p.get("unrealisedPnl", 0)),
        )

    async def stop(self) -> None:
        self._running = False
        for ws in (self._priv_ws, self._pub_ws):
            if ws is not None:
                await ws.close()
