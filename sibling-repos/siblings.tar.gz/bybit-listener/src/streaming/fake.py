"""In-memory fake market stream placeholder (kept under streaming/ for symmetry
with the spec layout). The functional fake lives in src/exchanges/fake.py's
``FakeMarketStream``; this module re-exports it so ``from src.streaming.fake import
FakeMarketStream`` works in tests.
"""

from __future__ import annotations

from src.exchanges.fake import FakeMarketStream

__all__ = ["FakeMarketStream"]
