"""Offline WS event harness (spec Phase 4). Drives the BybitWS parsers/dispatch with
real Bybit-shaped JSON payloads so fill-fee + liquidation-price parsing are verified
without a live socket. The LIVE testnet connection itself is gated on API keys.
"""

from __future__ import annotations

import asyncio

from src.domain.model import Fill, Position
from src.streaming.bybit_ws import BybitWS, WSConfig


class FakeBybitWS(BybitWS):
    """Subclass that skips the network connect() and lets tests inject messages."""

    def __init__(self, cfg: WSConfig | None = None, symbols: list[str] | None = None) -> None:
        super().__init__(cfg or WSConfig(), symbols)
        self.fills: list[Fill] = []
        self.positions: list[Position] = []
        self.orders: list[dict] = []
        self.wallets: list[float] = []
        self.marks: list[tuple[str, float]] = []
        self.heartbeats = 0
        self.on_fill = lambda f: self.fills.append(f)
        self.on_position = lambda p: self.positions.append(p)
        self.on_order = lambda o: self.orders.append(o)
        self.on_wallet = lambda w: self.wallets.append(w)
        self.on_mark = lambda s, p: self.marks.append((s, p))
        self.on_heartbeat = lambda: None

    async def start(self) -> None:  # override: no network
        self._running = True

    async def inject_private(self, data: dict) -> None:
        await self._dispatch_private(data)

    async def inject_public(self, data: dict) -> None:
        await self._dispatch_public(data)
