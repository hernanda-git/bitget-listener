"""Fee-aware durable ledger (spec §7) — Postgres `fatty_config`.

Reuses the Sera `fatty_config` DB (single driver: psycopg). The bybit bot's ledger is
FEE-AWARE (closes BUG A + BUG B):
  * trades_log: open_fee, close_fee, gross_usd, net_usd (net = gross - fees),
    exit_price REAL, liq_price (non-null only on liquidation, never 0.00).

SCHEMA RECONCILIATION (spec §7: "migrations safe, try/except ALTER"): the existing
`fatty_config` on Sera was created by the hyperliquid-fatty-trader fork and has an
OLDER `trades_log` shape (columns `bot`, `pnl`, `exit_px`, `dry`, ...). We do NOT assume
the spec's §7 columns exist. `_ensure_schema` CREATEs the table only if absent, then
ALTER-adds every fee-aware column (try/except per column, idempotent). `write_trade`
writes to BOTH the spec columns and the fork-legacy columns (bot=bot_name, pnl=net_usd,
exit_px=exit_price, ...) so the bybit trades are queryable from the existing dashboard
too. This is the DB analog of "testnet is the arbiter" — we verify against the real
schema and migrate, never hack around it.

Secrets are NEVER stored here. Reads CONFIG_DB_TEST_URL (tests) else CONFIG_DB_URL.
One fresh connection per write (asyncio safe). No-op (in-memory) when no URL is set.
"""

from __future__ import annotations

import os
from dataclasses import dataclass

DEFAULT_DB_URL = "postgresql://app:***@127.0.0.1:5432/fatty_config"

# Fee-aware columns this bot REQUIRES (spec §7). Added via ALTER if missing.
_TRADES_FEE_COLUMNS = [
    ("correlation_id", "TEXT"),
    ("bot_name", "TEXT"),
    ("exit_price", "NUMERIC"),
    ("open_fee", "NUMERIC NOT NULL DEFAULT 0"),
    ("close_fee", "NUMERIC NOT NULL DEFAULT 0"),
    ("gross_usd", "NUMERIC"),
    ("net_usd", "NUMERIC"),
    ("liq_price", "NUMERIC"),
    ("opened_ts_ms", "BIGINT"),
    ("closed_ts_ms", "BIGINT"),
    ("reflexivity_tilt", "NUMERIC"),
]

_SCHEMA = """
CREATE TABLE IF NOT EXISTS signals_log (
    id BIGSERIAL PRIMARY KEY, ts_ms BIGINT, symbol TEXT, side TEXT,
    entry NUMERIC, sl NUMERIC, tp NUMERIC, leverage INT, confidence NUMERIC,
    raw_text TEXT, status TEXT
);

CREATE TABLE IF NOT EXISTS trades_log (
    id BIGSERIAL PRIMARY KEY,
    correlation_id TEXT, bot_name TEXT, symbol TEXT, side TEXT,
    entry_price NUMERIC, exit_price NUMERIC,
    sl_price NUMERIC, tp_price NUMERIC, leverage INT,
    size_coin NUMERIC, margin_usd NUMERIC,
    open_fee NUMERIC NOT NULL DEFAULT 0,
    close_fee NUMERIC NOT NULL DEFAULT 0,
    gross_usd NUMERIC, net_usd NUMERIC,
    close_reason TEXT,
    liq_price NUMERIC,
    opened_ts_ms BIGINT, closed_ts_ms BIGINT,
    reflexivity_tilt NUMERIC
);

CREATE TABLE IF NOT EXISTS bias_log (
    id BIGSERIAL PRIMARY KEY, ts_ms BIGINT, source TEXT, bias TEXT,
    symbol TEXT, note TEXT
);
"""


@dataclass
class TradeRow:
    correlation_id: str
    bot_name: str
    symbol: str
    side: str
    entry_price: float
    exit_price: float
    sl_price: float | None
    tp_price: float | None
    leverage: int
    size_coin: float
    margin_usd: float
    open_fee: float
    close_fee: float
    gross_usd: float
    net_usd: float
    close_reason: str
    liq_price: float | None = None
    opened_ts_ms: int = 0
    closed_ts_ms: int = 0
    reflexivity_tilt: float = 0.0

    @property
    def fee_aware(self) -> bool:
        # The contract: net = gross - (open + close). Asserted on write.
        return abs(self.net_usd - (self.gross_usd - self.open_fee - self.close_fee)) < 1e-9


class Ledger:
    def __init__(self, db_url: str | None = None) -> None:
        self.db_url = db_url or os.getenv("CONFIG_DB_TEST_URL") or os.getenv("CONFIG_DB_URL", "")
        self._enabled = bool(self.db_url)
        if self._enabled:
            self._ensure_schema()

    def _conn(self):
        import psycopg
        return psycopg.connect(self.db_url, connect_timeout=10, autocommit=False)

    def _ensure_schema(self) -> None:
        with self._conn() as c:
            c.execute(_SCHEMA)
            # Migrate the existing fork trades_log to be fee-aware (spec §7 safe ALTER).
            existing = {r[0] for r in c.execute(
                "SELECT column_name FROM information_schema.columns "
                "WHERE table_name='trades_log'").fetchall()}
            for col, typ in _TRADES_FEE_COLUMNS:
                if col not in existing:
                    try:
                        c.execute(f"ALTER TABLE trades_log ADD COLUMN {col} {typ}")
                    except Exception:
                        # already added concurrently or type conflict — non-fatal
                        pass
            c.commit()

    def write_signal(self, ts_ms: int, symbol: str, side: str, entry, sl, tp,
                     leverage: int, confidence: float, raw_text: str, status: str) -> None:
        if not self._enabled:
            return
        with self._conn() as c:
            c.execute(
                "INSERT INTO signals_log (ts_ms, symbol, side, entry, sl, tp, leverage, "
                "confidence, raw_text, status) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",
                (ts_ms, symbol, side, entry, sl, tp, leverage, confidence, raw_text, status),
            )
            c.commit()

    def write_trade(self, row: TradeRow) -> None:
        """Persist a fee-aware trade close. Asserts net = gross - fees (BUG A/B contract)."""
        if not self._enabled:
            return
        assert row.fee_aware, "Ledger invariant broken: net_usd != gross - open - close"
        with self._conn() as c:
            cols = {r[0] for r in c.execute(
                "SELECT column_name FROM information_schema.columns "
                "WHERE table_name='trades_log'").fetchall()}
            # Spec columns (always present after migration).
            spec_cols = ["correlation_id", "bot_name", "symbol", "side", "entry_price",
                         "exit_price", "sl_price", "tp_price", "leverage", "size_coin",
                         "margin_usd", "open_fee", "close_fee", "gross_usd", "net_usd",
                         "close_reason", "liq_price", "opened_ts_ms", "closed_ts_ms",
                         "reflexivity_tilt"]
            spec_vals = [row.correlation_id, row.bot_name, row.symbol, row.side,
                        row.entry_price, row.exit_price, row.sl_price, row.tp_price,
                        row.leverage, row.size_coin, row.margin_usd, row.open_fee,
                        row.close_fee, row.gross_usd, row.net_usd, row.close_reason,
                        row.liq_price, row.opened_ts_ms, row.closed_ts_ms,
                        row.reflexivity_tilt]
            # Fork-legacy compat columns (if this is the shared fatty_config table).
            legacy_map = {
                "bot": row.bot_name, "exit_px": row.exit_price, "pnl": row.net_usd,
                "sl": row.sl_price, "tp": row.tp_price, "lev": row.leverage,
                "size": row.size_coin, "margin": row.margin_usd,
                "ts_open": row.opened_ts_ms, "ts_close": row.closed_ts_ms,
                "iso_open": "", "iso_close": "",
            }
            # Build the INSERT over every present column (spec + legacy) so NOT NULL
            # legacy columns (ts_open, ts_close, bot, ...) are satisfied in one statement.
            present: list[str] = []
            vals: list = []
            for c2 in spec_cols:
                if c2 in cols:
                    present.append(c2)
                    vals.append(spec_vals[spec_cols.index(c2)])
            for lcol, lval in legacy_map.items():
                if lcol in cols and lcol not in present:
                    present.append(lcol)
                    vals.append(lval)
            placeholders = ", ".join("%s" for _ in present)
            c.execute(
                f"INSERT INTO trades_log ({', '.join(present)}) VALUES ({placeholders})",
                vals,
            )
            c.commit()

    def write_bias(self, ts_ms: int, source: str, bias: str, symbol: str, note: str) -> None:
        if not self._enabled:
            return
        with self._conn() as c:
            c.execute(
                "INSERT INTO bias_log (ts_ms, source, bias, symbol, note) "
                "VALUES (%s,%s,%s,%s,%s)",
                (ts_ms, source, bias, symbol, note),
            )
            c.commit()

    def recent_trades(self, limit: int = 20) -> list[dict]:
        if not self._enabled:
            return []
        want = ["symbol", "side", "entry_price", "exit_price", "open_fee", "close_fee",
                "net_usd", "close_reason", "liq_price"]
        with self._conn() as c:
            cols = {r[0] for r in c.execute(
                "SELECT column_name FROM information_schema.columns "
                "WHERE table_name='trades_log'").fetchall()}
            present = [w for w in want if w in cols]
            # fallback label mapping for fork-legacy column names
            select = ", ".join(present) if present else "*"
            rows = c.execute(
                f"SELECT {select} FROM trades_log ORDER BY id DESC LIMIT %s",
                (limit,),
            ).fetchall()
        cols_out = present if present else []
        if not cols_out and rows:
            cols_out = [f"col{i}" for i in range(len(rows[0]))]
        return [dict(zip(cols_out, r)) for r in rows]
