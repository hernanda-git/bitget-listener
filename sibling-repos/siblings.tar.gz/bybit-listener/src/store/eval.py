"""Evaluation layer writer (spec §7, §14, §15) — Postgres `fatty_config`.

Persists the measured edge so it is queryable from outside the box:
  * equity_snapshots(ts_ms, bot_name, equity_usd, open_positions)
  * signal_popularity(signal_id, channel, first_seen_ms, reaction_count, price_impact_1s)
  * shadow_ledger(signal_id, entry_side, crowd_direction, price_impact_5s, outcome_net_usd, decay_score)
  * param_log(ts_ms, bot_name, leverage_cap, size_pct, reflexivity_tilt, expectancy_net_usd)
  * strategy_perf(window, trades, win_rate, net_usd, fee_usd, regime)
  * orderbook_features(ts_ms, symbol, imbalance, cvd, funding_rate)

Reuses `fatty_config` (single driver psycopg). The bybit bot creates these tables if
absent (migration-safe; the existing fork DB has no eval tables yet, so CREATE IF NOT
EXISTS is sufficient). No secrets stored. Reads CONFIG_DB_TEST_URL (tests) else
CONFIG_DB_URL; no-op when unset.
"""

from __future__ import annotations

import os


class EvalWriter:
    def __init__(self, db_url: str | None = None) -> None:
        self.db_url = db_url or os.getenv("CONFIG_DB_TEST_URL") or os.getenv("CONFIG_DB_URL", "")
        self._enabled = bool(self.db_url)
        if self._enabled:
            self._ensure_schema()

    def _conn(self):
        import psycopg
        return psycopg.connect(self.db_url, connect_timeout=10, autocommit=False)

    def _ensure_schema(self) -> None:
        with self._conn() as c:
            c.execute("""
                CREATE TABLE IF NOT EXISTS equity_snapshots (
                    ts_ms BIGINT, bot_name TEXT, equity_usd NUMERIC, open_positions INT
                );
                CREATE TABLE IF NOT EXISTS signal_popularity (
                    signal_id TEXT, channel TEXT, first_seen_ms BIGINT,
                    reaction_count INT, price_impact_1s NUMERIC
                );
                CREATE TABLE IF NOT EXISTS shadow_ledger (
                    signal_id TEXT, entry_side TEXT, crowd_direction TEXT,
                    price_impact_5s NUMERIC, outcome_net_usd NUMERIC, decay_score NUMERIC
                );
                CREATE TABLE IF NOT EXISTS param_log (
                    ts_ms BIGINT, bot_name TEXT, leverage_cap INT, size_pct NUMERIC,
                    reflexivity_tilt NUMERIC, expectancy_net_usd NUMERIC
                );
                CREATE TABLE IF NOT EXISTS strategy_perf (
                    window_label TEXT, trades INT, win_rate NUMERIC, net_usd NUMERIC,
                    fee_usd NUMERIC, regime TEXT
                );
                CREATE TABLE IF NOT EXISTS orderbook_features (
                    ts_ms BIGINT, symbol TEXT, imbalance NUMERIC, cvd NUMERIC, funding_rate NUMERIC
                );
            """)
            c.commit()

    def equity_snapshot(self, ts_ms: int, bot_name: str, equity_usd: float, open_positions: int) -> None:
        if not self._enabled:
            return
        with self._conn() as c:
            c.execute("INSERT INTO equity_snapshots (ts_ms, bot_name, equity_usd, open_positions) "
                      "VALUES (%s,%s,%s,%s)", (ts_ms, bot_name, equity_usd, open_positions))
            c.commit()

    def signal_popularity(self, signal_id: str, channel: str, first_seen_ms: int,
                          reaction_count: int, price_impact_1s: float) -> None:
        if not self._enabled:
            return
        with self._conn() as c:
            c.execute("INSERT INTO signal_popularity (signal_id, channel, first_seen_ms, "
                      "reaction_count, price_impact_1s) VALUES (%s,%s,%s,%s,%s)",
                      (signal_id, channel, first_seen_ms, reaction_count, price_impact_1s))
            c.commit()

    def shadow_row(self, signal_id: str, entry_side: str, crowd_direction: str,
                   price_impact_5s: float, outcome_net_usd: float, decay_score: float) -> None:
        if not self._enabled:
            return
        with self._conn() as c:
            c.execute("INSERT INTO shadow_ledger (signal_id, entry_side, crowd_direction, "
                      "price_impact_5s, outcome_net_usd, decay_score) VALUES (%s,%s,%s,%s,%s,%s)",
                      (signal_id, entry_side, crowd_direction, price_impact_5s,
                       outcome_net_usd, decay_score))
            c.commit()

    def param_log(self, ts_ms: int, bot_name: str, leverage_cap: int, size_pct: float,
                  reflexivity_tilt: float, expectancy_net_usd: float) -> None:
        if not self._enabled:
            return
        with self._conn() as c:
            c.execute("INSERT INTO param_log (ts_ms, bot_name, leverage_cap, size_pct, "
                      "reflexivity_tilt, expectancy_net_usd) VALUES (%s,%s,%s,%s,%s,%s)",
                      (ts_ms, bot_name, leverage_cap, size_pct, reflexivity_tilt, expectancy_net_usd))
            c.commit()

    def strategy_perf(self, window: str, trades: int, win_rate: float, net_usd: float,
                      fee_usd: float, regime: str) -> None:
        if not self._enabled:
            return
        with self._conn() as c:
            c.execute("INSERT INTO strategy_perf (window_label, trades, win_rate, net_usd, "
                      "fee_usd, regime) VALUES (%s,%s,%s,%s,%s,%s)",
                      (window, trades, win_rate, net_usd, fee_usd, regime))
            c.commit()

    def orderbook_features(self, ts_ms: int, symbol: str, imbalance: float,
                           cvd: float, funding_rate: float) -> None:
        if not self._enabled:
            return
        with self._conn() as c:
            c.execute("INSERT INTO orderbook_features (ts_ms, symbol, imbalance, cvd, "
                      "funding_rate) VALUES (%s,%s,%s,%s,%s)",
                      (ts_ms, symbol, imbalance, cvd, funding_rate))
            c.commit()
