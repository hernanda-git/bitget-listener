"""Per-pair min-notional floors cache (spec §4.8, §10).

Bybit enforces a per-symbol `minNotionalValue`. The order/validator gate checks
`qty * price >= minNotionalValue`. This cache is fed from the Bybit adapter's
instruments-info so the floor is REAL (testnet is the arbiter), not assumed.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class MinNotionalCache:
    floors: dict[str, float] = None  # symbol -> minNotionalValue (USD)

    def __post_init__(self) -> None:
        if self.floors is None:
            self.floors = {}

    def update(self, symbol: str, min_notional: float) -> None:
        self.floors[symbol] = min_notional

    def floor(self, symbol: str) -> float:
        return self.floors.get(symbol, 1.0)  # Bybit default $1

    def meets(self, symbol: str, qty: float, price: float) -> bool:
        return (qty * price) >= self.floor(symbol)
