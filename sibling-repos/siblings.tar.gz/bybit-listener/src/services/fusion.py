"""Independent signal fusion features (spec §15) — pure calculators.

Given public WS data (orderbook, publicTrade, tickers funding), compute:
  * orderbook imbalance: bid_vol / (bid_vol + ask_vol) - 0.5  (range ~[-0.5, 0.5])
  * CVD: cumulative volume delta from publicTrade (buy vol - sell vol)
  * funding_rate: from tickers (passed through; crowded positioning signal)

These fuse with the Telegram crowd signal; LLM only when they disagree (handled by the
orchestrator). Pure math, unit-testable, no network.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class MicroFeatures:
    symbol: str
    imbalance: float = 0.0     # orderbook imbalance in [-0.5, 0.5]
    cvd: float = 0.0           # cumulative volume delta
    funding_rate: float = 0.0


def orderbook_imbalance(bid_vol: float, ask_vol: float) -> float:
    total = bid_vol + ask_vol
    if total <= 0:
        return 0.0
    return bid_vol / total - 0.5


def cvd_update(prev_cvd: float, buy_vol: float, sell_vol: float) -> float:
    return prev_cvd + (buy_vol - sell_vol)


def fuse_tilt(imbalance: float, funding_rate: float) -> float:
    """A simple fusion tilt: positive imbalance + positive funding -> crowded long ->
    mild fade signal. Returns a tilt in [-1, 1] (positive = bullish micro bias)."""
    # normalize funding (typical ~ -0.001..0.001) to [-0.5, 0.5]
    fund = max(-0.5, min(0.5, funding_rate * 500.0))
    return max(-1.0, min(1.0, imbalance + fund))
