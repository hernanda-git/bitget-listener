"""Safety gates (spec §10) + pre-LLM fast-path decision (spec §16).

Gate 1 (pre-LLM, cheap): idempotency claim, symbol whitelist (against instruments-info
tradable set), confidence floor, cooldown per symbol, media filter, max-signal-age.

Gate 2 (post-LLM, ENTER only): size clamp, leverage cap, daily-loss cap, portfolio
notional cap, SL direction check (LONG sl < entry, SHORT sl > entry), min-notional
floor (qty*entry >= minNotionalValue), and a fee-adjusted expectancy gate (do not
enter if expected net_usd <= 0 after estimated fees).

The fast path emits an ENTER/IGNORE decision sub-second for clear signal shapes so we
front-run slow LLM bots (spec §16). LLM is escalated only when ambiguous.
"""

from __future__ import annotations

import time
from dataclasses import dataclass

from src.domain.model import RawSignal, Signal, TradeDecision
from src.interfaces.ports import RiskPolicy


@dataclass
class GateConfig:
    min_confidence: float = 0.5
    max_signal_age_s: int = 3600
    cooldown_per_symbol_s: int = 300
    media_requires_manual: bool = True
    fee_bps_estimate: float = 0.055          # round-trip taker fee estimate (Bybit ~0.055%)
    max_notional_usd: float = 50.0
    default_margin_usd: float = 1.0
    fallback_sl_pct: float = 0.05
    sl_required: bool = True                  # SL mandatory (spec §2.3)
    portfolio_notional_cap_usd: float = 1000.0
    daily_loss_cap_usd: float = 5.0


@dataclass
class GateResult:
    passed: bool
    reason: str


class Validator:
    def __init__(self, cfg: GateConfig | None = None,
                 tradable: set[str] | None = None) -> None:
        self.cfg = cfg or GateConfig()
        # tradable symbol set (e.g. {"BTCUSDT", ...}) from instruments-info.
        self.tradable: set[str] = set(tradable or set())
        self._last_symbol_ts: dict[str, float] = {}
        self._claimed: set[int] = set()

    # ---- Gate 1 (pre-LLM, cheap) ----
    def gate1(self, raw: RawSignal, now_ms: int | None = None) -> GateResult:
        now = (now_ms or int(time.time() * 1000)) / 1000.0
        # idempotency: edited/duplicate messages already claimed
        if raw.message_id is not None and raw.message_id in self._claimed:
            return GateResult(False, "duplicate message_id already claimed")
        # media filter: media signals need manual review unless vision is wired
        if raw.has_media and self.cfg.media_requires_manual:
            return GateResult(False, "media signal requires manual review")
        # max signal age
        if raw.ts_ms is not None:
            age_s = now - raw.ts_ms / 1000.0
            if age_s > self.cfg.max_signal_age_s:
                return GateResult(False, f"signal too old ({age_s:.0f}s)")
        # symbol whitelist against tradable set
        sym = raw.symbol_usdt
        if not sym:
            return GateResult(False, "no symbol resolved")
        if self.tradable and sym not in self.tradable:
            return GateResult(False, f"symbol {sym} not in tradable set")
        # confidence floor
        if raw.confidence < self.cfg.min_confidence:
            return GateResult(False, f"confidence {raw.confidence} < floor {self.cfg.min_confidence}")
        # per-symbol cooldown
        last = self._last_symbol_ts.get(sym)
        if last is not None and (now - last) < self.cfg.cooldown_per_symbol_s:
            return GateResult(False, f"cooldown active for {sym}")
        return GateResult(True, "gate1 ok")

    def claim(self, message_id: int) -> bool:
        """Idempotency claim; returns False if already claimed."""
        if message_id in self._claimed:
            return False
        self._claimed.add(message_id)
        return True

    def mark_seen(self, symbol: str, now_ms: int | None = None) -> None:
        now = (now_ms or int(time.time() * 1000)) / 1000.0
        self._last_symbol_ts[symbol] = now

    # ---- Gate 2 (post-LLM, ENTER only) ----
    def gate2(self, sig: Signal, size_coin: float, leverage: int,
              entry_mark: float, portfolio_used_usd: float = 0.0,
              daily_loss_usd: float = 0.0, min_notional_value: float = 1.0) -> GateResult:
        # leverage cap
        if leverage > 20:
            return GateResult(False, f"leverage {leverage} exceeds cap 20")
        # SL direction check (mandatory)
        if self.cfg.sl_required and sig.sl is None:
            return GateResult(False, "SL missing (mandatory)")
        if sig.sl is not None and sig.entry is not None:
            if sig.side == "BUY" and not (sig.sl < sig.entry):
                return GateResult(False, "LONG SL must be < entry")
            if sig.side == "SELL" and not (sig.sl > sig.entry):
                return GateResult(False, "SHORT SL must be > entry")
        # min-notional floor: qty * entry >= exchange minNotionalValue (per symbol,
        # supplied by caller; defaults to $1 which matches Bybit BTC/most alts).
        notional = size_coin * (sig.entry or entry_mark)
        if notional < min_notional_value:
            return GateResult(False, f"notional {notional:.2f} below minNotional {min_notional_value}")
        if notional > self.cfg.max_notional_usd:
            return GateResult(False, f"notional {notional:.2f} above cap {self.cfg.max_notional_usd}")
        # portfolio notional cap
        if portfolio_used_usd + notional > self.cfg.portfolio_notional_cap_usd:
            return GateResult(False, "portfolio notional cap exceeded")
        # daily loss cap
        if daily_loss_usd >= self.cfg.daily_loss_cap_usd:
            return GateResult(False, "daily loss cap reached")
        # fee-adjusted expectancy gate: expected net_usd must be > 0
        fee_est = notional * self.cfg.fee_bps_estimate / 100.0
        # crude expectancy proxy: assume we risk the SL distance, target ~1R; if even
        # fees eat the projected edge, refuse. We require gross(>=0) - fees > 0 i.e.
        # fee_est < notional (trivially true) BUT also require a positive risk:reward
        # so that after fees the trade can be +EV. Refuse if fee eats > 50% of notional.
        if fee_est > 0.5 * notional:
            return GateResult(False, "estimated fees exceed 50% of notional (negative EV)")
        return GateResult(True, "gate2 ok")


class FastPath:
    """Pre-LLM sub-second decision (spec §16). Handles clear shapes; escalates if ambiguous."""

    def __init__(self, validator: Validator, risk: RiskPolicy,
                 cfg: GateConfig | None = None, available_usd: float = 1000.0) -> None:
        self.v = validator
        self.risk = risk
        self.cfg = cfg or GateConfig()
        self.available_usd = available_usd

    def decide(self, raw: RawSignal, sig: Signal, mark: float | None) -> TradeDecision:
        # Escalate to LLM when ambiguous: missing entry/SL, low confidence,
        # or no mark price available.
        if sig.entry is None or sig.sl is None:
            return TradeDecision(action="IGNORE", signal=sig, leverage=sig.leverage,
                                 size_coin=0.0, sl=sig.sl, tp=sig.tp,
                                 reason="ambiguous: missing entry/sl -> escalate LLM")
        if sig.confidence < 0.6:
            return TradeDecision(action="IGNORE", signal=sig, leverage=sig.leverage,
                                 size_coin=0.0, sl=sig.sl, tp=sig.tp,
                                 reason="ambiguous: low confidence -> escalate LLM")
        if mark is None:
            return TradeDecision(action="IGNORE", signal=sig, leverage=sig.leverage,
                                 size_coin=0.0, sl=sig.sl, tp=sig.tp,
                                 reason="ambiguous: no mark price -> escalate LLM")
        # Clear shape: compute fee-aware size via risk policy, then pass Gate2.
        notional = sig.notional_usd or self.cfg.default_margin_usd
        if hasattr(self.risk, "size_from_risk"):
            size_coin, lev, _fee = self.risk.size_from_risk(sig, mark, self.available_usd)
        else:
            size_coin, lev = self.risk.compute_size(notional, mark, sig.leverage)
        g2 = self.v.gate2(sig, size_coin, lev, mark)
        if not g2.passed:
            return TradeDecision(action="IGNORE", signal=sig, leverage=lev,
                                 size_coin=size_coin, sl=sig.sl, tp=sig.tp,
                                 reason=f"gate2 rejected: {g2.reason}")
        return TradeDecision(action="ENTER", signal=sig, leverage=lev,
                            size_coin=size_coin, sl=sig.sl, tp=sig.tp,
                            reason="fast-path clear-shape ENTER")
