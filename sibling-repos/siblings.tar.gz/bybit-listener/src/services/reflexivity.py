"""Reflexivity guard + counter-trade tilt + shadow ledger (spec §14).

This is the edge both parents documented but never implemented. We make it REAL and
MEASURED:
  * SignalPopularity: per signal, track first_seen_ms, reaction_count, price_impact_1s.
  * CounterTradeTilt: a "crowded" signal (high reaction density) likely reflects
    liquidity-driven flow, not information -> tilt to fade (half size) or counter side.
    Emits `reflexivity_tilt` (e.g. 0.5 = half size) or -1.0 = counter-direction.
  * ShadowLedger: record signal -> price-impact over N rows, compute decay_score, rotate
    the tilt when the counter-edge decays.

All state is in-memory for the hot path; persistence goes through store/eval.EvalWriter
so it is queryable from outside the box (spec §7 eval layer). No network here.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field


@dataclass
class ReflexivityConfig:
    popularity_threshold: int = 5     # reaction count to consider a signal "crowded"
    fade_tilt: float = 0.5            # size multiplier when crowded (0.5 = half size)
    counter_edge_decay: float = 0.85  # decay applied to tilt effectiveness each window
    impact_window_s: float = 1.0      # price_impact measurement window


@dataclass
class PopularityRecord:
    signal_id: str
    first_seen_ms: int
    reaction_count: int = 0
    price_impact_1s: float = 0.0
    last_seen_ms: int = 0


class SignalPopularity:
    def __init__(self, cfg: ReflexivityConfig | None = None) -> None:
        self.cfg = cfg or ReflexivityConfig()
        self._recs: dict[str, PopularityRecord] = {}

    def observe(self, signal_id: str, price_impact: float = 0.0,
                ts_ms: int | None = None) -> PopularityRecord:
        now = ts_ms or int(time.time() * 1000)
        rec = self._recs.get(signal_id)
        if rec is None:
            rec = PopularityRecord(signal_id=signal_id, first_seen_ms=now, last_seen_ms=now)
            self._recs[signal_id] = rec
        rec.reaction_count += 1
        rec.last_seen_ms = now
        rec.price_impact_1s = (rec.price_impact_1s * 0.5) + (price_impact * 0.5)
        return rec

    def is_crowded(self, signal_id: str) -> bool:
        rec = self._recs.get(signal_id)
        return rec is not None and rec.reaction_count >= self.cfg.popularity_threshold


class CounterTradeTilt:
    """Maps popularity -> a size/direction tilt. Measured, not assumed."""

    def __init__(self, cfg: ReflexivityConfig | None = None) -> None:
        self.cfg = cfg or ReflexivityConfig()
        self._decay: dict[str, float] = {}

    def tilt(self, rec: PopularityRecord) -> float:
        """Return reflexivity_tilt for a decision.

        1.0 = full size as signaled; 0.5 = half size (fade); -1.0 = counter-direction.
        Crowded + positive impact -> fade (reduce size). Crowded with decaying edge ->
        rotate toward counter-direction.
        """
        if rec.reaction_count < self.cfg.popularity_threshold:
            return 1.0
        edge = self._decay.get(rec.signal_id, 1.0)
        if rec.price_impact_1s > 0:
            tilt = self.cfg.fade_tilt * edge
        else:
            tilt = -1.0 * edge
        self._decay[rec.signal_id] = max(0.1, edge * self.cfg.counter_edge_decay)
        return tilt

    def rotate(self, signal_id: str) -> None:
        """Explicitly rotate the tilt (counter-edge decayed)."""
        self._decay[signal_id] = max(0.1, self._decay.get(signal_id, 1.0) * self.cfg.counter_edge_decay)


@dataclass
class ShadowLedgerRow:
    signal_id: str
    entry_side: str
    crowd_direction: str
    price_impact_5s: float
    outcome_net_usd: float
    decay_score: float


class ShadowLedger:
    """Records signal->price-impact outcomes and computes decay_score over N rows."""

    def __init__(self, window: int = 20) -> None:
        self.window = window
        self._rows: list[ShadowLedgerRow] = []

    def record(self, row: ShadowLedgerRow) -> None:
        self._rows.append(row)
        if len(self._rows) > self.window:
            self._rows.pop(0)

    def decay_score(self, signal_id: str) -> float:
        rel = [r for r in self._rows if r.signal_id == signal_id]
        if not rel:
            return 0.0
        avg = sum(r.outcome_net_usd for r in rel) / len(rel)
        return max(-1.0, min(1.0, avg / max(1.0, abs(avg) + 1e-9) * 10.0))
