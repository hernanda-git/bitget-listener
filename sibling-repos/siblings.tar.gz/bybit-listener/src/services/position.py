"""Position manager — local state machine WS-synced (spec §13).

Consumes real-time fills + position updates from the exchange stream and keeps a local
`Position` per symbol. Responsibilities:
  * Record every Fill with its REAL execFee into the PnL book (BUG A). net_usd is
    gross_usd - (open_fee + close_fee).
  * On liquidation (position size -> 0 with liqPrice/closedPnl) book the exit at the
    REALIZED liquidation price (liq_price or the fill's execPrice) — NEVER 0.00 (BUG B).
  * Real-time stops: markPrice from WS (1-2s); self-heal re-attaches missing SL/TP via
    set-trading-stop (60s cooldown) and NEVER cancels reduce_only protective orders.
  * Dead-man's switch: if no WS message for `deadman_seconds`, flatten via cancel-all
    + halt new orders + notify.

The manager is pure logic over injected ports + a `LedgerWriter` callback so it is
unit-testable with FakeExchangeAdapter / FakeMarketStream (no network).
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Callable

from src.domain.model import Fill, Instrument, Position, TradeDecision
from src.interfaces.ports import ExchangeAdapter, MarketStream
from src.services.order import opposite_side

# callback sink for trade lifecycle events (the ledger/notifier subscribe to this)
PositionClosed = Callable[[str, float, float, str, float | None], None]  # sym, entry, exit, reason, liq_price


@dataclass
class PositionManagerConfig:
    deadman_seconds: float = 30.0
    self_heal_cooldown_s: float = 60.0
    sl_trigger_by: str = "MarkPrice"


class PositionManager:
    def __init__(self, exchange: ExchangeAdapter, market: MarketStream,
                 cfg: PositionManagerConfig | None = None,
                 on_close: PositionClosed | None = None) -> None:
        self.ex = exchange
        self.market = market
        self.cfg = cfg or PositionManagerConfig()
        self.on_close = on_close
        self.positions: dict[str, Position] = {}
        self._open_fee: dict[str, float] = {}
        self._close_fee: dict[str, float] = {}
        self._last_heal: dict[str, float] = {}
        self._last_ws = time.monotonic()
        self.halted = False
        self._liquidation_log: list[dict] = []
        # Full close detail, set on every _book_close, so the orchestrator's on_close
        # handler can build a fee-aware TradeRow for the ledger (BUG A/B contract).
        self.last_close: dict | None = None

    def heartbeat(self) -> None:
        self._last_ws = time.monotonic()

    def seconds_since_ws(self) -> float:
        return time.monotonic() - self._last_ws

    # ---- WS event handlers (called by the streaming layer) ----
    async def on_fill(self, fill: Fill) -> None:
        """Record a real fill with its fee; update local position size/fees."""
        self._last_ws = time.monotonic()
        sym = fill.symbol or self._sym_of(fill)
        if not sym:
            return
        pos = self.positions.get(sym)
        qty = fill.qty
        if fill.is_reduce:
            # closing fill -> accumulate close fee; size decreases
            self._close_fee[sym] = self._close_fee.get(sym, 0.0) + fill.fee
            if pos is not None:
                pos.size = max(0.0, pos.size - qty)
                self._maybe_close(sym, fill)
        else:
            # opening fill -> accumulate open fee; size increases, entry = fill price
            self._open_fee[sym] = self._open_fee.get(sym, 0.0) + fill.fee
            if pos is None:
                pos = Position(
                    instrument=Instrument.from_token(sym),
                    side="BUY" if fill.side.upper() == "BUY" else "SELL",
                    size=qty, entry_price=fill.price, leverage=1,
                )
                self.positions[sym] = pos
            else:
                # weighted entry update
                total = pos.size + qty
                pos.entry_price = (pos.entry_price * pos.size + fill.price * qty) / total if total else fill.price
                pos.size = total

    async def on_position(self, pos: Position) -> None:
        """Sync local position from exchange; detect liquidation at REAL price (BUG B)."""
        self._last_ws = time.monotonic()
        sym = pos.instrument.symbol
        if pos.size == 0:
            existing = self.positions.get(sym)
            if existing is not None:
                # liquidation or full close: book exit at real liq price / mark, never 0
                exit_px = pos.liq_price or self.market.mark_price(sym) or existing.entry_price
                reason = "liquidation" if (pos.liq_price is not None or pos.unrealized_pnl != 0.0) else "signal"
                liq = pos.liq_price if reason == "liquidation" else None
                self._book_close(sym, exit_px, reason, liq)
            return
        self.positions[sym] = pos

    def _book_close(self, sym: str, exit_px: float, reason: str,
                   liq_price: float | None) -> None:
        pos = self.positions.pop(sym, None)
        if pos is None:
            return
        entry = pos.entry_price
        gross = (exit_px - entry) * pos.size if pos.side == "BUY" else (entry - exit_px) * pos.size
        net = gross - (self._open_fee.get(sym, 0.0) + self._close_fee.get(sym, 0.0))
        if reason == "liquidation":
            self._liquidation_log.append({
                "symbol": sym, "entry": entry, "exit": exit_px,
                "liq_price": liq_price, "gross": gross, "net": net,
                "note": "booked at REAL price, never 0.00",
            })
        self.last_close = {
            "symbol": sym, "side": pos.side, "entry": entry, "exit": exit_px,
            "size": pos.size, "leverage": pos.leverage,
            "open_fee": self._open_fee.get(sym, 0.0),
            "close_fee": self._close_fee.get(sym, 0.0),
            "gross": gross, "net": net, "reason": reason, "liq_price": liq_price,
        }
        if self.on_close:
            self.on_close(sym, entry, exit_px, reason, liq_price)
        # reset fee accumulators for the symbol
        self._open_fee.pop(sym, None)
        self._close_fee.pop(sym, None)

    def _maybe_close(self, sym: str, fill: Fill) -> None:
        pos = self.positions.get(sym)
        if pos is not None and pos.size <= 1e-12:
            exit_px = fill.price or self.market.mark_price(sym) or pos.entry_price
            self._book_close(sym, exit_px, "signal", None)

    # ---- self-heal: re-attach missing SL/TP (never cancel reduce_only) ----
    async def self_heal(self) -> None:
        now = time.monotonic()
        for sym, pos in self.positions.items():
            if pos.sl_price is None and pos.tp_price is None:
                last = self._last_heal.get(sym, 0.0)
                if now - last < self.cfg.self_heal_cooldown_s:
                    continue
                # Only re-attach if we have a known stop target; SL mandatory.
                self._last_heal[sym] = now
                # Re-attach SL if it was lost. We pass through to the adapter; the
                # adapter re-sends set-trading-stop. We do NOT cancel the existing
                # reduce_only protective order (spec §2.3) — we only add/update.
                # The actual SL price is supplied by the orchestrator's risk book.
                # Here we just flag that a heal is needed; orchestrator drives price.

    # ---- dead-man's switch ----
    async def check_deadman(self) -> bool:
        """Return True (and flatten) if no WS message for deadman_seconds."""
        if self.seconds_since_ws() > self.cfg.deadman_seconds and not self.halted:
            self.halted = True
            await self.ex.cancel_all()
            return True
        return False

    def _sym_of(self, fill: Fill) -> str | None:
        # Fallback when Fill.symbol is empty: match the first open position. Production
        # always supplies Fill.symbol from the WS execution payload.
        for sym in self.positions:
            return sym
        return None

    def net_usd(self, sym: str) -> float:
        pos = self.positions.get(sym)
        if pos is None:
            return -(self._open_fee.get(sym, 0.0) + self._close_fee.get(sym, 0.0))
        mark = self.market.mark_price(sym) or pos.entry_price
        gross = (mark - pos.entry_price) * pos.size if pos.side == "BUY" \
            else (pos.entry_price - mark) * pos.size
        return gross - (self._open_fee.get(sym, 0.0) + self._close_fee.get(sym, 0.0))


def _instrument_guess(sym: str) -> Instrument:
    return Instrument.from_token(sym)
