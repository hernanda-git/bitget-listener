"""Order service — Bybit-specific order transforms (spec §12, §13).

Pure builders that turn a decision / management action into ``OrderRequest``(s). The
exchange adapter centralizes symbol/rounding, so every path (entry, manage, close,
cancel) uses these builders and never hand-rolls a request — the guard against the HL
asset-index latent bug and the fork's "string instead of int" cancellation bug.

Management semantics (spec §8, §13):
  * ``sl to entry`` / breakeven -> set-trading-stop SL=entry (never cancel reduce_only).
  * ``tp1 booked`` / partial -> close 50% (reduce_only market) -> SL->entry -> keep TP.
  * ``closed at entry`` / cutting / full -> reduce_only market close (opposite side).
  * ``tp1 <price>`` / ``tp2 <price>`` -> set-trading-stop new TP.
  * NEVER cancel reduce_only protective orders (spec §2.3, §18.5).
"""

from __future__ import annotations

from typing import Literal
from ulid import ULID

from src.domain.model import Instrument, OrderRequest, TradeDecision


def build_entry(decision: TradeDecision, sl: float | None, tp: float | None,
                position_idx: int = 0) -> OrderRequest:
    """Build the entry market order with attached SL/TP (atomic)."""
    sig = decision.signal
    assert sig is not None
    return OrderRequest(
        instrument=sig.instrument,
        side=sig.side,
        order_type="Market",
        qty=decision.size_coin,
        time_in_force="IOC",
        reduce_only=False,
        sl=sl,
        tp=tp,
        tpsl_mode="Full",
        sl_trigger_by="MarkPrice",
        tp_trigger_by="MarkPrice",
        position_idx=position_idx,
        client_order_id="b-" + ULID().hex,
        is_market=True,
    )


def build_sl_to_entry(instrument: Instrument, position_idx: int = 0) -> dict:
    """set-trading-stop payload moving SL to entry. Returns kwargs for the adapter.

    NOTE: the entry price must be passed by the caller (PositionManager knows it).
    """
    return {"sl": None, "tp": None, "to_entry": True, "position_idx": position_idx}


def build_partial_close(instrument: Instrument, current_size: float,
                        position_idx: int = 0) -> OrderRequest:
    """Close 50% of the position via a reduce_only market order (opposite side)."""
    close_side = "SELL"  # default; caller passes the correct opposite side
    return OrderRequest(
        instrument=instrument,
        side=close_side,
        order_type="Market",
        qty=current_size / 2.0,
        time_in_force="IOC",
        reduce_only=True,
        position_idx=position_idx,
        client_order_id="b-" + ULID().hex,
        is_market=True,
    )


def build_full_close(instrument: Instrument, position_idx: int = 0) -> OrderRequest:
    """Full market close (reduce_only). Opposite side chosen by the caller."""
    return OrderRequest(
        instrument=instrument,
        side="SELL",
        order_type="Market",
        qty=0.0,  # caller fills real size
        time_in_force="IOC",
        reduce_only=True,
        position_idx=position_idx,
        client_order_id="b-" + ULID().hex,
        is_market=True,
    )


def opposite_side(side: Literal["BUY", "SELL"]) -> Literal["BUY", "SELL"]:
    return "SELL" if side == "BUY" else "BUY"
