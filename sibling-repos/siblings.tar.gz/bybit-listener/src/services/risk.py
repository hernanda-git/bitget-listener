"""Fee-aware risk / size manager (spec §11, §2.1).

Computes coin size + effective leverage from a USD risk budget and the entry/SL
distance, applying the portfolio + leverage caps and a fee estimate. This closes BUG A
(fees known up front) and BUG B (no liquidation math depends on a 0.00 price).

PnL contract everywhere: ``net_usd = gross_usd - (open_fee + close_fee)``.
"""

from __future__ import annotations

from dataclasses import dataclass

from src.domain.model import Signal
from src.interfaces.ports import RiskPolicy


@dataclass
class RiskConfig:
    risk_pct: float = 0.10           # fraction of margin risked per trade ($1*10% = $0.10)
    default_leverage: int = 3
    max_leverage: int = 20
    max_notional_usd: float = 50.0
    default_margin_usd: float = 1.0
    fee_bps_round_trip: float = 0.055 * 2  # taker open + taker close (~0.11%)


class FixedRiskSizer(RiskPolicy):
    """Fee-aware fixed-fractional risk sizer (implements RiskPolicy)."""

    def __init__(self, cfg: RiskConfig | None = None) -> None:
        self.cfg = cfg or RiskConfig()

    def compute_size(self, notional_usd: float, mark_price: float,
                     max_leverage: int) -> tuple[float, int]:
        """Return (coin_size, effective_leverage).

        ``notional_usd`` is the margin/risk budget. Effective leverage is clamped to
        ``[1, min(default_leverage, max_leverage)]``. Coin size = notional / mark.
        """
        lev = max(1, min(self.cfg.default_leverage, max_leverage))
        # Notional here is the position notional budget (margin already sized small).
        notional = min(notional_usd, self.cfg.max_notional_usd)
        if mark_price <= 0:
            return 0.0, lev
        size = notional / mark_price
        return size, lev

    def fee_estimate(self, notional_usd: float) -> float:
        """Estimated round-trip fee in USD for a given notional (BUG A awareness)."""
        return notional_usd * self.cfg.fee_bps_round_trip / 100.0

    def size_from_risk(self, signal: Signal, mark_price: float,
                       available_usd: float) -> tuple[float, int, float]:
        """Full fee-aware sizing from a Signal.

        Returns (size_coin, leverage, est_round_trip_fee_usd). Rejects (0, lev, fee)
        if the SL distance is missing/zero (cannot size a bounded-risk trade).
        """
        if signal.sl is None or signal.entry is None:
            # Cannot size without a stop; caller must escalate/ignore.
            lev = min(self.cfg.default_leverage, max(1, signal.leverage))
            return 0.0, lev, 0.0
        risk_usd = self.cfg.default_margin_usd * self.cfg.risk_pct
        sl_distance_frac = abs(signal.entry - signal.sl) / signal.entry
        if sl_distance_frac <= 0:
            lev = min(self.cfg.default_leverage, max(1, signal.leverage))
            return 0.0, lev, 0.0
        size_usd = min(
            risk_usd / sl_distance_frac,
            self.cfg.max_notional_usd,
            available_usd * 0.95,
        )
        lev = min(self.cfg.default_leverage, max(1, signal.leverage), self.cfg.max_leverage)
        size_coin = size_usd / (signal.entry or mark_price)
        fee = self.fee_estimate(size_usd)
        # Margin sanity: size_usd / leverage <= available
        margin_needed = size_usd / lev
        if margin_needed > available_usd:
            size_usd = available_usd * lev
            size_coin = size_usd / (signal.entry or mark_price)
            fee = self.fee_estimate(size_usd)
        return size_coin, lev, fee
