"""Signal normalization + StablecoinPegGuard (spec §9).

Bybit is USDT-settled and the channel is USDT -> ``usdt_price = usdt_price * peg``
with ``peg = 1.0`` default. The guard rejects ``|peg - 1| > 0.005`` (0.5%). This
satisfies "handled in one place" and is future-proof if a USDC venue is added later.
"""

from __future__ import annotations

from dataclasses import dataclass

from src.domain.model import RawSignal, Signal
from src.interfaces.ports import PegSource


@dataclass
class ConstantPegSource(PegSource):
    """Default peg source: a constant 1.0 (USDT->USDT). Guard stays active."""

    rate: float = 1.0

    async def peg_rate(self) -> float:
        return self.rate


class StablecoinPegGuardError(ValueError):
    pass


class SignalNormalizer:
    """Converts a RawSignal (USDT) into an execution-ready Signal (USDT, peg-guarded)."""

    def __init__(self, peg: PegSource | None = None, tol: float = 0.005) -> None:
        self.peg = peg or ConstantPegSource(1.0)
        self.tol = tol

    async def normalize(self, raw: RawSignal) -> Signal:
        rate = await self.peg.peg_rate()
        if abs(rate - 1.0) > self.tol:
            # Bybit is USDT; a depeg beyond tolerance means the invariant broke.
            raise StablecoinPegGuardError(
                f"USDT peg {rate} outside tolerance {self.tol}; refusing to normalize"
            )
        from src.domain.model import Instrument
        inst = Instrument(
            symbol=raw.symbol_usdt or (raw.base + "USDT" if raw.base else ""),
            base=raw.base, quote="USDT", venue="bybit",
        )
        # peg is 1.0, so USDT prices pass through unchanged (guard only).
        return Signal(
            instrument=inst,
            side=raw.side,
            entry=raw.entry,
            sl=raw.sl,
            tp=raw.tp,
            notional_usd=raw.notional_usd,
            leverage=raw.leverage,
            confidence=raw.confidence,
            raw=raw.raw,
            source=raw.source,
            message_id=raw.message_id,
            ts_ms=raw.ts_ms,
            peg_rate=rate,
        )
