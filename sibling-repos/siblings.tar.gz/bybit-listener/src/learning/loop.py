"""Learning loop — drift detection + param rotation (spec §8, §12.7).

Per-close fee-adjusted outcome feeds param_log/strategy_perf. This module detects
expectancy DRIFT vs the baseline and PROPOSES a param rotation (leverage cap, size %,
reflexivity tilt). CRITICAL: any auto-change is GATED behind confirmation (spec §2.7,
§18) — the loop writes a proposal with `confirmed=False` and never mutates live sizing
until a human confirms. This is the guard against the YOLO auto-tune trap both parents
avoided by never building the loop at all.

Pure logic over an in-memory window + the EvalWriter for persistence. No network.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field


@dataclass
class Baseline:
    expectancy_net_usd: float = 0.0   # rolling baseline fee-adjusted expectancy
    win_rate: float = 0.0
    sample: int = 0


@dataclass
class ParamProposal:
    leverage_cap: int
    size_pct: float
    reflexivity_tilt: float
    reason: str
    confirmed: bool = False


class LearningLoop:
    def __init__(self, baseline: Baseline | None = None,
                 drift_threshold: float = 0.3, min_samples: int = 10) -> None:
        self.baseline = baseline or Baseline()
        self.drift_threshold = drift_threshold
        self.min_samples = min_samples
        self._net: list[float] = []
        self._wins: list[bool] = []
        self._proposals: list[ParamProposal] = []

    def record_close(self, net_usd: float, won: bool) -> None:
        """Feed a fee-adjusted close outcome."""
        self._net.append(net_usd)
        self._wins.append(won)
        if len(self._net) >= self.min_samples:
            self.baseline.expectancy_net_usd = sum(self._net) / len(self._net)
            self.baseline.win_rate = sum(1 for w in self._wins if w) / len(self._wins)
            self.baseline.sample = len(self._net)

    def detect_drift(self) -> float:
        """Return drift magnitude = (recent_window_mean - baseline) / |baseline|.

        Positive = improving, negative = decaying. Only meaningful after min_samples.
        """
        if len(self._net) < self.min_samples or self.baseline.sample == 0:
            return 0.0
        recent = self._net[-self.min_samples:]
        recent_mean = sum(recent) / len(recent)
        base = self.baseline.expectancy_net_usd
        if abs(base) < 1e-9:
            return 0.0
        return (recent_mean - base) / abs(base)

    def propose(self, current_leverage_cap: int, current_size_pct: float,
                current_tilt: float) -> ParamProposal | None:
        """Propose a param rotation if drift exceeds threshold. NEVER auto-applies.

        Decaying expectancy -> tighten leverage cap + size. Improving -> hold.
        Returns a proposal (confirmed=False) or None.
        """
        drift = self.detect_drift()
        if abs(drift) < self.drift_threshold:
            return None
        if drift < 0:
            new_lev = max(1, current_leverage_cap - 1)
            new_size = max(0.01, current_size_pct * 0.8)
            reason = f"expectancy drift {drift:.2f} < 0: tighten leverage/size"
            prop = ParamProposal(leverage_cap=new_lev, size_pct=new_size,
                                 reflexivity_tilt=current_tilt, reason=reason)
        else:
            prop = ParamProposal(leverage_cap=current_leverage_cap, size_pct=current_size_pct,
                                 reflexivity_tilt=current_tilt,
                                 reason=f"expectancy drift {drift:.2f} > 0: hold")
        self._proposals.append(prop)
        return prop

    def confirm(self, proposal: ParamProposal) -> ParamProposal:
        """Human confirmation gate (spec §2.7). Marks the proposal applied."""
        proposal.confirmed = True
        return proposal

    @property
    def pending(self) -> list[ParamProposal]:
        return [p for p in self._proposals if not p.confirmed]
